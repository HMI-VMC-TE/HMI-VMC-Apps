To use the GUI version of the RSW tools you need to install two packages: pyside6 and pyqtgraph.

Go to your Simufact Forming installation folder and locate the python.exe: ~\simufact\forming\2024.2\sfForming\python\python.exe

Open a command prompt in this location by right-clicking on an empty space, then select "Open in terminal" (Win11)

Copy this command, paste and hit enter: python.exe -m pip install pyqtgraph==0.13.2 pyside6==6.3.1

# ------
# Run this file from the Simufact Welding python console
# ------
# This script creates a USER ENVIRONMENT VARIABLE
# and the content of the variable should be the
# installation path of Simufact Welding up to version
# similar to "C:\Program Files\Simufact\welding\2021"

import os, subprocess, simufact
installationPath = simufact.welding.get_installation_path()
proc = subprocess.Popen(["setx", "sfWeldingPath", installationPath],
                                  shell=False,
                                  stdout=subprocess.PIPE,
                                  stderr=subprocess.DEVNULL)

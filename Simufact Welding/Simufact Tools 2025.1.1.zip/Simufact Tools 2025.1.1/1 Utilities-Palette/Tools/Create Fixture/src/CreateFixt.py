# coding: utf-8
import apex

def CreateFixture(dict={}):
    from apex.construct import Point3D, Point2D
    from math import sqrt, pow, degrees, acos, pi
    import os
    apex.disableShowOutput()
    apex.setScriptUnitSystem(unitSystemName=r'''mm-kg-s-N''')
    absPath = os.path.dirname(os.path.realpath(__file__))

    #Aux function to calculate distance between two points in [x,y,z]
    def distance(v1,v2):
        return sqrt(((v1[0]-v2[0])**2)+((v1[1]-v2[1])**2)+((v1[2]-v2[2])**2))

        
    #Aux function to find all near solids in a given distance
    def find_near_solids(solids,coord,tol):
        near_solids=apex.entityCollection()
        #declare variables that will be used
        local_orient, local_orig, faceID, local_orient2, local_orig2 = (None,)*5 
        orientation = [] #orientation and origin represent the side of the solid that is closer to the point
        origin = []
        orientation2 = [] #orietation2 and origin 2 represent the opposite side of the plate (we need this to figure out how to create the pair afterwards)
        origin2 = []
        for solid in solids:
            min_dist = 1.0E+10
            for face in solid.getExteriorFaces():
                solid_loc = face.evaluateClosestLocation(coord).getClosestLocation()
                v1 = [solid_loc.x,solid_loc.y,solid_loc.z]
                v2 = [coord.x,coord.y,coord.z]
                dist = distance(v1,v2)
                if dist <= min_dist:
                    #here we assign some temporary variables
                    min_dist = dist
                    #local_orient = apex.Orientation(face.getOrientation().getXAxis(),face.getOrientation().getYAxis(),face.getOrientation().getZAxis())
                    local_orient = face.getOrientation()
                    local_orig = apex.Coordinate(solid_loc.x,solid_loc.y,solid_loc.z)
                    faceID = face.getId()
            #if distance between point and solid face is below the tolerance, we can use it        
            if min_dist <= tol:
                #Since we're below tolerance, we can append the solid, orientation and point in solid to our variables
                near_solids.append(solid)
                orientation.append(local_orient)
                origin.append(local_orig)
                #Logic to figure out the orientation and point in the opposite face
                min_dist2 = 1.0E+10
                for face in solid.getExteriorFaces():
                    if face.getId()!=faceID: #make sure this is not the first used face
                        #below Z1 and Z2 are the normal vectors in the face. Z2 has a negative sign, that is, if Z2 is opposite to Z1 then we found opposite faces
                        z1 = [ round(elem, 2) for elem in [orientation[-1].getZAxis().x,orientation[-1].getZAxis().y,orientation[-1].getZAxis().z]] 
                        z2 = [ round(elem, 2) for elem in [-face.getOrientation().getZAxis().x,-face.getOrientation().getZAxis().y,-face.getOrientation().getZAxis().z]]
                        if z1 == z2:
                            #print("Found opposite face")
                            solid_loc = face.evaluateClosestLocation(coord).getClosestLocation()
                            v1 = [solid_loc.x,solid_loc.y,solid_loc.z]
                            v2 = [origin[-1].x,origin[-1].y,origin[-1].z]
                            dist = distance(v1,v2)
                            #Even though normal are opposite, we need to check the closes face, this way we make sure we found the *closest* opposite face
                            if dist <= min_dist2:# and dist <= tol:
                                #local temparary variables
                                min_dist2 = dist
                                #local_orient2 = apex.Orientation(face.getOrientation().getXAxis(),face.getOrientation().getYAxis(),face.getOrientation().getZAxis())
                                local_orient2 = face.getOrientation()
                                local_orig2 = apex.Coordinate(solid_loc.x,solid_loc.y,solid_loc.z)
                #assign to variables that will be used downstream
                orientation2.append(local_orient2)
                origin2.append(local_orig2)                        
            #print("Distance from point to ", solid.name," : ", min_dist)
        return near_solids, orientation, origin, orientation2, origin2


    def find_nearest_face(solids,coord,tol):
        faces = apex.entityCollection()        
        for solid in solids:
            faces.extend(solid.getExteriorFaces())
        # Get closest face
        for face in faces:
            min_dist = 1.0E+10
            face_loc = face.getCentroid() 
            face_closest= face.evaluateClosestLocation(coord).getClosestLocation()
            v1 = [face_loc.x,face_loc.y,face_loc.z]
            v2 = [coord.x,coord.y,coord.z]
            v3 = [face_closest.x,face_closest.y,face_closest.z]
            dist = distance(v1,v2)
            if dist <= min_dist and dist <= tol:
                min_dist = dist
                near_face = face
                diameter = round(distance(v2,v3),2)*2.0
        return near_face, diameter


    def CreateClampPair(Diameter=10.0):
        model_1 = apex.currentModel()
        tolerance = float(dict["srchDist"])
        #Assembly organization
        try:
            TrajAssy = model_1.getAssembly(pathName="Created Fixture")
        except:
            TrajAssy = model_1.createAssembly(name="Created Fixture")        
        
        #Starting actual code logic
        #Get all visible solids
        solidList = apex.entityCollection()
        for Part in model_1.getParts(True):
            if Part.getVisibility() and "Refinement regions" not in Part.path and "Created Fixture" not in Part.path:
                solidList.extend(Part.getSolids())
        # print(len(solidList))
        #Get selected points
        selection = apex.entityCollection()
        selection.extend(apex.selection.getCurrentSelection())
        #print(len(selection))
        #Iterate over all points
        for sel in selection:
            cylinder_collection = apex.entityCollection() #these are the cylinder created for this specific point
            coordinate = sel.getLocation()
            func_output = find_near_solids(solidList,coordinate,tolerance) #run function
            #Use better names for function output
            near_solids = func_output[0]
            orientation = func_output[1]
            origin = func_output[2]
            orientation2 = func_output[3]
            origin2 = func_output[4]
            #print(len(near_solids),len(orientation),len(origin),len(orientation2),len(origin2))
            #Check if no solids were found
            if len(near_solids) == 0:
                apex.enableShowOutput()
                print('There are no solids near this point')
                continue
            
            #Logic if only a single near solid (it is simpler)
            elif len(near_solids) == 1: 
                if dict["Pair"] == 'False':  #In case you want a cylinder only at the point, this will create it
                    CurrPart = apex.createPart(name="Cylinder_{0}_{1}_mm".format(near_solids[0].getParent().name, Diameter/2))
                    CurrPart.setParent(TrajAssy)
                    cyl1 = apex.geometry.createCylinderByLocationOrientation(
                        name = 'Cylinder',
                        description = '',
                        length = Diameter/2,
                        radius = Diameter/2,
                        sweepangle = 3.600000000000000e+02,
                        origin = origin[0],
                        orientation = orientation[0]
                        ) 
                    cylinder_collection.append(cyl1)
                else:   #In case you want the cylinder pair we just get the locations from the function result
                    CurrPart = apex.createPart(name="Cylinder_{0}_{1}_mm".format(near_solids[0].getParent().name, Diameter/2))
                    CurrPart.setParent(TrajAssy)                
                    cyl1 = apex.geometry.createCylinderByLocationOrientation(
                        name = 'Cylinder',
                        description = '',
                        length = Diameter/2,
                        radius = Diameter/2,
                        sweepangle = 3.600000000000000e+02,
                        origin = origin[0],
                        orientation = orientation[0]
                        ) 
                    cylinder_collection.append(cyl1)
                    try: #try to create the cylinder in opposite face
                        CurrPart = apex.createPart(name="Cylinder_{0}_{1}_mm".format(near_solids[0].getParent().name, Diameter/2))
                        CurrPart.setParent(TrajAssy)                    
                        cyl2 = apex.geometry.createCylinderByLocationOrientation(
                            name = 'Cylinder',
                            description = '',
                            length = Diameter/2,
                            radius = Diameter/2,
                            sweepangle = 3.600000000000000e+02,
                            origin = origin2[0],
                            orientation = orientation2[0]
                            )
                        cylinder_collection.append(cyl2)
                    except:
                        apex.enableShowOutput()
                        print('Error creating one of the clamp pairs')
                        continue
                    
            elif len(near_solids) > 1: #If there is more than one near solid the logic is a bit more complex
                if dict["Pair"] == 'False': #In case you want a cylinder only at the point, this will create it
                    CurrPart = apex.createPart(name="Cylinder_{0}_{1}_mm".format(near_solids[0].getParent().name, Diameter/2))
                    CurrPart.setParent(TrajAssy)                 
                    cyl1 = apex.geometry.createCylinderByLocationOrientation(
                        name = 'Cylinder',
                        description = '',
                        length = Diameter/2,
                        radius = Diameter/2,
                        sweepangle = 3.600000000000000e+02,
                        origin = origin[0],
                        orientation = orientation[0]
                        )
                    cylinder_collection.append(cyl1)
                else:
                    #First cylinder will always be on the reference point
                    CurrPart = apex.createPart(name="Cylinder_{0}_{1}_mm".format(near_solids[0].getParent().name, Diameter/2))
                    CurrPart.setParent(TrajAssy)                 
                    cyl1 = apex.geometry.createCylinderByLocationOrientation(
                        name = 'Cylinder',
                        description = '',
                        length = Diameter/2,
                        radius = Diameter/2,
                        sweepangle = 3.600000000000000e+02,
                        origin = origin[0],
                        orientation = orientation[0]
                        )
                    cylinder_collection.append(cyl1)
                    CurrPart = apex.createPart(name="Cylinder_{0}_{1}_mm".format(near_solids[0].getParent().name, Diameter/2))
                    CurrPart.setParent(TrajAssy)
                    #For second cylinder we need a logic to figure out the other side when you have multiple plates
                    ref_point = [origin[0].x,origin[0].y,origin[0].z] #Reference point will always be the same
                    max_dist = 0.0
                    side1 = True    #Aux variable to check which side the farthes point is located. It should be side 2, but we check both sides just for safety.
                    for i in range(1,len(near_solids)):
                        #First we check the distances between the ref point and firts side of near solids
                        point1 = [origin[i].x,origin[i].y,origin[i].z] 
                        dist = distance(ref_point,point1)
                        if dist > max_dist:
                            max_dist = dist
                            index = i   #Get the index so its easier to create the cylinder afterwards
                        #Then we check the distances between the ref point and opposite side of near solids
                        point2 = [origin2[i].x,origin2[i].y,origin2[i].z] 
                        dist = distance(ref_point,point2)
                        #print(dist,max_dist)
                        if dist > max_dist:
                            max_dist = dist
                            index = i   #Get the index so its easier to create the cylinder afterwards
                            side1 = False
                    #After that we found the furthest point in the near solids from our ref point
                    if side1 == False:
                        cyl2 = apex.geometry.createCylinderByLocationOrientation(
                            name = 'Cylinder',
                            description = '',
                            length = Diameter/2,
                            radius = Diameter/2,
                            sweepangle = 3.600000000000000e+02,
                            origin = origin2[index],
                            orientation = orientation2[0]
                            )
                        cylinder_collection.append(cyl2)
                    else: 
                        cyl2 = apex.geometry.createCylinderByLocationOrientation(
                            name = 'Cylinder',
                            description = '',
                            length = Diameter/2,
                            radius = Diameter/2,
                            sweepangle = 3.600000000000000e+02,
                            origin = origin[index],
                            orientation = orientation[0]
                            )
                        cylinder_collection.append(cyl2)
                        
            
            #Now we round the edges of the created cylinders
            if dict["Round"] == 'True':
                round_edges = apex.entityCollection()
                for solid in cylinder_collection:
                    round_edges.extend(solid.getEdges())
                # try:
                result = apex.geometry.pushPull(
                    target = round_edges,
                    method = apex.geometry.PushPullMethod.Fillet,
                    behavior = apex.geometry.PushPullBehavior.FollowShape,
                    removeInnerLoops = False,
                    createBooleanUnion = False,
                    distance = Diameter/10,
                    direction = [ 7.071067811865475e-01, 7.071067811865475e-01, 0.0 ]
                )
                # except:
                    # apex.enableShowOutput()
                    # print("Rounding failed")   

            #Now we mesh the outside surface of the created cylinders
            if dict["Mesh"] == 'True':
                try:
                    featuremeshtypes_1 = apex.mesh.FeatureMeshTypeVector()
                    result = apex.mesh.createSurfaceMesh(
                        name = "",
                        target = cylinder_collection,
                        meshSize = Diameter/10,
                        meshType = apex.mesh.SurfaceMeshElementShape.Mixed,
                        meshMethod = apex.mesh.SurfaceMeshMethod.Auto,
                        mappedMeshDominanceLevel = 2,
                        elementOrder = apex.mesh.ElementOrder.Linear,
                        allQuadBoundary = False,
                        refineMeshUsingCurvature = False,
                        elementGeometryDeviationRatio = 0.10,
                        elementMinEdgeLengthRatio = 0.20,
                        growFaceMeshSize = False,
                        faceMeshGrowthRatio = 1.2,
                        createFeatureMeshes = False,
                        featureMeshTypes = featuremeshtypes_1,
                        projectMidsideNodesToGeometry = True,
                        useMeshFlowOptimization = True,
                        meshFlow = apex.mesh.MeshFlow.Grid,
                        minimalMesh = False
                    )
                except:
                    apex.enableShowOutput()
                    print("Meshing failed!")
        
    
    def CreateLocatorPin():
        model_1 = apex.currentModel()
        tolerance = float(dict["srchDist"])
        #Assembly organization
        try:
            TrajAssy = model_1.getAssembly(pathName="Created Fixture")
        except:
            TrajAssy = model_1.createAssembly(name="Created Fixture")
        
        #Starting actual code logic
        #Get all visible solids
        solidList = apex.entityCollection()
        for Part in model_1.getParts(True):
            if Part.getVisibility() and "Refinement regions" not in Part.path and "Created Fixture" not in Part.path:
                solidList.extend(Part.getSolids())

        #Get selected points
        selection = apex.entityCollection()
        selection.extend(apex.selection.getCurrentSelection())

        #Iterate over all points
        for sel in selection:
            cylinder_collection = apex.entityCollection()
            coordinate = sel.getLocation()
            returned = find_nearest_face(solidList,coordinate,tolerance) #run function
            near_face =  returned[0]
            Diameter = returned[1]
            #near_face.highlight(apex.ColorRGB(200,0,0),lineWidth=2,pointSize=3)
            #near_face.clearHighlight()
            #print(near_face.getArea())
            # p1 = [near_face.getCylindricalAxisStartPoint().x,near_face.getCylindricalAxisStartPoint().y,near_face.getCylindricalAxisStartPoint().z]
            # p2 = [near_face.getCylindricalAxisEndPoint().x,near_face.getCylindricalAxisEndPoint().y,near_face.getCylindricalAxisEndPoint().z]
            # vec = apex.construct.Vector3D(p2[0]-p1[0],p2[1]-p1[1],p2[2]-p1[2])
            vec = [near_face.getCylindricalAxis().x,near_face.getCylindricalAxis().y,near_face.getCylindricalAxis().z]
            orientation = apex.Orientation(zAxis = near_face.getCylindricalAxis())
            CurrPart = apex.createPart(name=f"Locator_Pin")
            CurrPart.setParent(TrajAssy)
            cyl1 = apex.geometry.createCylinderByLocationOrientation(
                name = 'Cylinder',
                description = '',
                length = Diameter*4.0,
                radius = Diameter/2.0,
                sweepangle = 3.600000000000000e+02,
                origin = near_face.getCylindricalAxisMidPoint(),
                orientation = orientation) 
            cylinder_collection.append(cyl1) 
            
            _target = apex.EntityCollection()
            _target.append(cyl1)
            cyl1 = apex.transformTranslate(
                target=_target,
                direction=[-vec[0],-vec[1],-vec[2]],
                distance=Diameter*2.0,
                makeCopy=False
            )            
        

            #Now we round the edges of the created cylinders
            if dict["Round"] == 'True':
                round_edges = apex.entityCollection()
                for solid in cylinder_collection:
                    round_edges.extend(solid.getEdges())
                result = apex.geometry.pushPull(
                    target = round_edges,
                    method = apex.geometry.PushPullMethod.Fillet,
                    behavior = apex.geometry.PushPullBehavior.FollowShape,
                    removeInnerLoops = False,
                    createBooleanUnion = False,
                    distance = Diameter/10,
                    direction = [ 7.071067811865475e-01, 7.071067811865475e-01, 0.0 ]
                )        
            
            
            #Now we mesh the outside surface of the created cylinders
            if dict["Mesh"] == 'True':
                try:
                    featuremeshtypes_1 = apex.mesh.FeatureMeshTypeVector()
                    result = apex.mesh.createSurfaceMesh(
                        name = "",
                        target = cylinder_collection,
                        meshSize = Diameter/10,
                        meshType = apex.mesh.SurfaceMeshElementShape.Mixed,
                        meshMethod = apex.mesh.SurfaceMeshMethod.Auto,
                        mappedMeshDominanceLevel = 2,
                        elementOrder = apex.mesh.ElementOrder.Linear,
                        allQuadBoundary = False,
                        refineMeshUsingCurvature = False,
                        elementGeometryDeviationRatio = 0.10,
                        elementMinEdgeLengthRatio = 0.20,
                        growFaceMeshSize = False,
                        faceMeshGrowthRatio = 1.2,
                        createFeatureMeshes = False,
                        featureMeshTypes = featuremeshtypes_1,
                        projectMidsideNodesToGeometry = True,
                        useMeshFlowOptimization = True,
                        meshFlow = apex.mesh.MeshFlow.Grid,
                        minimalMesh = False
                    )
                except:
                    apex.enableShowOutput()
                    print("Meshing failed!")            

        
    #Now we actually run the code!
    if dict["Type"] == "Clamping Pair":
        diam=float(dict["cylDiameter"])
        CreateClampPair(diam)
    else:
        diam=float(dict["cylDiameter"])
        CreateLocatorPin()
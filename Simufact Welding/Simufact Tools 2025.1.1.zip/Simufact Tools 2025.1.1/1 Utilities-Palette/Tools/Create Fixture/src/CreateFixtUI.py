import sys
import os
import apex_sdk
import clr


#.NET references
import System
import System.Windows.Controls as WPFControls
from System.Windows.Automation import AutomationProperties
from Microsoft.Win32 import OpenFileDialog

dictionary = {}
current_file_path = os.path.dirname(os.path.realpath(__file__))

#setting pre-defined properties of tool_propertyContainer
def getUIContent():

   my_toolProperty = apex_sdk.ToolPropertyContainer()
   my_toolProperty.ToolPropertyContent = getCustomToolPropertyContent()
   my_toolProperty.TitleText = "  Create fixture   "
   my_toolProperty.TitleImageUriString = os.path.join(os.path.dirname(current_file_path), r"res\clamp 4.png")
   my_toolProperty.WorkFlowInstructions = ''' 
    <p><strong><span style="color: #999999;">Create Simplified Fixture<br /></span></strong></p>
    <p><span style="color: #999999;">Description: This tool automatically creates fixture geometries based on user options.<br /></span></p>
    <ul>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Type of fixture</span>: Select either clamping pair or locator pin. Works on visible solids.<br /></span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Cylinder diameter (mm)</span>: Size of the cylinder that will be created for the clamp/bearing pair. Available only for clamp pairs. For locator pin, diameter is automatically recognized.<br /></span></li>   
    <li><span style="color: #999999;"><span style="color: #00ccff;">Search distance (mm)</span>: How far other entities will be searched for. Default value is usually good.<br /></span></li>    
    <li><span style="color: #999999;"><span style="color: #00ccff;">Create pair</span>: Controls if a single cylinder will be created, or a pair. Available only for clamoing pairs.<br /></span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Round edges</span>: Controls if edges of cylinder will be rounded. Fillet radius is 1/5 of cylinder diemeter.<br /></span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Create mesh</span>: Controls if a mesh will be created for the geometries. Mesh size is 1/5 of the cylinder diameter.<br /></span></li>
    </ul>
    <p><span style="color: #999999;">Workflow:</span></p>
    <ol>
    <li><span style="color: #999999;">Create points in the locations of the clamps using "Points" tool in the Geometry Edit Tools menu or other method<br /></span></li>
    <li><span style="color: #999999;">Select the points or vertices<br /></span></li>
    <li><span style="color: #999999;">Select the type of fixture<br /></span></li>
    <li><span style="color: #999999;">For clamping pair, select the diameter of the cylinder in mm<br /></span></li>
    <li><span style="color: #999999;">Select appropriate options<br /></span></li>
    <li><span style="color: #999999;">Click "Create fixture"<br /></span></li>
    </ol>
    <p><span style="color: #999999;">For support: <a href="mailto:support.americas@simufact.com" style="color: #999999;"><span style="color: #ff0000;">support.americas@simufact.com</span></a></span></p>
    <p><span style="color: #999999;"><span style="color: #ff0000;"></span></span></p>
    '''
   # Define PickFilterList
   my_toolProperty.ShowPickChoice = True
   my_toolProperty.IsCustomTool = True                                   
   my_toolProperty.PickFilterList = setPickFilterList()
   return my_toolProperty
   
# Set PickFilters
def setPickFilterList():
    # Create an empty List of strings
    pickChoices = System.Collections.Generic.List[System.String]()

    # Exclusive picking and visibility picking
    pickChoices.Add(apex_sdk.PickFilterTypes.ExclusivePicking)
    pickChoices.Add(apex_sdk.PickFilterTypes.VisibilityPicking)

    # Add Types
    pickChoices.Add(apex_sdk.PickFilterTypes.Point)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Vertex)

    # Return the pick filter list
    return pickChoices


#get tool property content
def getCustomToolPropertyContent():
    global my_toolProperty
    #Create a Grid
    my_Grid = WPFControls.Grid()
    #Add 2 Rows and 1 Column
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())
    my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())    
   
     
    # Type of model
    modelType = WPFControls.TextBlock()
    modelType.Text = "Type of fixture:"
    WPFControls.Grid.SetRow(modelType, 1)
    WPFControls.Grid.SetColumn(modelType, 0)
    my_Grid.Children.Add(modelType)

    # Create a Combo box
    global modelTypeSelection
    modelTypeSelection = WPFControls.ComboBox()
    
    item1 = WPFControls.ComboBoxItem()
    item1.Content = "Clamping Pair"
    modelTypeSelection.Items.Add(item1)
    
    item2 = WPFControls.ComboBoxItem()
    item2.Content = "Locator Pin"
    modelTypeSelection.Items.Add(item2)
    
    modelTypeSelection.SelectedIndex = 0
    WPFControls.Grid.SetRow(modelTypeSelection, 1)
    WPFControls.Grid.SetColumn(modelTypeSelection, 1)
    my_Grid.Children.Add(modelTypeSelection)
    
    global sizeLbl
    sizeLbl = WPFControls.TextBlock()
    sizeLbl.Text = " Diameter (mm):      "
    WPFControls.Grid.SetRow(sizeLbl, 2)
    WPFControls.Grid.SetColumn(sizeLbl, 0)
    my_Grid.Children.Add(sizeLbl)

    # Create an empty input TextBox assign it to Row 0, Column 1
    global sizeVal
    sizeVal = WPFControls.TextBox()
    WPFControls.Grid.SetRow(sizeVal, 2)
    WPFControls.Grid.SetColumn(sizeVal, 2)
    sizeVal.Text = "15.0"
    my_Grid.Children.Add(sizeVal)

    srchLbl = WPFControls.TextBlock()
    srchLbl.Text = " Search distance (mm):      "
    WPFControls.Grid.SetRow(srchLbl, 3)
    WPFControls.Grid.SetColumn(srchLbl, 0)
    my_Grid.Children.Add(srchLbl)

    # Create an empty input TextBox assign it to Row 0, Column 1
    global srchVal
    srchVal = WPFControls.TextBox()
    WPFControls.Grid.SetRow(srchVal, 3)
    WPFControls.Grid.SetColumn(srchVal, 2)
    srchVal.Text = "30.0"
    my_Grid.Children.Add(srchVal)
    
    # Create checkbox
    global chk01
    chk01 = WPFControls.CheckBox()
    chk01.Content = "Create pair"
    chk01.Height = 20
    WPFControls.Grid.SetRow(chk01, 4)
    WPFControls.Grid.SetColumn(chk01, 1)
    WPFControls.Grid.SetColumnSpan(chk01, 1)
    chk01.IsChecked = System.Nullable[System.Boolean](True)
    my_Grid.Children.Add(chk01)
    
    # Create checkbox
    global chk02
    chk02 = WPFControls.CheckBox()
    chk02.Content = "Round edges"
    chk02.Height = 20
    WPFControls.Grid.SetRow(chk02, 4)
    WPFControls.Grid.SetColumn(chk02, 0)
    WPFControls.Grid.SetColumnSpan(chk02, 1)
    chk02.IsChecked = System.Nullable[System.Boolean](True)
    my_Grid.Children.Add(chk02)
    
    # Create checkbox
    global chk03
    chk03 = WPFControls.CheckBox()
    chk03.Content = "Create mesh"
    chk03.Height = 20
    WPFControls.Grid.SetRow(chk03, 5)
    WPFControls.Grid.SetColumn(chk03, 0)
    WPFControls.Grid.SetColumnSpan(chk03, 1)
    chk03.IsChecked = System.Nullable[System.Boolean](True)
    my_Grid.Children.Add(chk03)
    
    #Create button to do the simplification
    fixtBtn = WPFControls.Button()
    fixtBtn.Content = "Create fixture"
    WPFControls.Grid.SetRow(fixtBtn, 6)
    WPFControls.Grid.SetColumn(fixtBtn, 0)
    WPFControls.Grid.SetColumnSpan(fixtBtn, 3)
    fixtBtn.Height = 30
    fixtBtn.Click += HandleCreateFixt
    my_Grid.Children.Add(fixtBtn)
    
    #Setup pick filters
    if modelTypeSelection.Text == "Clamping Pair":
        chk01.Visibility = System.Windows.Visibility.Visible
        sizeLbl.Visibility = System.Windows.Visibility.Visible
        sizeVal.Visibility = System.Windows.Visibility.Visible        
    else:
        chk01.Visibility = System.Windows.Visibility.Collapsed
        sizeLbl.Visibility = System.Windows.Visibility.Collapsed
        sizeVal.Visibility = System.Windows.Visibility.Collapsed
        
    modelTypeSelection.SelectionChanged += handleChange    
    
        
    #Return the Grid
    return my_Grid

    
#user defined button clickHandlers
@apex_sdk.errorhandler
def HandleCreateFixt(sender, args):
   dictionary["cylDiameter"]= sizeVal.Text  
   dictionary["srchDist"]= srchVal.Text
   dictionary["Pair"] = chk01.IsChecked
   dictionary["Round"] = chk02.IsChecked
   dictionary["Mesh"] = chk03.IsChecked
   dictionary["Type"] = modelTypeSelection.Text
   file_path = os.path.dirname(os.path.realpath(__file__))
   script_path= os.path.join(file_path, 'CreateFixt.py')
   apex_sdk.runScriptFunction(script_path, "CreateFixture", dictionary)
   
@apex_sdk.errorhandler
def handleChange(sender, event):
    global my_Grid, modelTypeSelection, chk01, sizeLbl, sizeVal
    #For some reason this logic is inverted, but it works....
    if modelTypeSelection.Text == "Clamping Pair":
        chk01.Visibility = System.Windows.Visibility.Collapsed
        sizeVal.Visibility = System.Windows.Visibility.Collapsed
        sizeLbl.Visibility = System.Windows.Visibility.Collapsed
    else:
        chk01.Visibility = System.Windows.Visibility.Visible 
        sizeLbl.Visibility = System.Windows.Visibility.Visible
        sizeVal.Visibility = System.Windows.Visibility.Visible          
    return my_toolProperty   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
 
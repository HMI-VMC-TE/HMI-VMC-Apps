# coding: utf-8

import apex
from apex.construct import Point3D, Point2D

apex.setScriptUnitSystem(unitSystemName=r'''mm-kg-s-N''')
apex.disableShowOutput()


def ExpandSplit(dict={}):
    try:
        distance = float(dict["distance"])
    except ValueError:
        apex.enableShowOutput()
        print("Non-numeric input for distance, must be a number!")
        raise
    
    assemblies = apex.EntityCollection()
    parts = apex.EntityCollection()
    solids = apex.EntityCollection()
    for item in apex.selection.getCurrentSelection():
        if item.entityType == apex.EntityType.Assembly:
            assemblies.append(item)
        if item.entityType == apex.EntityType.Part:
            parts.append(item)
        if item.entityType == apex.EntityType.Solid:
            solids.append(item)

    model_1 = apex.currentModel()
    SelectedAssyName = ""
    _splitter = apex.EntityCollection()
    for Assembly in assemblies:
        SelectedAssyName += Assembly.getName()
        for Part in Assembly.getParts(True):
            for Solid in Part.getSolids():
                for Face in Solid.getFaces():
                    _splitter.append(Face)
    
    SelectedPartName = ""
    for Part in parts:
        SelectedPartName += Part.getName()
        for Solid in Part.getSolids():
            for Face in Solid.getFaces():
                _splitter.append(Face)   

    SelectedSolidName = ""
    for Solid in solids:
        SelectedSolidName += Solid.getName()
        for Face in Solid.getFaces():
            _splitter.append(Face)  

    if dict["splitSolids"] == 'True':
        includeSolid = True
    else:
        includeSolid = False
    if dict["splitSurfaces"] == 'True':
        includeSurface = True
    else:
        includeSurface = False

    _target = apex.EntityCollection()
    for Part in model_1.getParts(True):
        solid_part = False
        if Part.getPathName() not in SelectedAssyName and Part.getName() not in SelectedPartName:
            for solid in Part.getSolids():
                if solid.getName() in SelectedSolidName:
                    solid_part = True
            if Part.getVisibility() and not solid_part:
                if includeSolid:
                    for Solid in Part.getSolids():
                        if Solid.getVisibility():
                            _target.append(Solid)
                if includeSurface:
                    for Surface in Part.getSurfaces():
                        if Surface.getVisibility():
                            _target.append(Surface)

    try:
        result = apex.geometry.splitEntityWithOffsetFaces(
            target=_target,
            splitter=_splitter,
            offset= (-1.0 * distance), # Negative value to make it expand outwards, it does inwards otherwise
            splitBehavior=apex.geometry.GeometrySplitBehavior.Partition
        )
    except:
        print("Split failed, try using the Apex builtin tool instead. It is under partitioning, using offset.")
        apex.enableShowOutput()

    if dict["suppressVertices"] == 'True':
        _target = apex.EntityCollection()
        for Part in model_1.getParts(True):
            if SelectedAssyName not in Part.getPathName() or SelectedPartName not in Part.getName():
                for Surface in Part.getSurfaces():
                    if Surface.getVisibility():
                        _target.extend(Surface.getVertices())
        try:
            result = apex.geometry.suppressOnly(
                target=_target,
                maxEdgeAngle=1.000000000000000e+01,
                maxFaceAngle=5.000000000000000,
                keepVerticesAtCurvatureChange=False,
                cleanupTol=1.000000000000000,
                forceSuppress=False
            )
        except:
            apex.enableShowOutput()
            raise

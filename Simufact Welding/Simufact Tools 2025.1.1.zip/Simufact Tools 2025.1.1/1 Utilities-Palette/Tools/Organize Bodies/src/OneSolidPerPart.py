import apex
from apex.construct import Point3D, Point2D
import re
apex.disableShowOutput()

def OrganizeSolids(dict={}):
    #===================================================================
    ## Initializing Apex code
    apex.setScriptUnitSystem(unitSystemName = r'''mm-kg-s-N''')
    numOfSolidsChanged = 0
    for Part in apex.currentModel().getParts(recursive = True):
        if dict["separateSurface"] == 'True':
            if len(Part.getSurfaces()) > 0:
                for Surface in Part.getSurfaces()[1:]:
                    if Surface.getVisibility():
                        if dict["useSolidName"] == 'True':
                            try:
                                newPart = Part.getParent().createPart(name = re.sub('\W+',' ',Surface.getName()) + "_surf")
                            except:
                                newPart = Part.getParent().createPart(name = re.sub('\W+',' ', Surface.getParent().getName()) + "_surf")
                            Surface.setParent(newPart)
                            numOfSolidsChanged += 1
                        else:
                            newPart = Part.getParent().createPart(name = re.sub('\W+',' ', Surface.getParent().getName()) + "_surf")
                            Surface.setParent(newPart)
                            numOfSolidsChanged += 1
        if len(Part.getSolids()) > 0:
            for Solid in Part.getSolids()[1:]:
                if Solid.getVisibility():
                    if dict["useSolidName"] == 'True':
                        try:
                            newPart = Part.getParent().createPart(name = re.sub('\W+',' ', Solid.getName()) + "_solid")
                        except:
                            newPart = Part.getParent().createPart(name = re.sub('\W+',' ', Solid.getParent().getName()) + "_solid")
                        Solid.setParent(newPart)
                        numOfSolidsChanged += 1
                    else:
                        newPart = Part.getParent().createPart(name = re.sub('\W+',' ', Solid.getParent().getName()) + "_solid")
                        Solid.setParent(newPart)
                        numOfSolidsChanged += 1
        # if len(Part.getMeshes()) > 1:
            # for Mesh in Part.getMeshes():    
                # try:
                    # newPart = Part.getParent().createPart(name = re.sub('\W+',' ',Mesh.getName()) + "_mesh")
                # except:
                    # newPart = Part.getParent().createPart(name = re.sub('\W+',' ', Mesh.getParent().getName()) + "_mesh")
                # Mesh.setParent(newPart)
                # numOfSolidsChanged += 1
        print("Reorganized {0} solids.".format(numOfSolidsChanged))
                

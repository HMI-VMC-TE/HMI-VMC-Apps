# coding: utf-8
import apex, os
from apex.construct import Point3D, Point2D
from time import perf_counter
# 
# Start of recorded operations
# 

def find_near_surf(surfaces,point):
    near_surfs=apex.entityCollection()
    mySearch = apex.utility.ProximitySearch()
    iSurfs = apex.IPhysicalCollection()
    for data in surfaces:
        entType = data.getEntityType()
        if entType == apex.EntityType.Face:            
            iSurfs.append(data.asEntity())             
    mySearch.insertCollection(iSurfs)                          							#add surfaces as search target
    loc = point.getLocation()                   									#get point location and coordinates
    near_surfs = (mySearch.findNearestObjects(loc,numObjects=1).foundObjects())    #return surfaces near to this point location
    return near_surfs
    
def createReport(dict={}):
    t1_start = perf_counter()
    #Initializing
    apex.disableShowOutput()
    model_1 = apex.currentModel()
    apex.setScriptUnitSystem(unitSystemName = r'''mm-kg-s-N''')
    distTolerance = float(dict["searchDistance"])
    rswTolerance = float(dict["maxThick"])
    dirToSave = dict["saveToDir"]
    entityList=apex.EntityCollection()
    listOfRefSolid = []
    listOfRefSolidPaths = []
    listOfUsedSolidPairs = []
    listOfPoints = []
    
    #Gathering selected items
    for selElem in apex.selection.getCurrentSelection():
        if selElem.entityType == apex.EntityType.Assembly:
            for Part in selElem.getParts(True):
                for Solid in Part.getSolids():
                    listOfRefSolidPaths.append(Solid.getPathName())
                    listOfRefSolid.append(Solid)
        elif selElem.entityType == apex.EntityType.Part:
            for Solid in selElem.getSolids():
                listOfRefSolidPaths.append(Solid.getPathName())
                listOfRefSolid.append(Solid)
        elif selElem.entityType == apex.EntityType.Point:
            listOfPoints.append(selElem)
                
        for Part in model_1.getParts(True):
            for Solid in Part.getSolids():
                if Solid.getPathName() in listOfRefSolidPaths and Solid not in entityList:
                    entityList.append(Solid)
                    
    if dict["jointType"] == "Sheet Metal Arc Welding":
        report_lines = "Part 1;Part 2;Thick 1;Thick 2; Gap; Type\n"
        for refSolid in listOfRefSolid:
            distance_ = apex.measureDistance(source=refSolid,target=entityList)
            #print(distance_)
            apex.display.enableGraphicRefresh = False
            mids_exist = False
            for k in range(len(distance_)):
                if distance_[k] <= distTolerance and refSolid != entityList[k] and refSolid.parent.name != entityList[k].parent.name:
                    solid1 = refSolid
                    solid2 = entityList[k]
                    gap = round(distance_[k],2)
                    if f"{solid1.getPathName()}+{solid2.getPathName()}" not in listOfUsedSolidPairs and f"{solid2.getPathName()}+{solid1.getPathName()}" not in listOfUsedSolidPairs:
                        if len(solid1.parent.surfaces)>=1 and len(solid2.parent.surfaces)>=1:
                            if len(solid1.parent.surfaces[0].getMeshes()) >= 1 and  len(solid2.parent.surfaces[0].getMeshes()) >= 1:
                                mid1 = solid1.parent.surfaces[0]
                                mid2 = solid2.parent.surfaces[0]
                                nthickness1 = round(solid1.parent.surfaces[0].getMeshes()[0].getElements()[0].getThickness(),2)
                                nthickness2 = round(solid2.parent.surfaces[0].getMeshes()[0].getElements()[0].getThickness(),2)
                                mids_exist = True
                                # print(nthickness1,nthickness2)
                                if nthickness1 == 0.0 or nthickness2 == 0.0:
                                    apex.enableShowOutput()
                                    print("No thickness assigned to mid! Make sure to apply and re-run the code")
                                    continue
                        else:
                            #Get midsurface 1
                            _target = apex.entityCollection()
                            _target.append(solid1)
                            sections = []
                            A_old = apex.attribute.getFieldDictionary()
                            mid1 = apex.geometry.assignConstantThicknessMidSurface(
                                target=_target,
                                autoAssignThickness=True,
                                autoAssignTolerance=5.0e-02
                            )
                            A_new = apex.attribute.getFieldDictionary()
                            new_thickness1 = { k : A_new[k] for k in set(A_new) - set(A_old) }
                            for key,value in new_thickness1.items():
                                nthickness1 = round(apex.attribute.getDiscreteFEMField(pathName = apex.currentModel().name + "/Fields/" + key).thickness,2)
                                sections.append(key)
                            #Get Midsurface2   
                            _target = apex.entityCollection()
                            _target.append(solid2)
                            A_old = apex.attribute.getFieldDictionary()
                            mid2 = apex.geometry.assignConstantThicknessMidSurface(
                                target=_target,
                                autoAssignThickness=True,
                                autoAssignTolerance=5.0e-02
                            )
                            A_new = apex.attribute.getFieldDictionary()
                            new_thickness2 = { k : A_new[k] for k in set(A_new) - set(A_old) }
                            for key,value in new_thickness2.items():
                                nthickness2 = round(apex.attribute.getDiscreteFEMField(pathName = apex.currentModel().name + "/Fields/" + key).thickness,2)
                                sections.append(key)
                                
                        #simple logic to try and guess the joint type
                        joint_tol = distTolerance/2 #mm      
                        if mid1 and mid2:
                            if not mids_exist:
                                mid_dist = round(apex.measureDistance(source=mid1[0],target=mid2)[0],2)
                            else:
                                loc_collection = apex.ILocationCollection()
                                loc_collection.append(mid2)
                                mid_dist = round(apex.measureDistance(source=mid1,target=loc_collection)[0],2)
                        else:
                            apex.enableShowOutput()
                            print("\n***Warning: Some midsurfaces might have not been generated***\n")
                            continue
                        # print("Mid Dist: ",mid_dist,"Gap: ", gap)
                        # print("Check 1:",abs(mid_dist-(0.5*nthickness1+0.5*nthickness2+gap)))
                        # print("Check 2:",abs(mid_dist-(0.5*nthickness1+gap)),abs(mid_dist-(0.5*nthickness2+gap)))
                        # print("Check 3:",abs(mid_dist-gap))
                        if abs(mid_dist-(0.5*nthickness1+0.5*nthickness2+gap))<joint_tol:
                            joint_type = "Lap"
                        elif abs(mid_dist-(0.5*nthickness1+gap))<joint_tol or abs(mid_dist-(0.5*nthickness2+gap))<joint_tol:
                            joint_type = "Corner"
                        elif abs(mid_dist-gap)<joint_tol:
                            joint_type = "Butt"
                        else:
                            joint_type = "Type not found"
                            
                        # elif dict["jointType"] == "RSW":
                           # joint_type = "RSW"
                        #print(mid_dist,0.5*nthickness1,0.5*nthickness2, gap)
                        report_lines += f"{solid1.parent.name};{solid2.parent.name};{round(nthickness1,2)};{round(nthickness2,2)};{gap};{joint_type}\n"
                        #print(len(sections))
                        
                        if not mids_exist:
                            apex.deleteEntities(mid1)
                            apex.deleteEntities(mid2)
                            
                        listOfUsedSolidPairs.append(f"{solid1.getPathName()}+{solid2.getPathName()}")
                        
    elif dict["jointType"] == "RSW":
        report_lines = "ID; X; Y; Z;# of Sheets; Part 1; T1; Part 2; T2; ...Part n; T n; ; Gap 12; Gap 23; ...Gap ij;\n"
        n=1
        #Get all visible solids
        RSW_Solids = apex.EntityCollection()
        for Part in model_1.getParts(True):
            for Solid in Part.getSolids():
                if Solid.getVisibility():
                    RSW_Solids.append(Solid)
        
        max_stack = 0
        #Start iterating over each point
        for spotPoint in listOfPoints:
            #Find near solids to each point
            coord = apex.Coordinate(spotPoint.x,spotPoint.y,spotPoint.z)
            distance_ = apex.measureDistance(source=spotPoint,target=RSW_Solids)
            near_solids = apex.EntityCollection()
            farthest = 0.0
            #Find the farthest solid from point, this will be useful when building the stack
            for k in range(len(distance_)):
                if distance_[k] <= rswTolerance:
                    near_solids.append(RSW_Solids[k])
                    if distance_[k]>=farthest:
                        farthest = distance_[k]
                        far_solid = RSW_Solids[k]
            report_lines += f"{n}; {round(spotPoint.x,1)}; {round(spotPoint.y,1)}; {round(spotPoint.z,1)};"
            n+=1
            
            #Build stack
            if len(near_solids) == 0:
                apex.enableShowOutput()
                print("No near solids found for ", spotPoint.name)
                continue
            elif len(near_solids)==1:
                stack = [near_solids[0]]
                report_lines += f"{len(stack)};"
            elif len(near_solids)==2:
                stack = [near_solids[0],near_solids[1]]
                report_lines += f"{len(stack)};"                
            else:
                # Find out order
                if dict["orderedStack"] == 'True':
                    ref_dist = float('inf')
                    for face in far_solid.getExteriorFaces():
                        _target = apex.EntityCollection()
                        _target.append(face)
                        if apex.measureDistance(source=spotPoint,target=_target)[0] < ref_dist:
                            near_face = face
                            ref_dist = apex.measureDistance(source=spotPoint,target=_target)[0]
                    location_Coll = apex.ILocationCollection()
                    solid_loc = near_face.asEntity().evaluateClosestLocation(coord.getLocation()).getClosestLocation()
                    location_Coll.append(solid_loc.getLocation())
                    far_point = apex.geometry.createPointLocation(location_Coll)
                    
                    stack = []
                    used = []
                    stack.append(far_solid)
                    used.append(far_solid.parent.name)
                    distance2_ = apex.measureDistance(source=far_point[0],target=near_solids)
                    #Here goes one hell of a one liner! 
                    #   It gets a list of the indexes of the "distance2_" and it sorts the indexes based on min to max values on the list
                    # This way you know what order is the stack and use the sorted list to get the solids in the "near_solids" list in the correct order
                    sorted_list = [a for a,b in (sorted({i: j for i,j in enumerate(list(distance2_))}.items(), key=lambda x:x[1]))] #this returns tuples of index,value
                    for k in range(len(distance2_)):
                        if near_solids[sorted_list[k]].parent.name not in used:
                            stack.append(near_solids[sorted_list[k]])
                            used.append(near_solids[sorted_list[k]].parent.name)
                    report_lines += f"{len(stack)};"
                #Deprecated this option
                else:
                    stack = []
                    for solid in near_solids:
                        stack.append(solid)
                    report_lines += f"{len(stack)};"
            if len(stack) > max_stack:
                max_stack = len(stack)
            
            #Analyze stack
            solid_thick_dict = {}
            if len(stack) >= 1:
                for solid in stack:
                    part_name = solid.parent.name
                    if len(solid.parent.surfaces)>=1:
                        if len(solid.parent.surfaces[0].getMeshes()) >= 1:
                            thick = round(solid.parent.surfaces[0].getMeshes()[0].getElements()[0].getThickness(),2) #.getSection ().getThickness(),2)
                            report_lines += f"{part_name}; {thick};"
                            solid_thick_dict[part_name] = thick                      
                    #If there are no surfaces, extract mid and get thickness
                    else:
                        #Only way to figure out the created thickness is to see the differences in section catalog. It is dumb but it is the only way
                        A_old = apex.attribute.getFieldDictionary()
                        _target = apex.EntityCollection()
                        _target.append(solid)
                        mid = apex.geometry.assignConstantThicknessMidSurface(
                            target=_target,
                            autoAssignThickness=True,
                            autoAssignTolerance=5.0e-02
                        )
                        A_new = apex.attribute.getFieldDictionary()
                        new_thickness = { k : A_new[k] for k in set(A_new) - set(A_old) }
                        for key,value in new_thickness.items():
                            thick = round(apex.attribute.getDiscreteFEMField(pathName = apex.currentModel().name + "/Fields/" + key).thickness,2)
                        apex.deleteEntities(mid)
                        report_lines += f"{part_name}; {thick};"
                        solid_thick_dict[part_name] = thick
            else:
                apex.enableShowOutput()
                print(f"Couldn't find any near plates to {spotPoint.name}, please check point or increase max gap")
                continue
                
            #Analyze Gap between parts
            gap_dict = {}
            report_lines += f" ;"
            if len(stack) == 2:
                #Here I calculate distance from solid to solid simply for performance reasons, it may yield unreliable results but it seems good enough from test models
                second_solid = apex.EntityCollection()
                second_solid.append(stack[1])
                gap = abs(round(apex.measureDistance(source=stack[0],target=second_solid)[0],2))
                report_lines += f"{gap};"
                gap_dict[1] = gap
            elif len(stack)>2:
                for i in range(1,len(stack)):
                    _target = apex.EntityCollection()
                    _target.append(stack[i])
                    dist = apex.measureDistance(source=far_point[0],target=_target)
                    if i == 1:
                        gap = abs(round(dist[0],2))
                        report_lines += f"{gap};"
                        gap_dict[i] = gap
                    else:
                        summed_thick = 0.0
                        summed_gap = 0.0
                        for j in range(1,i):
                            summed_thick += solid_thick_dict[stack[j].parent.name]
                            summed_gap += gap_dict[j]
                        gap = abs(round(dist[0]-summed_thick-summed_gap,2))
                        report_lines += f"{gap};"
                        gap_dict[i] = gap

            #End stack
            report_lines += "\n"
            try:
                apex.deleteEntities(far_point) #Deleting aux point created before
            except:
                pass
    else:
        print("Failed")
        
    
    with open(os.path.join(dirToSave,"JointReport.txt"), 'w') as tempFile:
        tempFile.write(report_lines)
    
    #Logic to re-organize the file
    with open(os.path.join(dirToSave,"JointReport.csv"), 'w') as reportFile:
        if dict["jointType"] == "RSW":
            if max_stack == 0:
                apex.enableShowOutput()
                print("\nNo stacks were found, the report will not be written")
            else:
                report_lines2 = "ID; X; Y; Z;# of Sheets;"
                for i in range(0,max_stack):
                    report_lines2 += f"Part {i+1}; T{i+1};"
                report_lines2+="  ;"
                for i in range(0,max_stack-1):
                    report_lines2 += f"Gap {i+1}{i+2};"            
                report_lines2 += "\n"    
                for line in open(os.path.join(dirToSave,"JointReport.txt"), 'r'):
                    if not line.startswith("ID"):
                        parts = int(line.split(';')[4])
                        if parts < max_stack:
                            report_lines2 += f"{line.split(';')[0]};{line.split(';')[1]};{line.split(';')[2]};{line.split(';')[3]};{line.split(';')[4]};"
                            for i in range(5,5+2*parts,2):
                                report_lines2 += f"{line.split(';')[i]};{line.split(';')[i+1]};"
                            for i in range(0,2*(max_stack-parts)):
                                report_lines2 += f" ;"
                            report_lines2 += f"{line.split(';')[5+2*parts]};"
                            for i in range(1,parts):
                                report_lines2 += f"{line.split(';')[5+2*parts+i]};"
                            report_lines2 += "\n"
                        else:
                            report_lines2 += line
                #Write it
                reportFile.write(report_lines2)
        else:
            report_lines2 = report_lines
            reportFile.write(report_lines2)
            
    os.remove(os.path.join(dirToSave,"JointReport.txt"))

    t1_stop = perf_counter()
    print("\nElapsed time during the whole program:",round(t1_stop-t1_start,2),"seconds")

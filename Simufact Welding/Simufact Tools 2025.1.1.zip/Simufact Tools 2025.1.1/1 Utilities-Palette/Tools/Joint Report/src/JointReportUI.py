# import sys
import os
import apex_sdk
# import clr

# .NET references
import System
from System.Windows.Forms import FolderBrowserDialog
import System.Windows.Controls as WPFControls
#from Microsoft.Win32 import FolderBrowserDialog

# Define current file path of example
current_file_path = os.path.dirname(os.path.realpath(__file__))


# Set pre-defined properties of ToolPropertyContainer
def getUIContent():
    global my_toolProperty
    my_toolProperty = apex_sdk.ToolPropertyContainer()
    my_toolProperty.TitleText = "Create Joint Report"
    my_toolProperty.TitleImageUriString = os.path.join(os.path.dirname(current_file_path), r"res\report.png")
    my_toolProperty.WorkFlowInstructions = '''
    <p><strong><span style="color: #999999;">Joint Report<br /></span></strong></p>
    <p><span style="color: #999999;">Description: This tools uses the distance search algorithm to create a report of the joints found. Parts need to be solids!<br /></span></p>
    <ul>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Type of model</span>: Type of the model that will be analyzed<br /></span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Max gap (mm)</span>: Maximum expected gap between parts.<br /></span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Max stacked thickness (mm)</span>: Maximum stack thickness <br /></span></li>
    </ul>
    <p><span style="color: #999999;">Workflow:</span></p>
    <ol>
    <li><span style="color: #999999;">Define the max expected gap between the sheets and the max thickness of a stack<br /></span></li>
    <li><span style="color: #999999;">For Sheet Metal Arc Welding, select an assembly or parts containing the parts you want to analyse. For RSW, select points in space representing the spot locations<br /></span></li>
    <li><span style="color: #999999;">Click Create Joint Report<br /></span></li>
    </ol>
    <p><span style="color: #999999;">For support: <a href="mailto:support.americas@simufact.com" style="color: #999999;"><span style="color: #ff0000;">support.americas@simufact.com</span></a></span></p>
    <p><span style="color: #999999;"><span style="color: #ff0000;"></span></span></p>
    '''

    # Define UI
    my_toolProperty.ToolPropertyContent = getCustomToolPropertyContent()

    # Handle apply button (green) click event
    my_toolProperty.AppliedCommand = apex_sdk.ActionCommand(System.Action(HandleApplyButton))
    
    # Define PickFilterList
    my_toolProperty.ShowPickChoice = True
    return my_toolProperty


# Set PickFilters
def setPickFilterList1():
    # Create an empty List of strings
    pickChoices = System.Collections.Generic.List[System.String]()

    # Exclusive picking and visibility picking
    pickChoices.Add(apex_sdk.PickFilterTypes.ExclusivePicking)
    pickChoices.Add(apex_sdk.PickFilterTypes.VisibilityPicking)

    # Add Types
    pickChoices.Add(apex_sdk.PickFilterTypes.Part)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Solid)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Surface)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Face)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Cell)
    pickChoices.Add(apex_sdk.PickFilterTypes.Assembly)

    # Return the pick filter list
    return pickChoices
    
# Set PickFilters
def setPickFilterList2():
    # Create an empty List of strings
    pickChoices = System.Collections.Generic.List[System.String]()

    # Exclusive picking and visibility picking
    pickChoices.Add(apex_sdk.PickFilterTypes.ExclusivePicking)
    pickChoices.Add(apex_sdk.PickFilterTypes.VisibilityPicking)

    # Add Types
    #pickChoices.Add(apex_sdk.PickFilterTypes.Part)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Solid)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Surface)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Face)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Cell)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Assembly)
    pickChoices.Add(apex_sdk.PickFilterTypes.Point)

    # Return the pick filter list
    return pickChoices


# Define Layout and Components
def getCustomToolPropertyContent():
    global my_toolProperty
    # Create a Grid
    my_Grid = WPFControls.Grid()

    # Add 2 Rows and 1 Column
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())

    currRow = 0
     
    # Type of model
    currRow += 1
    modelType = WPFControls.TextBlock()
    modelType.Text = "Type of model:"
    WPFControls.Grid.SetRow(modelType, currRow)
    WPFControls.Grid.SetColumn(modelType, 0)

    # Create a Combo box
    global modelTypeSelection
    modelTypeSelection = WPFControls.ComboBox()
    
    item1 = WPFControls.ComboBoxItem()
    item1.Content = "Sheet Metal Arc Welding"
    modelTypeSelection.Items.Add(item1)
    
    item2 = WPFControls.ComboBoxItem()
    item2.Content = "RSW"
    modelTypeSelection.Items.Add(item2)

    # item3 = WPFControls.ComboBoxItem()
    # item3.Content = "Sheets and Solids Arc Welding"
    # modelTypeSelection.Items.Add(item3)
    
    modelTypeSelection.SelectedIndex = 1
    WPFControls.Grid.SetRow(modelTypeSelection, currRow)
    WPFControls.Grid.SetColumn(modelTypeSelection, 1)
    
    # Create input field
    currRow += 1
    lbl01 = WPFControls.TextBlock()
    lbl01.Text = "Max gap (mm):"
    WPFControls.Grid.SetRow(lbl01, currRow)
    WPFControls.Grid.SetColumn(lbl01, 0)
    
    global input01
    input01 = WPFControls.TextBox()
    WPFControls.Grid.SetRow(input01, currRow)
    WPFControls.Grid.SetColumn(input01, 1)
    input01.Text = "0.5"

    # Create input field
    currRow += 1
    lbl02 = WPFControls.TextBlock()
    lbl02.Text = "Max stacked thickness (mm):"
    WPFControls.Grid.SetRow(lbl02, currRow)
    WPFControls.Grid.SetColumn(lbl02, 0)
    
    global input02
    input02 = WPFControls.TextBox()
    WPFControls.Grid.SetRow(input02, currRow)
    WPFControls.Grid.SetColumn(input02, 1)
    input02.Text = "4.0"    
    
    # Create checkbox
    currRow += 1
    global chk01
    chk01 = WPFControls.CheckBox()
    chk01.Content = "Find stack order"
    chk01.Height = 20
    WPFControls.Grid.SetRow(chk01, currRow)
    WPFControls.Grid.SetColumn(chk01, 0)
    WPFControls.Grid.SetColumnSpan(chk01, 1)    
    
    # Create a button
    currRow += 1
    goButton = WPFControls.Button()
    goButton.Content = "Create joint report"
    WPFControls.Grid.SetRow(goButton, currRow)
    WPFControls.Grid.SetColumn(goButton, 0)
    goButton.Height = 30
    WPFControls.Grid.SetColumnSpan(goButton, 3)


    # Link a function to the Button "Click" event
    goButton.Click += HandleApplyButton
    
    #Setup pick filters
    if modelTypeSelection.Text == "RSW":
        my_toolProperty.PickFilterList = setPickFilterList2()
        chk01.Visibility = System.Windows.Visibility.Visible  
    else:
        my_toolProperty.PickFilterList = setPickFilterList1() 
        chk01.Visibility = System.Windows.Visibility.Collapsed
        
    modelTypeSelection.SelectionChanged += handleChange
    

    # Add the controls to the Grid
    my_Grid.Children.Add(lbl01)
    my_Grid.Children.Add(input01)
    my_Grid.Children.Add(lbl02)
    my_Grid.Children.Add(input02)
    my_Grid.Children.Add(modelType)
    my_Grid.Children.Add(modelTypeSelection)
    #my_Grid.Children.Add(chk01)
    my_Grid.Children.Add(goButton)
    # Return the Grid
    return my_Grid


@apex_sdk.errorhandler
def handleChange(sender, event):
    global modelType, modelTypeSelection, chk01
    #For some reason this logic is inverted, but it works....
    if modelTypeSelection.Text == "RSW":
        my_toolProperty.PickFilterList = setPickFilterList1()
        chk01.Visibility = System.Windows.Visibility.Collapsed
    else:
        my_toolProperty.PickFilterList = setPickFilterList2()
        chk01.Visibility = System.Windows.Visibility.Visible        
    return my_toolProperty
  
# Apply button handler (Green check mark)
@apex_sdk.errorhandler
def HandleApplyButton(sender, args):
    # Create a File open dialog
    dialog = FolderBrowserDialog()
    dialog.Title = "Select directory to save the report file"
    # Create a Dictionary to store the user defined tool data
    dictionary = {}
    if dialog.ShowDialog():
        dictionary["saveToDir"] = str(dialog.SelectedPath)
    else:
        dictionary["saveToDir"] = ""
    # Populate the Dictionary with the user defined tool data you need
    dictionary["jointType"] = modelTypeSelection.Text
    dictionary["searchDistance"] = input01.Text
    dictionary["maxThick"] = input02.Text
    dictionary["orderedStack"] = 'True'#chk01.IsChecked

    apex_sdk.runScriptFunction(os.path.join(current_file_path, r"JointReport.py"), "createReport", dictionary)

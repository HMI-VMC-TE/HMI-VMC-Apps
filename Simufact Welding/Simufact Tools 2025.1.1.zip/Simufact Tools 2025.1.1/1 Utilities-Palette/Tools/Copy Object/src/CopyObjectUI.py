import sys
import os
import apex_sdk
import clr

# .NET references
import System
from System.Windows.Forms import FolderBrowserDialog
import System.Windows.Controls as WPFControls
#from Microsoft.Win32 import FolderBrowserDialog

# Define current file path of example
current_file_path = os.path.dirname(os.path.realpath(__file__))


# Set pre-defined properties of ToolPropertyContainer
def getUIContent():
    my_toolProperty = apex_sdk.ToolPropertyContainer()
    my_toolProperty.TitleText = "Create copies of objects"
    my_toolProperty.TitleImageUriString = os.path.join(os.path.dirname(current_file_path), r"res\CopyObjectICON.png")
    my_toolProperty.WorkFlowInstructions = '''
    <p><strong><span style="color: #999999;">Copy Object<br /></span></strong></p>
    <p><span style="color: #999999;">Description: This tools creates one or several copies of a given geometry.<br /></span></p>
    <ul>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Copies</span>: Number of copies.</span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Distance</span>: Distance that the geometries will be moved in the vector direction.</span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Vector direction</span>: Direction vector for the copies to be made.</span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">One new part per new object</span>: Creates additional parts and reparent geometries automatically, to respect the "one body per part" organization of the model.</span></li>
    </ul>
    <p><span style="color: #999999;">Workflow:</span></p>
    <ol>
    <li><span style="color: #999999;">Select the geometries<br /></span></li>
    <li><span style="color: #999999;">Type the number of copies and distance<br /></span></li>
    <li><span style="color: #999999;">Select direction vector<br /></span></li>
    <li><span style="color: #999999;">Click Copy selected objects</span><span style="color: #999999;"></span></li>
    </ol>
    <p><span style="color: #999999;">For support: <a href="mailto:support.americas@simufact.com" style="color: #999999;"><span style="color: #ff0000;">support.americas@simufact.com</span></a></span></p>    <p><span style="color: #999999;"><span style="color: #ff0000;"></span></span></p>
    '''

    # Define UI
    my_toolProperty.ToolPropertyContent = getCustomToolPropertyContent()

    # Handle apply button (green) click event
    my_toolProperty.AppliedCommand = apex_sdk.ActionCommand(System.Action(HandleApplyButton))

    # Define PickFilterList
    my_toolProperty.ShowPickChoice = True
    my_toolProperty.PickFilterList = setPickFilterList()

    return my_toolProperty


# Set PickFilters
def setPickFilterList():
    # Create an empty List of strings
    pickChoices = System.Collections.Generic.List[System.String]()

    # Exclusive picking and visibility picking
    pickChoices.Add(apex_sdk.PickFilterTypes.ExclusivePicking)
    pickChoices.Add(apex_sdk.PickFilterTypes.VisibilityPicking)

    # Add Types
    #pickChoices.Add(apex_sdk.PickFilterTypes.Part)
    pickChoices.Add(apex_sdk.PickFilterTypes.Solid)
    pickChoices.Add(apex_sdk.PickFilterTypes.Surface)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Face)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Cell)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Assembly)

    # Return the pick filter list
    return pickChoices


# Define Layout and Components
def getCustomToolPropertyContent():
    # Create a Grid
    my_Grid = WPFControls.Grid()

    # Add 2 Rows and 1 Column

    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())
    my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())

    currRow = 0

    # Create input field
    currRow += 1
    lbl01 = WPFControls.TextBlock()
    lbl01.Text = "Copies:"
    WPFControls.Grid.SetRow(lbl01, currRow)
    WPFControls.Grid.SetColumn(lbl01, 0)
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())

    global input01
    input01 = WPFControls.TextBox()
    WPFControls.Grid.SetRow(input01, currRow)
    WPFControls.Grid.SetColumn(input01, 1)
    input01.Text = "1"



    # Create input field
    currRow += 1
    lbl06 = WPFControls.TextBlock()
    lbl06.Text = "Distance (mm):"
    WPFControls.Grid.SetRow(lbl06, currRow)
    WPFControls.Grid.SetColumn(lbl06, 0)
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.Children.Add(lbl06)

    global inputLength
    inputLength = WPFControls.TextBox()
    WPFControls.Grid.SetRow(inputLength, currRow)
    WPFControls.Grid.SetColumn(inputLength, 1)
    inputLength.Text = "100.0"
    my_Grid.Children.Add(inputLength)


    # Create input field
    currRow += 1
    lbl02 = WPFControls.TextBlock()
    lbl02.Text = "Vector direction"
    WPFControls.Grid.SetRow(lbl02, currRow)
    WPFControls.Grid.SetColumn(lbl02, 0)
    WPFControls.Grid.SetColumnSpan(lbl02, 3)
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.Children.Add(lbl02)




    # Create input field
    currRow += 1
    lbl03 = WPFControls.TextBlock()
    lbl03.Text = "X:"
    WPFControls.Grid.SetRow(lbl03, currRow)
    WPFControls.Grid.SetColumn(lbl03, 0)
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.Children.Add(lbl03)

    global inputX
    inputX = WPFControls.TextBox()
    WPFControls.Grid.SetRow(inputX, currRow)
    WPFControls.Grid.SetColumn(inputX, 1)
    inputX.Text = "1.0"
    my_Grid.Children.Add(inputX)



    # Create input field
    currRow += 1
    lbl04 = WPFControls.TextBlock()
    lbl04.Text = "Y:"
    WPFControls.Grid.SetRow(lbl04, currRow)
    WPFControls.Grid.SetColumn(lbl04, 0)
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.Children.Add(lbl04)

    global inputY
    inputY = WPFControls.TextBox()
    WPFControls.Grid.SetRow(inputY, currRow)
    WPFControls.Grid.SetColumn(inputY, 1)
    inputY.Text = "0.0"
    my_Grid.Children.Add(inputY)



    # Create input field
    currRow += 1
    lbl05 = WPFControls.TextBlock()
    lbl05.Text = "Z:"
    WPFControls.Grid.SetRow(lbl05, currRow)
    WPFControls.Grid.SetColumn(lbl05, 0)
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.Children.Add(lbl05)

    global inputZ
    inputZ = WPFControls.TextBox()
    WPFControls.Grid.SetRow(inputZ, currRow)
    WPFControls.Grid.SetColumn(inputZ, 1)
    inputZ.Text = "0.0"
    my_Grid.Children.Add(inputZ)




    # Create checkbox to extend the weld bead
    currRow += 1
    global chkBox01
    chkBox01 = WPFControls.CheckBox()
    chkBox01.Content = "One new part per new object"
    chkBox01.Height = 20
    WPFControls.Grid.SetRow(chkBox01, currRow)
    WPFControls.Grid.SetColumn(chkBox01, 0)
    WPFControls.Grid.SetColumnSpan(chkBox01, 3)
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    chkBox01.IsChecked = System.Nullable[System.Boolean](True)

    # Create a button
    currRow += 1
    currRow += 1
    goButton = WPFControls.Button()
    goButton.Content = "Copy selected objects"
    WPFControls.Grid.SetRow(goButton, currRow)
    WPFControls.Grid.SetColumn(goButton, 0)
    goButton.Height = 30
    WPFControls.Grid.SetColumnSpan(goButton, 3)
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())


    # Link a function to the Button "Click" event
    # This function will be called every time the Button is clicked
    goButton.Click += HandleApplyButton

    my_Grid.Children.Add(lbl01)
    my_Grid.Children.Add(input01)
    my_Grid.Children.Add(chkBox01)

    my_Grid.Children.Add(goButton)


    # Return the Grid
    return my_Grid


# Apply button handler (Green check mark)
# This function is called each time the Apply button is clicked
@apex_sdk.errorhandler
def HandleApplyButton(sender, args):
    # Create a Dictionary to store the user defined tool data
    dictionary = {}
    dictionary["onePartPerObj"] = chkBox01.IsChecked
    dictionary["numOfCopies"] = input01.Text
    dictionary["XDirec"] = inputX.Text
    dictionary["YDirec"] = inputY.Text
    dictionary["ZDirec"] = inputZ.Text
    dictionary["Distance"] = inputLength.Text
    apex_sdk.runScriptFunction(os.path.join(current_file_path, r"CopyObject.py"), "createCopy", dictionary)

# coding: utf-8


import apex
from apex.construct import Point3D, Point2D

apex.setScriptUnitSystem(unitSystemName = r'''mm-kg-s-N''')
model_1 = apex.currentModel()

# 
# Start of recorded operations
# 

def createCopy(dictionary={}):
    apex.disableShowOutput()
    model_1 = apex.currentModel()

    try:
        numOfCopies = int(dictionary["numOfCopies"])
        XDir = float(dictionary["XDirec"])
        YDir = float(dictionary["YDirec"])
        ZDir = float(dictionary["ZDirec"])
        copyDistance = float(dictionary["Distance"])
    except:
        print("Use only numbers in the fields.")
        raise
    _entities = apex.EntityCollection()
    for selElem in apex.selection.getCurrentSelection():
        _entities.append(selElem)

    if dictionary["onePartPerObj"] == 'True':
        for k in range(numOfCopies):
            for i in range(len(_entities)):
                new_part = apex.createPart(name = f"Copy {_entities[i].name} {k+1}")
                _target = apex.entityCollection()
                _target.append(_entities[i])
                new_part.setParent(_entities[i].getParent().getParent()) 
                newEntities = apex.transformTranslate(
                    target=_target,
                    direction=[XDir, YDir, ZDir],
                    distance= (k + 1) * copyDistance,
                    makeCopy=True
                )
                newEntities[0].setParent(new_part)
    else:
        for k in range(numOfCopies):
            newEntities = apex.transformTranslate(
                target=_entities,
                direction=[XDir, YDir, ZDir],
                distance= (k + 1) * copyDistance,
                makeCopy=True
            )


import apex
import math
from apex.construct import Point3D, Point2D
from scipy.spatial import KDTree
from datetime import datetime
import numpy as np

apex.disableShowOutput()
apex.disableRecoveryFileRecording()

# The following block tries to install two packages in case they are not already installed
try:
    from sklearn.metrics.pairwise import euclidean_distances
except:
    import subprocess, os, time
    for folder in os.listdir(r"C:\Program Files\MSC.Software\MSC Apex"):
        if "Lock" not in folder:
            installationPath = os.path.join("C:\Program Files\MSC.Software\MSC Apex",folder)
    pythonPath = os.path.join(installationPath, "python3", "python.exe")
    pythonPath_quotes = '"' + pythonPath + '"'
    pythonFolder = os.path.join(installationPath, "python3")
    assert os.path.isdir(pythonFolder)
    os.chdir(pythonFolder)
    sitePath = os.path.join(installationPath, "python3", "Lib", "site-packages")
    callPIP = subprocess.Popen(['python.exe', "-m", "pip", "install","--upgrade","--force-reinstall","numpy","pyqtgraph", "sklearn"],
        shell=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL)
    while callPIP.poll() is None:
        time.sleep(1)

try:
    from sklearn.metrics.pairwise import euclidean_distances
    import_sklearn = True
except:
    apex.enableShowOutput()
    #print(os.getlogin())
    import_sklearn = False
    print("""Failed installing sklearn, please install package manually
    
    Instructions:
    
    - Open cmd as administrator
    - Change directory to Apex "python3" folder (C:\Program Files\MSC.Software\MSC Apex\******\python3)
    - Run command: .\python.exe -m pip install --upgrade --force-reinstall numpy pyqtgraph sklearn
    
    Restart Apex and try running the tool again.
    """)

# Standard settings
apex.setScriptUnitSystem(unitSystemName = r'''mm-kg-s-N-K''')
applicationSettingsGeometry = apex.setting.ApplicationSettingsGeometry()
applicationSettingsGeometry.createGeometryInNewPart = apex.setting.CreateGeometryInNewPart.CurrentPart
applicationSettingsGeometry.geometryTessellationIsWatertight = False
applicationSettingsGeometry.geometryEdgeTesselationTolerance = apex.setting.GeometryTessellationTolerance.Medium
applicationSettingsGeometry.geometryFaceTesselationTolerance = apex.setting.GeometryTessellationTolerance.Medium
apex.setting.setApplicationSettingsGeometry(applicationSettingsGeometry = applicationSettingsGeometry)

# Defining main function
def nodeCollapse(dict={}):
    model_1 = apex.currentModel()
    start = datetime.now()
    used = []
    print("\nStarting script to merge close nodes\n")
    
    # Check if tolerance is valid
    try:
        tol = float(dict["tol"])
    except:
        apex.enableShowOutput()
        print("Invalid radius value!")
    
    # Check each selected surface
    for surf in apex.selection.getCurrentSelection():
        ## Check if there are meshes in this surface
        if len(surf.getMeshes()) == 0:
            apex.enableShowOutput()
            print("\nWARNING: No meshes found in", surf.name)
            continue
        mesh_1 = surf.getMeshes()[0]
        n_nodes = len(mesh_1.getNodes())
        
        # Create node array (will be used in KDTree)
        nd_array = np.zeros(shape=(n_nodes, 3))
        
        # Populate array and create dictionary with ordered ids and corresponding ids
        # This had to be done because nodes can start in ids different than 1 and can have skipped ids
        i = 0
        dict_nodes = {}
        for node in mesh_1.getNodes():
            dict_nodes[i]=node.getId()  # Dict has ordered id and corresponding ids
            nd_array[i] = [node.x, node.y, node.z]  # Array has oredered id and xyz position
            # print(node.x, node.y, node.z)
            i+=1
        
        # Create KDTree with node array
        tree = KDTree(nd_array)

        # Now iterate over all nodes in mesh
        i = 0
        for n1 in mesh_1.getNodes():
            if n1.getId() not in used: 
                # Result will be the ordered id of the nodes that are close to current node
                result = tree.query_ball_point(nd_array[i], tol)
                i+=1
                # Check if result is > 1 because current node will always return itself as a result
                if len(result) > 1:
                    n1_id = dict_nodes[result[0]]
                    n2_id = dict_nodes[result[1]]
                    print(n1_id,n2_id,'is a pair')
                    used.append(n1_id)
                    used.append(n2_id)
                    try:
                        nodes = mesh_1.getNodes(ids = f'{n1_id},{n2_id}') # Got both nodes at once because simply doing getNode was not working
                        n1 = nodes[0]
                        n2 = nodes[1]
                        apex.mesh.moveNodeToNode(n1,n2) # Execute
                    except:
                        print(f"Error merging on pair {n1_id} {n2_id}")                        
    
    # Wrap time statistics
    end = datetime.now()
    print("\nElapsed time: %s" % (end - start))
    
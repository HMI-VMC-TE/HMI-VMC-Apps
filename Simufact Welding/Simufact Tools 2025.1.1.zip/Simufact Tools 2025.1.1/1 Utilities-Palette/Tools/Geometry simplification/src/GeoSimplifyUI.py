import sys
import os
import apex_sdk
import clr


# .NET references
import System
import System.Windows.Controls as WPFControls
from System.Windows.Automation import AutomationProperties

dictionary = {}
current_file_path = os.path.dirname(os.path.realpath(__file__))

# setting pre-defined properties of tool_propertyContainer
def getUIContent():
    my_toolProperty = apex_sdk.ToolPropertyContainer()
    my_toolProperty.ToolPropertyContent = getCustomToolPropertyContent()
    my_toolProperty.TitleText = "Geometry simplification"
    my_toolProperty.TitleImageUriString = os.path.join(os.path.dirname(current_file_path), r"res\Simplify.png")
    my_toolProperty.WorkFlowInstructions = ''' 
    <p><strong><span style="color: #999999;">Geometry Simplification<br /></span></strong></p>
    <p><span style="color: #999999;">Description: This tool supresses edges and merge vertices based on a tolerance. The intended use is for complex stamped sheet bodies surfaces.<br /></span></p>
    <p><span style="color: #999999;">Select the expected element size, this will determine the tolerances for supression and merging of edges and vertices. You may increase or decrease this value, depending if you want to simplify more or less the geometry.<br /></span></p>
    <p><span style="color: #999999;">This tool will supress small edges, supress close edges and merge close vertices.<br /></span></p>
    <p><span style="color: #999999;">For support: <a href="mailto:support.americas@simufact.com" style="color: #999999;"><span style="color: #ff0000;">support.americas@simufact.com</span></a></span></p>
    '''
    
    # Define PickFilterList
    my_toolProperty.ShowPickChoice = True
    my_toolProperty.PickFilterList = setPickFilterList()

    return my_toolProperty

# Set PickFilters


def setPickFilterList():
    # Create an empty List of strings
    pickChoices = System.Collections.Generic.List[System.String]()

    # Exclusive picking and visibility picking
    pickChoices.Add(apex_sdk.PickFilterTypes.ExclusivePicking)
    pickChoices.Add(apex_sdk.PickFilterTypes.VisibilityPicking)

    # Add Types
    pickChoices.Add(apex_sdk.PickFilterTypes.Surface)
    pickChoices.Add(apex_sdk.PickFilterTypes.Solid)
    # pickChoices.Add(apex_sdk.PickFilterTypes.Face)
    # pickChoices.Add(apex_sdk.PickFilterTypes.Cell)
    # pickChoices.Add(apex_sdk.PickFilterTypes.Part)
    # pickChoices.Add(apex_sdk.PickFilterTypes.Assembly)

    # Return the pick filter list
    return pickChoices

# get tool property content


def getCustomToolPropertyContent():
    # Create a Grid
    my_Grid = WPFControls.Grid()

    my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())
    my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())

    currRow = 0

    currRow += 1
    edgeLengthLbl1 = WPFControls.TextBlock()
    edgeLengthLbl1.Text = "Select the expected mesh element size"
    WPFControls.Grid.SetRow(edgeLengthLbl1, currRow)
    WPFControls.Grid.SetColumn(edgeLengthLbl1, 0)
    my_Grid.Children.Add(edgeLengthLbl1)

    currRow += 1
    edgeLengthLbl = WPFControls.TextBlock()
    edgeLengthLbl.Text = "    Mesh Element Size (mm):"
    WPFControls.Grid.SetRow(edgeLengthLbl, currRow)
    WPFControls.Grid.SetColumn(edgeLengthLbl, 0)
    my_Grid.Children.Add(edgeLengthLbl)

    # Create an empty input TextBox assign it to Row 0, Column 1
    global edgeLengthVal
    edgeLengthVal = WPFControls.TextBox()
    WPFControls.Grid.SetRow(edgeLengthVal, currRow)
    WPFControls.Grid.SetColumn(edgeLengthVal, 1)
    edgeLengthVal.Text = "5.0"
    my_Grid.Children.Add(edgeLengthVal)
    
    # Create checkbox to decide what to do
    currRow += 1
    global chkBox01
    chkBox01 = WPFControls.CheckBox()
    chkBox01.Content = "Supress by Length"
    chkBox01.Height = 20
    WPFControls.Grid.SetRow(chkBox01, currRow)
    WPFControls.Grid.SetColumn(chkBox01, 0)
    chkBox01.IsChecked = System.Nullable[System.Boolean](True)
    my_Grid.Children.Add(chkBox01)
    
    currRow += 1
    global chkBox02
    chkBox02 = WPFControls.CheckBox()
    chkBox02.Content = "Supress by Proximity"
    chkBox02.Height = 20
    WPFControls.Grid.SetRow(chkBox02, currRow)
    WPFControls.Grid.SetColumn(chkBox02, 0)
    chkBox02.IsChecked = System.Nullable[System.Boolean](True)
    my_Grid.Children.Add(chkBox02)
    
    currRow += 1
    global chkBox03
    chkBox03 = WPFControls.CheckBox()
    chkBox03.Content = "Merge close vertices"
    chkBox03.Height = 20
    WPFControls.Grid.SetRow(chkBox03, currRow)
    WPFControls.Grid.SetColumn(chkBox03, 0)
    chkBox03.IsChecked = System.Nullable[System.Boolean](False)
    my_Grid.Children.Add(chkBox03)

    #Create button to do the simplification
    currRow += 1
    cleanEdges = WPFControls.Button()
    cleanEdges.Content = "Simplify geometry"
    WPFControls.Grid.SetRow(cleanEdges, currRow)
    WPFControls.Grid.SetColumn(cleanEdges, 0)
    WPFControls.Grid.SetColumnSpan(cleanEdges, 3)
    cleanEdges.Height = 30
    cleanEdges.Click += HandleByLength
    my_Grid.Children.Add(cleanEdges)

    currRow += 1
    edgeProxLbl = WPFControls.TextBlock()
    edgeProxLbl.Text = "    Suppress by proximity (mm):"
    WPFControls.Grid.SetRow(edgeProxLbl, currRow)
    WPFControls.Grid.SetColumn(edgeProxLbl, 0)
    #my_Grid.Children.Add(edgeProxLbl)

    # Create an empty input TextBox assign it to Row 0, Column 1
    global edgeProxVal
    edgeProxVal = WPFControls.TextBox()
    WPFControls.Grid.SetRow(edgeProxVal, currRow)
    WPFControls.Grid.SetColumn(edgeProxVal, 1)
    edgeProxVal.Text = "5.0"
    #my_Grid.Children.Add(edgeProxVal)

    currRow += 1
    suppressByProxim = WPFControls.Button()
    suppressByProxim.Content = "Suppress by proximity"
    WPFControls.Grid.SetRow(suppressByProxim, currRow)
    WPFControls.Grid.SetColumn(suppressByProxim, 1)
    suppressByProxim.Height = 30
    suppressByProxim.Click += HandleByProximity
    #my_Grid.Children.Add(suppressByProxim)








    currRow += 1
    edgeLengthLbl2 = WPFControls.TextBlock()
    edgeLengthLbl2.Text = "Edge merge"
    WPFControls.Grid.SetRow(edgeLengthLbl2, currRow)
    WPFControls.Grid.SetColumn(edgeLengthLbl2, 0)
    #my_Grid.Children.Add(edgeLengthLbl2)

    currRow += 1
    edgeLengthLbl3 = WPFControls.TextBlock()
    edgeLengthLbl3.Text = "    Merge below distance (mm):"
    WPFControls.Grid.SetRow(edgeLengthLbl3, currRow)
    WPFControls.Grid.SetColumn(edgeLengthLbl3, 0)
    #my_Grid.Children.Add(edgeLengthLbl3)

    # Create an empty input TextBox assign it to Row 0, Column 1
    global edgeProximVal
    edgeProximVal = WPFControls.TextBox()
    WPFControls.Grid.SetRow(edgeProximVal, currRow)
    WPFControls.Grid.SetColumn(edgeProximVal, 1)
    edgeProximVal.Text = "0.25"
    #my_Grid.Children.Add(edgeProximVal)


    currRow += 1
    mergeEdges = WPFControls.Button()
    mergeEdges.Content = "Merge edges"
    WPFControls.Grid.SetRow(mergeEdges, currRow)
    WPFControls.Grid.SetColumn(mergeEdges, 1)
    mergeEdges.Height = 30
    mergeEdges.Click += HandleMergeEdges
    #my_Grid.Children.Add(mergeEdges)



    for k in range(currRow + 1):
        my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())

    
    # Return the Grid
    return my_Grid


@apex_sdk.errorhandler
def HandleByLength(sender, args):
    dictionary = {}
    dictionary["EdgeLength"] = edgeLengthVal.Text
    # dictionary["EdgeLength"] is already defined from the GUI, now define the other two tolerance values
    dictionary["EdgeProximity"] = 0.75*float(edgeLengthVal.Text)
    dictionary["EdgeProxim"] = 0.1*float(edgeLengthVal.Text)
    dictionary["doLength"] = chkBox01.IsChecked
    dictionary["doProxim"] = chkBox02.IsChecked
    dictionary["doVerts"] = chkBox03.IsChecked
    file_path = os.path.dirname(os.path.realpath(__file__))
    script_path = os.path.join(file_path, 'SuppressAndMerge.py')
    apex_sdk.runScriptFunction(
        file=script_path, function="main", args=dictionary)
    #apex_sdk.runScriptFunction(r"D:\Personal\00-Okigami\04.2-ApexAutoARC\00-Modularized-IL\SuppressVerticesOnly.py", "SuppressVertices", dictionary)

@apex_sdk.errorhandler
def HandleByProximity(sender, args):
    dictionary = {}
    dictionary["EdgeProximity"] = edgeProxVal.Text
    file_path = os.path.dirname(os.path.realpath(__file__))
    script_path = os.path.join(file_path, 'SuppressAndMerge.py')
    apex_sdk.runScriptFunction(
        file=script_path, function="SuppressEdgesByProximity", args=dictionary)
    #apex_sdk.runScriptFunction(r"D:\Personal\00-Okigami\04.2-ApexAutoARC\00-Modularized-IL\SuppressVerticesOnly.py", "SuppressVertices", dictionary)


@apex_sdk.errorhandler
def HandleMergeEdges(sender, args):
    dictionary = {}
    dictionary["EdgeProxim"] = edgeProximVal.Text
    file_path = os.path.dirname(os.path.realpath(__file__))
    script_path = os.path.join(file_path, 'SuppressAndMerge.py')
    apex_sdk.runScriptFunction(
        file=script_path, function="MergeEdges", args=dictionary)
    #apex_sdk.runScriptFunction(r"D:\Personal\00-Okigami\04.2-ApexAutoARC\00-Modularized-IL\SuppressEdgesOnly.py", "SuppressEdges", dictionary)

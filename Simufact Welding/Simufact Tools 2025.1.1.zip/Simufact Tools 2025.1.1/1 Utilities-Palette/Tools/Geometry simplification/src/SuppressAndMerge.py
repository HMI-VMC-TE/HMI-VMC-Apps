import apex, sys
from apex.construct import Point3D, Point2D

apex.disableShowOutput
apex.disableRecoveryFileRecording()
#callPIP = subprocess.Popen(["python.exe", "-m", "pip", "install", "pyqtgraph", "sklearn"],
try:
    from sklearn.metrics.pairwise import euclidean_distances
except:
    import subprocess, os, time
    for folder in os.listdir(r"C:\Program Files\MSC.Software\MSC Apex"):
        if "Lock" not in folder:
            installationPath = os.path.join("C:\Program Files\MSC.Software\MSC Apex",folder)
    pythonPath = os.path.join(installationPath, "python3", "python.exe")
    pythonPath_quotes = '"' + pythonPath + '"'
    pythonFolder = os.path.join(installationPath, "python3")
    assert os.path.isdir(pythonFolder)
    os.chdir(pythonFolder)
    sitePath = os.path.join(installationPath, "python3", "Lib", "site-packages")
    callPIP = subprocess.Popen(['python.exe', "-m", "pip", "install","--upgrade","--force-reinstall","numpy","pyqtgraph", "sklearn"],
        shell=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL)
    while callPIP.poll() is None:
        time.sleep(1)

try:
    from sklearn.metrics.pairwise import euclidean_distances
except:
    apex.enableShowOutput()
    #print(os.getlogin())
    print("""Failed installing sklearn, please install package manually
    
    Instructions:
    
    - Open cmd as administrator
    - Change directory to Apex "python3" folder (C:\Program Files\MSC.Software\MSC Apex\******\python3)
    - Run command: .\python.exe -m pip install --upgrade --force-reinstall numpy pyqtgraph sklearn
    
    Restart Apex and try running the tool again.
    """)
    sys.exit()

def SuppressEdgesByLength(dict={}):
    #===================================================================
    ## Initializing Apex code
    apex.setScriptUnitSystem(unitSystemName = r'''mm-kg-s-N''')
    model_1 = apex.currentModel()
    _target = apex.entityCollection()
    #apex.display.enableGraphicRefresh(False)
    for selElement in apex.selection.getCurrentSelection():
        maxLength = float(dict["EdgeLength"])
        if selElement.getVisibility():
            for Edge in selElement.getEdges():
                if Edge.getLength() <= maxLength:
                    _target.append(Edge)

        result = apex.geometry.suppressOnly(
            target = _target,
            maxEdgeAngle = 1.745329251994330e-01,
            maxFaceAngle = 8.726646259971650e-02,
            keepVerticesAtCurvatureChange = False,
            cleanupTol = 1.000000000000000)
    #apex.display.enableGraphicRefresh(True)

def SuppressEdgesByProximity(dict={}):
    #===================================================================
    ## Initializing Apex code
    apex.setScriptUnitSystem(unitSystemName = r'''mm-kg-s-N''')
    model_1 = apex.currentModel()
    _target = apex.entityCollection()
    #apex.display.enableGraphicRefresh(False)
    for selElement in apex.selection.getCurrentSelection():
        edgeProx = float(dict["EdgeProximity"])
        if selElement.getVisibility():
            midpointList = []
            listOfEdges = apex.entityCollection()
            for Edge in selElement.getEdges():
                midpointList.append([Edge.getCentroid().getX(), Edge.getCentroid().getY(), Edge.getCentroid().getZ()])
                listOfEdges.append(Edge)
            
        calcDist = euclidean_distances(midpointList, midpointList)

        listToSuppress = []
        for k in range(int(len(calcDist))):
            for j in range(len(calcDist[k])):
                if 0.0 < calcDist[k][j] < edgeProx:
                    listToSuppress.append(j)
        
        listToSuppress = list(set(listToSuppress))

        for ID in listToSuppress:
            _target.append(listOfEdges[ID])

        result = apex.geometry.suppressOnly(
            target = _target,
            maxEdgeAngle = 1.745329251994330e-01,
            maxFaceAngle = 8.726646259971650e-02,
            keepVerticesAtCurvatureChange = False,
            cleanupTol = 1.000000000000000)
    #apex.display.enableGraphicRefresh(True)

def MergeEdges(dict={}):
#===================================================================
    ## Initializing Apex code
    apex.setScriptUnitSystem(unitSystemName = r'''mm-kg-s-N''')
    model_1 = apex.currentModel()
    _target = apex.entityCollection()
    #apex.display.enableGraphicRefresh(False)
    for selElement in apex.selection.getCurrentSelection(): #maybe do a for loop to run a few passes?
        #Create a list of the midpoints position
        used = [] #list to store vertices that were already used
        edgeProx = float(dict["EdgeProxim"])
        #print(edgeProx)
        try:
            if selElement.getVisibility():
                verts = []
                listOfEdges = apex.entityCollection()
                for Edge in selElement.getEdges():
                    verts.append([Edge.getVertices()[0].x,Edge.getVertices()[0].y,Edge.getVertices()[0].z])
                    verts.append([Edge.getVertices()[1].x,Edge.getVertices()[1].y,Edge.getVertices()[1].z])
                    listOfEdges.append(Edge)
                    #print("Edge ID: ", Edge.id)
        except:
            print("Failed to retrieve vertices")
        #Use function to calculate distance between each vertex
        #print(verts)
        len_verts = len(verts)
        calcDist = euclidean_distances(verts, verts)
        #print(calcDist)
        #Run through matrix of distances
        listToMerge = []
        distances = []
        for k in range(int(len(calcDist))):
            for j in range(len(calcDist[k])):
                if 0.0001 < calcDist[k][j] < edgeProx and calcDist[k][j] not in distances: #if below tolerance do:
                    print("\nDistance found in postion ",k,j," is: ",calcDist[k][j])
                    #print(len(listOfEdges[1].getConnectedFaces()))
                    #The vertex will depend on the position of the list. The logic tries to figure out the Edge in relation to the position of the calcDist matrix
                    print("K = ",k,"   J = ",j)
                    try:
                        if (k-1)%2 == 0:
                            conn_faces1 = len(listOfEdges[int((k+1)/2)].getConnectedFaces())      #Get connected faces of this edge, will check if it is internal
                            edge1_id = listOfEdges[int((k-1)/2)].id
                            snap_from = listOfEdges[int((k-1)/2)].getVertices()[1]
                        else:
                            conn_faces1 = len(listOfEdges[int((k+2)/2)].getConnectedFaces())
                            edge1_id = listOfEdges[int((k)/2)].id
                            snap_from = listOfEdges[int((k)/2)].getVertices()[0]
                        if (j-1)%2 == 0:
                            #conn_faces2 = len(listOfEdges[int((j+1)/2)].getConnectedFaces())
                            edge2_id=listOfEdges[int((j-1)/2)].id
                            snap_to = listOfEdges[int((j-1)/2)].getVertices()[1]
                        else:
                            #conn_faces2 = len(listOfEdges[int((j+2)/2)].getConnectedFaces())
                            edge2_id=listOfEdges[int((j)/2)].id
                            snap_to = listOfEdges[int((j)/2)].getVertices()[0]
                    except Exception as e: 
                        print(e)
                        print("***breaking***")
                        continue
                    if k not in used and j not in used and snap_from.id not in used and snap_to.id not in used and snap_from.id != snap_to.id: #check conditions
                        distances.append(calcDist[k][j]) #used to check if same distance appears again (it should not be processed twice)
                        try: 
                            result = apex.geometry.dragVertex(
                                targetVertex = snap_from,
                                snapMode = apex.geometry.SnapModeType.Vertex,
                                location = snap_to.getLocation(),
                                snapEntity = snap_to,
                                dragVertexBehavior = apex.geometry.DragVertexBehavior.KeepCurved
                            )
                            used.append(snap_from.id)
                            used.append(snap_from.id)
                            used.append(k)
                            used.append(j)
                            print("Dragged ",snap_from.id," to ",snap_to.id, "| Edge 1: ",edge1_id,"| Edge 2: ",edge2_id)
                        except:
                            print("Dragging Failed 1")
                    else:
                        print("No conditions met")
        #print("Used List:   ", used)
    #apex.display.enableGraphicRefresh(True)

def main(dict={}):
    apex.disableShowOutput()
    if dict["doLength"] == 'True':
        SuppressEdgesByLength(dict)
        #print("Done Supressing by Length")
    
    if dict["doProxim"] == 'True':
        SuppressEdgesByProximity(dict)
        #print("Done Supressing by Proximity")
    
    if dict["doVerts"] == 'True':
        #We will do some passes of this function because it was observed that this is needed to make all vertex merge work
        i = 0
        for i in range(0,3):
            MergeEdges(dict)
            i+=1
            print("Next Pass")
        print("Done merging vertices")
    
    
    
    
    
import apex
from apex.construct import Point3D, Point2D
import os, re

apex.disableShowOutput()


def ExportBDF(dict={}):
    # ===================================================================
    ## Initializing Apex code
    apex.setScriptUnitSystem(unitSystemName=r'''mm-kg-s-N''')
    # Export mesh to BDF
    model_1 = apex.currentModel()
    pathToSave = dict["DirPath"]
    parts = apex.entityCollection()
    for item in apex.selection.getCurrentSelection():
        if item.entityType == apex.EntityType.Part:
            parts.append(item)
        if item.entityType == apex.EntityType.Assembly:
            parts.extend(item.getParts(True))
    for Part in parts:
        if "=" not in Part.getName():
            part_name = re.sub('[^A-z0-9 -_]', '', Part.getName()).replace(" ", " ") + ".bdf"
            if len(part_name) > 128:
                part_name = part_name[:124]+ ".bdf"
            file_name = os.path.join(pathToSave, part_name)
            if not os.path.exists(file_name):
                Part.exportFEModel(
                    filename = file_name,
                    unitSystem = "m-kg-s-N-K",
                )
            else:
                i = 1
                while True:
                    new_name = os.path.join(pathToSave, re.sub('[^A-z0-9 -_]', '', Part.getName()).replace(" ", " ") + "_" + str(i) + ".bdf")
                    if not os.path.exists(new_name):
                        Part.exportFEModel(
                            filename = new_name,
                            unitSystem = "m-kg-s-N-K",
                        )
                        break 
                    i += 1
    print("End exporting")
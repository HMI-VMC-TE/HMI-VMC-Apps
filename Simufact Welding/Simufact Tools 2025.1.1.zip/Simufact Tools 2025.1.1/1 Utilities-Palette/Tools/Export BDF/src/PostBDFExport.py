import sys
import apex
apex.enableShowOutput()

def printName(BDFPath = "name"):
    print("Name of the script: ", BDFPath)

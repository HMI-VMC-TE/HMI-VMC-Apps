import sys
import os
import apex_sdk
import clr

# .NET references
import System
from System.Windows.Forms import FolderBrowserDialog
import System.Windows.Controls as WPFControls
#from Microsoft.Win32 import FolderBrowserDialog

# Define current file path of example
current_file_path = os.path.dirname(os.path.realpath(__file__))

# Set pre-defined properties of ToolPropertyContainer
def getUIContent():
    my_toolProperty = apex_sdk.ToolPropertyContainer()
    my_toolProperty.TitleText = "Get trajectory from edge"
    my_toolProperty.TitleImageUriString = os.path.join(os.path.dirname(current_file_path), r"res\GetTrajectoryICON.png")
    my_toolProperty.WorkFlowInstructions = '''
        <p><strong><span style="color: #999999;">Get trajectory tool<br /></span></strong></p>
        <p><span style="color: #999999;">Description: This tool was designed to help extracting trajectory information to be used in Simufact Welding.<br /></span></p>
        <ul>
        <li><span style="color: #999999;"><span style="color: #00ccff;">Resolution</span>: Distance between each point in the trajectory. Straight trajectories will have a resolution 3 times bigger to avoid unecessary creation of points.</span></li>
        <li><span style="color: #999999;"><span style="color: #00ccff;">Write Part name to file</span>: Useful when selecting trajectory from 3D weld beads. This way you can connect more easily in Simufact the Trajectory/Bead pair</span><span style="color: #999999;"></span><span style="color: #999999;"></span></li>
        </ul>
        <p><span style="color: #999999;">Workflow:</span></p>
        <ol>
        <li><span style="color: #999999;">Select the edges you want to create trajectories from (one or multiple)<br /></span></li>
        <li><span style="color: #999999;">Define whether you need the part name in trajectory name by marking the checkbox<br /></span></li>
        <li><span style="color: #999999;">Click get trajectory from selected edge<br /></span></li>
        </ol>
        <p><span style="color: #999999;">For support: <a href="mailto:support.americas@simufact.com" style="color: #999999;"><span style="color: #ff0000;">support.americas@simufact.com</span></a></span></p>    <p><span style="color: #999999;"><span style="color: #ff0000;"></span></span></p>
        <p><span style="color: #999999;"><span style="color: #ff0000;"></span></span></p>
    '''

    # Define UI
    my_toolProperty.ToolPropertyContent = getCustomToolPropertyContent()

    # Handle apply button (green) click event
    my_toolProperty.AppliedCommand = apex_sdk.ActionCommand(System.Action(HandleApplyButton))

    # Define PickFilterList
    my_toolProperty.ShowPickChoice = True
    my_toolProperty.PickFilterList = setPickFilterList()

    return my_toolProperty


# Set PickFilters
def setPickFilterList():
    # Create an empty List of strings
    pickChoices = System.Collections.Generic.List[System.String]()

    # Exclusive picking and visibility picking
    pickChoices.Add(apex_sdk.PickFilterTypes.ExclusivePicking)
    pickChoices.Add(apex_sdk.PickFilterTypes.VisibilityPicking)

    # Add Types
    #pickChoices.Add(apex_sdk.PickFilterTypes.Part)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Solid)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Surface)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Face)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Cell)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Assembly)
    pickChoices.Add(apex_sdk.PickFilterTypes.Edge)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Curve)

    # Return the pick filter list
    return pickChoices


# Define Layout and Components
def getCustomToolPropertyContent():
    # Create a Grid
    my_Grid = WPFControls.Grid()

    # Add 2 Rows and 1 Column
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    #my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())

    currRow = 0

    # Create input field
    currRow += 1
    lbl01 = WPFControls.TextBlock()
    lbl01.Text = "Region diam. (mm):"
    WPFControls.Grid.SetRow(lbl01, currRow)
    WPFControls.Grid.SetColumn(lbl01, 0)

    global input01
    input01 = WPFControls.TextBox()
    WPFControls.Grid.SetRow(input01, currRow)
    WPFControls.Grid.SetColumn(input01, 1)

    # Create checkbox to calculate normal direction
    currRow += 1
    global chkBox01
    chkBox01 = WPFControls.CheckBox()
    chkBox01.Content = "Calculate normal directions"
    chkBox01.Height = 20
    WPFControls.Grid.SetRow(chkBox01, currRow)
    WPFControls.Grid.SetColumn(chkBox01, 0)
    chkBox01.IsChecked = System.Nullable[System.Boolean](True)
    #WPFControls.Grid.SetColumnSpan(chkBox01, 2)
    
    # Create input field
    currRow += 1
    lbl02 = WPFControls.TextBlock()
    lbl02.Text = "Resolution (mm):"
    WPFControls.Grid.SetRow(lbl02, currRow)
    WPFControls.Grid.SetColumn(lbl02, 0)

    global input02
    input02 = WPFControls.TextBox()
    WPFControls.Grid.SetRow(input02, currRow)
    WPFControls.Grid.SetColumn(input02, 1)
    input02.Text = "2.0"
    
    # Create checkbox to consolidate neighbor edges
    currRow += 1
    global chkBox02
    chkBox02 = WPFControls.CheckBox()
    chkBox02.Content = "Consolidate Neighbour Edges"
    chkBox02.Height = 20
    WPFControls.Grid.SetRow(chkBox02, currRow)
    WPFControls.Grid.SetColumn(chkBox02, 0)
    chkBox02.IsChecked = System.Nullable[System.Boolean](True)
    
    # Create checkbox to wrtie part name
    currRow += 1
    global chkBox03
    chkBox03 = WPFControls.CheckBox()
    chkBox03.Content = "Write Part name to file"
    chkBox03.Height = 20
    WPFControls.Grid.SetRow(chkBox03, currRow)
    WPFControls.Grid.SetColumn(chkBox03, 0)
    chkBox03.IsChecked = System.Nullable[System.Boolean](True)
   

    # Create a button
    currRow += 2
    goButton = WPFControls.Button()
    goButton.Content = "Get trajectory from selected edge"
    WPFControls.Grid.SetRow(goButton, currRow)
    WPFControls.Grid.SetColumn(goButton, 0)
    goButton.Height = 30
    WPFControls.Grid.SetColumnSpan(goButton, 2)

    # Link a function to the Button "Click" event
    # This function will be called every time the Button is clicked
    goButton.Click += HandleApplyButton

    global dialog
    dialog = FolderBrowserDialog()
    dialog.Description = "Directory where to save trajectories"
    dialog.ShowNewFolderButton = True

    #my_Grid.Children.Add(lbl01)
    #my_Grid.Children.Add(input01)
    #my_Grid.Children.Add(chkBox01)
    my_Grid.Children.Add(chkBox02)
    my_Grid.Children.Add(chkBox03)
    my_Grid.Children.Add(goButton)
    my_Grid.Children.Add(lbl02)
    my_Grid.Children.Add(input02)


    # Return the Grid
    return my_Grid


# Apply button handler (Green check mark)
# This function is called each time the Apply button is clicked
@apex_sdk.errorhandler
def HandleApplyButton(sender, args):
    # Create a Dictionary to store the user defined tool data
    dictionary = {}
    #dictionary["refDiam"] = input01.Text
    if dialog.ShowDialog():
        dictionary["saveToDir"] = str(dialog.SelectedPath)
    else:
        dictionary["saveToDir"] = ""

    dictionary["getNormalDirection"] = chkBox01.IsChecked
    dictionary["Consolidate"] = chkBox02.IsChecked
    dictionary["ParentName"] = chkBox03.IsChecked
    dictionary["pointDist"] = input02.Text
    apex_sdk.runScriptFunction(os.path.join(current_file_path, r"GetTrajectory.py"), "extractTrajectory", dictionary)

# coding: utf-8


import apex
from apex.construct import Point3D, Point2D
import sys
import math
import os
import numpy
import datetime as dt


#
# Start of recorded operations
#

def extractTrajectory(dict={}):
    apex.setScriptUnitSystem(unitSystemName=r'''mm-kg-s-N''')
    apex.disableShowOutput()
    model_1 = apex.currentModel()
    dirToSave = dict["saveToDir"]
    used = []    #list of edges already used
    selected = apex.EntityCollection()
    #Selected stores all selected edges 
    for edge in apex.selection.getCurrentSelection():
        selected.append(edge)
        #print("Selected edge ID:   ",edge.id)
      
    for selEdge in selected:
        print("\n***Starting to work in a new curve or set of curves\n")
        maxPointSpacing = float(dict["pointDist"])  # mm
        workingEdge = selEdge
        workingEdgeLength = workingEdge.getLength()
        _path = apex.EntityCollection()   #collection of connected curves to create a trajectory (instead of creating one by one) 
        
        #Logic to go to next edge in case the current one was already used
        if dict["Consolidate"] == "True":
            break_for = False   #aux varialble to break outer loop
            #print("Parent edge ID:  ",selEdge.id)
            if len(used)!=0:
                for i in range(len(used)):
                    if selEdge.entityType == apex.EntityType.Edge:      
                        if  used[i] == selEdge.id:                      #if edge id is in the group of edges already used/processed
                            print("     Edge from group already used, breaking ***")
                            break_for = True
                            
            if break_for == True:
                continue #goes to next edge   

        #Logic to figure out the individual edge groups to be added to the sweep path
        #If edges share vertices, it means they are a single "path" and should be connected
        verts = []
        if dict["Consolidate"] == 'True':
            _path.append(selEdge)
            used.append(selEdge.id)
            for edge in selected:
                if edge.id not in used and edge.getBody().getName() == selEdge.getBody().getName():   #Check for same parent 
                    for vert in selEdge.getVertices():
                        verts.append(vert.id)           
                    verts2 = []
                    for vert2 in edge.getVertices():
                        verts2.append(vert2.id)
                    #print("List of vertices in group2 :", verts2)
                    try:
                        if verts2[0] in verts or verts2[1] in verts:     #if vertices are both on reference edge, and selected edge, add them to _path   
                            verts.append(verts2[0])
                            verts.append(verts2[1])
                            _path.append(edge)
                            #print("appendded edge ",edge.id)
                            used.append(edge.id)  
                    except:
                        #print("Edges do not share vertices")
                        pass
            #print("List of vertices in group :", verts)
            #print("Path len before extending: ", len(_path))
            
            #We need to do aditional code to get also the edges that are not directly connected to the current edge
            #Hence we do some passes (for i in range) to make sure we get all edged in a path (this might be changed if path is too long)
            i=0
            for i in range(0,len(selected)):
                verts3 = []
                for edge in _path:  
                    for vert in edge.getVertices():
                        verts3.append(vert.id)
                #print("List of vertices3 in group :", verts3)
                for edge in selected:
                    verts4 = []
                    for vert in edge.getVertices():
                        verts4.append(vert.id)
                    #print("Verts4: ",verts4)
                    #print("Edge ID: ", edge.id, "  Used list: ", used)
                    if edge.id not in used and len(verts4) > 1:        #make sure the edge was not already used
                        if verts4[0] in verts3 or verts4[1] in verts3:  #if vertices are both on reference edge, and selected edge, add them to _path
                            #print("Found new edge")
                            _path.append(edge)
                            used.append(edge.id)
                i+=1
            #print("Path len after extending: ", len(_path))
            #print(used)
            #Add a vertex in case edge does not have any
            for edge in _path:
                if len(edge.getVertices()) == 0:
                    result = apex.geometry.addVertex(
                        target = edge,
                        locationTarget = edge.getMidPoint()
                    )
        else:
            _path.append(selEdge) #If we don't want to consolidate, we simply get the selected edge
            #Add a vertex in case edge does not have any
            if len(selEdge.getVertices()) == 0:
                result = apex.geometry.addVertex(
                    target = edge,
                    locationTarget = edge.getMidPoint()
                )

     
        #Start logic to reorder the edges
        
        if dict["Consolidate"] == "True":
            ordered_path = []
            all_ids = []
            used_ids = []
            i = 0
            end_reached = False #variable to break the loop in case we match the last vertex id
            for edge in _path:
                if len(edge.getVertices()) > 1:
                    all_ids.append(edge.getVertices()[0].id)
                    all_ids.append(edge.getVertices()[1].id)        #get all ids
                if len(edge.getVertices()) == 1:
                    all_ids.append(edge.getVertices()[0].id)
                    all_ids.append(edge.getVertices()[0].id)    #adding twice the same ID, since the beggining and end are the same
            #print("All edge IDS in path  ", all_ids)
            border_verts = list(set([x for x in all_ids if all_ids.count(x) == 1]))    # this line gets the IDs that appear only a single time in the list. Hence they are the border nodes
            if len(border_verts) != 0: #This means this is not a closed loop (we have border verts)
                for edge in _path:
                    if edge.getVertices()[0].id == border_verts[0]:
                        ordered_path.append(edge) #this is the first edge
                        next_id = edge.getVertices()[1].id  #this is the id of the next edge
                        used_ids.append(edge.id)
                    elif edge.getVertices()[1].id == border_verts[0]:
                        ordered_path.append(edge) #this is the first edge
                        next_id = edge.getVertices()[0].id  #this is the id of the next edge
                        used_ids.append(edge.id)
                for i in range(0,len(_path)-1):     #here we will iterate to append one edge at a time to the path. 
                    for edge in _path:
                        if end_reached == True: break
                        if edge.getVertices()[0].id == next_id and edge.id not in used_ids: #the edge will be appended if one of their vertexes is present in the last edge of the path
                            ordered_path.append(edge)
                            used_ids.append(edge.id)
                            next_id = edge.getVertices()[1].id
                            i+=1
                            if edge.getVertices()[1].id == border_verts[1]: #This is the last vertex ID, hence this path ended
                                end_reached = True
                        elif edge.getVertices()[1].id == next_id and edge.id not in used_ids:
                            ordered_path.append(edge)
                            used_ids.append(edge.id)
                            next_id = edge.getVertices()[0].id 
                            i+=1   
                            if edge.getVertices()[0].id == border_verts[1]:
                                end_reached = True                        
            else: #this means we have a closed loop
                print("A closed loop was identified")
                #For the closed loop path we do not know where it starts, so the code is simpler (just append one edge after another, until we have no edges left
                if len(_path) > 1:
                    for edge in _path:
                        ordered_path.append(edge) #this is the first edge
                        next_id = edge.getVertices()[1].id  #this is the id of the next edge
                        used_ids.append(edge.id)
                        break
                    for i in range(0,len(_path)-1):  
                        for edge in _path:
                            if edge.getVertices()[0].id == next_id and edge.id not in used_ids:
                                ordered_path.append(edge)
                                used_ids.append(edge.id)
                                next_id = edge.getVertices()[1].id
                                i+=1
                            elif edge.getVertices()[1].id == next_id and edge.id not in used_ids:
                                ordered_path.append(edge)
                                used_ids.append(edge.id)
                                next_id = edge.getVertices()[0].id 
                                i+=1
                elif len(_path) == 1:
                    ordered_path = _path
        else:
            ordered_path = _path #we don't need to reorder anything if we are not consolidating
            
            
        
        #Now we start writing the actual trajectory
        
        #Now use the path of edges to create the trajectory files
        if dict["ParentName"] == 'True':
            if selEdge.entityType != apex.EntityType.Edge:
                dict["getNormalDirection"] = "False"
                trajName = f"Trajectory_{selEdge.getName()}_{selEdge.getBody().getParent().getName()}.csv"
            else:
                trajName = f"Trajectory_{selEdge.getId()}_{selEdge.getBody().getParent().getName()}.csv"
        else:
            if selEdge.entityType != apex.EntityType.Edge:
                dict["getNormalDirection"] = "False"
                trajName = f"Trajectory_{selEdge.getName()}.csv"
            else:
                trajName = f"Trajectory_{selEdge.getId()}.csv"

        pathToSaveFile = os.path.join(dirToSave, trajName)

        # -Get the correct file header from a Simufact trajectory
        trajHeader = "# CSV file produced by the Welding Toolkit on MSC Apex"
        trajHeader += f"\n# Date of creation: {dt.datetime.now().strftime('%Y-%m-%d %H:%M')}"
        trajHeader += "\n# Length unit: Meter [m]"
        trajHeader += "\n#"
        trajHeader += "\n# Orientation: 0 - global vector ; 1 - local vector; 2 - local second point"
        trajHeader += "\n1"
        trajHeader += "\n#"
        trajHeader += "\n# order;activity;x-coordinate;y-coordinate;z-coordinate;x-second point;y-second point;z-second point"

        trajBuild = trajHeader
        
        j = 0
        if dict["getNormalDirection"] == 'True':
            reverse_first = False   #variable to check if the direction of the first edge needs to be corrected
            first_id = ordered_path[0].id
            if len(ordered_path) > 1:
                #this block is solely to check if the orientation of the first edge will be inverted in relation  to the second edge
                coord11 = ordered_path[0].evaluateEdgeParametricCoordinate(ordered_path[0].getParametricRange()['uStart'])
                coord12 = ordered_path[0].evaluateEdgeParametricCoordinate(ordered_path[0].getParametricRange()['uEnd'])
                coord21= ordered_path[1].evaluateEdgeParametricCoordinate(ordered_path[1].getParametricRange()['uStart'])
                coord22=ordered_path[1].evaluateEdgeParametricCoordinate(ordered_path[1].getParametricRange()['uEnd'])
                p1 = [round(coord11.x,4),round(coord11.y,4),round(coord11.z,4)]
                p2 = [round(coord12.x,4),round(coord12.y,4),round(coord12.z,4)]
                pref = p2   #Reference point is the end point of the current edge
                p21 =[round(coord21.x,4),round(coord21.y,4),round(coord21.z,4)]
                p22 = [round(coord22.x,4),round(coord22.y,4),round(coord22.z,4)]
                #We will need to add a lot of conditions because we want to enable a tolerance
                if math.isclose(p1[0], p21[0],rel_tol=0.001) and math.isclose(p1[1], p21[1],rel_tol=0.001) and math.isclose(p1[2], p21[2],rel_tol=0.001):
                    reverse_first = True
                    pref = p1
                    print("True")
                if math.isclose(p1[0], p22[0],rel_tol=0.001) and math.isclose(p1[1], p22[1],rel_tol=0.001) and math.isclose(p1[2], p22[2],rel_tol=0.001):
                    reverse_first = True
                    pref = p1                    
                    print("True")                    
            # Now we start iterating over the other edges. If the end point of one edge, is not the first point of the next edge, it means the next edge needs to be inverted       
                for workingEdge in ordered_path:
                        workingEdgeLength = workingEdge.getLength()
                        print("Working edge ID:   ",workingEdge.id)
                        # -Getting faces that are connected to this edge (at least three will come up)
                        proxSearch = apex.utility.ProximitySearch()
                        listOfConnectedFaces = workingEdge.getConnectedFaces()
                        ans = proxSearch.insertCollection(listOfConnectedFaces)
                        
                        # -Find the face on which the edge is lying on top (should be only one)
                        edgeMidpoint = workingEdge.getMidPoint()
                        edgeCentroid = workingEdge.getCentroid()
                        resSearch = proxSearch.findNearestObjects(location=edgeMidpoint, numObjects=1)
                        selectedFace = ""
                        for elem in resSearch.foundObjects():
                            selectedFace = elem
                            
                        #Decide if this is a curve or not
                        is_curve = True
                        x1,y1,z1 = edgeMidpoint.x,edgeMidpoint.y,edgeMidpoint.z
                        x2,y2,z2 = edgeCentroid.x,edgeCentroid.y,edgeCentroid.z
                        #print(x1,x2,y1,y2,z1,z2)
                        if math.isclose(x1, x2,rel_tol=0.001) and math.isclose(y1, y2,rel_tol=0.001) and math.isclose(z1, z2,rel_tol=0.001):
                            is_curve = False
                            #print("not a curve")

                        # -Define trajectory characteristics
                        if is_curve == True:
                            trajStep = int(workingEdgeLength / maxPointSpacing)
                            trajResolution = trajStep + 1 if trajStep > 2 else 3
                        elif is_curve == False:
                            trajStep = int(workingEdgeLength / (maxPointSpacing*3)) #Uses a spacing 3 times bigger if it is not a curve
                            trajResolution = trajStep + 1 if trajStep > 2 else 3
                        else:
                            trajResolution = 4
                        paramRange = workingEdge.getParametricRange()
                        delta = abs(paramRange['uEnd'] - paramRange['uStart']) / trajResolution
                        sampling = [(x * delta) + paramRange['uStart'] for x in range(0, trajResolution + 1)]

                        # -Build trajectory information
                        trajInfo = []
                        for i in range(len(sampling)):
                            pointCoord = [workingEdge.evaluateEdgeParametricCoordinate(sampling[i]).x / 1000,
                                          # Converting to meters
                                          workingEdge.evaluateEdgeParametricCoordinate(sampling[i]).y / 1000,
                                          # Converting to meters
                                          workingEdge.evaluateEdgeParametricCoordinate(sampling[i]).z / 1000]  # Converting to meters

                            pointResolve = apex.Coordinate(pointCoord[0] * 1000,  # Converting to mm
                                                           pointCoord[1] * 1000,  # Converting to mm
                                                           pointCoord[2] * 1000)  # Converting to mm
                            try:
                                paramU = selectedFace.evaluatePointOnFace(pointResolve).u
                                paramV = selectedFace.evaluatePointOnFace(pointResolve).v
                                normalAtPoint = selectedFace.evaluateNormal(paramU, paramV)
                                pointDir = [normalAtPoint.x, normalAtPoint.y, normalAtPoint.z]
                            except:
                                pointDir = [1.0,0.0,0.0]
                            trajInfo.append(pointCoord + pointDir)
                        
                        
                        # Here we check if end point of edge 1 is the same as start point of edge 2. If not, we inver the trajectory                    
                        coordi1 = workingEdge.evaluateEdgeParametricCoordinate(workingEdge.getParametricRange()['uStart'])
                        coordi2 = workingEdge.evaluateEdgeParametricCoordinate(workingEdge.getParametricRange()['uEnd'])
                        pi1 = [round(coordi1.x,4),round(coordi1.y,4),round(coordi1.z,4)]
                        pi2 = [round(coordi2.x,4),round(coordi2.y,4),round(coordi2.z,4)]
                        print(pref,pi1,pi2)
                        if workingEdge.id == first_id and reverse_first == True:
                            trajInfo = trajInfo[::-1]
                            print("Reversing first")
                            
                        #if workingEdge.id != first_id and pref == pi2:
                        if workingEdge.id != first_id and math.isclose(pref[0], pi2[0],rel_tol=0.001) and math.isclose(pref[1], pi2[1],rel_tol=0.001) and math.isclose(pref[2], pi2[2],rel_tol=0.001):
                            print("Inverting direction")
                            trajInfo = trajInfo[::-1] #Inverting traj direction if needed
                            pref = pi1   #Reference point is the end point of the current edge
                        elif workingEdge.id != first_id:
                            pref = pi2   #Reference point is the end point of the current edge

                        # Now that the order and direction are correct, we can efectivelly write the lines to the csv file (phew!)
                        for i in range(len(trajInfo)):
                            lineBuild = f"\n{j + 1};true;{trajInfo[i][0]};{trajInfo[i][1]};{trajInfo[i][2]};{trajInfo[i][3]};{trajInfo[i][4]};{trajInfo[i][5]}"
                            trajBuild += lineBuild                    
                            j+=1
                        
                        trajBuild += "\n#next edge"
                        
                        # -Write the trajectory file
                        if pathToSaveFile:
                            with open(pathToSaveFile, 'w') as newTrajFile:
                                newTrajFile.write(trajBuild)
                print("\nCreated ",trajName,"\n")
            else:
                # -Getting faces that are connected to this edge (at least three will come up)
                proxSearch = apex.utility.ProximitySearch()
                listOfConnectedFaces = workingEdge.getConnectedFaces()
                ans = proxSearch.insertCollection(listOfConnectedFaces)

                # -Find the face on which the edge is lying on top (should be only one)
                edgeMidpoint = workingEdge.getMidPoint()
                edgeCentroid = workingEdge.getCentroid()
                resSearch = proxSearch.findNearestObjects(location=edgeMidpoint, numObjects=1)
                selectedFace = ""
                for elem in resSearch.foundObjects():
                    selectedFace = elem
                    
                #Decide if this is a curve or not
                is_curve = True
                x1,y1,z1 = edgeMidpoint.x,edgeMidpoint.y,edgeMidpoint.z
                x2,y2,z2 = edgeCentroid.x,edgeCentroid.y,edgeCentroid.z
                #print(x1,x2,y1,y2,z1,z2)
                if math.isclose(x1, x2,rel_tol=0.001) and math.isclose(y1, y2,rel_tol=0.001) and math.isclose(z1, z2,rel_tol=0.001):
                    is_curve = False
                    #print("not a curve")

                # -Define trajectory characteristics
                if is_curve == True:
                    trajStep = int(workingEdgeLength / maxPointSpacing)
                    trajResolution = trajStep + 1 if trajStep > 2 else 3
                elif is_curve == False:
                    trajStep = int(workingEdgeLength / (maxPointSpacing*3)) #Uses a spacing 3 times bigger if it is not a curve
                    trajResolution = trajStep + 1 if trajStep > 2 else 3
                else:
                    trajResolution = 4
                paramRange = workingEdge.getParametricRange()
                delta = abs(paramRange['uEnd'] - paramRange['uStart']) / trajResolution
                sampling = [(x * delta) + paramRange['uStart'] for x in range(0, trajResolution + 1)]

                # -Build trajectory information
                trajInfo = []
                for i in range(len(sampling)):
                    pointCoord = [workingEdge.evaluateEdgeParametricCoordinate(sampling[i]).x / 1000,
                                  # Converting to meters
                                  workingEdge.evaluateEdgeParametricCoordinate(sampling[i]).y / 1000,
                                  # Converting to meters
                                  workingEdge.evaluateEdgeParametricCoordinate(
                                      sampling[i]).z / 1000]  # Converting to meters

                    pointResolve = apex.Coordinate(pointCoord[0] * 1000,  # Converting to mm
                                                   pointCoord[1] * 1000,  # Converting to mm
                                                   pointCoord[2] * 1000)  # Converting to mm
                    try:
                        paramU = selectedFace.evaluatePointOnFace(pointResolve).u
                        paramV = selectedFace.evaluatePointOnFace(pointResolve).v
                        normalAtPoint = selectedFace.evaluateNormal(paramU, paramV)
                        pointDir = [normalAtPoint.x, normalAtPoint.y, normalAtPoint.z]
                    except:
                        pointDir = [1.0,0.0,0.0]
                    trajInfo.append(pointCoord + pointDir)

                for i in range(len(trajInfo)):
                    lineBuild = f"\n{i + 1};true;{trajInfo[i][0]};{trajInfo[i][1]};{trajInfo[i][2]};{trajInfo[i][3]};{trajInfo[i][4]};{trajInfo[i][5]}"
                    trajBuild += lineBuild

                # -Write the trajectory file
                if pathToSaveFile:
                    with open(pathToSaveFile, 'w') as newTrajFile:
                        newTrajFile.write(trajBuild)
                
        '''        
        else: #This option has been removed from the GUI and will no longer have an effect
            # -Define trajectory characteristics
            if maxPointSpacing > 0:
                trajStep = int(workingEdgeLength / maxPointSpacing)
                trajResolution = trajStep + 1 if trajStep > 2 else 3
            else:
                trajResolution = 4
            paramRange = workingEdge.getParametricRange()
            delta = abs(paramRange['uEnd'] - paramRange['uStart']) / trajResolution
            sampling = [(x * delta) + paramRange['uStart'] for x in range(0, trajResolution + 1)]

            # -Build trajectory information
            trajInfo = []
            for i in range(len(sampling)):
                pointCoord = [workingEdge.evaluateEdgeParametricCoordinate(sampling[i]).x / 1000,
                              # Converting to meters
                              workingEdge.evaluateEdgeParametricCoordinate(sampling[i]).y / 1000,
                              # Converting to meters
                              workingEdge.evaluateEdgeParametricCoordinate(sampling[i]).z / 1000]  # Converting to meters
                trajInfo.append(pointCoord)

            for i in range(len(trajInfo)):
                lineBuild = f"\n{j + 1};true;{trajInfo[i][0]};{trajInfo[i][1]};{trajInfo[i][2]};0.0;0.0;1.0"
                trajBuild += lineBuild
                j+=1

            # -Write the trajectory file
            if pathToSaveFile:
                with open(pathToSaveFile, 'w') as newTrajFile:
                    newTrajFile.write(trajBuild)
        '''
                    
    print("\nIf you get Permission Error 13, please close the CSV file and run again")

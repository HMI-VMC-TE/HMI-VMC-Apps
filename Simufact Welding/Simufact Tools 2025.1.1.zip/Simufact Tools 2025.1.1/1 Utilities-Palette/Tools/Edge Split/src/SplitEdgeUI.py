import sys
import os
import apex_sdk
import clr

# .NET references
import System
from System.Windows.Forms import FolderBrowserDialog
import System.Windows.Controls as WPFControls
#from Microsoft.Win32 import FolderBrowserDialog

# Define current file path of example
current_file_path = os.path.dirname(os.path.realpath(__file__))


# Set pre-defined properties of ToolPropertyContainer
def getUIContent():
    my_toolProperty = apex_sdk.ToolPropertyContainer()
    my_toolProperty.TitleText = "  Split Edge"
    my_toolProperty.TitleImageUriString = os.path.join(os.path.dirname(current_file_path), r"res\dashed3.png")
    my_toolProperty.WorkFlowInstructions = '''
        <p><strong><span style="color: #999999;">Split Edge Tool<br /></span></strong></p>
        <p><span style="color: #999999;">Description: This tool was designed to split an edge to create an intermittent pattern. After using this tool, you can use the Get Trajectory tool to easily create the trajectories.<br /></span></p>
        <ul>
        <li><span style="color: #999999;"><span style="color: #00ccff;">Offset in mm</span>: Offset from start</span></li>
        <li><span style="color: #999999;"><span style="color: #00ccff;">Bead length</span>: Size of the actual weld bead in mm</span></li>
        <li><span style="color: #999999;"><span style="color: #00ccff;">Gap</span>: Distance between end of one bead to the start of the next</span></li>
        <li><span style="color: #999999;"><span style="color: #00ccff;">Number of beads</span>: Total number of beads in this edge</span></li>
        <li><span style="color: #999999;"><span style="color: #00ccff;">Reverse direction</span>: Starts split from opposite end of edge</span></li>
        </ul>
        <p><span style="color: #999999;">Workflow:</span></p>
        <ol>
        <li><span style="color: #999999;">Enter dimensions of the intermittent pattern<br /></span></li>
        <li><span style="color: #999999;">Select edge to split<br /></span></li>
        <li><span style="color: #999999;">Click on "Split edge" button<br /></span></li>
        </ol>
        <p><span style="color: #999999;">For support: <a href="mailto:support.americas@simufact.com" style="color: #999999;"><span style="color: #ff0000;">support.americas@simufact.com</span></a></span></p>    <p><span style="color: #999999;"><span style="color: #ff0000;"></span></span></p>
        <p><span style="color: #999999;"><span style="color: #ff0000;"></span></span></p>
    '''

    # Define UI
    my_toolProperty.ToolPropertyContent = getCustomToolPropertyContent()

    # Handle apply button (green) click event
    my_toolProperty.AppliedCommand = apex_sdk.ActionCommand(System.Action(HandleApplyButton))

    # Define PickFilterList
    my_toolProperty.ShowPickChoice = True
    my_toolProperty.PickFilterList = setPickFilterList()

    return my_toolProperty


# Set PickFilters
def setPickFilterList():
    # Create an empty List of strings
    pickChoices = System.Collections.Generic.List[System.String]()

    # Exclusive picking and visibility picking
    pickChoices.Add(apex_sdk.PickFilterTypes.ExclusivePicking)
    pickChoices.Add(apex_sdk.PickFilterTypes.VisibilityPicking)

    # Add Types
    #pickChoices.Add(apex_sdk.PickFilterTypes.Part)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Solid)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Surface)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Face)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Cell)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Assembly)
    pickChoices.Add(apex_sdk.PickFilterTypes.Edge)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Curve)

    # Return the pick filter list
    return pickChoices


# Define Layout and Components
def getCustomToolPropertyContent():
    # Create a Grid
    my_Grid = WPFControls.Grid()

    # Add 2 Rows and 1 Column
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    #my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())

    currRow = 0

    # Create input field
    currRow += 1
    lbl01 = WPFControls.TextBlock()
    lbl01.Text = "Offset (mm):"
    WPFControls.Grid.SetRow(lbl01, currRow)
    WPFControls.Grid.SetColumn(lbl01, 0)
    my_Grid.Children.Add(lbl01)

    global input01
    input01 = WPFControls.TextBox()
    WPFControls.Grid.SetRow(input01, currRow)
    WPFControls.Grid.SetColumn(input01, 1)
    my_Grid.Children.Add(input01)
    input01.Text = "0.0"
    
    # Create input field
    currRow += 1
    lbl02 = WPFControls.TextBlock()
    lbl02.Text = "Bead Size (mm):"
    WPFControls.Grid.SetRow(lbl02, currRow)
    WPFControls.Grid.SetColumn(lbl02, 0)
    my_Grid.Children.Add(lbl02)

    global input02
    input02 = WPFControls.TextBox()
    WPFControls.Grid.SetRow(input02, currRow)
    WPFControls.Grid.SetColumn(input02, 1)
    my_Grid.Children.Add(input02)  
    input02.Text = "10.0"

    # Create input field
    currRow += 1
    lbl03 = WPFControls.TextBlock()
    lbl03.Text = "Gap (mm):"
    WPFControls.Grid.SetRow(lbl03, currRow)
    WPFControls.Grid.SetColumn(lbl03, 0)
    my_Grid.Children.Add(lbl03)

    global input03
    input03 = WPFControls.TextBox()
    WPFControls.Grid.SetRow(input03, currRow)
    WPFControls.Grid.SetColumn(input03, 1)
    my_Grid.Children.Add(input03) 
    input03.Text = "30.0"
    
    # Create input field
    currRow += 1
    lbl04 = WPFControls.TextBlock()
    lbl04.Text = "Number of Beads:"
    WPFControls.Grid.SetRow(lbl04, currRow)
    WPFControls.Grid.SetColumn(lbl04, 0)
    my_Grid.Children.Add(lbl04)

    global input04
    input04 = WPFControls.TextBox()
    WPFControls.Grid.SetRow(input04, currRow)
    WPFControls.Grid.SetColumn(input04, 1)
    my_Grid.Children.Add(input04)
    input04.Text = "5"    
    
    currRow += 1
    global check01
    check01 = WPFControls.CheckBox()
    check01.Content = "Reverse direction"
    check01.Height = 30
    WPFControls.Grid.SetRow(check01, currRow)
    WPFControls.Grid.SetColumn(check01, 0)
    WPFControls.Grid.SetColumnSpan(check01, 3)
    check01.IsChecked = System.Nullable[System.Boolean](False)
    my_Grid.Children.Add(check01)

    # Create a button
    currRow += 1
    actionButton = WPFControls.Button()
    actionButton.Content = "Split edge"
    WPFControls.Grid.SetRow(actionButton, currRow)
    WPFControls.Grid.SetColumn(actionButton, 0)
    actionButton.Height = 30
    WPFControls.Grid.SetColumnSpan(actionButton, 2)
    actionButton.Click += HandleApplyButton         # Link a function to the Button "Click" event   
    my_Grid.Children.Add(actionButton)    




    # Return the Grid
    return my_Grid


# Apply button handler (Green check mark)
# This function is called each time the Apply button is clicked
@apex_sdk.errorhandler
def HandleApplyButton(sender, args):
    # Create a Dictionary to store the user defined tool data
    dictionary = {}
    dictionary["offset"] = input01.Text
    dictionary["size"] = input02.Text
    dictionary["gap"] = input03.Text
    dictionary["number"] = input04.Text
    dictionary["reverse"] = check01.IsChecked
    apex_sdk.runScriptFunction(os.path.join(current_file_path, r"SplitEdge.py"), "splitEdge", dictionary)

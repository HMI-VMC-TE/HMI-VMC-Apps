# coding: utf-8


import apex
from apex.construct import Point3D, Point2D
import math


#
# Start of recorded operations
#
def distance(v1,v2):
    return sqrt(((v1[0]-v2[0])**2)+((v1[1]-v2[1])**2)+((v1[2]-v2[2])**2))
    

def splitEdge(dict={}):
    apex.setScriptUnitSystem(unitSystemName=r'''mm-kg-s-N''')
    apex.disableShowOutput()
    model_1 = apex.currentModel()
    offset = float(dict["offset"])
    size = float(dict["size"])
    gap = float(dict["gap"])
    number = float(dict["number"])
    reverse = dict["reverse"]
    
    #Start actual work  
    for selEdge in apex.selection.getCurrentSelection():
        verts=apex.EntityCollection()
        points=apex.EntityCollection()
        uStart =  selEdge.getParametricRange()['uStart']
        print("U Start: ", uStart)
        uEnd = selEdge.getParametricRange()['uEnd']
        print("U End: ", uEnd)
        length = selEdge.getLength()
        print("Length: ", length)
        evaluate = selEdge.evaluatePointOnEdge(selEdge.getLocation())
        print("Evaluate returns: ", evaluate)
        np = int(number) #number of points
        print("Number of beads: ",np)
        
        #if reverse
        if reverse == 'True':
            temp = uStart
            uStart = uEnd
            uEnd = temp 
            print("Reversing")
        
        #Create first point (offset)
        u_ref = (((uEnd-uStart)*offset)/length)+uStart
        coord1 = selEdge.evaluateEdgeParametricCoordinate(u_ref)
        p1 = apex.geometry.createPointXYZ( x = coord1.x, y = coord1.y, z = coord1.z )
        verts.append(p1.vertices[0])
        points.append(p1)
        
        
        #Create points for actual beads
        i = 0
        for i in range(0,np):
            u1 = u_ref + (((uEnd-uStart)*size)/length)
            u2 = u1 + (((uEnd-uStart)*gap)/length)
            print("U1: ",u1," | U2: ",u2)
            #Create points for not reversed logic
            if reverse == 'False' and uStart <= u1 and u1 <= uEnd:
                coord = selEdge.evaluateEdgeParametricCoordinate(u1)
                point = apex.geometry.createPointXYZ( x = coord.x, y = coord.y, z = coord.z )
                verts.append(point.vertices[0])
                points.append(point)
                if i<np-1 and uStart <= u2 and u2 <= uEnd:
                    coord = selEdge.evaluateEdgeParametricCoordinate(u2)
                    point = apex.geometry.createPointXYZ( x = coord.x, y = coord.y, z = coord.z )
                    verts.append(point.vertices[0])   
                    points.append(point)
            #If reverse is on, we need to change check signal       
            elif reverse == 'True' and uStart >= u1 and u1 >= uEnd:
                coord = selEdge.evaluateEdgeParametricCoordinate(u1)
                point = apex.geometry.createPointXYZ( x = coord.x, y = coord.y, z = coord.z )
                verts.append(point.vertices[0])
                points.append(point)
                if i<np-1 and uStart >= u2 and u2 >= uEnd:
                    coord = selEdge.evaluateEdgeParametricCoordinate(u2)
                    point = apex.geometry.createPointXYZ( x = coord.x, y = coord.y, z = coord.z )
                    verts.append(point.vertices[0])   
                    points.append(point)
            i+=1
            u_ref = u2
            
        #Actually do the split
        _target = apex.EntityCollection()
        _target.append(selEdge)
        result = apex.geometry.splitCurvesWithPoints(
            target = _target,
            splitter = verts,
            useOnlyNearbySplitters = False
        )        
        apex.deleteEntities(points)
            
        






# part_1 = apex.getPart( pathName = apex.currentModel().name + "/Part 3" )
# body_1 = part_1.getSolid( name = "Box 1" )
# _target = body_1.getEdge( id = 227510 )
# _location = apex.Coordinate( 2.9951559451349752e+01, 2.000000000000000e+02, 2.000000000000000e+02 )
# result = apex.geometry.addVertex(
    # target = _target,
    # locationTarget = _location
# )
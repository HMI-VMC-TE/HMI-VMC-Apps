# coding: utf-8


import apex
from apex.construct import Point3D, Point2D
import sys
from math import sqrt, pow, degrees, acos, pi
import os

apex.setScriptUnitSystem(unitSystemName = r'''mm-kg-s-N''')
model_1 = apex.currentModel()
apex.disableShowOutput()
#
# Start of recorded operations
#

def createRefRegion(dict={}):
    model_1 = apex.currentModel()

    ### Math functions needed when numpy is not available
    def multip3D(v1, k):  # Addition of two ponts in 3D
        return [x * k for x in v1]

    def add3D(v1, v2):  # Addition of two ponts in 3D
        return [x + y for x, y in zip(v1, v2)]

    def subtract3D(v1, v2):  # Subtraction of two ponts in 3D
        return [x - y for x, y in zip(v1, v2)]

    def distance3D(v1, v2):  # Distance between two points in 3D
        return sqrt(abs(sum((a - b) for a, b in zip(v1, v2))))

    def dotproduct(v1, v2):  # Dot product of two vectors (list), cosine of the angle
        return sum((a * b) for a, b in zip(v1, v2))

    def length(v):  # Length of a vector (list)
        return sqrt(dotproduct(v, v))

    def angle(v1, v2):  # Angle between two vectors in degrees (lists)
        return degrees(acos(dotproduct(v1, v2) / (length(v1) * length(v2))))  # Return the angle in degrees

    def cross(a, b):  # Cross-product (orthogonal vector) of two vectors (list)
        c = [a[1] * b[2] - a[2] * b[1],
             a[2] * b[0] - a[0] * b[2],
             a[0] * b[1] - a[1] * b[0]]
        return c  # List of three components (x,y,z) of the orthogonal vector

    def doCircle(diam=8.0):
        part_1 = model_1.getCurrentPart()
        if part_1 is None:
            part_1 = model_1.createPart()
        sketch_1 = part_1.createSketchOnGlobalPlane(
            name='',
            plane=apex.construct.GlobalPlane.YZ,
            alignSketchViewWithViewport=False
        )

        circle_1 = sketch_1.createCircleCenterPoint(
            name="",
            centerPoint=Point2D(0, 0),
            pointOnCircle=Point2D(0, diam / 2)
        )
        return sketch_1.completeSketch(fillSketches=True)


    try:
        refDiameter = float(dict["refDiam"])
    except:
        apex.enableShowOutput()
        print("\nInvalid diameter value!")
        raise

    try:
        TrajAssy = model_1.getAssembly(pathName="Refinement regions")
    except:
        TrajAssy = model_1.createAssembly(name="Refinement regions")

    try:
        if TrajAssy.getPart(name=f"RefDiam_{refDiameter}"):
            pass
        else:
            SpecifiedDiameter = TrajAssy.createPart(name=f"RefDiam_{refDiameter}")
    except:
        print("Part creation failed!")

    used = []
    selected = apex.EntityCollection()
    for edge in apex.selection.getCurrentSelection():
        selected.append(edge)
        
    for selEdge in selected:
        print("\nStart Next")
        CurrPart = apex.createPart(name="Edge_{0}_{1}mm".format(selEdge.getId(), refDiameter))
        CurrPart.setParent(TrajAssy)
        
        #logic to go to next edge in case the current one was already used
        if dict["MergeCurves"] == "True":
            break_for = False
            #print("Parent edge ID:  ",selEdge.id)
            if len(used)!=0:
                for i in range(len(used)):
                    if  used[i] == selEdge.id:
                        #print("Edge from group already used, breaking ***")
                        break_for = True
            if break_for == True:
                CurrPart.delete()
                continue

        #Logic to figure out the individual edge groups to be added to the sweep path
        #If edges share vertices, it means they are a single "path" and should be connected
        verts = []
        _path = apex.EntityCollection()
        if dict["MergeCurves"] == 'True':
            _path.append(selEdge)
            used.append(selEdge.id)
            for edge in selected:
                if edge.id not in used and edge.getBody().getName() == selEdge.getBody().getName():   #Check for same parent 
                    for vert in selEdge.getVertices():
                        verts.append(vert.id)           
                    verts2 = []
                    for vert2 in edge.getVertices():
                        verts2.append(vert2.id)
                    #print("List of vertices in group2 :", verts2)
                    try:
                        if verts2[0] in verts or verts2[1] in verts:     #if vertices are both on reference edge, and selected edge, add them to _path   
                            verts.append(verts2[0])
                            verts.append(verts2[1])
                            _path.append(edge)
                            #print("appendded edge ",edge.id)
                            used.append(edge.id)  
                    except:
                        #print("Edges do not share vertices")
                        pass
            #print("List of vertices in group :", verts)
            #print("Path len before extending: ", len(_path))
            
            #We need to do aditional code to get also the edges that are not directly connected to the current edge
            #Hence we do some passes (for i in range) to make sure we get all edged in a path (this might be changed if path is too long)
            i=0
            for i in range(0,len(selected)):
                verts3 = []
                for edge in _path:  
                    for vert in edge.getVertices():
                        verts3.append(vert.id)
                #print("List of vertices3 in group :", verts3)
                for edge in selected:
                    verts4 = []
                    for vert in edge.getVertices():
                        verts4.append(vert.id)
                    #print("Verts4: ",verts4)
                    #print("Edge ID: ", edge.id, "  Used list: ", used)
                    if edge.id not in used and len(verts4) > 1:        #make sure the edge was not already used
                        if verts4[0] in verts3 or verts4[1] in verts3:  #if vertices are both on reference edge, and selected edge, add them to _path
                            #print("Found new edge")
                            _path.append(edge)
                            used.append(edge.id)
                i+=1
            #print("Path len after extending: ", len(_path))
            #print(used)
            #Add a vertex in case edge does not have any
            for edge in _path:
                if len(edge.getVertices()) == 0:
                    result = apex.geometry.addVertex(
                        target = edge,
                        locationTarget = edge.getMidPoint()
                    )
        else:
            _path.append(selEdge) #If we don't want to consolidate, we simply get the selected edge
            #Add a vertex in case edge does not have any
            if len(selEdge.getVertices()) == 0:
                result = apex.geometry.addVertex(
                    target = edge,
                    locationTarget = edge.getMidPoint()
                )

        #Start logic to reorder the edges
        if dict["MergeCurves"] == "True":
            ordered_path = []
            all_ids = []
            used_ids = []
            i = 0
            end_reached = False #variable to break the loop in case we match the last vertex id
            for edge in _path:
                if len(edge.getVertices()) > 1:
                    all_ids.append(edge.getVertices()[0].id)
                    all_ids.append(edge.getVertices()[1].id)        #get all ids
                if len(edge.getVertices()) == 1:
                    all_ids.append(edge.getVertices()[0].id)
                    all_ids.append(edge.getVertices()[0].id)    #adding twice the same ID, since the beggining and end are the same
            #print("All edge IDS in path  ", all_ids)
            border_verts = list(set([x for x in all_ids if all_ids.count(x) == 1]))    # this line gets the IDs that appear only a single time in the list. Hence they are the border nodes
            if len(border_verts) != 0: #This means this is not a closed loop (we have border verts)
                for edge in _path:
                    if edge.getVertices()[0].id == border_verts[0]:
                        ordered_path.append(edge) #this is the first edge
                        next_id = edge.getVertices()[1].id  #this is the id of the next edge
                        used_ids.append(edge.id)
                    elif edge.getVertices()[1].id == border_verts[0]:
                        ordered_path.append(edge) #this is the first edge
                        next_id = edge.getVertices()[0].id  #this is the id of the next edge
                        used_ids.append(edge.id)
                for i in range(0,len(_path)-1):     #here we will iterate to append one edge at a time to the path. 
                    for edge in _path:
                        if end_reached == True: break
                        if edge.getVertices()[0].id == next_id and edge.id not in used_ids: #the edge will be appended if one of their vertexes is present in the last edge of the path
                            ordered_path.append(edge)
                            used_ids.append(edge.id)
                            next_id = edge.getVertices()[1].id
                            i+=1
                            if edge.getVertices()[1].id == border_verts[1]: #This is the last vertex ID, hence this path ended
                                end_reached = True
                        elif edge.getVertices()[1].id == next_id and edge.id not in used_ids:
                            ordered_path.append(edge)
                            used_ids.append(edge.id)
                            next_id = edge.getVertices()[0].id 
                            i+=1   
                            if edge.getVertices()[0].id == border_verts[1]:
                                end_reached = True                        
            else: #this means we have a closed loop
                print("A closed loop was identified")
                #For the closed loop path we do not know where it starts, so the code is simpler (just append one edge after another, until we have no edges left
                if len(_path) > 1:
                    for edge in _path:
                        ordered_path.append(edge) #this is the first edge
                        next_id = edge.getVertices()[1].id  #this is the id of the next edge
                        used_ids.append(edge.id)
                        break
                    for i in range(0,len(_path)-1):  
                        for edge in _path:
                            if edge.getVertices()[0].id == next_id and edge.id not in used_ids:
                                ordered_path.append(edge)
                                used_ids.append(edge.id)
                                next_id = edge.getVertices()[1].id
                                i+=1
                            elif edge.getVertices()[1].id == next_id and edge.id not in used_ids:
                                ordered_path.append(edge)
                                used_ids.append(edge.id)
                                next_id = edge.getVertices()[0].id 
                                i+=1
                elif len(_path) == 1:
                    ordered_path = _path
        else:
            ordered_path = _path #we don't need to reorder anything if we are not consolidating
          
        
        #Start creating point list of the edge (will be used later)
        maxPointSpacing = 2 #mm
        if maxPointSpacing > 0:
            trajStep = int(selEdge.getLength() / maxPointSpacing)
            trajResolution = trajStep + 1 if trajStep > 2 else 3
        else:
            trajResolution = 4
        paramRange = selEdge.getParametricRange()
        delta = abs(paramRange['uEnd'] - paramRange['uStart']) / trajResolution
        sampling = [(x * delta) + paramRange['uStart'] for x in range(0, trajResolution + 1)] 
        
        _lockDirection = apex.construct.Vector3D(0.0, 0.0, 0.0)    
        
        #print("# of edges in this group: ", len(_path))
        _PointCollection = apex.IPhysicalCollection()
        PathPoints = []
        for i in range(len(sampling)):
            pointCoord = apex.Coordinate(selEdge.evaluateEdgeParametricCoordinate(sampling[i]).x ,
                                         selEdge.evaluateEdgeParametricCoordinate(sampling[i]).y ,
                                         selEdge.evaluateEdgeParametricCoordinate(sampling[i]).z)
            _PointCollection.append(pointCoord)

            PathPoints.append([selEdge.evaluateEdgeParametricCoordinate(sampling[i]).x ,
                               selEdge.evaluateEdgeParametricCoordinate(sampling[i]).y ,
                               selEdge.evaluateEdgeParametricCoordinate(sampling[i]).z])

        #newSpline = apex.geometry.createCurve(
        #    target=_PointCollection,
        #    behavior=apex.geometry.CurveBehavior.Spline
        #)

        CircleDone = doCircle(diam=refDiameter)

        ## Move circle to a new point location
        _target = apex.EntityCollection()
        _target.append(CurrPart.getSurfaces()[0])
        PathLength = sqrt(pow(PathPoints[0][0], 2) + pow(PathPoints[0][1], 2) + pow(PathPoints[0][2], 2))
        apex.transformTranslate(target=_target,
                                direction=[PathPoints[0][0], PathPoints[0][1], PathPoints[0][2]],
                                distance=PathLength,
                                makeCopy=False)
        ## Rotate the circle
        TurnAngle = angle([1, 0, 0], [a - b for a, b in zip(PathPoints[1], PathPoints[0])])
        if TurnAngle == 180:
            TurnAngle = 0
        apex.transformRotate(target=_target,
                             axisDirection=cross([1, 0, 0], [a - b for a, b in zip(PathPoints[1], PathPoints[0])]),
                             axisPoint=Point3D(PathPoints[0][0], PathPoints[0][1], PathPoints[0][2]),
                             angle=TurnAngle,
                             makeCopy=False)
        
        ## Do the sweep
        _target = apex.EntityCollection()
        _target.append(CurrPart.getSurfaces()[0]) 
        print(_path[0].id)
        try:
            result = apex.geometry.createGeometrySweepPath(
                target=_target,
                path=_path,
                scale=0.0,
                twist=0.0,
                profileSweepAlignmentMethod=apex.geometry.SweepProfileAlignmentMethod.Normal,
                islocked=False,
                lockDirection=_lockDirection,
                profileClamp=apex.geometry.SweepProfileClampingMethod.Smooth
            )

            CurrPart.getSolids()[0].update(enableTransparency=True, transparencyLevel=50)
            
            DelEntities = apex.EntityCollection()
            for Surface in CurrPart.getSurfaces():
                DelEntities.append(Surface)
            apex.deleteEntities(DelEntities)

            if dict["extendRegion"] == "True":
                for edge in _path:
                    for Vertex in edge.getVertices():
                        result = apex.geometry.createSphereByLocationOrientation(
                            name='Sphere',
                            description='',
                            radius=refDiameter / 2.0,
                            origin=Vertex,
                            orientation=apex.construct.createOrientation(alpha=0.0, beta=0.0, gamma=0.0)
                        )

            _target = apex.EntityCollection()
            _target.extend(CurrPart.getSolids())
            result = apex.geometry.mergeBoolean(
                target=_target,
                retainOriginalBodies=False,
                mergeSolidsAsCells=False
                )
                      
        except:
            CurrPart.update(name=CurrPart.getName() + "_FAILED")
        
        #delete reference curve
        #spline=apex.EntityCollection()
        #spline.append(newSpline)
        #apex.deleteEntities(spline)
        #print("List of IDs already used:", used)
            



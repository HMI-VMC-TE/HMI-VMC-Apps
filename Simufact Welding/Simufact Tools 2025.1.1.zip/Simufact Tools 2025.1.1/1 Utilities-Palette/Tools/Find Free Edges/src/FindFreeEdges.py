import apex
from apex.construct import Point3D, Point2D


def DisplayFreeEdges(dict={}):
    apex.disableShowOutput()
    apex.display.clearAllGraphicsText()

    foundEdgeColor    = apex.ColorRGB(200,   0,   0) 

    model_1 = apex.currentModel()
    listOfParts = apex.entityCollection()
    for selElement in apex.selection.getCurrentSelection():
        if selElement.entityType == apex.EntityType.Assembly:
            for Part in selElement.getParts(True):
                if Part.getVisibility():
                    listOfParts.append(Part)
        
        elif selElement.entityType == apex.EntityType.Part:
            if selElement.getVisibility():
                listOfParts.append(selElement)

    for Part in listOfParts:
        listOfExteriorEdges = apex.entityCollection()
        if Part.getVisibility():
            for Surface in Part.getSurfaces():
                if Surface.getVisibility:
                    for Edge in Surface.getExteriorEdges():
                        if dict["TryFix"] == 'True':
                            try:
                                _target = apex.EntityCollection()
                                _target.append( Edge )
                                result = apex.geometry.fillerSurface( target = _target )
                            except:
                                listOfExteriorEdges.append(Edge)
                        else:
                            listOfExteriorEdges.append(Edge)

        for Edge in listOfExteriorEdges:
            name = "O-"+str(Edge.getIndex())
            apex.display.displayText(text=name, textLocation=Edge.getMidPoint(), graphicsFontColor=foundEdgeColor, graphicsFontSize=14)

def exit(dict={}):
    apex.disableShowOutput()
    apex.display.clearAllGraphicsText()


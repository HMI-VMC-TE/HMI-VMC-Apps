import os
import apex_sdk


#.NET references
import System
import System.Windows.Controls as WPFControls

current_file_path = os.path.dirname(os.path.realpath(__file__))

#setting pre-defined properties of tool_propertyContainer
def getUIContent():
    my_toolProperty = apex_sdk.ToolPropertyContainer()
    my_toolProperty.TitleText = "Find free edges"
    my_toolProperty.TitleImageUriString = os.path.join(os.path.dirname(current_file_path), r"res\FindFreeEdgesICON.png")
    my_toolProperty.WorkFlowInstructions = '''
    <p><strong><span style="color: #999999;">Find Free Edges<br /></span></strong></p>
    <p><span style="color: #999999;">Description: This tool will highlight the free edges of the model, helping find CAD deffects.</span></p>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Try to fix using filler tool</span>: In case the free edges represent a hole, this option tries to close this hole.</span></li>
    <p><span style="color: #999999;">For support: <a href="mailto:support.americas@simufact.com" style="color: #999999;"><span style="color: #ff0000;">support.americas@simufact.com</span></a></span></p>
    '''

    # set property content
    my_toolProperty.ToolPropertyContent = getCustomToolPropertyContent()

    # Define PickFilterList
    my_toolProperty.ShowPickChoice = True
    my_toolProperty.PickFilterList = setPickFilterList()
   
    my_toolProperty.ExitCommand = apex_sdk.ActionCommand(System.Action(HandleExitButton))
    #return my_toolProperty
    return my_toolProperty

# Set PickFilters
def setPickFilterList():
    # Create an empty List of strings
    pickChoices = System.Collections.Generic.List[System.String]()

    # Exclusive picking and visibility picking
    pickChoices.Add(apex_sdk.PickFilterTypes.ExclusivePicking)
    pickChoices.Add(apex_sdk.PickFilterTypes.VisibilityPicking)

    # Add Types
    # pickChoices.Add(apex_sdk.PickFilterTypes.Part)
    # pickChoices.Add(apex_sdk.PickFilterTypes.Solid)
    # pickChoices.Add(apex_sdk.PickFilterTypes.Surface)
    # pickChoices.Add(apex_sdk.PickFilterTypes.Cell)
    # pickChoices.Add(apex_sdk.PickFilterTypes.Face)
    pickChoices.Add(apex_sdk.PickFilterTypes.Part)
    pickChoices.Add(apex_sdk.PickFilterTypes.Assembly)
    

    # Return the pick filter list
    return pickChoices


def getCustomToolPropertyContent():
    my_Grid = WPFControls.Grid()
    createLayout(my_Grid, 4, 2)

    currRow = 0

    
    global check01
    check01 = WPFControls.CheckBox()
    check01.Content = "Try to fix using filler tool"
    check01.Height = 30
    WPFControls.Grid.SetRow(check01, currRow)
    WPFControls.Grid.SetColumn(check01, 0)
    WPFControls.Grid.SetColumnSpan(check01, 3)
    #check01.IsChecked = System.Nullable[System.Boolean](True)
    my_Grid.Children.Add(check01)
    currRow += 1

    labelEdgesBtn = WPFControls.Button()
    labelEdgesBtn.Content="Find free edges"
    labelEdgesBtn.Click+=HandleLabelEdgesBtn
    WPFControls.Grid.SetColumnSpan(labelEdgesBtn, 2)
    WPFControls.Grid.SetRow(labelEdgesBtn, currRow)
    WPFControls.Grid.SetColumn(labelEdgesBtn, 0)
    labelEdgesBtn.Height = 30
    my_Grid.Children.Add(labelEdgesBtn)
    

    return my_Grid


def createLayout(parent, numRows, numCols):
    for k in range(numRows):
        parent.RowDefinitions.Add(WPFControls.RowDefinition())
    for k in range(numCols):
        parent.ColumnDefinitions.Add(WPFControls.ColumnDefinition())



@apex_sdk.errorhandler
def HandleApplyButton():
    dictionary = {}
    dictionary["TryFix"] = check01.IsChecked

    file_path = os.path.dirname(os.path.realpath(__file__))
    script_path= os.path.join(file_path, 'FindFreeEdges.py')
    apex_sdk.runScriptFunction(script_path, "DisplayFreeEdges", dictionary)


@apex_sdk.errorhandler
def HandleLabelEdgesBtn(sender, args):
    HandleApplyButton()
    
    
# exit button (red) from tool header
@apex_sdk.errorhandler
def HandleExitButton():
	file_path = os.path.dirname(os.path.realpath(__file__))
	script_path= os.path.join(file_path, 'FindFreeEdges.py')
	# Create a Dictionary to store the user defined tool data  
	dictionary = {}
	apex_sdk.runScriptFunction(script_path, "exit", dictionary)


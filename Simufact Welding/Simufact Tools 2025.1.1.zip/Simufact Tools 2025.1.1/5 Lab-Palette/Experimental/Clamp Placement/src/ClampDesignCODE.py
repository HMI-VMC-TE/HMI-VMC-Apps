import apex
from apex.construct import Point3D, Point2D
import datetime, os, sys

apex.setScriptUnitSystem(unitSystemName = r'''mm-kg-s-N''')
model_1 = apex.currentModel()
current_file_path = os.path.dirname(os.path.realpath(__file__))

#
# Start of recorded operations
#

def StiffnessOptimizer(dict={}):
    apex.disableShowOutput()
    model_1 = apex.currentModel()
    maxNumPts = int(dict["MaxNumOfPoints"])
    
    # Assign Material
    try:
        dummyMaterial = apex.catalog.getMaterial("Steel")
    except:
        dummyMaterial = apex.catalog.createMaterial(name="Steel", description="", color=[64, 254, 250])
        dummyMaterial.update(elasticModulus=210.e+9, poissonRatio=0.3, density=7.8e-6)
    
    # Check if a single assy was selected    
    if len(apex.selection.getCurrentSelection()) > 1:
        apex.enableShowOutput()
        print("Please select only a single assembly!")
        sys.exit()
    elif len(apex.selection.getCurrentSelection()) == 0:
        apex.enableShowOutput()
        print("Please select at least one assembly!")
        sys.exit()
    currAssy = apex.selection.getCurrentSelection()[0]
    
    # Get assembly and parts
    all_surfs = apex.EntityCollection()
    for selPart in currAssy.parts:
        _target = apex.EntityCollection()
        _target.append(selPart)
        all_surfs.extend(selPart.surfaces)
        #apex.attribute.assignMaterial(material=dummyMaterial, target=_target)
        selPart.setParent(currAssy)

    # Glue all surfs
    if len(all_surfs) > 1:
        try:
            glue_surfs(currAssy)
        except:
            pass # glue already exists probably
    
    context_ = currAssy
    study = apex.getPrimaryStudy()
    #Start optimization loop
    for i in range(maxNumPts+1):        
        # Create job
        currScenario = study.createScenarioByModelRep(context=context_, simulationType=apex.studies.SimulationType.NormalModes)
        
        # Save and run
        model_1.save()
        currScenario.execute()
        
        # Run post function
        fix_node = post_process(currAssy)
        
        # Add new clamp
        if i < (maxNumPts):
            new_constraint = add_clamp(currAssy,fix_node)
        
        #Delete scenario after done (save for last iteration)
        if i < (maxNumPts):
            study.deleteScenario(currScenario)
       
def add_clamp(currAssy,max_node_id):
    # Find 4 nearest nodes to the max node    
    mySearch = apex.utility.ProximitySearch()
    iNodes = apex.IPhysicalCollection()
    for part in currAssy.parts:
        for node in part.nodes:
            iNodes.append(node.asEntity())
            if int(node.getId()) == int(max_node_id):
                max_node = node
    loc = max_node.getCoordinates().getLocation()
    mySearch.insertCollection(iNodes)
    near_nodes = mySearch.findNearestObjects(loc,4).foundObjects()
    
    # Add constraint
    _target = apex.EntityCollection()
    _target.extend(near_nodes)
    new_constraint = apex.environment.createConstraintSinglePoint(
        name = "Constraint",
        constrainTranslationX = True,
        constrainTranslationY = True,
        constrainTranslationZ = True,
        constrainRotationX = True,
        constrainRotationY = True,
        constrainRotationZ = True,
        target = _target,
        constraintType = apex.attribute.ConstraintType.Clamped
    )
    return new_constraint

def post_process(currAssy):
    # --- Do postprocessing - why is this so complicated :(
    # Set basic settings
    result = apex.session.displayMeshCracks(False)
    result = apex.session.display2DSpans(False)
    result = apex.session.display3DSpans(False)
    apex.display.hideRotationCenter()
    result = apex.session.displayMeshCracks(False)
    result = apex.session.displayInteractionMarkers(True)
    result = apex.session.displayConnectionMarkers(True)
    result = apex.session.display2DSpans(False)
    result = apex.session.display3DSpans(True)
    result = apex.session.displayLoadsAndBCMarkers(True)
    result = apex.session.displaySensorMarkers(True)
    
    # State plot is just a parent object to the actual results (contour and deform visualization)
    study = apex.getPrimaryStudy()
    scenario1 = study.getScenario(name="Mode Scenario " + currAssy.getName())
    executedscenario_1 = scenario1.getLastExecutedScenario()
    event1 = executedscenario_1.getEvent(pathName="/Study/{0}<< -1>>/Event 1".format("Mode Scenario " + currAssy.getName()))
    stateplot_1 = apex.post.createStatePlot(
        event=event1,
        resultDataSetIndex=[1])
    
    # This is the actual range and colors that appear in the contour object
    colormap_1 = apex.post.createColorMap(
        name="FringeSpectrum",
        colorMapSegmentMethod=apex.post.ColorMapSegmentMethod.Linear,
        start=0.0,
        end=0.0,
        isLocked=False,
        useOutOfRangeColors=False,
        displayContinuousColors=False)

    # This is where the color plot actually shows up
    visualizationTarget1 = apex.entityCollection()
    visualizationTarget1.append(executedscenario_1.getAssembly(currAssy.getPathName()))
    contourvisualization_1 = stateplot_1.createContourVisualization(
        contourStyle=apex.post.ContourStyle.Fringe,
        target=visualizationTarget1,
        resultQuantity=apex.post.ResultQuantity.DisplacementTranslational,
        resultDerivation=apex.post.ResultDerivation.Magnitude,
        layerIdentificationMethod=apex.post.LayerIdentificationMethod.Position,
        layers=["NONE"],
        layerEnvelopingMethod=apex.post.LayerEnvelopingMethod.Unknown,
        elementNodalProcessing=apex.post.ElementNodalProcessing.Averaged,
        coordinateSystemMethod=apex.post.CoordinateSystemMethod.Global,
        colorMap=colormap_1,
        displayUnit="mm"
    )

    # Additional settings
    contourvisualization_1.update()
    result = apex.session.display3DSpans(False)
    result = apex.session.displaySensorMarkers(True)
    result = apex.session.display2DSpans(False)
    result = apex.session.display3DSpans(False)
    result = apex.session.displaySensorMarkers(True)
    
    # Probe all nodes and find max disp
    plotVisualization = stateplot_1.getVisualization(entityType = apex.EntityType.ContourVisualization)
    contourvisualization_1 = plotVisualization.asContourVisualization()
    resultprobe0d = apex.post.createResultProbe0D(dataVisualization = contourvisualization_1)    
    max_node = 0
    max_disp = 0.0
    for part in currAssy.getParts():
        node_list = []
        for node in part.getNodes():
            node_list.append(node.getId())    
        nodes_1 = executedscenario_1.getNodes(pathName = part.getMeshes()[0].getPathName(),
            ids = ",".join(node_list))
        resultprobe0d.addProbeTargetEntities(
            probeTarget = nodes_1, 
            probeTargetUpdateMode = apex.post.ProbeTargetUpdateMode.Add)
    export_file = os.path.join(current_file_path,'data.csv')
    resultprobe0d.exportDataCSV(export_file)
    with open(export_file,'r') as csv:
        for _ in range(9):
            next(csv)
        for line in csv:
            if ',' in line:
                node_id = int(line.split(',')[0])
                node_disp = float(line.split(',')[1])
                if node_disp >= max_disp:
                    max_disp = node_disp
                    max_node = node_id
    
    # Delete probe, file, and exit post
    resultprobe0d.deleteProbe()
    os.remove(export_file)
    apex.post.exitPostProcess()
    
    return max_node

def glue_surfs(currAssy):
    apex.beginUndoIndent()
    _body1Property = apex.attribute.createContactBodyProperty(
        smoothingState = False,
    )
    _body2Property = apex.attribute.createContactBodyProperty(
        smoothingState = False,
    )
    _interactionPropertyGeometric = apex.attribute.createInteractionPropertyGeometric(
        contactToleranceCalculationMethod = apex.AutoManual.Automatic,
        ignoreShellThicknessSide1 = False,
        shellLayerSide1 = apex.attribute.ShellLayer.TopAndButtom,
        ignoreShellThicknessSide2 = False,
        shellLayerSide2 = apex.attribute.ShellLayer.TopAndButtom,
        contactSearchOrder = apex.attribute.ContactSearchOrder.SingleSide,
        stressFreeInitialContact = False,
        delayedSlideOff = False,
        retainMoment = True,
        allowSeparation = False,
        stepGlue = False,
        flexibleGlue = False,
        interferenceFit = False,
        initialClearance = False,
    )
    _interactionPropertyPhysical = apex.attribute.createInteractionPropertyPhysical(
        exponent1 = 2.,
        exponent2 = 2.,
    )
    _target = apex.EntityCollection()
    _geoms = apex.EntityCollection()
    for part in currAssy.parts: 
        _geoms.extend(part.surfaces)
    _target.extend( _geoms )
    interactioncollection_1 = apex.attribute.createInteractionAutoPair(
        name = 'Interaction',
        description = '',
        targetSide = _target,
        body1Property = _body1Property,
        body2Property = _body2Property,
        pairTolerance = 5.,
        interactionPropertyGeometric = _interactionPropertyGeometric,
        interactionPropertyPhysical = _interactionPropertyPhysical,
    )
    index = 0
    listsize = len(interactioncollection_1)
    while index < listsize:
        interaction = interactioncollection_1[index]
        index += 1
        _activeRep = interaction.createInteractionRep(
        name = 'Interaction',
        description = '',
        interactionType = apex.attribute.InteractionType.Glue,
        interactionPropertyGeometric = _interactionPropertyGeometric,
        interactionPropertyPhysical = _interactionPropertyPhysical,
        allowSelfContactSide1 = False,
        allowSelfContactSide2 = False,
    )
    apex.endUndoIndent(description="created contact")
    
####
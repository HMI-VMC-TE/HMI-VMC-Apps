import apex
from apex.construct import Point3D, Point2D
import os, time, subprocess, sys, shutil


apex.disableShowOutput()

try:
    sfWeldingPath = os.path.join(os.environ['sfWeldingPath'], "bin", "simufact.welding.exe")
except KeyError:
    sfWeldingPath = r"C:\Program Files\simufact\welding\2022.0.1\bin\simufact.welding.exe" #change this variable if needed

if not sfWeldingPath:
    raise Exception("Simufact Welding path not defined. Run the binding script.")


apex.setScriptUnitSystem(unitSystemName=r'''mm-kg-s-N''')

def CreateProjectStructure(dict={}):
    currModel = apex.currentModel()
    def CreateAssyGroup(parentAssy=None):
        try:
            _res = parentAssy.getAssembly(pathName="Components")
        except:
            _res = parentAssy.createAssembly(name="Components")

        try:
            _res = parentAssy.getAssembly(pathName="Bearings")
        except:
            _res = parentAssy.createAssembly(name="Bearings")

        try:
            _res = parentAssy.getAssembly(pathName="Clamps")
        except:
            _res = parentAssy.createAssembly(name="Clamps")

        try:
            _res = parentAssy.getAssembly(pathName="Fixed geometries")
        except:
            _res = parentAssy.createAssembly(name="Fixed geometries")

    if apex.selection.getCurrentSelection():
        for Assy in apex.selection.getCurrentSelection():
            CreateAssyGroup(Assy)
    else:
        parentAssy = currModel.createAssembly(name="Welding project")
        CreateAssyGroup(parentAssy)


def CreateWeldingProject(dict={}):
    apex.setScriptUnitSystem(unitSystemName=r'''mm-kg-s-N''')
    currModel = apex.currentModel()
    for Assy in apex.selection.getCurrentSelection():
        timeNow = time.strftime("%Y.%m.%d-%Hh%Mm%Ss")
        projectPath = os.path.join(dict["ProjectPath"], Assy.getName(), timeNow)
        meshDirPath = os.path.join(projectPath, "MeshFiles")
        if not os.path.exists(meshDirPath):
            os.makedirs(meshDirPath)
        componentsPath = os.path.join(meshDirPath, "Components")
        if not os.path.exists(componentsPath):
            os.makedirs(componentsPath)
        BCsPath = os.path.join(meshDirPath, "BCs")
        if not os.path.exists(BCsPath):
            os.makedirs(BCsPath)

        # - Pre-defined structure of parts and assemblies
        componentsAssy = Assy.getAssembly(name="Components")
        bearingsAssy = Assy.getAssembly(name="Bearings")
        clampsAssy = Assy.getAssembly(name="Clamps")
        fixedGeomAssy = Assy.getAssembly(name="Fixed geometries")

        # - Get meshes and save them at the correct directory
        #-Meshes for components
        try:
            for Part in componentsAssy.getParts(True):
                if Part.getVisibility():
                    if len(Part.getMeshes()) > 1:
                        Part.update(name=Part.getName() + "_check")
                    else:
                        for Mesh in Part.getMeshes():
                            fileName = ""
                            if Mesh.entityType == apex.EntityType.SurfaceMesh:  # Test to see if mesh is of surface type
                                fileName = os.path.join(componentsPath, f"{Part.getName()}_surf_{len(Mesh.getElements())}.bdf")
                            elif Mesh.entityType == apex.EntityType.HexMesh:  # Test to see if mesh is of hexmesh type
                                fileName = os.path.join(componentsPath, f"{Part.getName()}_hex_{len(Mesh.getElements())}.bdf")
                            elif Mesh.entityType == apex.EntityType.SolidMesh:  # Test to see if mesh is of tetmesh type
                                fileName = os.path.join(componentsPath, f"{Part.getName()}_tet_{len(Mesh.getElements())}.bdf")

                            Part.exportFEModel(
                                filename=fileName,
                                unitSystem="m-kg-s-N-K",
                            )
        except: pass
        #-Meshes for bearings
        try:
            for Part in bearingsAssy.getParts(True):
                if Part.getVisibility():
                    if len(Part.getMeshes()) > 1:
                        Part.update(name=Part.getName() + "_check")
                    else:
                        for Mesh in Part.getMeshes():
                            fileName = os.path.join(BCsPath, f"{Part.getName()}_bng_{len(Mesh.getElements())}.bdf")
                            Part.exportFEModel(
                                filename=fileName,
                                unitSystem="m-kg-s-N-K",
                            )
        except: pass
        #-Meshes for clamps
        try:
            for Part in clampsAssy.getParts(True):
                if Part.getVisibility():
                    if len(Part.getMeshes()) > 1:
                        Part.update(name=Part.getName() + "_check")
                    else:
                        for Mesh in Part.getMeshes():
                            fileName = os.path.join(BCsPath, f"{Part.getName()}_cmp_{len(Mesh.getElements())}.bdf")
                            Part.exportFEModel(
                                filename=fileName,
                                unitSystem="m-kg-s-N-K",
                            )
        except: pass
        #-Meshes for fixed geometries
        try:
            for Part in fixedGeomAssy.getParts(True):
                if Part.getVisibility():
                    if len(Part.getMeshes()) > 1:
                        Part.update(name=Part.getName() + "_check")
                    else:
                        for Mesh in Part.getMeshes():
                            fileName = os.path.join(BCsPath, f"{Part.getName()}_fxg_{len(Mesh.getElements())}.bdf")
                            Part.exportFEModel(
                                filename=fileName,
                                unitSystem="m-kg-s-N-K",
                            )
        except: pass
        thisFilePath = os.path.dirname(os.path.realpath(__file__))
        scriptPath = os.path.join(thisFilePath,'buildModel.py')
        destPathScrit = os.path.join(projectPath, "buildModel.py")
        shutil.copyfile(scriptPath, destPathScrit)
        procLaunch = subprocess.Popen([sfWeldingPath, "-run", destPathScrit], shell=False, stdout=subprocess.PIPE,
                                      stderr=subprocess.DEVNULL)
        while procLaunch.poll() is None:
            time.sleep(1)
        if dict["openGUI"] == 'True':
            for Dir in os.listdir(projectPath):
                if Dir.startswith("WeldingProj-"):
                    for File in os.listdir(os.path.join(projectPath, Dir)):
                        if File.endswith(".swproj"):
                            #result = subprocess.Popen(f'explorer /select,{os.path.join(projectPath, Dir)}')
                            result = subprocess.Popen([sfWeldingPath, "-importProject", os.path.join(projectPath, Dir, File)])
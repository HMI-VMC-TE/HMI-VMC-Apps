import simufact, time, os, math

thisFilePath = os.path.dirname(os.path.realpath(__file__))

# -- Getting the necessary paths and data
timeNow = time.strftime("%Y%m%d-%Hh%Mm%Ss")
projPath = thisFilePath
projName = f"WeldingProj-{timeNow}"
meshPath = os.path.join(thisFilePath, "MeshFiles")
componentsPath = os.path.join(meshPath, "Components")
BCsPath = os.path.join(meshPath, "BCs")

# -- Creating a new project and setting up a RSW simulation
currProject = simufact.welding.new_project(projName, projPath)
currentProcess = currProject.new_process(
    name = "WeldingProject",
    process_type = "arc-welding",
    comment = f"Welding project based on automatic script.\nCreated on {timeNow}."
)

# - Adding necessary objects to the catalog
tempObj = currProject.new_temperature(name="20C", initial_temperature=20)
# matObj = currProject.import_material_from_library("S235-SPM_sw")
# proj.import_material(r"D:\Data\MyMaterials\Al99.5_sw.xmt")

# - Import meshes, create components and boundary conditions
#layers=2                                
for meshFile in os.listdir(componentsPath):
    with open(os.path.join(componentsPath, meshFile), 'r') as BDFFile:
        for line in BDFFile:
            if 'Length' in line: # Get the unit from the file
                meshUnit = line.strip().split()[-1]
            elif line.startswith('CQUAD'): # Check if mesh is of type shell
                thickness = float(line.strip().split()[3])
                meshType = 'shell'
                layers=min(math.ceil(1000*thickness/2),4) 
                geomObj = currProject.import_shell_geometry(filename=os.path.join(componentsPath, meshFile),
                                                            num_layers=layers,
                                                            extrusion_dir="mid",
                                                            as_single_body=True)
                currentProcess.new_component(name=meshFile[:-4],
                                             geometry=geomObj,
                                             temperature=tempObj)
                break
            elif 'CHEX' in line or 'CTET' in line: # Check if mesh is of type solid (tet or hex)
                geomObj = currProject.import_geometry(filename=os.path.join(componentsPath, meshFile),
                                                      unit=meshUnit)
                currentProcess.new_component(name=meshFile[:-4],
                                             geometry=geomObj[0],
                                             temperature=tempObj)
                break


for meshFile in os.listdir(BCsPath):
    geomObj = currProject.import_geometry(filename=os.path.join(BCsPath, meshFile),
                                          unit=meshUnit)
    if "_bng_" in meshFile:
        Bearing = currentProcess.new_bearing(name=meshFile[:-4],
                                             geometry=geomObj[0],
                                             temperature=tempObj)

    elif "_cmp_" in meshFile:
        Clamping = currentProcess.new_clamping(name=meshFile[:-4],
                                               geometry=geomObj[0],
                                               temperature=tempObj)
        Clamping.definition = 'stiffness+force'
        Clamping.force = simufact.UnitValueForce(100,'N')
        Clamping.direction = "auto"

    elif "_fxg_" in meshFile:
        FixedGeometry = currentProcess.new_fixed_geometry(name=meshFile[:-4],
                                                          geometry=geomObj[0],
                                                          temperature=tempObj)

procSpotGun = currentProcess.new_robot()
_res = currProject.save()







import sys
import os
import apex_sdk
import clr

# .NET references
import System
import System.Windows.Controls as WPFControls
from Microsoft.Win32 import OpenFileDialog
from System.Windows.Forms import FolderBrowserDialog

# Define current file path of example
current_file_path = os.path.dirname(os.path.realpath(__file__))


# Set pre-defined properties of ToolPropertyContainer
def getUIContent():
    my_toolProperty = apex_sdk.ToolPropertyContainer()
    my_toolProperty.TitleText = "Create a welding project"
    my_toolProperty.TitleImageUriString = os.path.join(os.path.dirname(current_file_path), r"res\WeldingIcon.png")
    my_toolProperty.WorkFlowInstructions = '''
    <p><strong><span style="color: #999999;">Create <span style="color: #ff0000;">Simufact Welding</span> project based on meshed bodies.</span></p>
    <p><strong><span style="color: #999999;">The Apex model must be organized the following way:</span></p>
    <ul>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Components (Assembly)</span>: Each component is a separate part in here</span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Bearings (Assembly)</span>: Each bearing is a separate part in here</span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Clamps (Assembly)</span>: Each clamp is a separate part in here</span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Fixed geometries (Assembly)</span>: Each fixed geometry is a separate part in here</span></li>
    </ul>
    <p><span style="color: #999999;">Workflow:</span></p>
    <ol>
    <li><span style="color: #999999;">Click Create model structure to automatically setup the Master assembly with the appropriate subassemblies<br /></span></li>
    <li><span style="color: #999999;">Select the master assembly with all the subassemblies contained in it and click Create welding project<br/span><span style="color: #999999;"></span></li>
    <li><span style="color: #999999;">Wait for Simufact to open and the model build will happen automatically. If Simufact opens, but does not build the model, run the "buildModel.py" script from within the created folder.</span><span style="color: #999999;"></span><br /></li>
    <li><span style="color: #999999;">If Simufact doesn't open or you have an error, check script directory to change the Simufact path in the "CreateWeldingProject.py" script. Or, contact support at the adress below.</span><span style="color: #999999;"></span></li>
    </ol>
    <p><span style="color: #999999;">For support: <a href="mailto:support.americas@simufact.com" style="color: #999999;"><span style="color: #ff0000;">support.americas@simufact.com</span></a></span></p> 
    '''

    # Define UI
    my_toolProperty.ToolPropertyContent = getCustomToolPropertyContent()

    # Handle apply button (green) click event
    #my_toolProperty.AppliedCommand = apex_sdk.ActionCommand(System.Action(HandleApplyButton))

    # Define PickFilterList
    my_toolProperty.ShowPickChoice = True
    my_toolProperty.PickFilterList = setPickFilterList()

    return my_toolProperty


# Set PickFilters
def setPickFilterList():
    # Create an empty List of strings
    pickChoices = System.Collections.Generic.List[System.String]()

    # Exclusive picking and visibility picking
    pickChoices.Add(apex_sdk.PickFilterTypes.ExclusivePicking)
    pickChoices.Add(apex_sdk.PickFilterTypes.VisibilityPicking)

    # Add Types
    # pickChoices.Add(apex_sdk.PickFilterTypes.Part)
    # pickChoices.Add(apex_sdk.PickFilterTypes.Solid)
    # pickChoices.Add(apex_sdk.PickFilterTypes.Surface)
    # pickChoices.Add(apex_sdk.PickFilterTypes.Cell)
    # pickChoices.Add(apex_sdk.PickFilterTypes.Face)
    pickChoices.Add(apex_sdk.PickFilterTypes.Assembly)

    # Return the pick filter list
    return pickChoices


# Define Layout and Components
def getCustomToolPropertyContent():
    # Create a Grid
    my_Grid = WPFControls.Grid()

    # Add 2 Rows and 1 Column
    my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())

    currRow = 0

    # Create a button
    button01 = WPFControls.Button()
    button01.Content = "Create model structure"
    WPFControls.Grid.SetRow(button01, currRow)
    WPFControls.Grid.SetColumn(button01, 0)
    button01.Height = 35
    button01.Click += HandleCreateStructureButton
    my_Grid.Children.Add(button01)
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    currRow += 1

    global chkBox01
    chkBox01 = WPFControls.CheckBox()
    chkBox01.Content = "Open Simufact Welding afterwards"
    chkBox01.Height = 20
    WPFControls.Grid.SetRow(chkBox01, currRow)
    WPFControls.Grid.SetColumn(chkBox01, 1)
    chkBox01.IsChecked = System.Nullable[System.Boolean](True)
    my_Grid.Children.Add(chkBox01)
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    currRow += 1

    # Create a button
    actionButton = WPFControls.Button()
    actionButton.Content = "Create welding project"
    WPFControls.Grid.SetRow(actionButton, currRow)
    WPFControls.Grid.SetColumn(actionButton, 0)
    actionButton.Height = 35
    actionButton.Click += HandleCreateProjectButton
    my_Grid.Children.Add(actionButton)
    my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
    currRow += 1

    # Return the Grid
    return my_Grid


# Apply button handler (Green check mark)
# This function is called each time the Apply button is clicked
@apex_sdk.errorhandler
def HandleCreateProjectButton(sender, args):
    # Create a Dictionary to store the user defined tool data
    dictionary = {}
    dialog = FolderBrowserDialog()
    dialog.Description = "Directory where to save trajectories"
    dialog.ShowNewFolderButton = True
    dictionary["openGUI"] = chkBox01.IsChecked

    if dialog.ShowDialog():
        dictionary["ProjectPath"] = str(dialog.SelectedPath)
    else:
        dictionary["ProjectPath"] = ""

    if dictionary["ProjectPath"] != "":
        apex_sdk.runScriptFunction(os.path.join(current_file_path,r"CreateWeldingProject.py"),
                                   "CreateWeldingProject",
                                   dictionary)


@apex_sdk.errorhandler
def HandleCreateStructureButton(sender, args):
    # Create a Dictionary to store the user defined tool data
    dictionary = {}
    apex_sdk.runScriptFunction(os.path.join(current_file_path,r"CreateWeldingProject.py"),
                               "CreateProjectStructure", dictionary)

import tkinter as tk
from tkinter import filedialog
import sys, os, time, subprocess

# File handling
root = tk.Tk()
root.withdraw()
# Path for Digimat bat executable
try:
    versionList = []
    for dirname in os.listdir("C:/MSC.Software/Digimat"):
        if 'shortcuts' not in dirname and 'working' not in dirname:
            versionList.append(dirname)
    digi_path = os.path.join("C:/MSC.Software/Digimat",versionList[-1],"DigimatMAP\exec\DigimatMAP.bat")
except:
    bdf_path = filedialog.askopenfilename(title=r"Please select Digimat BAT file in 'Digimat\*****\DigimatMAP\exec'",
                                          filetypes=[('BAT file', '*.bat')],
                                          initialdir = 'C:/MSC.Software/Digimat')

# Path for ARC result files
arc_path = filedialog.askopenfilenames(title=r"Please select ARC file results from Simufact",
                                      filetypes=[('ARC file', '*.ARC')])
arc_list = ""
for elem in list(arc_path):
    arc_list += elem
    arc_list += ','
arc_list = arc_list[:-1]

# Path for Nastran BDF file
bdf_path = filedialog.askopenfilename(title=r"Please select Nastran BDF file",
                                      filetypes=[('BDF file', '*.bdf')])
file_dir = os.path.split(bdf_path)[0]
if bdf_path == "":
    print("Please select BDF file!")
    sys.exit()

# Creating Digimat MAP file
with open(os.path.join(file_dir,'digimat.map'),'w') as map:
    lines = f"""###################################################
DONOR_MESH
name = Sf_result_mesh
format = SIMUFACTARC
file = {arc_list}
###################################################
DONOR_DATA
name = Sf_result_stress
parent_mesh_name = Sf_result_mesh
type = Stress
format = SimufactArc
file = {arc_list}
###################################################
RECEIVER_MESH
name = Nastran_mesh
format = NASTRAN
file = {bdf_path}
###################################################
MAPPING_PROCEDURE
name = myMapping
type = 3D_Mapping
method = PG2PGS
number_of_layers = 12
tolerance = auto
thickness_spacing = Uniform_Centers
donor_mesh_name = Sf_result_mesh
donor_data_name = Sf_result_stress
receiver_mesh_name = Nastran_mesh
###################################################
OUTPUT
name = mappedStress
type = Stress
format = Nastran
file = {os.path.join(file_dir,'istress.bdf')}
###################################################
    """
    map.write(lines)
    map.close()

# Run Digimat
callCMD = subprocess.Popen([digi_path, 'input', '=',  os.path.join(file_dir,"digimat.map")],
                              shell=False,
                              stdout=subprocess.PIPE,
                              stderr=subprocess.DEVNULL)
while callCMD.poll() is None:
    time.sleep(1)

# Create edited Nastran input deck
bdf_lines = ""
with open(bdf_path,'r') as bdf:
    with open(bdf_path[:-4]+"_ISTRESS.bdf",'w') as new_bdf:
        for line in bdf:
            bdf_lines += line
            if "BEGIN BULK" in line:
                bdf_lines += "include 'istress.bdf'\n"
        new_bdf.write(bdf_lines)
    new_bdf.close()
    bdf.close()

# Remove digimat file (not needed)
os.remove(os.path.join(file_dir,'digimat.map'))
import tkinter as tk
from tkinter import filedialog
import sys, os, time, subprocess
import apex

apex.disableShowOutput()

def run_nastran(exportedFilePath):
    versionList = []
    nas_exe = ''
    if os.path.isdir("C:\Program Files\MSC.Software\MSC_Nastran"):
        for dirname in os.listdir("C:\Program Files\MSC.Software\MSC_Nastran"):
            versionList.append(dirname)
        version = versionList[-1]
        nas_exe = os.path.join("C:\Program Files\MSC.Software\MSC_Nastran",version,"bin", "nastran.exe")
    else:
        with open(os.path.join(os.path.dirname(__file__),'paths.txt'),'r') as path_file:
            for line in path_file:
                if line.startswith("Nastran"):
                    nas_exe = line[8:].rstrip()
                    print(nas_exe)
        if nas_exe == '':
            nas_exe = filedialog.askopenfilename(title=r"Please select Nastran EXE file (usually '...\bin\nastran.exe'",
                                                  filetypes=[('EXE file', '*.exe')],
                                                  initialdir = 'C:\Program Files\MSC.Software\MSC_Nastran')
            with open(os.path.join(os.path.dirname(__file__),'paths.txt'),'a') as path_file:
                path_file.write("\nNastran "+nas_exe)
            
# Create a string holding nastran executable
#    nas_exe = r"C:\Program Files\MSC.Software\MSC_Nastran\2020\msc20200\win64i8\nastran.exe"
# Arguments are passed using a list, args
    args = []
    args.append(nas_exe)
    args.append(exportedFilePath)
    args.append('out=%s' % (os.path.dirname(exportedFilePath)))
    args.append('scr=yes')

# This variable (my_env) is used to pass environment variables to the sub process... I am using os.environ() to pass all variables as-is
    my_env = os.environ
# Variable used to change working directory for the subprocess command - I am using the same directory as where Nastran is running
    nastran_cwd = os.path.dirname(exportedFilePath)
# Subprocess allows you redirect output or errors to files or to standard output. You can also change working directory using the cwd variable
    p = subprocess.Popen(args, shell=False, cwd=nastran_cwd, env=my_env)
    out, err = p.communicate()  # this line makes the script wait for the process end without, the nastran job will be immediately killed
    
    
def Mapping_ARC_BDF(dict={}):
    #print(dict)
    # File handling
    root = tk.Tk()
    root.withdraw()
    # Path for Digimat bat executable
    versionList = []
    digi_path = ''
    if os.path.isdir("C:/MSC.Software/Digimat"):
        for dirname in os.listdir("C:/MSC.Software/Digimat"):
            if 'shortcuts' not in dirname and 'working' not in dirname:
                versionList.append(dirname)
        digi_path = os.path.join("C:/MSC.Software/Digimat",versionList[-1],"DigimatMAP\exec\DigimatMAP.bat")
    else:
        with open(os.path.join(os.path.dirname(__file__),'paths.txt'),'r') as path_file:
            for line in path_file:
                if line.startswith("Digimat"):
                    digi_path = line[8:].rstrip()
                    print(digi_path)
            if digi_path == '':
                digi_path = filedialog.askopenfilename(title=r"Please select Digimat BAT file in 'Digimat\*****\DigimatMAP\exec'",
                                                      filetypes=[('BAT file', '*.bat')],
                                                      initialdir = 'C:/MSC.Software/Digimat')
                with open(os.path.join(os.path.dirname(__file__),'paths.txt'),'a') as path_file:
                        path_file.write("\nDigimat "+digi_path)                                     

    # Path for ARC result files
    arc_list = dict["ARCFileList"][:-1]
    if arc_list == "":
        print("\n***Please select ARC files!")
        apex.enableShowOutput()
        sys.exit()    
    #Scenario selection
    Scenario=dict["Scenario"]
    if Scenario == "Please select a Nonlinear Scenario":
        print("\n***Please select a Nonlinear Scenario!")
        apex.enableShowOutput()
        sys.exit()
        # Path for Nastran BDF file
    bdf_path = dict["BDFFile"]
    file_dir = os.path.split(bdf_path)[0]
    if bdf_path == str(dict["Scenario"])+".bdf":
        print("\n***Please select BDF Export location!")
        apex.enableShowOutput()
        sys.exit()   
    else:
        study = apex.getPrimaryStudy()
        scenario1 = study.getScenario( name = Scenario )
        scenario1.exportFEModel(
            filename = bdf_path,
            unitSystem = "m-kg-s-N",
            exportWideFormat = False,
            exportHierarchicalFiles = False,
            resultOutputType = apex.attribute.NastranResultOutputType.Hdf5,
        )

    # Creating Digimat MAP file
    with open(os.path.join(file_dir,'digimat.map'),'w') as map_file:
        lines = f"""###################################################
    DONOR_MESH
    name = Sf_result_mesh
    format = SIMUFACTARC
    file = {arc_list}
    ###################################################
    DONOR_DATA
    name = Sf_result_stress
    parent_mesh_name = Sf_result_mesh
    type = Stress
    format = SimufactArc
    file = {arc_list}
    ###################################################
    RECEIVER_MESH
    name = Nastran_mesh
    format = NASTRAN
    file = {bdf_path}
    ###################################################
    MAPPING_PROCEDURE
    name = myMapping
    type = 3D_Mapping
    method = PG2PG
    number_of_layers = 12
    tolerance = auto
    automatic_superpose = off
    thickness_spacing = Uniform_Centers
    donor_mesh_name = Sf_result_mesh
    donor_data_name = Sf_result_stress
    receiver_mesh_name = Nastran_mesh
    ###################################################
    OUTPUT
    name = mappedStress
    type = Stress
    format = Nastran
    file = {os.path.join(file_dir,'istress.bdf')}
    ###################################################
        """
        map_file.write(lines)
        map_file.close()

    # Create edited Nastran input deck
    bdf_lines = ""
    sol400 = False
    with open(bdf_path,'r') as bdf:
        with open(bdf_path[:-4]+"_ISTRESS.bdf",'w') as new_bdf:
            for line in bdf:
                if "SOL 400" in line:
                    sol400 = True
                    break
            if sol400:
                bdf.seek(0)
                for line in bdf:
                    if "STRESS(PLOT" in line:
                        bdf_lines += "STRESS(PLOT,center) = ALL"
                    else:
                        bdf_lines += line
                        if "BEGIN BULK" in line:
                            bdf_lines += "include 'istress.bdf'\n"
            else:
                print("\n***Exported scenario is not Nonlinear!")
                apex.enableShowOutput()            
                sys.exit()
            new_bdf.write(bdf_lines)
        new_bdf.close()
        bdf.close()

    # Run Digimat
    callCMD = subprocess.Popen([digi_path, 'input', '=',  os.path.join(file_dir,"digimat.map")],
                                  shell=False,
                                  stdout=subprocess.PIPE,
                                  stderr=subprocess.DEVNULL)
    
    while callCMD.poll() is None:
        time.sleep(1)

    # Remove digimat file (not needed)
    #os.remove(os.path.join(file_dir,'digimat.map'))
    
    if dict["runNastran"] == 'True':
        run_nastran(bdf_path[:-4]+"_ISTRESS.bdf")
    
    if dict["postH5"] == 'True':
        study = apex.getPrimaryStudy()
        scenario1 = study.getScenario( name = Scenario )
        result = bdf_path[:-4]+"_ISTRESS.h5"
        print(result.lower())
        scenario1.importNastranResults(
            resultsFilename = "C:/Users/Nicholas Avedissian/Desktop/Digimat scripting/Script/Apex Export/nonlinear scenario 1_istress.h5",
            unitSystenName = "m-kg-s-N-K",
            )        
    
    
    
    
    
    
    
    
    
    
    
    
    
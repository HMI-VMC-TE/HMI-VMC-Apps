import sys
import os
import apex_sdk
import clr


#.NET references
import System
import System.Windows.Controls as WPFControls
from System.Windows.Automation import AutomationProperties
from System.Windows.Forms import FolderBrowserDialog
from Microsoft.Win32 import OpenFileDialog

dictionary = {}
current_file_path = os.path.dirname(os.path.realpath(__file__))

#setting pre-defined properties of tool_propertyContainer
def getUIContent():

   my_toolProperty = apex_sdk.ToolPropertyContainer()
   my_toolProperty.ToolPropertyContent = getCustomToolPropertyContent()
   my_toolProperty.TitleText = "  Couple Simufact Stresses"
   my_toolProperty.TitleImageUriString = os.path.join(os.path.dirname(current_file_path), r"res\map.png")
   my_toolProperty.WorkFlowInstructions = ''' 
    <p><strong><span style="color: #999999;">Couple Simufact Stresses<br /></span></strong></p>
    <p><span style="color: #999999;">Description: This tools maps Simufact stresses (ARC format) into Nastran models (BDF format)<br /></span></p>
    <p><span style="color: #999999;">*** Make sure both models are in same position ***<br /></span></p>
    <ul>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Simufact ARC results</span>: ARC results coming from Simufact<br /></span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Study</span>: Scenarion that will be run<br /></span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Study export location</span>: Location where model will be written<br /></span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Run Nastran</span>: Flag to automatically run Nastran<br /></span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Couple Simufact Stresses</span>: Start the process<br /></span></li>
    </ul>
    <p><span style="color: #999999;">Workflow:</span></p>
    <ol>
    <li><span style="color: #999999;">Create a Nonlinear scenario in Apex<br /></span></li>
    <li><span style="color: #999999;">Select ARC results<br /></span></li>
    <li><span style="color: #999999;">Select Nonlinear scenario<br /></span></li>
    <li><span style="color: #999999;">Select BDF export location<br /></span></li>
    <li><span style="color: #999999;">Check if you want to run Nastran automatically<br /></span></li>
    <li><span style="color: #999999;">Click Couple Simufact Stresses<br /></span></li>
    <li><span style="color: #999999;">Check BDF export directory for results<br /></span></li>
    </ol>
    <p><span style="color: #999999;">For support: <a href="mailto:support.americas@simufact.com" style="color: #999999;"><span style="color: #ff0000;">support.americas@simufact.com</span></a></span></p>
    <p><span style="color: #999999;"><span style="color: #ff0000;"></span></span></p>
    '''
   # Define PickFilterList
   my_toolProperty.ShowPickChoice = True
   my_toolProperty.IsCustomTool = True                                   
   my_toolProperty.PickFilterList = setPickFilterList()
   return my_toolProperty
   
# Set PickFilters
def setPickFilterList():
    # Create an empty List of strings
    pickChoices = System.Collections.Generic.List[System.String]()

    # Exclusive picking and visibility picking
    pickChoices.Add(apex_sdk.PickFilterTypes.ExclusivePicking)
    pickChoices.Add(apex_sdk.PickFilterTypes.VisibilityPicking)

    # Add Types
    #pickChoices.Add(apex_sdk.PickFilterTypes.Point)

    # Return the pick filter list
    return pickChoices

#get tool property content
def getCustomToolPropertyContent():
   #Create a Grid
   my_Grid = WPFControls.Grid()
   global selectedFiles
   selectedFiles = []
   global selectedFiles2
   selectedFiles2 = [] 
   global selectedFolder
   selectedFolder = ""
   curRow = 0
   #Add 2 Rows and 1 Column
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   c1 = my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())
   c2 = my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())
   c3 = my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())
   
 
   #Create a button and set it's text to "Import"
   #Assign it to Row1, Column 0
   global importBtn
   importBtn = WPFControls.Button()
   importBtn.Content="Browse..."
   WPFControls.Grid.SetRow(importBtn, curRow)
   WPFControls.Grid.SetColumn(importBtn, 0)
   
   #Link a function to the Button "Click" event 
   #This function will be called every time the Button is clicked
   importBtn.Click+=HandleimportBtn1
   
   #Create an empty input TextBox
   global fileNameTextBox
   fileNameTextBox =WPFControls.TextBox()
   WPFControls.Grid.SetRow(fileNameTextBox, curRow)
   WPFControls.Grid.SetColumn(fileNameTextBox, 2)
   
   global selectedFilesText
   selectedFilesText = WPFControls.TextBlock()
   selectedFilesText.Text = "   Simufact ARC results:      "
   WPFControls.Grid.SetRow(selectedFilesText, curRow)
   WPFControls.Grid.SetColumn(selectedFilesText, 1)
   
   curRow+=1
   global scenariosComboBox, scenariosComboTextBlock
   scenariosComboTextBlock = createTextBlock(my_Grid, "                Study:", curRow, 0)
   scenariosComboBox       = createComboBox2(my_Grid, curRow, 1)
   scenariosComboTextBlock.Visibility = System.Windows.Visibility.Visible
   scenariosComboBox.Visibility       = System.Windows.Visibility.Visible
   WPFControls.Grid.SetColumnSpan(scenariosComboBox, 2)
   
   #Run external utility to get scenarios
   file_path = os.path.dirname(os.path.realpath(__file__))
   script_path_parts= os.path.join(file_path, 'getScenarios.py')
   apex_sdk.runScriptFunction(script_path_parts, "main", callback=getScenariosCB)
   
   curRow += 1
   #Create a button and set it's text to "Import"
   #Assign it to Row1, Column 0
   global importBtn2
   importBtn2 = WPFControls.Button()
   importBtn2.Content="Browse..."
   WPFControls.Grid.SetRow(importBtn2, curRow)
   WPFControls.Grid.SetColumn(importBtn2, 0)
   
   #Link a function to the Button "Click" event 
   #This function will be called every time the Button is clicked
   importBtn2.Click+=HandleimportBtn2
   
   #Create an empty input TextBox
   global fileNameTextBox2
   fileNameTextBox2 =WPFControls.TextBox()
   WPFControls.Grid.SetRow(fileNameTextBox2, curRow)
   WPFControls.Grid.SetColumn(fileNameTextBox2, 2)
   
   global selectedFilesText2
   selectedFilesText2 = WPFControls.TextBlock()
   selectedFilesText2.Text = "   Study export location:      "
   WPFControls.Grid.SetRow(selectedFilesText2, curRow)
   WPFControls.Grid.SetColumn(selectedFilesText2, 1)
   
   # Create checkbox
   curRow += 1
   global runCheck
   runCheck = WPFControls.CheckBox()
   runCheck.Content = "Run Nastran (will hold Apex until finishes)"
   runCheck.Height = 20
   WPFControls.Grid.SetRow(runCheck, curRow)
   WPFControls.Grid.SetColumn(runCheck, 0)
   WPFControls.Grid.SetColumnSpan(runCheck, 3)
   runCheck.IsChecked = System.Nullable[System.Boolean](False)
   
   curRow += 1
   # Create checkbox
   global postCheck
   postCheck = WPFControls.CheckBox()
   postCheck.Content = "Import results"
   postCheck.Height = 20
   WPFControls.Grid.SetRow(postCheck, curRow)
   WPFControls.Grid.SetColumn(postCheck, 0)
   WPFControls.Grid.SetColumnSpan(postCheck, 3)
   postCheck.IsChecked = System.Nullable[System.Boolean](False)
   
   
   curRow += 1   
   #Create a button
   #Assign it to Row1, Column 0
   mapBtn = WPFControls.Button()
   mapBtn.Content="Couple Simufact Stresses"
   WPFControls.Grid.SetRow(mapBtn, curRow)
   WPFControls.Grid.SetColumn(mapBtn, 0)
   WPFControls.Grid.SetColumnSpan(mapBtn, 3)
   mapBtn.Height = 30   
   
   #Link a function to the Button "Click" event 
   #This function will be called every time the Butto is clicked
   mapBtn.Click+=HandleMap
   
   global dialog
   dialog = FolderBrowserDialog()
   dialog.Description = "Study export folder"
   dialog.ShowNewFolderButton = True
   
   
   # Add the controls to the Grid
   my_Grid.Children.Add(importBtn)
   my_Grid.Children.Add(mapBtn)
   my_Grid.Children.Add(fileNameTextBox)
   my_Grid.Children.Add(selectedFilesText)
   my_Grid.Children.Add(importBtn2)
   my_Grid.Children.Add(fileNameTextBox2)
   my_Grid.Children.Add(selectedFilesText2)
   my_Grid.Children.Add(runCheck)
   #my_Grid.Children.Add(postCheck)
   

   
   #Return the Grid
   return my_Grid
 
#Function to handle the Import Button "Click" event
#This function gets called every time the Button is clicked
@apex_sdk.errorhandler
def HandleimportBtn1(sender,args):
   global selectedFiles
   #Create a File open dialog
   dialog = OpenFileDialog()
   dialog.Title = "Select ARC file(s)"
   
   #Configure for single file selection
   dialog.Multiselect = True
   
   #Set up the file types you want to support
   dialog.Filter = "ARC Files|*.arc|All Files|*.*"
   
   #Display the dialog
   #If it returns anything
   #   get the file name
   if dialog.ShowDialog():
    selectedFiles = dialog.FileNames
    fileNameTextBox.Text = str(len(selectedFiles))

@apex_sdk.errorhandler
def HandleimportBtn2(sender,args):
   global selectedFolder
   #Create a File open dialog
   dialog.ShowDialog()
   dialog.Title = "Select BDF export folder"
   selectedFolder = str(dialog.SelectedPath)
   fileNameTextBox2.Text = selectedFolder
   
def createComboBox2(parent, row, col):
	comboBox = WPFControls.ComboBox()
	
	comboBox.Margin = System.Windows.Thickness(5.)
	
	WPFControls.Grid.SetRow(comboBox, row)
	WPFControls.Grid.SetColumn(comboBox, col)
	
	parent.Children.Add(comboBox)
	
	return comboBox

def updateComboBox2(comboBox, comboItems):
	
	for comboItem in comboItems:
		item = WPFControls.ComboBoxItem()
		item.Content=comboItem
		comboBox.Items.Add(item)
	
	comboBox.SelectedIndex="0"
    
def createTextBlock(parent, text, row, col):
	textBlock = WPFControls.TextBlock()
	textBlock.Text = text
	
	textBlock.Margin = System.Windows.Thickness(5.)
	
	WPFControls.Grid.SetRow(textBlock, row)
	WPFControls.Grid.SetColumn(textBlock, col)
	parent.Children.Add(textBlock)
	
	return textBlock
    
#user defined button clickHandlers
@apex_sdk.errorhandler
def HandleMap(sender, args):
   global selectedFiles, selectedFolder,scenariosComboBox
   dictionary["ARCFileList"] = ""
   dictionary["runNastran"] = runCheck.IsChecked
   dictionary["postH5"] = postCheck.IsChecked
   if len(selectedFiles) > 0:
       for elem in list(selectedFiles):
           dictionary["ARCFileList"] += elem
           dictionary["ARCFileList"] += ','
   choices = scenariosComboBox.SelectedValue.ToString().split(":")
   choice = choices[len(choices)-1].lstrip().rstrip() 
   dictionary["Scenario"] = choice
   dictionary["BDFFile"] = os.path.join(selectedFolder,(str(choice)+".bdf"))
   
   file_path = os.path.dirname(os.path.realpath(__file__))
   script_path= os.path.join(file_path, 'MappingCODE.py')
   apex_sdk.runScriptFunction(script_path, "Mapping_ARC_BDF", dictionary)
   
   
#This function receives data from the Script API function and updates the Tool UI 
@apex_sdk.errorhandler
def getScenariosCB():
	global scenariosComboBox
	global partsComboBox

	
	ret_dict = apex_sdk.getScriptFunctionReturnData()
	scenarios=["Please select a Nonlinear Scenario"]
	
	try:
		tmp = ret_dict["ScenarioList"]
	except:
		print("No scenarios found")
		tmp=[]
	
	parts=[]
	
	partsFlag=False
	for item in tmp:
		if item == '#Parts': 
			partsFlag=True
			continue
		if not partsFlag:
			scenarios.append(item)
		else:
			parts.append(item)

	
	updateComboBox2(scenariosComboBox, scenarios)	
	updateComboBox2(partsComboBox, parts)	
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
 
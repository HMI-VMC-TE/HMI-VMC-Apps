# coding: utf-8

import apex
import os




def main(dict={}):
#def main():
	apex.disableShowOutput()
	
	study = apex.getPrimaryStudy()
	try:
		scenarios = study.getScenarios(True)
		scenarioNames = []
		for scenario in scenarios:
			scenarioNames.append( scenario.getName() )
			print(scenario.getName())
	
	except:
		print("There ar no scenarios in this model")
		scenarios=[]
		return {}

	
	scenarioNames = []
	for scenario in scenarios:
		scenarioNames.append( scenario.getName() )
		print(scenario.getName())
		
		
	myModel = apex.currentModel()	
	parts = myModel.getParts(True)
	
	partNames = []
	for part in parts:
		partNames.append( part.getName() )	
		
	scenarioNames.append('#Parts')
	scenarioNames+=partNames	
		
	ret_dict = {}
	ret_dict["ScenarioList"] = scenarioNames
	
	return ret_dict
	
#if __name__ == "__main__":
#	main(dict={})
#main()



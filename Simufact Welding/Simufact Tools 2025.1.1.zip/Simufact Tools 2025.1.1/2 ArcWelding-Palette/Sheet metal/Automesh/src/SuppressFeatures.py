import apex
from apex.construct import Point3D, Point2D
apex.disableShowOutput()

def SuppressFeatures(dict={}):
    #===================================================================
    ## Initializing Apex code
    apex.setScriptUnitSystem(unitSystemName = r'''mm-kg-s-N''')
    model_1 = apex.currentModel()
    _target = apex.entityCollection()

    for selElement in apex.selection.getCurrentSelection():
        if selElement.getVisibility():
            _target.extend(selElement.getEdges())
            _target.extend(selElement.getVertices())
        try:
            result = apex.geometry.suppressOnly(
                target = _target,
                maxEdgeAngle = 1.745329251994330e-01,
                maxFaceAngle = 8.726646259971650e-02,
                keepVerticesAtCurvatureChange = False,
                cleanupTol = 1.000000000000000)
        except:
            print("Supress failed")


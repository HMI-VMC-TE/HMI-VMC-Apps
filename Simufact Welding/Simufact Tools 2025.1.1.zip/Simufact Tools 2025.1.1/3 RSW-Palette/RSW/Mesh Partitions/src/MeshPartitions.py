import apex
from time import perf_counter
from apex.construct import Point3D, Point2D

apex.disableShowOutput()
apex.disableRecoveryFileRecording()
try:
    from sklearn.metrics.pairwise import euclidean_distances
except:
    import subprocess, os, time
    for folder in os.listdir(r"C:\Program Files\MSC.Software\MSC Apex"):
        if "Lock" not in folder:
            installationPath = os.path.join("C:\Program Files\MSC.Software\MSC Apex",folder)
    pythonPath = os.path.join(installationPath, "python3", "python.exe")
    pythonPath_quotes = '"' + pythonPath + '"'
    pythonFolder = os.path.join(installationPath, "python3")
    assert os.path.isdir(pythonFolder)
    os.chdir(pythonFolder)
    sitePath = os.path.join(installationPath, "python3", "Lib", "site-packages")
    callPIP = subprocess.Popen(['python.exe', "-m", "pip", "install","--upgrade","--force-reinstall","numpy","pyqtgraph", "sklearn"],
        shell=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL)
    while callPIP.poll() is None:
        time.sleep(1)

try:
    from sklearn.metrics.pairwise import euclidean_distances
    import_sklearn = True
except:
    apex.enableShowOutput()
    #print(os.getlogin())
    import_sklearn = False
    print("""Failed installing sklearn, please install package manually
    
    Instructions:
    
    - Open cmd as administrator
    - Change directory to Apex "python3" folder (C:\Program Files\MSC.Software\MSC Apex\******\python3)
    - Run command: .\python.exe -m pip install --upgrade --force-reinstall numpy pyqtgraph sklearn
    
    Restart Apex and try running the tool again.
    """)


def CreateMeshPartitions(dict={}):
    # ===================================================================
    ## Initializing Apex code
    
        t1_start = perf_counter()
        apex.setScriptUnitSystem(unitSystemName=r'''mm-kg-s-N''')
        model_1 = apex.currentModel()

        ## Collect faces to mesh
        _targetFine = apex.entityCollection()
        listOfLengths = []
        listOfDiameters = []

        MeshSize = float(dict["MeshSize"])

    #try:
        listOfTrajectories = model_1.getAssembly("Refinement regions").getParts(True)
        listOfAllParts = []
        for Part in model_1.getParts(True):
            if "Refinement regions" not in Part.getPath():
                listOfAllParts.append(Part)

        for Part in listOfTrajectories:
            if 'RefDiam' in Part.getName():
                _, Diam = Part.getName().split('_')
                listOfDiameters.append(float(Diam))
            else:
                if len(Part.getCurves()) > 0:
                    listOfLengths.append(Part.getCurves()[0].getLength())

        maxDiameter = max(listOfDiameters) #Getting the max diameter to use as search range
        
        #Use old and slow code in case sklearn fails to import
        if import_sklearn == False:
            _target = apex.EntityCollection()
            ## Getting all faces from all parts that are not under 'Trajectories'
            for Part in listOfAllParts:
                for Surface in Part.getSurfaces():
                    for Face in Surface.getFaces():
                        for part in listOfTrajectories:
                            for solid in part.solids:
                                x1, y1, z1 = solid.getLocation().x, solid.getLocation().y, solid.getLocation().z
                                x2, y2, z2 = Face.getLocation().x, Face.getLocation().y, Face.getLocation().z
                                dist = ((x1-x2)**2+(y1-y2)**2+(z1-z2)**2)**0.5
                                # print(dist)
                                if dist < maxDiameter:
                                    _target.append(Face)
        else:
            #Get spheres and the centroids
            listOfSpheres = apex.EntityCollection()
            SphereCGs = []
            for Part in model_1.getParts(True):
                if "Refinement regions" in Part.getPath():
                    for solid in Part.getSolids():
                        listOfSpheres.append(solid)
                        SphereCGs.append([solid.getLocation().x, solid.getLocation().y, solid.getLocation().z])   
            
            #Get faces and the centroids
            listOfFaces = apex.EntityCollection()
            FaceCGs = []
            for Part in listOfAllParts:
                for Surface in Part.getSurfaces():
                    for Face in Surface.getFaces():
                        FaceCGs.append([Face.getCentroid().getX(), Face.getCentroid().getY(), Face.getCentroid().getZ()])
                        listOfFaces.append(Face)
            
            #Use sklearn to calc distances
            calcDist = euclidean_distances(SphereCGs, FaceCGs)

            listToMesh = []
            for k in range(int(len(calcDist))):
                for j in range(len(calcDist[k])):
                    if calcDist[k][j] < maxDiameter:
                        listToMesh.append(j)  
                        
            listToMesh = list(set(listToMesh))
            
            _target = apex.EntityCollection()
            for ID in listToMesh:
                _target.append(listOfFaces[ID])                        

        apex.mesh.createSurfaceMesh(
            name="",
            target=_target,
            meshSize=MeshSize,
            meshType=apex.mesh.SurfaceMeshElementShape.Quadrilateral,
            meshMethod=apex.mesh.SurfaceMeshMethod.Pave,
            mappedMeshDominanceLevel=2,
            elementOrder=apex.mesh.ElementOrder.Linear,
            meshUsingPrincipalAxes=False,
            refineMeshUsingCurvature=True,
            elementGeometryDeviationRatio=0.10,
            elementMinEdgeLengthRatio=0.50,
            createFeatureMeshOnFillets=False,
            createFeatureMeshOnChamfers=False,
            createFeatureMeshOnWashers=False,
            createFeatureMeshOnQuadFaces=False
        )

        t1_stop = perf_counter()
        print("Elapsed time during the whole program in seconds:",round(t1_stop-t1_start,3))
    # except:
        # print("Meshing failed or not performed.")

# coding: utf-8



import apex
from apex.construct import Point3D, Point2D
from tempfile import mkstemp
from shutil import move
import os
from pathlib import Path
from math import sqrt, pow, degrees, acos, pi

#Based on XYZ location data script

def distance(v1,v2):
    return sqrt(((v1[0]-v2[0])**2)+((v1[1]-v2[1])**2)+((v1[2]-v2[2])**2))

def find_near_surfs_location(surfaces,coord,tol):
    near_surfs2=apex.entityCollection()
    for surf in surfaces:
        surf_loc = surf.evaluateClosestLocation(coord.getLocation()).getClosestLocation()
        v1 = [surf_loc.x,surf_loc.y,surf_loc.z]
        v2= [coord.x,coord.y,coord.z]
        dist = distance(v1,v2)
        #print("Distance from point to ", surf.name," : ", dist)
        if dist <= tol:
            near_surfs2.append(surf)
    return near_surfs2

def mwf_out(selectedData,unit,directory):
    #print('Data Legth: ',selectedData.len())
    #print(dict)
    mySearch = apex.utility.ProximitySearch()
    iSurfs = apex.IPhysicalCollection()
    surfaces = apex.entityCollection()
    id=0
    tol = 50.0
    print("Will write CSV File\n")
    print("If you get permission error 13, please close the CSV file and run the script again\n")
    p = Path(apex.currentModel().path)            #get Apex model directory
    text_file = open(os.path.join(directory,'Weld Points.csv'), "wt")     #create file on Apex model parent directory
    text_file.write("# Length unit: ["+unit+']\n')        #write file header
    text_file.write("#\n")     
    text_file.write("#Orientation: local second point\n") 
    text_file.write("2\n")
    text_file.write("# order;activity;x-coordinate;y-coordinate;z-coordinate;x-orientation;y-orientation;z-orientation;pause time\n")        #write file header
    print('\nSearching for selected surfaces')
    for data in selectedData:
        entType = data.getEntityType()
        if entType == apex.EntityType.Surface:             #iterate over selected surfaces
            iSurfs.append(data.asEntity())             #append surfaces to IPhysical Collection to be searched
            surfaces.append(data)
    mySearch.insertCollection(iSurfs)                          #add surfaces as search target
    print('Searching for selected weld points')
    for data in selectedData:
        entType = data.getEntityType()
        if entType == apex.EntityType.Point:               #iterate over selected points
            name=[]                                    #string for parent Part names
            id=id+1                                    #counter
            loc = data.getLocation()                   #get point location and coordinates
            x = loc.getX()
            y = loc.getY()
            z = loc.getZ()
            near = find_near_surfs_location(surfaces,loc,tol)                            #return surfaces near to this pojt location
            n = len(near)
            for surf in near:
                name.append(surf.asEntity().asSurface().getParent().getName())      #get name of first part
            text_file.write(str(id)+";TRUE;"+str(round(x,3))+";"+str(round(y,3))+";"+str(round(z,3))+";0.0;0.0;1.0;0.0\n")                                              
            # for i in name:
                # text_file.write(";"+i)                                           #write part name
            # text_file.write("\n")
    print('Wrote CSV File, check export directory')
    text_file.close()



def main(dict={}):
    unitSystems = {}
    unitSystems["inch"] = r'''in-slinch-s-lbf'''
    unitSystems["mm"]   = r'''mm-t-s-N'''
    unitSystems["m"]    = r'''m-kg-s-N'''
    myModel = apex.currentModel()
    unit = dict["unit"]
    data = dict["data"]
    dirToSave = dict["saveToDir"]
    apex.disableShowOutput()
    apex.setScriptUnitSystem(unitSystemName = r'''m-kg-s-N''') # set the unit system to report data
    
    print("Selected base unit: m") 

    _selected = apex.selection.getCurrentSelection()       #get selection
    
    if _selected.len() == 0:
        print("Nothing selected!")
        return
        
    mwf_out(_selected, unit,dirToSave)     #run main job

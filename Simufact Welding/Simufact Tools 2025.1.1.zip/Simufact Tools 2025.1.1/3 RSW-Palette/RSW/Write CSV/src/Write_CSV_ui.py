import sys
import os
import apex_sdk
import clr

#.NET references
import System
import System.Windows.Controls as WPFControls
from System.Windows.Forms import FolderBrowserDialog
from System.Windows.Automation import AutomationProperties

#Based on XYZ location data script

# Define current file path of example
current_file_path = os.path.dirname(os.path.realpath(__file__))

#setting pre-defined properties of tool_propertyContainer
def getUIContent():
    my_toolProperty = apex_sdk.ToolPropertyContainer()
    my_toolProperty.ToolPropertyContent = getCustomToolPropertyContent()
    my_toolProperty.TitleText = "CSV File Writter"
    my_toolProperty.TitleImageUriString = os.path.join(os.path.dirname(current_file_path), r"res\sequence.png") 
    
    my_toolProperty.WorkFlowInstructions = ''' 
    <p><strong><span style="color: #999999;">Creates a CSV Spot Weld File<br /></span></strong></p>
    <p><span style="color: #999999;">Description: Will create a CSV File based on spot weld point location. This file can then be used by the "Create Spot Weld" tool afterwards.<br /></span></p>
    <p><span style="color: #999999;">Workflow:</span></p>
    <ol>
    <li><span style="color: #999999;">Select the points you want to create the file for</span></li>
    <li><span style="color: #999999;">Click Create CSV File and select the export sirectory<span><span style="color: #999999;"></span></li>
    <li><span style="color: #999999;">After that, you can use the Create Spot Weld Tool with the generated files!</span><span style="color: #999999;"></span></li>
    </ol>
    <p><span style="color: #999999;">For support: <a href="mailto:support.americas@simufact.com" style="color: #999999;"><span style="color: #ff0000;">support.americas@simufact.com</span></a></span></p>
    '''

    
    # handle apply button (green) click event
    my_toolProperty.AppliedCommand = apex_sdk.ActionCommand(System.Action(HandleApplyButton))
    # handle exit button (red) click event
    my_toolProperty.ExitCommand = apex_sdk.ActionCommand(System.Action(HandleExitButton))
    
    #define pickFiterTools
    my_toolProperty.ShowPickChoice = True
    my_toolProperty.IsCustomTool = True
    #setPickFilterTools()
    my_toolProperty.PickFilterList = setPickFilterTools()
    
    #return my_toolProperty
    return my_toolProperty


#get tool property content
def getCustomToolPropertyContent():
    my_Grid = WPFControls.Grid()
    
    createLayout(my_Grid, 4, 2)
    currRow = 0
    
    global unitComboBox
    unitComboBox = createComboBox2(my_Grid, "Unit:", ["m", "mm", "inch"], 0, 0, 0)
    
    # Create a button
    currRow += 2
    goButton = WPFControls.Button()
    goButton.Content = "Create CSV File"
    WPFControls.Grid.SetRow(goButton, currRow)
    WPFControls.Grid.SetColumn(goButton, 0)
    goButton.Height = 30
    WPFControls.Grid.SetColumnSpan(goButton, 3)
    
    global dialog
    dialog = FolderBrowserDialog()
    dialog.Description = "Directory where to save trajectories"
    dialog.ShowNewFolderButton = True

    # Link a function to the Button "Click" event
    # This function will be called every time the Button is clicked
    goButton.Click += HandleApplyButton
    my_Grid.Children.Add(goButton)
    return my_Grid






def createLayout(parent, numRows, numCols):
    for k in range(numRows):
        parent.RowDefinitions.Add(WPFControls.RowDefinition())
    for k in range(numCols):
        parent.ColumnDefinitions.Add(WPFControls.ColumnDefinition())


def createDataBox(parent, title, value, row, col):
    textBlock = WPFControls.TextBlock()
    textBlock.Text = title
    WPFControls.Grid.SetRow(textBlock, row)
    WPFControls.Grid.SetColumn(textBlock, col)

    textBox =WPFControls.TextBox()
    WPFControls.Grid.SetRow(textBox, row)
    WPFControls.Grid.SetColumn(textBox, col+1)
    textBox.Text=value
    
    parent.Children.Add(textBlock)
    parent.Children.Add(textBox)
    
    return textBox



def createComboBox2(parent, title, labels, selected, row, col):
    textBlock = WPFControls.TextBlock()
    textBlock.Text = title
    WPFControls.Grid.SetRow(textBlock, row)
    WPFControls.Grid.SetColumn(textBlock, col)

    #parent.Children.Add(textBlock)
    
    comboBox = WPFControls.ComboBox()
    for label in labels:
        item = WPFControls.ComboBoxItem()
        item.Content=label
        comboBox.Items.Add(item)
    
    WPFControls.Grid.SetRow(comboBox, row)
    WPFControls.Grid.SetColumn(comboBox, col+1)
    
    if selected > len(labels): selected = 0
    comboBox.SelectedIndex=selected
    
    #parent.Children.Add(comboBox)
    
    return comboBox



#set pickFilers
#some pick choices are commented out
def setPickFilterTools():
    pickChoices = System.Collections.Generic.List[System.String]()
    
    #exclusive picking and visibility picking	
    pickChoices.Add(apex_sdk.PickFilterTypes.ExclusivePicking)
    pickChoices.Add(apex_sdk.PickFilterTypes.VisibilityPicking)
    
    #Assembly and part
    #pickChoices.Add(apex_sdk.PickFilterTypes.Assembly)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Part)
    
    #Bodies	
    #pickChoices.Add(apex_sdk.PickFilterTypes.SolidMesh)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Solid)
    #pickChoices.Add(apex_sdk.PickFilterTypes.SurfaceMesh)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Surface)
    #pickChoices.Add(apex_sdk.PickFilterTypes.CurveMesh)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Curve)
    pickChoices.Add(apex_sdk.PickFilterTypes.Point)
    
    #features
    #pickChoices.Add(apex_sdk.PickFilterTypes.CellMesh)
    #pickChoices.Add(apex_sdk.PickFilterTypes.FaceMesh)
    #pickChoices.Add(apex_sdk.PickFilterTypes.EdgeMesh)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Cell)
    #pickChoices.Add(apex_sdk.PickFilterTypes.VertexMesh)
    
    #Lower Dimensional Entities
    #pickChoices.Add(apex_sdk.PickFilterTypes.Element3D)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Element2D)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Face)
    #pickChoices.Add(apex_sdk.PickFilterTypes.MeshSeed)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Element1D)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Edge)
    #pickChoices.Add(apex_sdk.PickFilterTypes.SeedPoint)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Node)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Vertex)
    
    #Sub Lower Dimensional Entities
    #pickChoices.Add(apex_sdk.PickFilterTypes.ElementEdge)
    #pickChoices.Add(apex_sdk.PickFilterTypes.ElementFace)
    
    #Interactions and connections
    #pickChoices.Add(apex_sdk.PickFilterTypes.DiscreteTie)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Connector)
    #pickChoices.Add(apex_sdk.PickFilterTypes.EdgeTie)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Joint)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Glue)
    
    #LBCs
    #pickChoices.Add(apex_sdk.PickFilterTypes.Pressure)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Gravity)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Constraint)
    #pickChoices.Add(apex_sdk.PickFilterTypes.ForceMoment)
    #pickChoices.Add(apex_sdk.PickFilterTypes.EnforcedMotion)
    
    #Attributes and other objects
    #pickChoices.Add(apex_sdk.PickFilterTypes.CompositeZone)
    #pickChoices.Add(apex_sdk.PickFilterTypes.LayeredPanel)
    #pickChoices.Add(apex_sdk.PickFilterTypes.InterfacePoint)
    #pickChoices.Add(apex_sdk.PickFilterTypes.PointMass)
    #pickChoices.Add(apex_sdk.PickFilterTypes.BeamSpan)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Offset)
    
    #Sensors
    #pickChoices.Add(apex_sdk.PickFilterTypes.MotionEnvelopeSensor)
    #pickChoices.Add(apex_sdk.PickFilterTypes.ClearanceSensor)
    #pickChoices.Add(apex_sdk.PickFilterTypes.CrossSectionSensor)
    #pickChoices.Add(apex_sdk.PickFilterTypes.PointSensor)
    
    #Coordinate system
    #pickChoices.Add(apex_sdk.PickFilterTypes.CoordinateSystem)
    
    #Tool Registration
    #Tool Name has to be the same
    #apex_sdk.PickFilterRegistration.RegisterTool("Location Data", pickChoices)
    return pickChoices





# apply button (green) from tool header
@apex_sdk.errorhandler
def HandleApplyButton(sender,args):
    dictionary = {}
    
    if dialog.ShowDialog():
        dictionary["saveToDir"] = str(dialog.SelectedPath)
    else:
        dictionary["saveToDir"] = ""
    
    dictionary["data"] = "Location"
    
    choices = unitComboBox.SelectedValue.ToString().split(":")
    choice = choices[len(choices)-1].lstrip().rstrip()
    
    dictionary["unit"] = "m"
    
    file_path = os.path.dirname(os.path.realpath(__file__))
    script_path= os.path.join(file_path, 'Write_CSV.py')
    apex_sdk.runScriptFunction(script_path, "main", dictionary)
    

# exit button (red) from tool header
@apex_sdk.errorhandler
def HandleExitButton():
    print("HandleExitButton")


'''
#This function receives data from the Script API function and updates the Tool UI 
@apex_sdk.errorhandler
def UpdateFormData():
    ret_dict = apex_sdk.getScriptFunctionReturnData()
    if ret_dict["count"] == "1":
        entityTextBox = ret_dict["entity"]
        xTextBox.Text = ret_dict["x"]
        yTextBox.Text = ret_dict["y"]
        zTextBox.Text = ret_dict["y"]
'''

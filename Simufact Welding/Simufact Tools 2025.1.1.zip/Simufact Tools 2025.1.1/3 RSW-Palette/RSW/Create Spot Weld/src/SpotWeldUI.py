import sys
import os
import apex_sdk
import clr


#.NET references
import System
import System.Windows.Controls as WPFControls
from System.Windows.Automation import AutomationProperties
from Microsoft.Win32 import OpenFileDialog

dictionary = {}
current_file_path = os.path.dirname(os.path.realpath(__file__))

#setting pre-defined properties of tool_propertyContainer
def getUIContent():

   my_toolProperty = apex_sdk.ToolPropertyContainer()
   my_toolProperty.ToolPropertyContent = getCustomToolPropertyContent()
   my_toolProperty.TitleText = "  Create spot locations"
   my_toolProperty.TitleImageUriString = os.path.join(os.path.dirname(current_file_path), r"res\CreateSpotWeldICON.png")
   my_toolProperty.WorkFlowInstructions = ''' 
    <p><strong><span style="color: #999999;">Create Spot Weld<br /></span></strong></p>
    <p><span style="color: #999999;">Description: This tools creates spherical refinement regions in spot weld locations<br /></span></p>
    <ul>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Refinement diameter (mm)</span>: Size of the refinement region that will be created<br /></span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Max stacked thickness (mm)</span>: maximum total thickness in the model, used as a search area for nearby plates<br /></span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Split surfaces</span>: Option to automatically split the surfaces to create refinement regions (recommended)<br /></span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Single sphere per location</span>: This will create a single sphere per location. Useful to be used with the AutoRSW tool.<br /></span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Use CAD Points instead of CSV</span>: Option to use selected points instead of CSV File<br /></span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Type of CSV file</span>: Simufact format is the default. If using generic format, file need to be in units of "mm", must use ";" as separator, and only have the X, Y and Z coordinates in each line and nothing else in the file. See doc folder of this script for example files.<br /></span></li>
    <li><span style="color: #999999;"><span style="color: #00ccff;">Files selected</span>: Selected CSV files in Simufact format. You may use the Write CSV tool to generate this file given surfaces and points from CAD<br /></span></li>
    </ul>
    <p><span style="color: #999999;">Workflow:</span></p>
    <ol>
    <li><span style="color: #999999;">Select the CSV files with the spot weld location or select the points on screen<br /></span></li>
    <li><span style="color: #999999;">Select appropriate options in the GUI<br/span><span style="color: #999999;"></span></li>
    <li><span style="color: #999999;">Click "Create spot locations" button<br/span><span style="color: #999999;"></span></li>
    <li><span style="color: #999999;">After that, you can use the Mesh Partitions and Mesh non partition tools to automatically mesh the model!</span><span style="color: #999999;"></span></li>
    </ol>
    <p><span style="color: #999999;">For support: <a href="mailto:support.americas@simufact.com" style="color: #999999;"><span style="color: #ff0000;">support.americas@simufact.com</span></a></span></p>
    <p><span style="color: #999999;"><span style="color: #ff0000;"></span></span></p>
    '''
   # Define PickFilterList
   my_toolProperty.ShowPickChoice = True
   my_toolProperty.IsCustomTool = True                                   
   my_toolProperty.PickFilterList = setPickFilterList()
   return my_toolProperty
   
# Set PickFilters
def setPickFilterList():
    # Create an empty List of strings
    pickChoices = System.Collections.Generic.List[System.String]()

    # Exclusive picking and visibility picking
    pickChoices.Add(apex_sdk.PickFilterTypes.ExclusivePicking)
    pickChoices.Add(apex_sdk.PickFilterTypes.VisibilityPicking)

    # Add Types
    pickChoices.Add(apex_sdk.PickFilterTypes.Point)

    # Return the pick filter list
    return pickChoices

#get tool property content
def getCustomToolPropertyContent():
   #Create a Grid
   my_Grid = WPFControls.Grid()
   global selectedFiles
   selectedFiles = []
   #Add 2 Rows and 1 Column
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.RowDefinitions.Add(WPFControls.RowDefinition())
   my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())
   my_Grid.ColumnDefinitions.Add(WPFControls.ColumnDefinition())
   
   #Row 0
   #Create a label (TextBlock)
   #Set it's Text value
   #Assign it to Row 0, Column 0
   global refineSizeTextBox
   refineTextBlock = WPFControls.TextBlock()
   refineTextBlock.Text = "Refinement diameter (mm):"
   WPFControls.Grid.SetRow(refineTextBlock, 0)
   WPFControls.Grid.SetColumn(refineTextBlock, 0)

   

   #Create an empty input TextBox assign it to Row 0, Column 1
   refineSizeTextBox =WPFControls.TextBox()
   WPFControls.Grid.SetRow(refineSizeTextBox, 0)
   WPFControls.Grid.SetColumn(refineSizeTextBox, 1)
   refineSizeTextBox.Text = str(5.0)   
   
   #Create a button and set it's text to "Import"
   #Assign it to Row1, Column 0
   global importBtn
   importBtn = WPFControls.Button()
   importBtn.Content="Import CSV files"
   WPFControls.Grid.SetRow(importBtn, 7)
   WPFControls.Grid.SetColumn(importBtn, 0)
   
   #Link a function to the Button "Click" event 
   #This function will be called every time the Button is clicked
   importBtn.Click+=HandleimportBtn
   
   #Create an empty input TextBox
   global fileNameTextBox
   fileNameTextBox =WPFControls.TextBox()
   WPFControls.Grid.SetRow(fileNameTextBox, 5)
   WPFControls.Grid.SetColumn(fileNameTextBox, 1)
   
   global selectedFilesText
   selectedFilesText = WPFControls.TextBlock()
   selectedFilesText.Text = "File(s) selected:"
   WPFControls.Grid.SetRow(selectedFilesText, 5)
   WPFControls.Grid.SetColumn(selectedFilesText, 0)
   
   #Create a label (TextBlock)
   #Set it's Text value
   #Assign it to Row 0, Column 0
   global tolTextBlock
   tolTextBlock = WPFControls.TextBlock()
   tolTextBlock.Text = "Max stacked thickness (mm):"
   WPFControls.Grid.SetRow(tolTextBlock, 1)
   WPFControls.Grid.SetColumn(tolTextBlock, 0)


   global tolTextBox
   #Create an empty input TextBox assign it to Row 0, Column 1
   tolTextBox =WPFControls.TextBox()
   WPFControls.Grid.SetRow(tolTextBox, 1)
   WPFControls.Grid.SetColumn(tolTextBox, 1)
   tolTextBox.Text = str(10.0)
   
   #Create a button
   #Assign it to Row1, Column 0
   goSpots = WPFControls.Button()
   goSpots.Content="Create spot locations"
   WPFControls.Grid.SetRow(goSpots, 8)
   WPFControls.Grid.SetColumn(goSpots, 0)
   WPFControls.Grid.SetColumnSpan(goSpots, 2)
   goSpots.Height = 30
   
   # Create checkbox
   global chk01
   chk01 = WPFControls.CheckBox()
   chk01.Content = "Use CAD Points instead of CSV"
   chk01.Height = 20
   WPFControls.Grid.SetRow(chk01, 4)
   WPFControls.Grid.SetColumn(chk01, 0)
   WPFControls.Grid.SetColumnSpan(chk01, 1)
   
   # Create checkbox
   global chk02
   chk02 = WPFControls.CheckBox()
   chk02.Content = "Split surfaces?"
   chk02.Height = 20
   WPFControls.Grid.SetRow(chk02, 2)
   WPFControls.Grid.SetColumn(chk02, 0)
   WPFControls.Grid.SetColumnSpan(chk02, 1)
   chk02.IsChecked = System.Nullable[System.Boolean](True)
   
   # Create checkbox
   global chk03
   chk03 = WPFControls.CheckBox()
   chk03.Content = "Single sphere per location"
   chk03.Height = 20
   WPFControls.Grid.SetRow(chk03, 3)
   WPFControls.Grid.SetColumn(chk03, 0)
   WPFControls.Grid.SetColumnSpan(chk03, 1)
   
   # Type of model
   global modelType
   modelType = WPFControls.TextBlock()
   modelType.Text = "Type of CSV File:"
   WPFControls.Grid.SetRow(modelType, 6)
   WPFControls.Grid.SetColumn(modelType, 0)

   # Create a Combo box
   global modelTypeSelection
   modelTypeSelection = WPFControls.ComboBox()
   item1 = WPFControls.ComboBoxItem()
   item1.Content = "Simufact format"
   modelTypeSelection.Items.Add(item1)

   item2 = WPFControls.ComboBoxItem()
   item2.Content = "Generic XYZ data"
   modelTypeSelection.Items.Add(item2) 

   modelTypeSelection.SelectedIndex = 0
   WPFControls.Grid.SetRow(modelTypeSelection, 6)
   WPFControls.Grid.SetColumn(modelTypeSelection, 1)     
   
   #Link a function to the Button "Click" event 
   #This function will be called every time the Butto is clicked
   goSpots.Click+=HandleCreateSpots
   
   
   chk01.Checked   += chk01HandleCheck
   chk01.Unchecked += chk01HandleUnCheck
   
   
   # Add the controls to the Grid
   my_Grid.Children.Add(chk01)
   my_Grid.Children.Add(chk02)
   my_Grid.Children.Add(chk03)
   my_Grid.Children.Add(importBtn)
   my_Grid.Children.Add(goSpots)
   my_Grid.Children.Add(tolTextBlock)
   my_Grid.Children.Add(tolTextBox)
   my_Grid.Children.Add(refineTextBlock)
   my_Grid.Children.Add(refineSizeTextBox)
   my_Grid.Children.Add(fileNameTextBox)
   my_Grid.Children.Add(selectedFilesText)
   my_Grid.Children.Add(modelType)
   my_Grid.Children.Add(modelTypeSelection)

   
   #Return the Grid
   return my_Grid

@apex_sdk.errorhandler
def chk01HandleUnCheck(sender, event):
    global importBtn,fileNameTextBox,selectedFilesText,modelType,modelTypeSelection
    
    fileNameTextBox.Visibility = System.Windows.Visibility.Visible
    selectedFilesText.Visibility = System.Windows.Visibility.Visible
    importBtn.Visibility = System.Windows.Visibility.Visible
    modelType.Visibility = System.Windows.Visibility.Visible
    modelTypeSelection.Visibility = System.Windows.Visibility.Visible

@apex_sdk.errorhandler
def chk01HandleCheck(sender, event):
    global importBtn,fileNameTextBox,selectedFilesText,modelType,modelTypeSelection

    fileNameTextBox.Visibility = System.Windows.Visibility.Collapsed
    selectedFilesText.Visibility = System.Windows.Visibility.Collapsed
    importBtn.Visibility = System.Windows.Visibility.Collapsed
    modelType.Visibility = System.Windows.Visibility.Collapsed
    modelTypeSelection.Visibility = System.Windows.Visibility.Collapsed
 
#Function to handle the Import Button "Click" event
#This function gets called every time the Button is clicked
@apex_sdk.errorhandler
def HandleimportBtn(sender,args):
   global selectedFiles
   #Create a File open dialog
   dialog = OpenFileDialog()
   dialog.Title = "Select CSV file(s)"
   
   #Configure for single file selection
   dialog.Multiselect = True
   
   #Set up the file types you want to support
   dialog.Filter = "CSV Files|*.csv|All Files|*.*"
   
   #Display the dialog
   #If it returns anything
   #   get the file name
   if dialog.ShowDialog():
    selectedFiles = dialog.FileNames
    fileNameTextBox.Text = str(len(selectedFiles))
    
#user defined button clickHandlers
@apex_sdk.errorhandler
def HandleCreateSpots(sender, args):
   global selectedFiles
   dictionary["RefineDiameter"]= refineSizeTextBox.Text
   dictionary["Tolerance"]= tolTextBox.Text
   dictionary["FileList"] = ""
   dictionary["CADPoint"] = chk01.IsChecked
   dictionary["SplitChk"] = chk02.IsChecked
   dictionary["SingleSphere"] = chk03.IsChecked
   dictionary["jointType"] = modelTypeSelection.Text
   if len(selectedFiles) > 0:
       for elem in list(selectedFiles):
           dictionary["FileList"] += elem
           dictionary["FileList"] += ','
   
   file_path = os.path.dirname(os.path.realpath(__file__))
   script_path= os.path.join(file_path, 'SpotWeld.py')
   apex_sdk.runScriptFunction(script_path, "CreateSpots", dictionary)
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
 
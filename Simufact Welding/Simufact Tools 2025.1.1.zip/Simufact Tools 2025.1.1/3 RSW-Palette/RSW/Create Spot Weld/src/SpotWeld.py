# coding: utf-8
import apex
apex.disableShowOutput()

def CreateSpots(dict={}):
    from apex.construct import Point3D, Point2D
    from math import sqrt, pow, degrees, acos, pi
    import os

    apex.setScriptUnitSystem(unitSystemName=r'''mm-kg-s-N''')
    absPath = os.path.dirname(os.path.realpath(__file__))

    ### Math functions needed when numpy is not available
    def dotproduct(v1, v2):  # Dot product of two vectors (list), cosine of the angle
        return sum((a * b) for a, b in zip(v1, v2))

    def length(v):  # Length of a vector (list)
        return sqrt(dotproduct(v, v))

    def distance(v1,v2):
        return sqrt(((v1[0]-v2[0])**2)+((v1[1]-v2[1])**2)+((v1[2]-v2[2])**2))

    def angle(v1, v2):  # Angle between two vectors in degrees (lists)
        return degrees(acos(dotproduct(v1, v2) / (length(v1) * length(v2))))  # Return the angle in degrees

    def cross(a, b):  # Cross-product (orthogonal vector) of two vectors (list)
        c = [a[1] * b[2] - a[2] * b[1],
             a[2] * b[0] - a[0] * b[2],
             a[0] * b[1] - a[1] * b[0]]
        return c  # List of three components (x,y,z) of the orthogonal vector

    def find_near_surfs(surfaces,coord,tol):
        near_surfs=apex.entityCollection()
        mySearch = apex.utility.ProximitySearch()
        iSurfs = apex.IPhysicalCollection()
        for data in surfaces:
            entType = data.getEntityType()
            if entType == apex.EntityType.Surface:            
                iSurfs.append(data.asEntity())             
        mySearch.insertCollection(iSurfs)                          							#add surfaces as search target
        loc = coord.getLocation()                   									#get point location and coordinates
        near_surfs = mySearch.findObjectsWithinDistance(loc,tol).foundObjects()    #return surfaces near to this point location
        return near_surfs
        
    def find_near_surfs_location(surfaces,coord,tol):
        near_surfs2=apex.entityCollection()
        for surf in surfaces:
            surf_loc = surf.evaluateClosestLocation(coord.getLocation()).getClosestLocation()
            v1 = [surf_loc.x,surf_loc.y,surf_loc.z]
            v2= [coord.x,coord.y,coord.z]
            dist = distance(v1,v2)
            #print("Distance from point to ", surf.name," : ", dist)
            if dist <= tol:
                near_surfs2.append(surf)
        return near_surfs2

    def CreateSpotGroup(CSVPath="Path", RefineDiam=8.0):
        model_1 = apex.currentModel()

        # if "/" in CSVPath:
            # TrajectoryName = CSVPath[CSVPath.rfind("/") + 1:-4]
        # else:
            # TrajectoryName = CSVPath[CSVPath.rfind("\\") + 1:-4]

        try:
            TrajAssy = model_1.getAssembly(pathName="Refinement regions")
        except:
            TrajAssy = model_1.createAssembly(name="Refinement regions")
            
        try:
            if model_1.getAssembly("Refinement regions").getPart(name="RefDiam_{0}".format(RefineDiam)):
                SpecifiedDiameter = model_1.getAssembly("Refinement regions").getPart(name="RefDiam_{0}".format(RefineDiam))
            else:
                SpecifiedDiameter = apex.createPart(name = "RefDiam_{0}".format(RefineDiam))
                SpecifiedDiameter.setParent(model_1.getAssembly("Refinement regions"))
        except:
            print("Part creation failed!")
        
        part = SpecifiedDiameter
        partPath = part.getPath()[part.getPath().find("/")+1:]+"/"+part.getName()
        model_1.setCurrentPart(partPath)
        tol = float(dict["Tolerance"])
        WeldPositions = []
        ScalingToMM = 1.0
        if dict["CADPoint"]== 'False':
            with open(CSVPath, 'r') as CSVFile:
                for line in CSVFile:
                    if dict["jointType"] == "Simufact format":
                        if "Length unit: " in line:
                            unit = line.strip().split('[')[-1].replace("]", "")
                            #print(unit)
                            if "mm" in unit:
                                print("No scaling needed")
                                ScalingToMM = 1.0
                            elif "m" in unit:
                                print("Scaling from meters")
                                ScalingToMM = 1000.0
                            elif "in" in unit:
                                print("Scaling from inches")
                                ScalingToMM = 25.40      
                        if ('true' in line) or ('TRUE' in line):
                            print('true')
                            WeldPositions.append([ScalingToMM * float(x) for x in line.strip().split(';')[2:5]])
                    elif dict["jointType"] == "Generic XYZ data":
                        WeldPositions.append([float(line.strip().split(';')[0]),float(line.strip().split(';')[1]),float(line.strip().split(';')[2])])
        else:
            if len(apex.selection.getCurrentSelection()) > 0:
                for data in apex.selection.getCurrentSelection():
                    if data.getEntityType() == apex.EntityType.Point:   
                        WeldPositions.append([data.getLocation().x,data.getLocation().y,data.getLocation().z])                    
            else:
               apex.enableShowOutput() 
               print("Please select at least one point")

        
        #find all surfaces
        spheres = apex.entityCollection()
        surfaces = apex.entityCollection()        
        for part in model_1.getParts(recursive=True):
            surfaces.extend(part.surfaces)
        print("Total # of surfaces: ",len(surfaces))
        print("Total # of weld points: ",len(WeldPositions))
        #start to work point by point
        for spotPoint in WeldPositions:
            coord = apex.Coordinate(spotPoint[0],spotPoint[1],spotPoint[2])
            #near = find_near_surfs(surfaces,coord,tol)
            near2 = find_near_surfs_location(surfaces,coord,tol)
            #print("Near surfaces: ",len(near2))
            if len(near2) == 0 and dict["SingleSphere"]== 'False':
                apex.enableShowOutput()
                print("No near surfaces found, please make sure midsurfaces are present")
                continue
            if dict["SingleSphere"]== 'True':
               sphere = apex.geometry.createSphereByLocationOrientation(
                    name='',
                    description='',
                    radius=RefineDiam / 2.0,
                    origin=coord,
                    orientation=apex.construct.createOrientation(alpha=0.0, beta=0.0, gamma=0.0)
               )
               sphere.asSolid().update(enableTransparency=True, transparencyLevel=50)
            else:
                for surf in near2:
                   surf_loc = surf.evaluateClosestLocation(coord.getLocation()).getClosestLocation()
                   sphere = apex.geometry.createSphereByLocationOrientation(
                        name='',
                        description='',
                        radius=RefineDiam / 2.0,
                        origin=apex.Coordinate(surf_loc.x,surf_loc.y,surf_loc.z),
                        orientation=apex.construct.createOrientation(alpha=0.0, beta=0.0, gamma=0.0)
                   )
                   sphere.asSolid().update(enableTransparency=True, transparencyLevel=50)
                   spheres.append(sphere)
                   
                   surfs = apex.entityCollection()
                   surfs.append(surf)
                   #faces = apex.entityCollection()
                   #faces.append(sphere.faces[0])
                   #Create an additional sphere to have a smoother transition
                   sphere2 = apex.geometry.createSphereByLocationOrientation(
                        name='',
                        description='',
                        radius=(1.5*RefineDiam) / 2.0,
                        origin=apex.Coordinate(surf_loc.x,surf_loc.y,surf_loc.z),
                        orientation=apex.construct.createOrientation(alpha=0.0, beta=0.0, gamma=0.0)
                   )
                   sphere2.asSolid().update(enableTransparency=True, transparencyLevel=50)
                   #faces.append(sphere2.faces[0])
                   spheres.append(sphere2)
        
        # find all spheres that lie on a given surface
        if dict["SplitChk"] == 'True':
            for surf in surfaces:
                split_surf = apex.entityCollection()
                split_surf.append(surf)
                faces = apex.entityCollection()
                for sphere in spheres:
                    surf_loc = surf.evaluateClosestLocation(sphere.getOrigin()).getClosestLocation()
                    v1 = [surf_loc.x,surf_loc.y,surf_loc.z]
                    v2= [sphere.getOrigin().x,sphere.getOrigin().y,sphere.getOrigin().z]
                    dist = distance(v1,v2)
                    if dist <= 0.1:
                        faces.append(sphere.faces[0])
                #print(len(faces))
                try:
                    splitted = apex.geometry.split(
                       target = split_surf,
                       splitter = faces,
                       splitBehavior = apex.geometry.GeometrySplitBehavior.Partition
                    )
                except:
                    #print("Split failed, no near surfaces probably")
                    pass
    if dict["FileList"] == "":
        #print(dict)
        CreateSpotGroup(CSVPath = "", RefineDiam = float(dict["RefineDiameter"]))
    else:
        vecFiles = dict["FileList"][0:-1].split(',')
        for file in vecFiles:
            CreateSpotGroup(CSVPath = file, RefineDiam = float(dict["RefineDiameter"]))

# 
# Macro recording stopped on Nov 26, 2018 at 17:52:26
#

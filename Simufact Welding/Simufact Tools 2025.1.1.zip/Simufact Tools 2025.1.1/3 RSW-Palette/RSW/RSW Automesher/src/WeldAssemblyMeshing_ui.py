#
# Copyright © 2022 Hexagon Manufacturing Intelligence, Inc. (“Hexagon”)
#  
# Permission to use Scripts
#  
# Permission is granted to customers of Hexagon and its affiliates with valid licenses of the MSC Apex™ software 
# to use script files posted on this page (collectively “Scripts”) solely for customers’ own authorized 
# internal use in conjunction with licensed use of the MSC Apex software.  
# No other use is permitted.  No license to MSC Apex or other software is granted under this Permission.
#  
# SCRIPTS ARE PROVIDED ON AN "AS-IS" BASIS, WITH NO WARRANTIES OF ANY KIND.  USE OF THE SCRIPTS IS AT CUSTOMER'S SOLE RISK.
#  
# IN NO EVENT SHALL HEXAGON, ITS AFFILIATES, SUBSIDIARIES, SUPPLIERS, AGENTS, REPRESENTATIVES OR EMPLOYEES BE LIABLE FOR ANY 
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, TORT, 
# STRICT LIABILITY, OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION USE OF THE SCRIPTS, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
#  
# Customer shall indemnify, defend and hold Hexagon, its affiliates, subsidiaries, suppliers, agents, 
# employees or representatives (collectively, “Indemnified Parties”) harmless from and against any third-party claims 
# brought against Indemnified Parties rising out of or in connection with Customer’s use of the Scripts.
#
# MSC Apex - User Defined Tools using Python Scripts
# Simple Layout UI Example
# 
#import sys
import os
import apex_sdk
#import clr


# .NET references
import System
import System.Windows.Controls as WPFControls

# Define current file path of example
current_file_path = os.path.dirname(os.path.realpath(__file__))


# Set pre-defined properties of ToolPropertyContainer
def getUIContent():

   my_toolProperty = apex_sdk.ToolPropertyContainer()

   # Provide an icon and a name for the tool property panel
   my_toolProperty.TitleImageUriString = os.path.join(os.path.dirname(current_file_path), r"res\Spot Weld Meshing.png")
   my_toolProperty.TitleText = "RSW Automesher"   

   # Define UI
   my_toolProperty.ToolPropertyContent = getCustomToolPropertyContent()
   #handle apply button (green) click event
   my_toolProperty.AppliedCommand = apex_sdk.ActionCommand(System.Action(HandleApplyButton))
   # handle exit button (red) click event
   my_toolProperty.ExitCommand = apex_sdk.ActionCommand(System.Action(HandleExitButton))
      

   #define pickFiterTools
   my_toolProperty.ShowPickChoice = True
   my_toolProperty.IsCustomTool = True
   #setPickFilterTools()
   my_toolProperty.PickFilterList = setPickFilterTools()

   my_toolProperty.WorkFlowInstructions = '''
    <p><strong><span style="color: #999999;">Automesh RSW<br /></span></strong></p>
    <p><span style="color: #999999;">Description: This tools automatically creates surface meshes with local refinements at spot locations. WARNING: The tool can take several minutes/hours for very complex parts or assemblies with lots of parts.<br /></span></p>
    <p><span style="color: #999999;">Workflow:</span></p>
    <ol>
    <li><span style="color: #999999;">Select the sheet metal solid parts and a single sphere for each spot location (you can use the Create Spot Weld tool to create the single spheres)<br /></span></li>
    <li><span style="color: #999999;">Select the meshing parameters<br /></span></li>
    <li><span style="color: #999999;">The tolerance value can be increased in case some refinement regions are missed.<br /></span></li>
    <li><span style="color: #999999;">Click Automesh RSW</span><span style="color: #999999;"></span></li>
    </ol>
    <p><span style="color: #999999;">For support: <a href="mailto:support.americas@simufact.com" style="color: #999999;"><span style="color: #ff0000;">support.americas@simufact.com</span></a></span></p>
    <p><span style="color: #999999;"><span style="color: #ff0000;"></span></span></p>
    '''

  
   return my_toolProperty


def createLayout(parent, numRows, numCols):
    for k in range(numRows):
        parent.RowDefinitions.Add(WPFControls.RowDefinition())
    for k in range(numCols):
        parent.ColumnDefinitions.Add(WPFControls.ColumnDefinition())

def createCheckBox(parent, label, row, col):

    checkBox = WPFControls.CheckBox()
    checkBox.Content = label
    checkBox.Margin = System.Windows.Thickness(5.)

    WPFControls.Grid.SetRow(checkBox, row)
    WPFControls.Grid.SetColumn(checkBox, col)

    parent.Children.Add(checkBox)

    return checkBox

def createComboBox(parent, row, col):
    comboBox = WPFControls.ComboBox()

    comboBox.Margin = System.Windows.Thickness(5.)

    WPFControls.Grid.SetRow(comboBox, row)
    WPFControls.Grid.SetColumn(comboBox, col)

    parent.Children.Add(comboBox)

    return comboBox


def updateComboBox(comboBox, comboItems):

    for comboItem in comboItems:
        item = WPFControls.ComboBoxItem()
        item.Content=comboItem
        comboBox.Items.Add(item)

    comboBox.SelectedIndex=0


def createComboBox2(parent, title, labels, selected, row, col):
    textBlock = WPFControls.TextBlock()
    textBlock.Text = title

    textBlock.Margin = System.Windows.Thickness(5.)

    WPFControls.Grid.SetRow(textBlock, row)
    WPFControls.Grid.SetColumn(textBlock, col)

    parent.Children.Add(textBlock)

    comboBox = WPFControls.ComboBox()

    comboBox.Margin = System.Windows.Thickness(5.)

    for label in labels:
        item = WPFControls.ComboBoxItem()
        item.Content=label
        comboBox.Items.Add(item)

    WPFControls.Grid.SetRow(comboBox, row)
    WPFControls.Grid.SetColumn(comboBox, col+1)

    if selected > len(labels): selected = 0
    comboBox.SelectedIndex=selected

    parent.Children.Add(comboBox)

    return comboBox


def createSeparator(parent, hight, thickness, span, row,col):

    separator = WPFControls.Separator()
    separator.Margin = System.Windows.Thickness(thickness)

    # Opacity 0.0 could be used as an invisible separator
    separator.Height = hight
    #separator.HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch

    WPFControls.Grid.SetColumnSpan(separator, span)
    WPFControls.Grid.SetRow(separator, row)
    WPFControls.Grid.SetColumn(separator, col)

    parent.Children.Add(separator)

    return separator

def createButton(parent,callback, text, thickness, span, row,col):

    button = WPFControls.Button()
    button.Content = text

    WPFControls.Grid.SetColumn(button, col)
    WPFControls.Grid.SetRow(button, row)
    WPFControls.Grid.SetColumnSpan(button, span)

    # HorizontalAlignment = 3 means STRECHED
    button.HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch
    button.Margin = System.Windows.Thickness(thickness)
    parent.Children.Add(button)
    button.Click += callback


def createDataBox(parent, title, value, row, col):
    textBlock = WPFControls.TextBlock()
    textBlock.Text = title
    WPFControls.Grid.SetRow(textBlock, row)
    WPFControls.Grid.SetColumn(textBlock, col)

    textBox =WPFControls.TextBox()
    WPFControls.Grid.SetRow(textBox, row)
    WPFControls.Grid.SetColumn(textBox, col+1)
    textBox.Text=value

    parent.Children.Add(textBlock)
    parent.Children.Add(textBox)

    return textBox


def getCustomToolPropertyContent():

    my_Grid = WPFControls.Grid()

    createLayout(my_Grid, 8, 2)

    global part_mesh_size_dbox
    global weld_mesh_size_dbox
    global weld_mesh_dia_dbox
    global distance_tol_dbox
    #global methodComboBox
    #global button
    #global TestModeToggle

    iRow = iCol = 0

    part_mesh_size_dbox = createDataBox(my_Grid, "Part Mesh Size (mm):", "4.0", iRow, iCol)
    iRow += 1

    weld_mesh_size_dbox = createDataBox(my_Grid, "Weld Mesh Size (mm):", "0.8", iRow, iCol)
    iRow += 1

    weld_mesh_dia_dbox = createDataBox(my_Grid, "Weld Mesh Diameter (mm):", "6.0", iRow, iCol)
    iRow += 1

    distance_tol_dbox = createDataBox(my_Grid, "Distance Tolerance (mm):", "0.1", iRow, iCol)
    iRow += 1

    #methodComboBox = createComboBox2(my_Grid, "Weld Mesh Method:", ["Geometry Imprint", "Mesh Control" ], 0, iRow, iCol)
    #iRow += 1
    #methodComboBox.SelectionChanged += methodTypeComboBoxCB

    #TestModeToggle =  createCheckBox(my_Grid, "Test Mode", iRow, 0)
    #iRow += 1
    #TestModeToggle.Visibility       = System.Windows.Visibility.Collapsed


    #button = createButton(my_Grid,handleHighlightButton,"Automesh RSW", 20,2, iRow,iCol)
    #iRow += 1

    # Create a button
    iRow += 1
    goButton = WPFControls.Button()
    goButton.Content = "Automesh RSW"
    WPFControls.Grid.SetRow(goButton, iRow)
    WPFControls.Grid.SetColumn(goButton, 0)
    goButton.Height = 30
    WPFControls.Grid.SetColumnSpan(goButton, 3)
    goButton.Click += HandleApplyButton
    my_Grid.Children.Add(goButton)
    

    #TestModeToggle.Checked   += attachWasherHandleCheck
    #TestModeToggle.Unchecked += attachWasherHandleUnCheck


    return my_Grid

'''
def methodTypeComboBoxCB(sender, event):
    # I need to learn and understand sender and event
    global methodComboBox
    global TestModeToggle

    choices = methodComboBox.SelectedValue.ToString().split(":")
    choice = choices[len(choices)-1].lstrip().rstrip()

    if choice == "Geometry Imprint":
        TestModeToggle.Visibility       = System.Windows.Visibility.Collapsed

    else:  # this will be Mesh Control
        TestModeToggle.Visibility       = System.Windows.Visibility.Visible
'''




@apex_sdk.errorhandler
def HandleApplyButton(sender,args):
    dictionary = {}

    dictionary["partSize"]    = part_mesh_size_dbox.Text
    dictionary["weldSize"]    = weld_mesh_size_dbox.Text
    dictionary["weldDia"]     = weld_mesh_dia_dbox.Text
    dictionary["tol"]         = distance_tol_dbox.Text
    #choices = methodComboBox.SelectedValue.ToString().split(":")
    #method = choices[len(choices)-1].lstrip().rstrip()
    dictionary["method"]     = "Geometry Imprint"#method
    dictionary["testMode"]         = 'False' #TestModeToggle.IsChecked

    apex_sdk.runScriptFunction(os.path.join(current_file_path,r'WeldAssemblyMeshing.py'), "main", dictionary)


'''
@apex_sdk.errorhandler
def handleHighlightButton(sender, args):
        
    dummy_dict = {}

    user_tool_script = os.path.join(current_file_path, 'WeldAssemblyMeshing.py')
    apex_sdk.runScriptFunction(user_tool_script, "reset_vp_colors", dummy_dict)
'''


# exit button (red) from tool header
@apex_sdk.errorhandler
def HandleExitButton():
        
    dummy_dict = {}

    user_tool_script = os.path.join(current_file_path, r'WeldAssemblyMeshing.py')
    apex_sdk.runScriptFunction(user_tool_script, "reset_vp_colors", dummy_dict)

'''
def attachWasherHandleCheck(sender, event):
    global washerFactorTextBlock, washerFactorTextBox

    washerFactorTextBlock.Visibility = System.Windows.Visibility.Visible
    washerFactorTextBox.Visibility = System.Windows.Visibility.Visible


def attachWasherHandleUnCheck(sender, event):
    global washerFactorTextBlock, washerFactorTextBox

    washerFactorTextBlock.Visibility = System.Windows.Visibility.Collapsed
    washerFactorTextBox.Visibility = System.Windows.Visibility.Collapsed
'''

def setPickFilterTools():
    pickChoices = System.Collections.Generic.List[System.String]()

    #exclusive picking and visibility picking
    pickChoices.Add(apex_sdk.PickFilterTypes.ExclusivePicking)
    pickChoices.Add(apex_sdk.PickFilterTypes.VisibilityPicking)

    #Assembly and part
    #pickChoices.Add(apex_sdk.PickFilterTypes.Assembly)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Part)

    #Bodies
    #pickChoices.Add(apex_sdk.PickFilterTypes.SolidMesh)
    pickChoices.Add(apex_sdk.PickFilterTypes.Solid)
    #pickChoices.Add(apex_sdk.PickFilterTypes.SurfaceMesh)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Surface)
    #pickChoices.Add(apex_sdk.PickFilterTypes.CurveMesh)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Curve)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Point)

    #features
    #pickChoices.Add(apex_sdk.PickFilterTypes.CellMesh)
    #pickChoices.Add(apex_sdk.PickFilterTypes.FaceMesh)
    #pickChoices.Add(apex_sdk.PickFilterTypes.EdgeMesh)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Cell)
    #pickChoices.Add(apex_sdk.PickFilterTypes.VertexMesh)

    #Lower Dimensional Entities
    #pickChoices.Add(apex_sdk.PickFilterTypes.Element3D)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Element2D)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Face)
    #pickChoices.Add(apex_sdk.PickFilterTypes.MeshSeed)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Element1D)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Edge)
    #pickChoices.Add(apex_sdk.PickFilterTypes.SeedPoint)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Node)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Vertex)

    #Sub Lower Dimensional Entities
    #pickChoices.Add(apex_sdk.PickFilterTypes.ElementEdge)
    #pickChoices.Add(apex_sdk.PickFilterTypes.ElementFace)

    #Interactions and connections
    #pickChoices.Add(apex_sdk.PickFilterTypes.DiscreteTie)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Connector)
    #pickChoices.Add(apex_sdk.PickFilterTypes.EdgeTie)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Joint)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Glue)

    #LBCs
    #pickChoices.Add(apex_sdk.PickFilterTypes.Pressure)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Gravity)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Constraint)
    #pickChoices.Add(apex_sdk.PickFilterTypes.ForceMoment)
    #pickChoices.Add(apex_sdk.PickFilterTypes.EnforcedMotion)

    #Attributes and other objects
    #pickChoices.Add(apex_sdk.PickFilterTypes.CompositeZone)
    #pickChoices.Add(apex_sdk.PickFilterTypes.LayeredPanel)
    #pickChoices.Add(apex_sdk.PickFilterTypes.InterfacePoint)
    #pickChoices.Add(apex_sdk.PickFilterTypes.PointMass)
    #pickChoices.Add(apex_sdk.PickFilterTypes.BeamSpan)
    #pickChoices.Add(apex_sdk.PickFilterTypes.Offset)

    #Sensors
    #pickChoices.Add(apex_sdk.PickFilterTypes.MotionEnvelopeSensor)
    #pickChoices.Add(apex_sdk.PickFilterTypes.ClearanceSensor)
    #pickChoices.Add(apex_sdk.PickFilterTypes.CrossSectionSensor)
    #pickChoices.Add(apex_sdk.PickFilterTypes.PointSensor)

    #Coordinate system
    #pickChoices.Add(apex_sdk.PickFilterTypes.CoordinateSystem)

    return pickChoices

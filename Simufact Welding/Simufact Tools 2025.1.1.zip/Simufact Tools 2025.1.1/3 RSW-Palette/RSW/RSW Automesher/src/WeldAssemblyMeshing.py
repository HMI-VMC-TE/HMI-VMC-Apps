# coding: utf-8
#
# Copyright © 2022 Hexagon Manufacturing Intelligence, Inc. (“Hexagon”)
#  
# Permission to use Scripts
#  
# Permission is granted to customers of Hexagon and its affiliates with valid licenses of the MSC Apex™ software 
# to use script files posted on this page (collectively “Scripts”) solely for customers’ own authorized 
# internal use in conjunction with licensed use of the MSC Apex software.  
# No other use is permitted.  No license to MSC Apex or other software is granted under this Permission.
#  
# SCRIPTS ARE PROVIDED ON AN "AS-IS" BASIS, WITH NO WARRANTIES OF ANY KIND.  USE OF THE SCRIPTS IS AT CUSTOMER'S SOLE RISK.
#  
# IN NO EVENT SHALL HEXAGON, ITS AFFILIATES, SUBSIDIARIES, SUPPLIERS, AGENTS, REPRESENTATIVES OR EMPLOYEES BE LIABLE FOR ANY 
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, TORT, 
# STRICT LIABILITY, OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION USE OF THE SCRIPTS, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
#  
# Customer shall indemnify, defend and hold Hexagon, its affiliates, subsidiaries, suppliers, agents, 
# employees or representatives (collectively, “Indemnified Parties”) harmless from and against any third-party claims 
# brought against Indemnified Parties rising out of or in connection with Customer’s use of the Scripts.
#

# Author: Jleedom
# Revised by: jleedom
# Revision History
# Date         Change                                 By
# 2023-07-03   Original code (1.0)                    jleedom

import apex
import math
from apex.construct import  Point2D
from apex.construct import  Point3D
import numpy as np
import time


def returnFloat(inVal):

   try:
      outVal = float(inVal)
      return outVal
   except:
      return 0.0

def highlight_stuff(item,r,g,b):
   col1=apex.ColorRGB(r,g,b)              
   #if surf.getVisibility() == 1:      
   item.highlight(col1,2,3)

def reset_vp_colors(dict={}):
    apex.disableShowOutput()
    apex.session.clearHighlights()


def create_weld_templateCurve(dia, partName="" ):
   part =  myCreatePart(partName,_target="",makeCurrent = True,hide=True)
   part.hide() 

   _axisVector = apex.construct.Vector3D( 0.,0.,1.0 )
   _axisPoint = Point3D( 0.,0.,0.)
   _target = apex.EntityCollection()
   _pnt = apex.geometry.createPointXYZ( x = dia/2.00, y = 0.0, z = 0.0 )
   _target.append(_pnt )
   result = apex.geometry.createGeometryRevolve(
      target = _target,
      axisVector = _axisVector,
      axisPoint = _axisPoint,
      angleOfRevolution = 3.600000000000000e+02,
      startOffsetAngle = 0.0
   )
   if result:
      return result[_pnt]
   else:
      raise Exception("Failed top create weld template curve!")

def create_weld_templateTube(dia, tol, partName=""):

   part =  myCreatePart(partName,_target="",makeCurrent = True,hide=True)
   part.hide() 

   _axisVector = apex.construct.Vector3D( 0.,0.,1.0 )
   _axisPoint = Point3D( 0.,0.,0.)
   _target = apex.EntityCollection()
   _pnt1 = apex.geometry.createPointXYZ( x = dia/2.00, y = 0.0, z = -tol*1.5 )
   _pnt2 = apex.geometry.createPointXYZ( x = dia/2.00, y = 0.0, z =  tol*1.5 )
   _target.append(_pnt1 )
   _target.append(_pnt2 )
   result = apex.geometry.createGeometryRevolve(
      target = _target,
      axisVector = _axisVector,
      axisPoint = _axisPoint,
      angleOfRevolution = 3.600000000000000e+02,
      startOffsetAngle = 0.0
   )
   if result:
      curve1 = result[_pnt1]
      curve2 = result[_pnt2]
   else:
      raise Exception("Failed top create weld template curve!")

   edges1 = curve1.getEdges()
   edges2 = curve2.getEdges()

   _list = []
   _target1 = apex.EntityCollection()
   _target1.extend( edges1 )
   _list.append(_target1)
   _target2 = apex.EntityCollection()
   _target2.extend( edges2 )
   _list.append(_target2)
   newWeld = apex.geometry.createSurfaceLofted(
      name = '',
      target = _list,
      loftClampingMethod = apex.geometry.LoftClampingMethod.No,
      clampStartProfile = True,
      clampEndProfile = True,
      stitch = True
   )
   if not newWeld:
      raise Exception("failed to create templata tube ")
   
   _toDelete = apex.EntityCollection()
   _toDelete.append(curve1)
   _toDelete.append(curve2)
   _toDelete.append(_pnt1)
   _toDelete.append(_pnt2)
   _toDelete.append(part)
   apex.deleteEntities	(_toDelete)	

   return newWeld


# create a single weld mesh to use as a template for the rest. 
def fillAndMeshTemplateCurve(curvebody, mesh_size):

   print(" in fill and mesh and template curve catate, name = ", curvebody.name)

   _target = apex.EntityCollection()
   _target.extend(curvebody.getEdges())
   # fill curve circle with surface so we can mesh it.
   fillerSurf = apex.geometry.fillerSurface( target = _target, 
      locations = apex.ILocationCollection(),
      retainReferenceCurveEdges = False )

   if not fillerSurf:
      raise Exception("Failed to create fill template curve")
   _target = apex.EntityCollection()
   _target.append(fillerSurf)
   result = apex.mesh.createSurfaceMesh(
      name = "",
      target = _target,
      meshSize = mesh_size,
      meshType = apex.mesh.SurfaceMeshElementShape.Mixed,
      meshMethod = apex.mesh.SurfaceMeshMethod.Auto,
      mappedMeshDominanceLevel = 2,
      elementOrder = apex.mesh.ElementOrder.Linear,
      allQuadBoundary = False,
      refineMeshUsingCurvature = False,
      curvatureType = apex.mesh.CurvatureType.EdgeAndFace,
      elementGeometryDeviationRatio = 0.10,
      elementMinEdgeLengthRatio = 0.20,
      proximityRefinement = False,
      growFaceMeshSize = False,
      faceMeshGrowthRatio = 1.2,
      createFeatureMeshes = False,
      featureMeshTypes = apex.mesh.FeatureMeshTypeVector(),
      projectMidsideNodesToGeometry = True,
      useMeshFlowOptimization = True,
      meshFlow = apex.mesh.MeshFlow.Grid,
      minimalMesh = False
   ) 
   meshes = result.getSurfaceMeshes()
   if meshes:
      templateMesh = meshes[0]
      templateMesh.disassociateFromGeometry ()
      _toDelete = apex.EntityCollection()
      _toDelete.append(fillerSurf)
      apex.deleteEntities(_toDelete)	# delete template mesh surface, no longer needed
      return templateMesh
   else:
      raise Exception ("Mesh failed on template mesh surface")
   


def unit_vector(vector):
    return vector / np.linalg.norm(vector)

def angle_between(v1, v2):
    v1_u = unit_vector(v1)
    v2_u = unit_vector(v2)
    return np.arccos(np.clip(np.dot(v1_u, v2_u), -1.0, 1.0))


def getLocalWeldTube(w,mid_surf,template_body,tol):
   wldxyz = w.getCentroid()
   Zloc = mid_surf.evaluateClosestLocation(wldxyz)
   loc = Zloc.getClosestLocation()
   normal = mid_surf.evaluateSurfaceNormal(wldxyz)
   newWeld = getOrientedCopyOfWeldTemplate(template_body,loc,normal)
   _target = apex.EntityCollection()
   _target.append(newWeld)

   newEntities1 = apex.transformTranslate(
      target = _target,
      direction = [ normal.x, normal.y, normal.z  ],
      distance = tol*1.5,
      makeCopy = True
   )
   edges1 = newEntities1[0].getEdges()
   newEntities2 = apex.transformTranslate(
      target = _target,
      direction = [ normal.x, normal.y, normal.z  ],
      distance = -tol*1.5,
      makeCopy = False
   )
   edges2 = newEntities2[0].getEdges()

   _list = []
   _target1 = apex.EntityCollection()
   _target1.extend( edges1 )
   _list.append(_target1)
   _target2 = apex.EntityCollection()
   _target2.extend( edges2 )
   _list.append(_target2)
   newWeld = apex.geometry.createSurfaceLofted(
      name = '',
      target = _list,
      loftClampingMethod = apex.geometry.LoftClampingMethod.No,
      clampStartProfile = True,
      clampEndProfile = True,
      stitch = True
   )
   if not newWeld:
      raise Exception("failed to create splitter tube for mid surf", mid_surf.name)
   
   _toDelete = apex.EntityCollection()
   _toDelete.extend(newEntities1)
   _toDelete.extend(newEntities2)
   apex.deleteEntities	(_toDelete)	

   return newWeld

def getLocalWeld(w,mid_surf,template_body):
   wldxyz = w.getCentroid()
   Zloc = mid_surf.evaluateClosestLocation(wldxyz)
   loc = Zloc.getClosestLocation()
   normal = mid_surf.evaluateSurfaceNormal(wldxyz)
   newWeld = getOrientedCopyOfWeldTemplate(template_body,loc,normal)
   return newWeld

def getMidSurf(bdy,suppress,targetPart=""):
   solid_target = apex.EntityCollection()
   solid_target.append(bdy)
   result = apex.geometry.assignConstantThicknessMidSurface(target = solid_target,autoAssignThickness = True,autoAssignTolerance = 5.0e-02)
   if result.len() !=1:
      raise Exception("Did not get one mid-surface from body"+bdy.name+" execution terminated!")
   mid_surf = result[0]
   #if targetPart:
   #   apex.reparent( parent = targetPart, target = result )   
   if suppress:
      supressAllEdges(mid_surf)
      _target = apex.EntityCollection()
      _target.extend( mid_surf.getVertices(  ) )
      result = apex.geometry.removeVertex(
         targetVertex = _target,
         keepAtCurvatureChange = True
      )
   #apex.session.displayShellThickness(	False)
   return mid_surf  


def getOrientedCopyOfWeldTemplate(bdy,loc,normal):
   
   _target = apex.EntityCollection()
   _target.append(bdy)
   dist = math.sqrt(loc.x**2 + loc.y**2 +loc.z**2)
   newEntities = apex.transformTranslate(
      target = _target,
      direction = [ loc.x, loc.y, loc.z  ],
      distance = dist,
      makeCopy = True
   )
   if not newEntities:
      print([ loc.x, loc.y, loc.z  ],[normal.x,normal.y,normal.z], dist)
      raise Exception("tranform translate failed for template and body=",bdy.name)
   
   norm = [normal.x,normal.y,normal.z]
   zaxis = [0.,0.,1.]
   axis = np.cross(norm,zaxis)
   ang = math.degrees(angle_between(norm, zaxis))
   if ang == 180.0:
      axis = [1.,0.,0.]

   newEntities = apex.transformRotate(
      target = newEntities,
      axisDirection = axis,
      axisPoint = apex.Coordinate( loc.x, loc.y, loc.z ),
      angle = -ang,
      makeCopy = False
   )
   if not newEntities:
      print([ loc.x, loc.y, loc.z  ],norm, -ang, axis)
      raise Exception("tranform rotate failed for template and body=",bdy.name)
   
   finalEdge = newEntities[0]
   return finalEdge

def supressAllEdges(surfbody):
   interiorEdges = surfbody.getInteriorEdges()  
   #print("number of edges to suppress = ",interiorEdges.len())
   result = apex.geometry.suppressOnly(
       target = interiorEdges,
      maxEdgeAngle = 1.000000000000000e+01,
      maxFaceAngle = 5.000000000000000,
      keepVerticesAtCurvatureChange = False,
      cleanupTol = 1.000000000000000,
      forceSuppress = False
   )

def getCompletenessString(count,numTargetBodies,numDotsForCompleteness):
   percentComplete = count/numTargetBodies
   numDots = int (percentComplete * numDotsForCompleteness)
   numBlank = numDotsForCompleteness - numDots
   dot = "="
   blank = "o"
   return "|" + dot*numDots + blank*numBlank + "|"

# get the spheres within tol of each body and save the lists by updating weldData
def getWeldSpheresTouchingParts(weldData, tol, targetBodies, weldLocations):
    # update status message to show progress....

   # loop through all solids to find ones within tol of each target solid.  distance between sphere and part solid.
   count = 0
   numDotsForCompleteness = 50
   numTargetBodies = targetBodies.len()

   for bdy in targetBodies:
      count +=1
      dots = getCompletenessString(count,numTargetBodies,numDotsForCompleteness) 
      apex.session.displayStatusMessage("Finding weld spheres for bodies "+dots)
      highlight_stuff(bdy,255,255,255)
      weldData[bdy] = {'welds':apex.EntityCollection()}
      if weldLocations.len():
         distance_ = apex.measureDistance(source=bdy, target=weldLocations)
         print("check body ",bdy.name," Against ",weldLocations.len(),"Weld locations")
         for i in range(len(distance_)):
            if float(distance_[i]) <= float(tol):
               highlight_stuff(weldLocations[i],0,255,0)
               weldData[bdy]['welds'].append(weldLocations[i])
            else:
               highlight_stuff(weldLocations[i],255,0,0)
   apex.session.clearHighlights()	
   return weldData


def mesh_surface(size=10.0, face_ids=[], surface_ids=[], part_ids=[], controlMeshes=None):

   _target = apex.EntityCollection()   
   for f in face_ids:
      _target.apppend( f)
      
   for s in surface_ids:
      _target.append( s)
   
   if part_ids:
      for p in part_ids:
         _surfs = p.getSurfaces ()
         _target.extend( _surfs)
         
   if not _target.len():
      raise Exception("no targets specified to mesh")
      
   meshControl = None   
   if controlMeshes:
      #print("patch meshing", "num meshes = ",controlMeshes.len())
      meshControl = apex.mesh.ElementCollection()   
      for m in controlMeshes:
         m.disassociateFromGeometry ()
         _elems = m.getElements()
         meshControl.extend(_elems)
      #print("Num mesh control elements = ",meshControl.len())
         
   #print("_target = ",_target.len())

   result = apex.mesh.createSurfaceMesh(
      name = "",
      target = _target,
      meshSize = size,
      meshType = apex.mesh.SurfaceMeshElementShape.Mixed,
      meshMethod = apex.mesh.SurfaceMeshMethod.Auto,
      mappedMeshDominanceLevel = 2,
      elementOrder = apex.mesh.ElementOrder.Linear,
      allQuadBoundary = False,
      refineMeshUsingCurvature = False,
      curvatureType = apex.mesh.CurvatureType.EdgeAndFace,
      elementGeometryDeviationRatio = 0.10,
      elementMinEdgeLengthRatio = 0.20,
      proximityRefinement = True,
      growFaceMeshSize = True,
      faceMeshGrowthRatio = 1.4,
      createFeatureMeshes = False,
      featureMeshTypes = apex.mesh.FeatureMeshTypeVector(),
      projectMidsideNodesToGeometry = True,
      useMeshFlowOptimization = True,
      meshFlow = apex.mesh.MeshFlow.Grid,
      minimalMesh = False,
      meshControlFeature = meshControl,
      snapMeshFeature = True, 
      cleanupTolerance = .0001
    )
   return result

# separate bodies with one external face into welds vs Parts with more than one. 
def separateWeldsFromParts(_selected):
    # store data in dictionary weldData{solid:{mSurf:midsurf, welds:goodwelds, meshControls:meshControlBodies, mesh:finalMeshBody}}
    print("num selected bodies = ",_selected.len())
    if _selected.len() == 0: return
    #clearHighlights()  
    weldLocations = apex.EntityCollection()
    targetBodies  = apex.EntityCollection()
   
    for s in _selected:
      extFaces = s.getExteriorFaces()
      s.clearHighlight()
      if extFaces.len() == 1:
         xyz = s.getCentroid()
         #highlight_stuff(s,255,0,0)
         weldLocations.append(s)
      else:
         #highlight_stuff(s,0,255,0)
         targetBodies.append(s)

    return (weldLocations,targetBodies)



def myCreatePart(partName,_target="",makeCurrent = True,hide=False):   

   model = apex.currentModel()

   if not makeCurrent:
      # get current Part
      currentPart = model.getCurrentPart()

   #check if part already exists first. If I create it again, what does it do. 
   try:
      part = apex.getPart( model.name+"/"+partName )
   except:
      part = apex.createPart(name = partName)

   if hide:
      part.hide()
   if not makeCurrent:
      #set original Part current again
      model.setCurrentPart(pathName = currentPart.getPathName())

   if _target:
      apex.reparent( parent = part, target = _target )

   return part


#this is where all the hard work happens.  Define local weld geom, split mid-surface, then mesh. 
def MeshBodyWithWeldsUsingSurfaceSplit(welds, mid_surf, template_body, partMeshSize, weldMeshSize, tol):

   _target = apex.EntityCollection()
   _target.append(mid_surf)
   newWelds = apex.EntityCollection()

   mesh_result = ""
   _splitter = apex.EntityCollection()

   # get geometry for local weld for splitting mid-surface
   for w in welds: 
      newWeld = getLocalWeld(w,mid_surf,template_body)
      if not newWeld:
         raise Exception("Error, failed to create weld Tube for splitting mid-surface on weld extrusion tube")
      newWelds.append(newWeld) # i am using this in case split fails, so I can move the input entities into a special Part to see what happen
      _splitter.extend( newWeld.getFaces() )
   new_faces = mid_surf.getFaces()

   # split mid-surface on all weld geometry
   if _splitter.len(): 
      _target = mid_surf.getFaces()
      result = apex.geometry.splitSurfacesWithSurfaces(target = _target,splitter = _splitter,stitch = False)
      numNew = 0
      if result:
         new_faces = result.getNewFaces()
         numNew = new_faces.len()
      if numNew:
         new_faces = result.getNewFaces()
         print("After splitting on welds, mid surface now has = ",new_faces.len()," faces.  One of them is the filler face.")
         apex.deleteEntities	(_splitter)	

      else:
         print("Split Failed for Mid surface '",mid_surf.name,"' put inputs into Part name = "+"'Failed Splits'")
         part_2 = myCreatePart('Failed Splits',_target=newWelds,makeCurrent = False,hide=False)
         badMid = apex.EntityCollection()
         badMid.extend(_splitter)
         badMid.append(mid_surf)
         apex.reparent( parent = part_2, target = badMid ) 

   # separate faces of split mid-surface into welds vs filler faces. faces with smallest area, they are weld faces
   biggestArea = 0.0
   weldFaces = apex.EntityCollection()
   fillerFace = 0
   count = 0
   for f in new_faces:
      count += 1
      a = f.getArea()
      if a > biggestArea:
         if fillerFace:
            weldFaces.append(fillerFace)
         fillerFace = f
         biggestArea = a
      else:
         weldFaces.append(f)


   #mesh the weld faces, then the filler faces
   if weldFaces.len() > 0:
      print("Mesh Weld faces with size = ", weldMeshSize,"...")
      mesh_result = mesh_surface(size=weldMeshSize, surface_ids=weldFaces)
   if fillerFace:
      fillerFaces = apex.EntityCollection()
      fillerFaces.append(fillerFace)
      print("Mesh filler face with size = ", partMeshSize,"...")
      mesh_result = mesh_surface(size=partMeshSize, surface_ids=fillerFaces)
   else:
      print("No Filler face found for mid surface '",mid_surf.name,"' put inputs into Part name = "+"'Failed Splits'") 
      part_2 = myCreatePart('Failed Splits',_target=newWelds,makeCurrent = False,hide=False)
      badMid = apex.EntityCollection()
      badMid.append(mid_surf)
      apex.reparent( parent = part_2, target = badMid )   

   return mesh_result


def MeshBodyWithWeldsUsingMeshControls(welds, mid_surf, template_body, partMeshSize,testMode):
   meshCtrlBodies = apex.EntityCollection()
   goodWeldPatches = apex.EntityCollection()
   _target = apex.EntityCollection()
   _target.append(mid_surf)

   mesh_result = ""

   print("Using Mesh Control Method....Template body = ",template_body.name)
   tryOneWeldAtATime = testMode  # do this to help diagones which weld patches are causing mesh failure 
   for w in welds:
      newWeld = getLocalWeld(w,mid_surf,template_body)
      print("new weld surface name = ",newWeld.name)
      meshCtrlBodies.append(newWeld)
      if tryOneWeldAtATime:  # try one at a time to see which welds successfull mesh, keep track of good ones for later. 
         print("===========running in test mode ================",tryOneWeldAtATime )
         print("try meshing with patch = ",newWeld.name," num patches = ",meshCtrlBodies.len())
         try: #try one fastener at a time to find bad ones
            mesh_result = mesh_surface(size=partMeshSize, surface_ids=_target, controlMeshes = meshCtrlBodies)
            if mesh_result:
               apex.undo()
               print( "    +Mesh Succsefful for surface =",mid_surf.name, "weld sphere = ",w.name )
               highlight_stuff(w,0,255,0)  #highlight good weld
               goodWeldPatches.extend(meshCtrlBodies)
            else:
               print( "    *Mesh FAILED for surface =",mid_surf.name," Weld body = ", newWeld.name,  "weld sphere = ",w.name)
               highlight_stuff(w,255,0,0)  #highlight bad weld
         except:
            print( "    *Mesh FAILED for surface =",mid_surf.name," Weld body = ", newWeld.name,  "weld sphere = ",w.name)
            highlight_stuff(w,255,0,0)  #highlight bad weld
         meshCtrlBodies = apex.EntityCollection() #clear mesh controlls so we try one at a time
         print("    clear weld list")
   if tryOneWeldAtATime:  # mesh with all the successful ones from above.
   #create mesh using only good welds from trial tests
      try:
         mesh_result = mesh_surface(size=partMeshSize, surface_ids=_target, controlMeshes = goodWeldPatches)
      except:
         print( "this on at a time control mesh method try failed for mesh",mid_surf.name)
   else:  # this for when we just mesh with all at once. 
   #create mesh using mesh control
      print("about to mesh.  num contrlMeses = ", meshCtrlBodies.len())
      try:
         mesh_result = mesh_surface(size=partMeshSize, surface_ids=_target, controlMeshes = meshCtrlBodies)
      except:
         print( "this all at once control mesh method try failed for surface",mid_surf.name)
   return mesh_result


def main(dict={}):

   #apex.enableShowOutput(	)	


   partMeshSize = returnFloat(dict["partSize"])
   weldMeshSize = returnFloat(dict["weldSize"])
   weldSize     = returnFloat(dict["weldDia"])
   tol          = returnFloat(dict["tol"])
   method       = dict["method"] # Mesh Control or Geometry Imprint methods
   testModeStr     = dict["testMode"] # applies to Mesh Control method only
    
   testMode = False
   if testModeStr == "True": testMode = True

   weldData = {}

   start = time.time()

   #print( partMeshSize, weldMeshSize, weldSize, tol, method, testMode)
    
   _selected = apex.selection.getCurrentSelection()
   
   if not _selected:
      raise Exception("No bodies selected. You must select sheet metal solids and weld spheres before MMB or selecting green check box.")  

   apex.disableUndoRedo()
   apex.disableRecoveryFileRecording()

   apex.session.displayStatusMessage(str(_selected.len())+" Bodies Selected.  Separate Weld Spheres from Target Sheet Metal Parts...")
   weldLocations,targetBodies =  separateWeldsFromParts(_selected)
    

   # get touching spheres for each Target body. Identified by tolerance not sphere geometry.      
   apex.session.displayStatusMessage("Finding weld spheres for each Part...")
   weldData = getWeldSpheresTouchingParts(weldData, tol, targetBodies, weldLocations)
   #midSurfPart =  myCreatePart('Meshed Parts',_target="",makeCurrent = True,hide=False)
   #print("Created part = ",midSurfPart.name)
   #print("update part color...")
   #midSurfPart.update(color = [ 255, 255, 255 ])

   # create weld mesh body template centered at 0,0,0 and oriented normal to Z axis.
   # extract mesh pattern

   if method == "Geometry Imprint": 
      template_body= create_weld_templateTube( weldSize, tol, partName= "Weld Construction Geometry")
      #print("new tempalte tube = ",template_body.name)
   else:
      template_body= create_weld_templateCurve( weldSize, partName= "Weld Construction Geometry")
      template_body= fillAndMeshTemplateCurve( template_body, weldMeshSize)
      #print("filler surf mesh = ",template_body.name)

   count = 0
   for bdy in weldData:
      count += 1
      print("Body ",count," has ",weldData[bdy]['welds'].len()," welds")
      mid_surf = getMidSurf(bdy,True,targetPart = "")
      apex.session.displayShellThickness(	apex.session.DisplayShellThickness.Display_None)
      if mid_surf:
         mid_surf.update(color = [ 100, 100, 100 ])
         weldData[bdy]['midsurf'] = mid_surf
         #print("new midsurface = ",mid_surf.name)
         bdy.hide()
         if method == "Geometry Imprint": 
            mesh_result = MeshBodyWithWeldsUsingSurfaceSplit(weldData[bdy]['welds'], mid_surf, template_body,partMeshSize,weldMeshSize, tol)
         else:
            mesh_result = MeshBodyWithWeldsUsingMeshControls(weldData[bdy]['welds'], mid_surf, template_body,partMeshSize,testMode)
         if mesh_result:
            mid_surf.update(color = [ 0, 255, 0 ])
            meshes = mesh_result.getSurfaceMeshes()
            if meshes.len()> 0:
               meshes[0].update(color = [ 0, 255, 0 ]) 
               meshes[0].update(renderStyle = apex.session.DisplayRenderStyle.ShadedWithEdges) 
               mid_surf.update(renderStyle = apex.session.DisplayRenderStyle.Wireframe)
         else:
            mid_surf.update(color = [ 255, 0, 0 ])
            mid_surf.update(renderStyle = apex.session.DisplayRenderStyle.ShadedWithEdges)
      else:
         print("Mid Surface failed to extract from body '",bdy.name,"'.  Skiping this body...")
   end = time.time()
   print("Run time = ",end - start,"seconds")
   apex.session.displayShellThickness(	apex.session.DisplayShellThickness.Display_None)
   apex.enableUndoRedo()
   apex.enableRecoveryFileRecording()
   apex.disableShowOutput()


   

       
       
     
         

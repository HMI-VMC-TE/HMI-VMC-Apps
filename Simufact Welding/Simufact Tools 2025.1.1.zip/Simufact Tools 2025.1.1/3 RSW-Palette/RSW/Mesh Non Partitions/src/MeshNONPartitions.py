import apex
from apex.construct import Point3D, Point2D
apex.disableShowOutput()

def CreateMeshNONPartitions(dict={}):
    #===================================================================
    ## Initializing Apex code
    apex.setScriptUnitSystem(unitSystemName = r'''mm-kg-s-N''')
    model_1 = apex.currentModel()
    
    MeshSize = float(dict["MeshSize"])
         
    listOfAllParts = []
    for Part in model_1.getParts(True):
        if "Trajectories" not in Part.getPath():
            listOfAllParts.append(Part)
            
    ## Getting all faces from all parts that are not under 'Trajectories'
    listOfNonMeshedFaces = apex.EntityCollection()
    for Part in listOfAllParts:
        if Part.getVisibility():
            for Surface in Part.getSurfaces():
                for Face in Surface.getFaces():
                    if not Face.getElements():
                        listOfNonMeshedFaces.append(Face)
    
    ## -----------------------------------------------------------------------------------------------------------
    ## -----------------------------------------------------------------------------------------------------------

    apex.mesh.createSurfaceMesh(
        name="",
        target=listOfNonMeshedFaces,
        meshSize= MeshSize,
        meshType = apex.mesh.SurfaceMeshElementShape.Mixed,
        meshMethod = apex.mesh.SurfaceMeshMethod.Auto,
        mappedMeshDominanceLevel = 2,
        elementOrder = apex.mesh.ElementOrder.Linear,
        allQuadBoundary = False,
        refineMeshUsingCurvature = False,
        curvatureType = apex.mesh.CurvatureType.EdgeAndFace,
        elementGeometryDeviationRatio = 0.20,
        elementMinEdgeLengthRatio = 0.40,
        proximityRefinement = True,
        growFaceMeshSize = True,
        faceMeshGrowthRatio = 1.4,
        createFeatureMeshes = False,
        featureMeshTypes = apex.mesh.FeatureMeshTypeVector(),
        projectMidsideNodesToGeometry = True,
        useMeshFlowOptimization = True,
        meshFlow = apex.mesh.MeshFlow.Grid,
        minimalMesh = False,
    )

                    
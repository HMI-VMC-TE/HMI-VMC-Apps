# coding: utf-8

import apex
from apex.construct import Point3D, Point2D
import os
apex.disableShowOutput()

apex.setScriptUnitSystem(unitSystemName = r'''mm-kg-s-N''')
model_1 = apex.currentModel()


def buildCoachPeel(dict={}):
    # - Get the data from the dictionary
    SampleWidth = float(dict["SampleWidth"])
    SampleLength = float(dict["SampleLength"])
    SampleThickness = float(dict["SampleThick"])
    spotSize = float(dict["SpotSize"])
    OverlapLength = float(dict["OverlapLength"])
    
    model_1 = apex.currentModel()
    ParentAssy = model_1.createAssembly(name="CoachPeel")
    part_1 = apex.createPart()
    
    # Do sketch
    def doSketch_1():
        part_1 = model_1.getCurrentPart()
        if part_1 is None:
            part_1 = model_1.createPart()
        sketch_1 = part_1.createSketchOnGlobalPlane(
            name = 'Sketch 1',
            plane = apex.construct.GlobalPlane.ZX,
            alignSketchViewWithViewport = True
        )


        rectangle_1 = sketch_1.createRectangle2Point(
            name = "Rectangle 1",
            location = Point2D( 0.0, 0.0 ),
            diagonal = Point2D( SampleThickness, OverlapLength + 6 + SampleThickness )
        )

        rectangle_2 = sketch_1.createRectangle2Point(
            name = "Rectangle 2",
            location = Point2D( 0.0, 0.0 ),
            diagonal = Point2D( SampleLength, SampleThickness )
        )

        _edge1 = sketch_1.getEdge( id = 4151 )
        _edge2 = sketch_1.getEdge( id = 7121 )
        fillet_1 = sketch_1.createFilletEdge(
            name = 'Fillet 1',
            edge1 = _edge1,
            edge2 = _edge2,
            radiusPoint = Point2D( 2.885875292122364, 1.7339540645480156 )
        )

        fillet_1.update( radius = 6.000000000000000 )

        _edge1 = sketch_1.getEdge( id = 3111 )
        _edge2 = sketch_1.getEdge( id = 1191 )
        fillet_2 = sketch_1.createFilletEdge(
            name = 'Fillet 2',
            edge1 = _edge1,
            edge2 = _edge2,
            radiusPoint = Point2D( 2.410411834716797, 1.1000046506524086 )
        )

        fillet_2.update( radius = 6 + SampleThickness )

        return sketch_1.completeSketch( fillSketches = True )


    newbodies = doSketch_1()
    
    entities_1 = apex.EntityCollection()
    entities_1.append(part_1.getCurves()[0])
    apex.deleteEntities(entities_1)
    
    # Make into 3D body
    _target = apex.EntityCollection()
    _target.append(part_1.getSurfaces()[0].getFaces()[0])
    result = apex.geometry.pushPull(
        target = _target,
        method = apex.geometry.PushPullMethod.Normal,
        behavior = apex.geometry.PushPullBehavior.Extrude,
        removeInnerLoops = False,
        createBooleanUnion = False,
        distance = SampleWidth,
        direction = [ 0.0, 1.000000000000000, 0.0 ]
    )

    newEntities = apex.transformTranslate(
        target = result,
        direction = [ 0.0, -1.000000000000000, 0.0 ],
        distance = SampleWidth/2,
        makeCopy = False
    )

    newEntities = apex.transformTranslate(
        target = result,
        direction = [ -1.0, 0.0, 0.0 ],
        distance = 7 + OverlapLength/2,
        makeCopy = False
    )
    
    # Mirror 
    newEntities = apex.transformMirror(
        target = newEntities,
        planeNormal = [ 0.0, 0.0, 1.000000000000000 ],
        planePoint = apex.Coordinate( 0.0, 0.0, 0.0 ),
        makeCopy = True
    )

    part_2 = apex.createPart()
    _target = apex.EntityCollection()
    _target.append(part_1)
    _target.append(part_2)
    apex.reparent( parent = part_2, target = newEntities )
    apex.reparent( parent = ParentAssy, target = _target ) 
    
    
    # Creating split regions
    cylPart = model_1.createPart(name="Cylinder")
    result = apex.geometry.createCylinderByLocationOrientation(
        name='',
        description='',
        length=20.0,
        radius=0.25*spotSize,
        sweepangle=360.0,
        origin=apex.Coordinate(0.0, 0.0, -10.0),
        orientation=apex.construct.createOrientation(alpha=0.0, beta=0.0, gamma=0.0)
    )

    entities_1 = apex.EntityCollection()
    entities_1.append(result)
    entities_1.hide()

    result = apex.geometry.createCylinderByLocationOrientation(
        name='',
        description='',
        length=20.0,
        radius=1.5 * spotSize,
        sweepangle=360.0,
        origin=apex.Coordinate(0.0, 0.0, -10.0),
        orientation=apex.construct.createOrientation(alpha=0.0, beta=0.0, gamma=0.0)
    )

    entities_1 = apex.EntityCollection()
    entities_1.append(result)
    entities_1.hide()
    
    result = apex.geometry.createCylinderByLocationOrientation(
        name='',
        description='',
        length=20.0,
        radius= 1.2*spotSize,
        sweepangle=360.0,
        origin=apex.Coordinate(0.0, 0.0, -10.0),
        orientation=apex.construct.createOrientation(alpha=0.0, beta=0.0, gamma=0.0)
    )

    entities_1 = apex.EntityCollection()
    entities_1.append(result)
    entities_1.hide()

    ## Split sheets
    _target = apex.EntityCollection()
    _target.append( part_1.getSolids()[0] )
    _target.append( part_2.getSolids()[0] )
    _splitter = apex.EntityCollection()
    for Solid in cylPart.getSolids():
        _splitter.extend(Solid.getFaces())
    result = apex.geometry.split(
        target = _target,
        splitter = _splitter,
        splitBehavior = apex.geometry.GeometrySplitBehavior.Partition
    )

    entities_1 = apex.EntityCollection()
    entities_1.append(cylPart)
    apex.deleteEntities(entities_1)

    _plane = apex.construct.Plane(
        apex.construct.Point3D(0.0, 0.0, 0.0),
        apex.construct.Vector3D(1.0, 0.0, 0.0)
    )
    result = apex.geometry.splitWithPlane(
        target=_target,
        plane=_plane,
        splitBehavior=apex.geometry.GeometrySplitBehavior.Partition
    )

    _plane = apex.construct.Plane(
        apex.construct.Point3D(0.0, 0.0, 0.0),
        apex.construct.Vector3D(0.0, 1.0, 0.0)
    )
    result = apex.geometry.splitWithPlane(
        target=_target,
        plane=_plane,
        splitBehavior=apex.geometry.GeometrySplitBehavior.Partition
    )
      
    # Seed edges that are at the center
    for part in ParentAssy.parts:
        if dict["MeshForMe"] == 'True':
            for edge in part.solids[0].edges:
                x, y, z = edge.getMidPoint().x,edge.getMidPoint().y,edge.getMidPoint().z
                if (x == 0.25*spotSize and y == 0.0) or (x == 0.0 and y == 0.25*spotSize):
                    seedEdge = apex.EntityCollection()
                    seedEdge.append(edge)
                    result = apex.mesh.createEdgeSeedUniformByNumber(
                        target=seedEdge,
                        numberElementEdges=5
                    )
                elif (x == -0.25*spotSize and y == 0.0) or (x == 0.0 and y == -0.25*spotSize):
                    seedEdge = apex.EntityCollection()
                    seedEdge.append(edge)
                    result = apex.mesh.createEdgeSeedUniformByNumber(
                        target=seedEdge,
                        numberElementEdges=5
                    )
                elif (x == 1.2*spotSize and y == 0.0) or (x == 0.0 and y == 1.2*spotSize):
                    seedEdge = apex.EntityCollection()
                    seedEdge.append(edge)
                    result = apex.mesh.createEdgeSeedUniformByNumber(
                        target=seedEdge,
                        numberElementEdges=5
                    )
                elif (x == -1.2*spotSize and y == 0.0) or (x == 0.0 and y == -1.2*spotSize):
                    seedEdge = apex.EntityCollection()
                    seedEdge.append(edge)
                    result = apex.mesh.createEdgeSeedUniformByNumber(
                        target=seedEdge,
                        numberElementEdges=5
                    )               
                elif (x == 1.5*spotSize and y == 0.0) or (x == 0.0 and y == 1.5*spotSize):
                    seedEdge = apex.EntityCollection()
                    seedEdge.append(edge)
                    result = apex.mesh.createEdgeSeedUniformByNumber(
                        target=seedEdge,
                        numberElementEdges=2
                    )
                elif (x == -1.5*spotSize and y == 0.0) or (x == 0.0 and y == -1.5*spotSize):
                    seedEdge = apex.EntityCollection()
                    seedEdge.append(edge)
                    result = apex.mesh.createEdgeSeedUniformByNumber(
                        target=seedEdge,
                        numberElementEdges=2
                    )                
            
        # Mesh
            for solid in part.solids:
                proxSearch = apex.utility.ProximitySearch()
                ans = proxSearch.insertList(list(solid.getCells()))
                refPoint = apex.Coordinate(0.0, 0.0, 0.0)
                resSearch = proxSearch.findNearestObjects(location=refPoint, numObjects=4)

                cellsToMesh = apex.EntityCollection()
                for elem in resSearch.foundObjects():
                    cellsToMesh.append(elem)

                _SweepFace = apex.EntityCollection()
                result = apex.mesh.createHexMesh(
                    name="",
                    target=cellsToMesh,
                    meshSize= 0.25,
                    surfaceMeshMethod=apex.mesh.SurfaceMeshMethod.Pave,
                    mappedMeshDominanceLevel=2,
                    elementOrder=apex.mesh.ElementOrder.Linear,
                    refineMeshUsingCurvature=False,
                    elementGeometryDeviationRatio=0.10,
                    elementMinEdgeLengthRatio=0.20,
                    createFeatureMeshOnWashers=False,
                    createFeatureMeshOnArbitraryHoles=False,
                    preserveWasherThroughMesh=True,
                    sweepFace=_SweepFace,
                    hexMeshMethod=apex.mesh.HexMeshMethod.Auto
                )
                
                # Mesh plates (mid region)
                proxSearch = apex.utility.ProximitySearch()
                ans = proxSearch.insertList(list(solid.getCells()))
                resSearch = proxSearch.findNearestObjects(location=refPoint, numObjects=8)

                cellsToMesh = apex.EntityCollection()
                for elem in resSearch.foundObjects():
                    if len(elem.elements) == 0:
                        cellsToMesh.append(elem)
                    
                _SweepFace = apex.EntityCollection()
                result = apex.mesh.createHexMesh(
                    name="",
                    target=cellsToMesh,
                    meshSize= 0.25,
                    surfaceMeshMethod=apex.mesh.SurfaceMeshMethod.Mapped,
                    mappedMeshDominanceLevel=5,
                    elementOrder=apex.mesh.ElementOrder.Linear,
                    refineMeshUsingCurvature=False,
                    elementGeometryDeviationRatio=0.20,
                    elementMinEdgeLengthRatio=0.40,
                    createFeatureMeshOnWashers=False,
                    createFeatureMeshOnArbitraryHoles=False,
                    preserveWasherThroughMesh=True,
                    sweepFace=_SweepFace,
                    hexMeshMethod=apex.mesh.HexMeshMethod.Auto
                )

                # Mesh rest of plates (coarse region)
                proxSearch = apex.utility.ProximitySearch()
                ans = proxSearch.insertList(list(solid.getCells()))
                resSearch = proxSearch.findNearestObjects(location=refPoint, numObjects=16)

                cellsToMesh = apex.EntityCollection()
                for elem in resSearch.foundObjects():
                    if len(elem.elements) == 0:
                        cellsToMesh.append(elem)
                    
                _SweepFace = apex.EntityCollection()
                result = apex.mesh.createHexMesh(
                    name="",
                    target=cellsToMesh,
                    meshSize= 1.5,
                    surfaceMeshMethod=apex.mesh.SurfaceMeshMethod.Auto,
                    mappedMeshDominanceLevel=2,
                    elementOrder=apex.mesh.ElementOrder.Linear,
                    refineMeshUsingCurvature=False,
                    elementGeometryDeviationRatio=0.20,
                    elementMinEdgeLengthRatio=0.40,
                    createFeatureMeshOnWashers=False,
                    createFeatureMeshOnArbitraryHoles=False,
                    preserveWasherThroughMesh=True,
                    sweepFace=_SweepFace,
                    hexMeshMethod=apex.mesh.HexMeshMethod.Auto
                )
    
# END


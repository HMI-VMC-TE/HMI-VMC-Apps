# -*- coding: utf-8 -*-
# support@simufact.de
# This file was created automatically by the packaging tool on 2026.01.16_13h07min10s.

import marshal, os
scriptDir = os.path.dirname(__file__)
appPath = os.path.join(scriptDir, "VF_main.pyc")
with open(appPath, 'rb') as appFile:
    appFile.read(16)
    code = marshal.load(appFile)
    exec(code)

# Standard imports
from PySide6 import QtWidgets
from PySide6.QtWidgets import QApplication, QMainWindow, QDialog
from PySide6 import QtCore
import sys, os, json, subprocess
from datetime import datetime

# check the python modules needed for the application, otherwised install them
from UI.pathsetup_ui import Ui_SystemPathWindow


# Logger class to redirect stdout and stderr to file
class Logger:
    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log = open(filename, "a", encoding='utf-8')
   
    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        self.log.flush()
    
    def flush(self):
        self.terminal.flush()
        self.log.flush()
    
    def close(self):
        self.log.close()


# Select path and vtk module class
class SystemPathWindow_window(QDialog, Ui_SystemPathWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        # read json file for the path configuration
        with open(os.path.join(os.path.dirname(__file__), 'Settings', 'path_configuration.json'), 'r') as f:
            path_config = json.load(f)
            self.swpath_plainTextEdit.setPlainText(path_config['SW_Installation_Path'])
            self.smaterialpath_plainTextEdit.setPlainText(path_config['Simufact_Matarial_Path'])
            self.smesh_plainTextEdit.setPlainText(path_config['Simufact_Mesh_Path'])
            self.workdirect_plainTextEdit.setPlainText(path_config['Work_Directory'])

        # connect the buttons to the functions
        self.swpath_pushButton.clicked.connect(self.select_sw_path)
        self.smaterialpath_pushButton.clicked.connect(self.select_smaterial_path)
        self.smesh_pushButton.clicked.connect(self.select_smesh_path)
        self.workdirect_pushButton.clicked.connect(self.select_work_folder)
        self.checkpath_pushButton.clicked.connect(self.checkset_paths)
        self.installvtk_pushButton.clicked.connect(self.install_vtk_module)
  
    def checkset_paths(self):
        # read the paths from the plainTextEdit
        sw_path = self.swpath_plainTextEdit.toPlainText()
        material_path = self.smaterialpath_plainTextEdit.toPlainText()
        mesh_path = self.smesh_plainTextEdit.toPlainText()
        work_path = self.workdirect_plainTextEdit.toPlainText()

        # change the paths text color to green if the path is existing, otherwise red
        if os.path.exists(sw_path):
            self.swpath_plainTextEdit.setStyleSheet("color: green;")
        else:
            self.swpath_plainTextEdit.setStyleSheet("color: red;")
        if os.path.exists(material_path):
            self.smaterialpath_plainTextEdit.setStyleSheet("color: green;")
        else:
            self.smaterialpath_plainTextEdit.setStyleSheet("color: red;")
        if os.path.exists(mesh_path):
            self.smesh_plainTextEdit.setStyleSheet("color: green;")
        else:
            self.smesh_plainTextEdit.setStyleSheet("color: red;")
        if os.path.exists(work_path):
            self.workdirect_plainTextEdit.setStyleSheet("color: green;")
        else:
            self.workdirect_plainTextEdit.setStyleSheet("color: red;")

        # check whether the paths are correct or not
        if os.path.exists(sw_path) and os.path.exists(material_path) and os.path.exists(mesh_path) and os.path.exists(work_path):
            print("GUI : All paths are correct.")
            path_config = {
                "SW_Installation_Path": sw_path,
                "Simufact_Matarial_Path": material_path,
                "Simufact_Mesh_Path": mesh_path,
                "Work_Directory": work_path
            }
            with open(os.path.join(os.path.dirname(__file__), 'Settings', 'path_configuration.json'), 'w') as f:
                json.dump(path_config, f, indent=4)
            print("GUI : Paths are set successfully set to the system.")
        else:
            print("GUI : Some paths are not correct. Please re-select the paths.")

    def select_sw_path(self):
        default_path = os.path.normpath(r'C:\Program Files\simufact')
        folder_path = QtWidgets.QFileDialog.getExistingDirectory(self, 
                                                                 "Select Simufact Welding Installation Path", 
                                                                 default_path)
        if folder_path:
            self.swpath_plainTextEdit.setPlainText(folder_path)
        else:
            print("GUI : No folder selected")
    
    def select_smaterial_path(self):
        default_path = os.path.normpath(r'C:\Program Files\simufact')
        folder_path = QtWidgets.QFileDialog.getExistingDirectory(self, 
                                                                 "Select Simufact Material Path", 
                                                                 default_path)
        if folder_path:
            self.smaterialpath_plainTextEdit.setPlainText(folder_path)
        else:
            print("GUI : No folder selected")
    
    def select_smesh_path(self):
        default_path = os.path.normpath(r'C:\Program Files\simufact')
        folder_path = QtWidgets.QFileDialog.getExistingDirectory(self, 
                                                                 "Select Simufact Mesh Path", 
                                                                 default_path)
        if folder_path:
            self.smesh_plainTextEdit.setPlainText(folder_path)
        else:
            print("GUI : No folder selected")
    
    def select_work_folder(self):
        folder_path = QtWidgets.QFileDialog.getExistingDirectory(self, 
                                                                 "Select Work Directory", 
                                                                 "")
        if folder_path:
            self.workdirect_plainTextEdit.setPlainText(folder_path)
        else:
            print("GUI : No folder selected")
        
    def install_vtk_module(self):
        print("GUI : Start installing VTK module...")

        # check whether sw installation path is set. if not, show a message. if yes, install the vtk module.
        if not os.path.exists(self.swpath_plainTextEdit.toPlainText()):
            print("GUI : Please set the SW Installation path, before installing the VTK module.")
        else:
            # use pip.bat inside python folder of sw installation path to install vtk module
            pip_path = os.path.join(self.swpath_plainTextEdit.toPlainText(), "python", "pip.bat")
            module_name = "vtk==9.3.1"
            package_name = "vtk"
            try:
                import vtk
                print(f"GUI : {package_name} is already installed.")
            except ImportError:
                subprocess.call([pip_path, "install", module_name])
                print(f"GUI : {package_name} is installed successfully.")
            print("GUI : VTK module installation is completed. Please restart the APP.")

# check the python modules needed for the application, otherwised install them
path_ok = False
vtk_ok = False
with open(os.path.join(os.path.dirname(__file__), 'Settings', 'path_configuration.json'), 'r') as f:
    path_config = json.load(f)
    sw_path = path_config['SW_Installation_Path']
    material_path = path_config['Simufact_Matarial_Path']
    mesh_path = path_config['Simufact_Mesh_Path']
    project_path = path_config['Work_Directory']
if not (os.path.exists(sw_path) and os.path.exists(material_path) 
        and os.path.exists(mesh_path) and os.path.exists(project_path)):
    print("GUI : Path configuration is not correct. Please select the correct paths.")
    path_ok = False
else:
    print("GUI : Path configuration is correct.")
    path_ok = True

try:
    import vtk
    print("GUI : VTK module is already installed.")
    vtk_ok = True
except ImportError:
    print("GUI : VTK module is not installed. Please install the VTK module.")
    vtk_ok = False

if not path_ok or not vtk_ok:
    if QApplication.instance() is None:
        app = QApplication([])
    else:
        app = QApplication.instance()
    path_window = SystemPathWindow_window()
    path_window.exec()
    sys.exit(app.exec_())
else:
    print("GUI : All paths and module settings are set correctly.")


# QTdesigner UI imports
from UI.ui_main_ui import Ui_MainWindow

# External functions imports
from Functions.VFproject_controller import VFproject_controller


# ///////////////////////////////////////////////////////////////////////
# Main Application Class (Main window)
# ///////////////////////////////////////////////////////////////////////
class MyApp(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        # initiate the VF project controller
        self.vfproject_controller = VFproject_controller(self)

        # --------------------- #
        # set default page
        # --------------------- #
        self.importgeometryicon_pushButton.setChecked(True)
        self.pages_stackedWidget.setCurrentIndex(0)
        self.settingsinfo_widget.setHidden(True)
        self.verticalWidget.setHidden(True)

        # --------------------- #
        # set up toggle animation
        # --------------------- #
        # set the variables for the menu animation
        self.menuwidget_animatedWidget = self.process_name_widget
        self.menu_pushButton.clicked.connect(self.toggle_menu_animation)
        self.menu_is_expanded = False
        self.process_name_widget.setHidden(True)

        # set the variables for the parameters animation
        self.parameter_animatedWidget = self.parameters_widget
        self.parameters_pushButton.clicked.connect(self.toggle_parameters_animation)
        self.parameters_is_expanded = False
        self.parameters_widget.setHidden(True)

        # --------------------- #
        # connect menu buttons to pages
        # --------------------- #
        # connect the main menu buttons to the pages
        self.importgeometryicon_pushButton.clicked.connect(self.open_importgeometry_page)
        self.importgeometry_pushButton.clicked.connect(self.open_importgeometry_page)
        self.importmeasurementicon_pushButton.clicked.connect(self.open_importmeasurement_page)
        self.importmeasurement_pushButton.clicked.connect(self.open_importmeasurement_page)
        self.importfixtureicon_pushButton.clicked.connect(self.open_importfixture_page)
        self.importfixture_pushButton.clicked.connect(self.open_importfixture_page)
        self.importrpsicon_pushButton.clicked.connect(self.open_importrps_page)
        self.importrps_pushButton.clicked.connect(self.open_importrps_page)
        self.morphicon_pushButton.clicked.connect(self.open_morphing_page)
        self.morph_pushButton.clicked.connect(self.open_morphing_page)
        self.gcicon_pushButton.clicked.connect(self.open_gc_page)
        self.gc_pushButton.clicked.connect(self.open_gc_page)
        self.rpsicon_pushButton.clicked.connect(self.open_rps_page)
        self.rps_pushButton.clicked.connect(self.open_rps_page)
        self.shimmingcon_pushButton.clicked.connect(self.open_shimming_page)
        self.shimming_pushButton.clicked.connect(self.open_shimming_page)

        # connect settings button to settings page
        self.setting_pushButton.clicked.connect(self.open_settings_page)
        self.settingicon_pushButton.clicked.connect(self.open_settings_page)
        self.info_pushButton.clicked.connect(self.open_info_page)
        self.infoicon_pushButton.clicked.connect(self.open_info_page)

    # ////////////////////////////////
    # Page Navigation
    # ////////////////////////////////
    def open_importgeometry_page(self):
        self.pages_stackedWidget.setCurrentIndex(0)
    
    def open_importmeasurement_page(self):
        self.pages_stackedWidget.setCurrentIndex(1)
    
    def open_importfixture_page(self):
        self.pages_stackedWidget.setCurrentIndex(2)
    
    def open_importrps_page(self):
        self.pages_stackedWidget.setCurrentIndex(3)
    
    def open_morphing_page(self):
        self.pages_stackedWidget.setCurrentIndex(4)
    
    def open_gc_page(self):
        self.pages_stackedWidget.setCurrentIndex(5)

    def open_rps_page(self):
        self.pages_stackedWidget.setCurrentIndex(6)

    def open_settings_page(self):
        self.settingsinfo_stackwidget.setCurrentIndex(0)
    
    def open_info_page(self):
        self.settingsinfo_stackwidget.setCurrentIndex(1)

    def open_shimming_page(self):
        self.vfproject_controller.open_shimming_page()

    # ////////////////////////////////
    # Menu Animation
    # ////////////////////////////////
    def toggle_menu_animation(self):
        # set the animation
        self.menu_animation = QtCore.QPropertyAnimation(self.menuwidget_animatedWidget, b"maximumWidth")
        self.menu_animation.setDuration(500)
        self.menu_animation.setStartValue(100)
        self.menu_animation.setEndValue(300)

        # if the menu is expanded
        if self.menu_is_expanded:
            self.menu_animation.setDirection(QtCore.QAbstractAnimation.Backward)
            self.menu_is_expanded = False
        else:
            self.menu_animation.setDirection(QtCore.QAbstractAnimation.Forward)
            self.menuwidget_animatedWidget.setHidden(False)
            self.menu_is_expanded = True

        # start the animation
        self.menu_animation.start()
    
    def toggle_parameters_animation(self):
        # set the animation
        self.parameters_animation = QtCore.QPropertyAnimation(self.parameter_animatedWidget, b"maximumWidth")
        self.parameters_animation.setDuration(400)
        self.parameters_animation.setStartValue(0)
        self.parameters_animation.setEndValue(240)

        # if the menu is expanded
        if self.parameters_is_expanded:
            self.parameters_animation.setDirection(QtCore.QAbstractAnimation.Backward)
            self.parameters_is_expanded = False
        else:
            self.parameters_animation.setDirection(QtCore.QAbstractAnimation.Forward)
            self.parameter_animatedWidget.setHidden(False)
            self.parameters_is_expanded = True

        # start the animation
        self.parameters_animation.start()


# ///////////////////////////////////////////////////////////////////////
# Main Application initialization
# ///////////////////////////////////////////////////////////////////////
if __name__ == "__main__":
    # Set up logging to capture all console output
    logs_dir = os.path.join(os.path.dirname(__file__), 'Logs')
    os.makedirs(logs_dir, exist_ok=True)
    log_filename = os.path.join(logs_dir, f"Log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    sys.stdout = Logger(log_filename)
    sys.stderr = Logger(log_filename)
    print(f"Logging started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Log file: {log_filename}\n")
    
    if 'VFVC' in locals():
        locals()['VFVC'].show()
        print('Loading GUI from memory...')
    else:
        print('Creating new GUI instance...')
        if QApplication.instance() is None:
            app = QApplication([])
        else:
            app = QApplication.instance()
        VFVC = MyApp()
        #VFVC.show()
        VFVC.show()
        app.exec()
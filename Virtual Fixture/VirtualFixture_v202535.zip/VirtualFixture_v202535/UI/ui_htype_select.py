# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'htype_selectPkdiKk.ui'
##
## Created by: Qt User Interface Compiler version 6.5.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QHBoxLayout, QLabel,
    QMainWindow, QMenuBar, QPushButton, QSizePolicy,
    QSpacerItem, QStatusBar, QVBoxLayout, QWidget)

class Ui_MainWindow2(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(900, 600)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout_2 = QVBoxLayout(self.centralwidget)
        self.verticalLayout_2.setSpacing(5)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.htype_setting_widget = QWidget(self.centralwidget)
        self.htype_setting_widget.setObjectName(u"htype_setting_widget")
        self.htype_setting_widget.setMaximumSize(QSize(16777215, 50))
        self.horizontalLayout = QHBoxLayout(self.htype_setting_widget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.label = QLabel(self.htype_setting_widget)
        self.label.setObjectName(u"label")
        self.label.setMinimumSize(QSize(160, 0))
        self.label.setMaximumSize(QSize(160, 16777215))
        self.label.setStyleSheet(u"font: 12pt \"Segoe UI\";")

        self.horizontalLayout.addWidget(self.label)

        self.hnum_comboBox = QComboBox(self.htype_setting_widget)
        self.hnum_comboBox.addItem("")
        self.hnum_comboBox.addItem("")
        self.hnum_comboBox.addItem("")
        self.hnum_comboBox.addItem("")
        self.hnum_comboBox.addItem("")
        self.hnum_comboBox.addItem("")
        self.hnum_comboBox.addItem("")
        self.hnum_comboBox.addItem("")
        self.hnum_comboBox.setObjectName(u"hnum_comboBox")
        self.hnum_comboBox.setMinimumSize(QSize(100, 0))
        self.hnum_comboBox.setMaximumSize(QSize(100, 16777215))
        self.hnum_comboBox.setStyleSheet(u"font: 12pt \"Segoe UI\";")

        self.horizontalLayout.addWidget(self.hnum_comboBox)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.h_visual_pushButton = QPushButton(self.htype_setting_widget)
        self.h_visual_pushButton.setObjectName(u"h_visual_pushButton")
        self.h_visual_pushButton.setMinimumSize(QSize(210, 30))
        self.h_visual_pushButton.setMaximumSize(QSize(210, 30))
        self.h_visual_pushButton.setStyleSheet(u"font: 11pt \"Segoe UI\";")

        self.horizontalLayout.addWidget(self.h_visual_pushButton)


        self.verticalLayout_2.addWidget(self.htype_setting_widget)

        self.htype_visual_widget = QWidget(self.centralwidget)
        self.htype_visual_widget.setObjectName(u"htype_visual_widget")
        self.htype_visual_widget.setMinimumSize(QSize(0, 0))
        self.horizontalLayout_2 = QHBoxLayout(self.htype_visual_widget)
        self.horizontalLayout_2.setSpacing(5)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.cadvisual_widget = QWidget(self.htype_visual_widget)
        self.cadvisual_widget.setObjectName(u"cadvisual_widget")
        self.cadvisual_widget.setMinimumSize(QSize(300, 300))
        self.cadvisual_layout = QVBoxLayout(self.cadvisual_widget)
        self.cadvisual_layout.setSpacing(0)
        self.cadvisual_layout.setObjectName(u"cadvisual_layout")
        self.cadvisual_layout.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout_3.addWidget(self.cadvisual_widget)

        self.label_2 = QLabel(self.htype_visual_widget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setMinimumSize(QSize(0, 40))
        self.label_2.setMaximumSize(QSize(16777215, 40))
        self.label_2.setLayoutDirection(Qt.LeftToRight)
        self.label_2.setStyleSheet(u"font: 12pt \"Segoe UI\";")
        self.label_2.setAlignment(Qt.AlignHCenter|Qt.AlignTop)

        self.verticalLayout_3.addWidget(self.label_2)


        self.horizontalLayout_2.addLayout(self.verticalLayout_3)

        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.gcvisual_widget = QWidget(self.htype_visual_widget)
        self.gcvisual_widget.setObjectName(u"gcvisual_widget")
        self.gcvisual_widget.setMinimumSize(QSize(300, 300))
        self.gcvisual_layout = QVBoxLayout(self.gcvisual_widget)
        self.gcvisual_layout.setSpacing(0)
        self.gcvisual_layout.setObjectName(u"gcvisual_layout")
        self.gcvisual_layout.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout_4.addWidget(self.gcvisual_widget)

        self.label_3 = QLabel(self.htype_visual_widget)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setMinimumSize(QSize(0, 40))
        self.label_3.setMaximumSize(QSize(16777215, 40))
        self.label_3.setSizeIncrement(QSize(0, 0))
        self.label_3.setBaseSize(QSize(0, 0))
        self.label_3.setStyleSheet(u"font: 12pt \"Segoe UI\";")
        self.label_3.setAlignment(Qt.AlignHCenter|Qt.AlignTop)

        self.verticalLayout_4.addWidget(self.label_3)


        self.horizontalLayout_2.addLayout(self.verticalLayout_4)


        self.verticalLayout_2.addWidget(self.htype_visual_widget)

        self.htype_bottom_widget = QWidget(self.centralwidget)
        self.htype_bottom_widget.setObjectName(u"htype_bottom_widget")
        self.htype_bottom_widget.setMinimumSize(QSize(0, 80))
        self.htype_bottom_widget.setMaximumSize(QSize(16777215, 80))
        self.horizontalLayout_3 = QHBoxLayout(self.htype_bottom_widget)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.pushButton = QPushButton(self.htype_bottom_widget)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setMinimumSize(QSize(130, 70))
        self.pushButton.setMaximumSize(QSize(130, 70))
        self.pushButton.setStyleSheet(u"font: 12pt \"Segoe UI\";")

        self.horizontalLayout_3.addWidget(self.pushButton)

        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer_2)

        self.pushButton_2 = QPushButton(self.htype_bottom_widget)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setMinimumSize(QSize(120, 70))
        self.pushButton_2.setMaximumSize(QSize(120, 70))
        self.pushButton_2.setStyleSheet(u"font: 12pt \"Segoe UI\";")

        self.horizontalLayout_3.addWidget(self.pushButton_2)


        self.verticalLayout_2.addWidget(self.htype_bottom_widget)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 900, 22))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"H-type RPS selection", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"H-Type RPS number: ", None))
        self.hnum_comboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"1", None))
        self.hnum_comboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"2", None))
        self.hnum_comboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"3", None))
        self.hnum_comboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"4", None))
        self.hnum_comboBox.setItemText(4, QCoreApplication.translate("MainWindow", u"5", None))
        self.hnum_comboBox.setItemText(5, QCoreApplication.translate("MainWindow", u"6", None))
        self.hnum_comboBox.setItemText(6, QCoreApplication.translate("MainWindow", u"7", None))
        self.hnum_comboBox.setItemText(7, QCoreApplication.translate("MainWindow", u"8", None))

        self.h_visual_pushButton.setText(QCoreApplication.translate("MainWindow", u"Set and visualize geometries", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"CAD geometry", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"Distorted geometry", None))
        self.pushButton.setText(QCoreApplication.translate("MainWindow", u"Reset selection", None))
        self.pushButton_2.setText(QCoreApplication.translate("MainWindow", u"Export CSV", None))
    # retranslateUi


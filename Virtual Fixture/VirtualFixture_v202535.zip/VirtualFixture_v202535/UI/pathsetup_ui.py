# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'path_setupEpGzJg.ui'
##
## Created by: Qt User Interface Compiler version 6.5.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
    QPlainTextEdit, QPushButton, QSizePolicy, QSpacerItem,
    QVBoxLayout, QWidget)
import UI.resources_rc

class Ui_SystemPathWindow(object):
    def setupUi(self, SystemPathWindow):
        if not SystemPathWindow.objectName():
            SystemPathWindow.setObjectName(u"SystemPathWindow")
        SystemPathWindow.resize(650, 294)
        SystemPathWindow.setMinimumSize(QSize(350, 200))
        SystemPathWindow.setStyleSheet(u"background-color: rgb(61, 61, 61);")
        self.verticalLayout_3 = QVBoxLayout(SystemPathWindow)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(5, 5, 5, 5)
        self.message_label = QLabel(SystemPathWindow)
        self.message_label.setObjectName(u"message_label")
        self.message_label.setMinimumSize(QSize(0, 28))
        self.message_label.setMaximumSize(QSize(16777215, 28))
        self.message_label.setStyleSheet(u"font: 700 italic 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.message_label.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.verticalLayout_3.addWidget(self.message_label)

        self.message_label_2 = QLabel(SystemPathWindow)
        self.message_label_2.setObjectName(u"message_label_2")
        self.message_label_2.setMinimumSize(QSize(0, 21))
        self.message_label_2.setMaximumSize(QSize(16777215, 21))
        self.message_label_2.setStyleSheet(u"font: 700 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.message_label_2.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.verticalLayout_3.addWidget(self.message_label_2)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setSpacing(10)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.swpath_plainTextEdit = QPlainTextEdit(SystemPathWindow)
        self.swpath_plainTextEdit.setObjectName(u"swpath_plainTextEdit")
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.swpath_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.swpath_plainTextEdit.setSizePolicy(sizePolicy)
        self.swpath_plainTextEdit.setMinimumSize(QSize(500, 29))
        self.swpath_plainTextEdit.setMaximumSize(QSize(16777215, 29))
        self.swpath_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #1d1d1d; /* Modern dark background */\n"
"    color: white; /* Soft, modern text color */\n"
"    border: 1px solid grey; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"}\n"
"")

        self.horizontalLayout_3.addWidget(self.swpath_plainTextEdit)

        self.swpath_pushButton = QPushButton(SystemPathWindow)
        self.swpath_pushButton.setObjectName(u"swpath_pushButton")
        self.swpath_pushButton.setMinimumSize(QSize(80, 30))
        self.swpath_pushButton.setMaximumSize(QSize(80, 30))
        self.swpath_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")
        self.swpath_pushButton.setIconSize(QSize(24, 24))
        self.swpath_pushButton.setCheckable(True)
        self.swpath_pushButton.setAutoExclusive(True)

        self.horizontalLayout_3.addWidget(self.swpath_pushButton)


        self.verticalLayout_3.addLayout(self.horizontalLayout_3)

        self.message_label_3 = QLabel(SystemPathWindow)
        self.message_label_3.setObjectName(u"message_label_3")
        self.message_label_3.setMinimumSize(QSize(0, 21))
        self.message_label_3.setMaximumSize(QSize(16777215, 21))
        self.message_label_3.setStyleSheet(u"font: 700 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.message_label_3.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.verticalLayout_3.addWidget(self.message_label_3)

        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setSpacing(10)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.smaterialpath_plainTextEdit = QPlainTextEdit(SystemPathWindow)
        self.smaterialpath_plainTextEdit.setObjectName(u"smaterialpath_plainTextEdit")
        sizePolicy.setHeightForWidth(self.smaterialpath_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.smaterialpath_plainTextEdit.setSizePolicy(sizePolicy)
        self.smaterialpath_plainTextEdit.setMinimumSize(QSize(500, 29))
        self.smaterialpath_plainTextEdit.setMaximumSize(QSize(16777215, 29))
        self.smaterialpath_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #1d1d1d; /* Modern dark background */\n"
"    color: white; /* Soft, modern text color */\n"
"    border: 1px solid grey; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"}")

        self.horizontalLayout_5.addWidget(self.smaterialpath_plainTextEdit)

        self.smaterialpath_pushButton = QPushButton(SystemPathWindow)
        self.smaterialpath_pushButton.setObjectName(u"smaterialpath_pushButton")
        self.smaterialpath_pushButton.setMinimumSize(QSize(80, 30))
        self.smaterialpath_pushButton.setMaximumSize(QSize(80, 30))
        self.smaterialpath_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")
        self.smaterialpath_pushButton.setIconSize(QSize(24, 24))
        self.smaterialpath_pushButton.setCheckable(True)
        self.smaterialpath_pushButton.setAutoExclusive(True)

        self.horizontalLayout_5.addWidget(self.smaterialpath_pushButton)


        self.verticalLayout_3.addLayout(self.horizontalLayout_5)

        self.message_label_4 = QLabel(SystemPathWindow)
        self.message_label_4.setObjectName(u"message_label_4")
        self.message_label_4.setMinimumSize(QSize(0, 21))
        self.message_label_4.setMaximumSize(QSize(16777215, 21))
        self.message_label_4.setStyleSheet(u"font: 700 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.message_label_4.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.verticalLayout_3.addWidget(self.message_label_4)

        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setSpacing(10)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.smesh_plainTextEdit = QPlainTextEdit(SystemPathWindow)
        self.smesh_plainTextEdit.setObjectName(u"smesh_plainTextEdit")
        sizePolicy.setHeightForWidth(self.smesh_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.smesh_plainTextEdit.setSizePolicy(sizePolicy)
        self.smesh_plainTextEdit.setMinimumSize(QSize(500, 29))
        self.smesh_plainTextEdit.setMaximumSize(QSize(16777215, 29))
        self.smesh_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #1d1d1d; /* Modern dark background */\n"
"    color: white; /* Soft, modern text color */\n"
"    border: 1px solid grey; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"}")

        self.horizontalLayout_6.addWidget(self.smesh_plainTextEdit)

        self.smesh_pushButton = QPushButton(SystemPathWindow)
        self.smesh_pushButton.setObjectName(u"smesh_pushButton")
        self.smesh_pushButton.setMinimumSize(QSize(80, 30))
        self.smesh_pushButton.setMaximumSize(QSize(80, 30))
        self.smesh_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")
        self.smesh_pushButton.setIconSize(QSize(24, 24))
        self.smesh_pushButton.setCheckable(True)
        self.smesh_pushButton.setAutoExclusive(True)

        self.horizontalLayout_6.addWidget(self.smesh_pushButton)


        self.verticalLayout_3.addLayout(self.horizontalLayout_6)

        self.message_label_5 = QLabel(SystemPathWindow)
        self.message_label_5.setObjectName(u"message_label_5")
        self.message_label_5.setMinimumSize(QSize(0, 21))
        self.message_label_5.setMaximumSize(QSize(16777215, 21))
        self.message_label_5.setStyleSheet(u"font: 700 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.message_label_5.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.verticalLayout_3.addWidget(self.message_label_5)

        self.horizontalLayout_7 = QHBoxLayout()
        self.horizontalLayout_7.setSpacing(10)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.workdirect_plainTextEdit = QPlainTextEdit(SystemPathWindow)
        self.workdirect_plainTextEdit.setObjectName(u"workdirect_plainTextEdit")
        sizePolicy.setHeightForWidth(self.workdirect_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.workdirect_plainTextEdit.setSizePolicy(sizePolicy)
        self.workdirect_plainTextEdit.setMinimumSize(QSize(500, 29))
        self.workdirect_plainTextEdit.setMaximumSize(QSize(16777215, 29))
        self.workdirect_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #1d1d1d; /* Modern dark background */\n"
"    color: white; /* Soft, modern text color */\n"
"    border: 1px solid grey; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"}\n"
"")

        self.horizontalLayout_7.addWidget(self.workdirect_plainTextEdit)

        self.workdirect_pushButton = QPushButton(SystemPathWindow)
        self.workdirect_pushButton.setObjectName(u"workdirect_pushButton")
        self.workdirect_pushButton.setMinimumSize(QSize(80, 30))
        self.workdirect_pushButton.setMaximumSize(QSize(80, 30))
        self.workdirect_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")
        self.workdirect_pushButton.setIconSize(QSize(24, 24))
        self.workdirect_pushButton.setCheckable(True)
        self.workdirect_pushButton.setAutoExclusive(True)

        self.horizontalLayout_7.addWidget(self.workdirect_pushButton)


        self.verticalLayout_3.addLayout(self.horizontalLayout_7)

        self.horizontalWidget = QWidget(SystemPathWindow)
        self.horizontalWidget.setObjectName(u"horizontalWidget")
        self.horizontalWidget.setMinimumSize(QSize(0, 50))
        self.horizontalWidget.setMaximumSize(QSize(16777215, 50))
        self.horizontalLayout_2 = QHBoxLayout(self.horizontalWidget)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(1, 1, 1, 6)
        self.checkpath_pushButton = QPushButton(self.horizontalWidget)
        self.checkpath_pushButton.setObjectName(u"checkpath_pushButton")
        self.checkpath_pushButton.setMinimumSize(QSize(110, 30))
        self.checkpath_pushButton.setMaximumSize(QSize(110, 30))
        self.checkpath_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_2.addWidget(self.checkpath_pushButton)

        self.installvtk_pushButton = QPushButton(self.horizontalWidget)
        self.installvtk_pushButton.setObjectName(u"installvtk_pushButton")
        self.installvtk_pushButton.setMinimumSize(QSize(150, 30))
        self.installvtk_pushButton.setMaximumSize(QSize(150, 30))
        self.installvtk_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_2.addWidget(self.installvtk_pushButton)

        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_2)

        self.close_pushButton = QPushButton(self.horizontalWidget)
        self.close_pushButton.setObjectName(u"close_pushButton")
        self.close_pushButton.setMinimumSize(QSize(100, 30))
        self.close_pushButton.setMaximumSize(QSize(100, 30))
        self.close_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_2.addWidget(self.close_pushButton)


        self.verticalLayout_3.addWidget(self.horizontalWidget)


        self.retranslateUi(SystemPathWindow)
        self.close_pushButton.clicked.connect(SystemPathWindow.close)

        QMetaObject.connectSlotsByName(SystemPathWindow)
    # setupUi

    def retranslateUi(self, SystemPathWindow):
        SystemPathWindow.setWindowTitle(QCoreApplication.translate("SystemPathWindow", u"System path selection window", None))
        self.message_label.setText(QCoreApplication.translate("SystemPathWindow", u"System paths' Setting", None))
        self.message_label_2.setText(QCoreApplication.translate("SystemPathWindow", u"Simufact Welding installation path", None))
        self.swpath_plainTextEdit.setPlainText(QCoreApplication.translate("SystemPathWindow", u"Select the Simufact Welding 2024.4 installation path here -->", None))
        self.swpath_pushButton.setText(QCoreApplication.translate("SystemPathWindow", u"Browse", None))
        self.message_label_3.setText(QCoreApplication.translate("SystemPathWindow", u"Simufact Material path", None))
        self.smaterialpath_plainTextEdit.setPlainText(QCoreApplication.translate("SystemPathWindow", u"Select the Simufact Material path here -->", None))
        self.smaterialpath_pushButton.setText(QCoreApplication.translate("SystemPathWindow", u"Browse", None))
        self.message_label_4.setText(QCoreApplication.translate("SystemPathWindow", u"Simufact Mesh path", None))
        self.smesh_plainTextEdit.setPlainText(QCoreApplication.translate("SystemPathWindow", u"Select the Simufact Mesh path here -->", None))
        self.smesh_pushButton.setText(QCoreApplication.translate("SystemPathWindow", u"Browse", None))
        self.message_label_5.setText(QCoreApplication.translate("SystemPathWindow", u"Work directory (project storage)", None))
        self.workdirect_plainTextEdit.setPlainText(QCoreApplication.translate("SystemPathWindow", u"Select the Work directory here -->", None))
        self.workdirect_pushButton.setText(QCoreApplication.translate("SystemPathWindow", u"Browse", None))
        self.checkpath_pushButton.setText(QCoreApplication.translate("SystemPathWindow", u"Check paths", None))
        self.installvtk_pushButton.setText(QCoreApplication.translate("SystemPathWindow", u"Install VTK module", None))
        self.close_pushButton.setText(QCoreApplication.translate("SystemPathWindow", u"Close", None))
    # retranslateUi


# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'selectrpsuKktib.ui'
##
## Created by: Qt User Interface Compiler version 6.5.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
    QPushButton, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)

class Ui_SelectRPSWindow(object):
    def setupUi(self, SelectRPSWindow):
        if not SelectRPSWindow.objectName():
            SelectRPSWindow.setObjectName(u"SelectRPSWindow")
        SelectRPSWindow.resize(750, 580)
        SelectRPSWindow.setMinimumSize(QSize(450, 250))
        SelectRPSWindow.setStyleSheet(u"background-color: rgb(61, 61, 61);")
        self.verticalLayout_3 = QVBoxLayout(SelectRPSWindow)
        self.verticalLayout_3.setSpacing(5)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(5, 5, 5, 5)
        self.message_label = QLabel(SelectRPSWindow)
        self.message_label.setObjectName(u"message_label")
        self.message_label.setMinimumSize(QSize(0, 25))
        self.message_label.setMaximumSize(QSize(16777215, 25))
        self.message_label.setStyleSheet(u"font: 700 italic 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.message_label.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.verticalLayout_3.addWidget(self.message_label)

        self.message_label_2 = QLabel(SelectRPSWindow)
        self.message_label_2.setObjectName(u"message_label_2")
        self.message_label_2.setMinimumSize(QSize(0, 25))
        self.message_label_2.setMaximumSize(QSize(16777215, 25))
        self.message_label_2.setStyleSheet(u"font: 700 italic 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.message_label_2.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.verticalLayout_3.addWidget(self.message_label_2)

        self.manualselect_widget = QWidget(SelectRPSWindow)
        self.manualselect_widget.setObjectName(u"manualselect_widget")
        self.manualselect_widget.setStyleSheet(u"background-color: rgb(77, 77, 77);")
        self.manualselect_widget_layout = QVBoxLayout(self.manualselect_widget)
        self.manualselect_widget_layout.setSpacing(0)
        self.manualselect_widget_layout.setObjectName(u"manualselect_widget_layout")
        self.manualselect_widget_layout.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout_3.addWidget(self.manualselect_widget)

        self.horizontalWidget = QWidget(SelectRPSWindow)
        self.horizontalWidget.setObjectName(u"horizontalWidget")
        self.horizontalWidget.setMinimumSize(QSize(0, 40))
        self.horizontalWidget.setMaximumSize(QSize(16777215, 40))
        self.horizontalLayout_2 = QHBoxLayout(self.horizontalWidget)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(1, 1, 1, 6)
        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_2)

        self.close_pushButton = QPushButton(self.horizontalWidget)
        self.close_pushButton.setObjectName(u"close_pushButton")
        self.close_pushButton.setMinimumSize(QSize(100, 30))
        self.close_pushButton.setMaximumSize(QSize(100, 30))
        self.close_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_2.addWidget(self.close_pushButton)


        self.verticalLayout_3.addWidget(self.horizontalWidget)


        self.retranslateUi(SelectRPSWindow)
        self.close_pushButton.clicked.connect(SelectRPSWindow.close)

        QMetaObject.connectSlotsByName(SelectRPSWindow)
    # setupUi

    def retranslateUi(self, SelectRPSWindow):
        SelectRPSWindow.setWindowTitle(QCoreApplication.translate("SelectRPSWindow", u"Manual F-type and H-type RPS selection", None))
        self.message_label.setText(QCoreApplication.translate("SelectRPSWindow", u"[Shift + left click] to select F-type RPS", None))
        self.message_label_2.setText(QCoreApplication.translate("SelectRPSWindow", u"[Ctrl + Shift + left click] to select H-type RPS", None))
        self.close_pushButton.setText(QCoreApplication.translate("SelectRPSWindow", u"Close", None))
    # retranslateUi


from PySide6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QLabel, QWidget, QFileDialog
from PySide6.QtWidgets import QApplication
import sys, os

class ImportPolyWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)

        # Set up the window
        self.setWindowTitle("Import measurement plan")
        self.resize(500, 130)

        # Create a layout
        layout = QVBoxLayout()

        # Add a label and text input for the point measurement path
        self.point_measurement_label = QLabel("Point Measurement CSV file:")
        self.point_measurement_input = QLineEdit()
        self.point_measurement_browse_button = QPushButton("Browse")
        self.point_measurement_browse_button.clicked.connect(self.browse_point_measurement)
        point_measurement_layout = QHBoxLayout()
        point_measurement_layout.addWidget(self.point_measurement_input)
        point_measurement_layout.addWidget(self.point_measurement_browse_button)
        layout.addWidget(self.point_measurement_label)
        layout.addLayout(point_measurement_layout)

        # Add a label and text input for the round hole measurement path
        self.round_hole_measurement_label = QLabel("Round Hole Measurement CSV file:")
        self.round_hole_measurement_input = QLineEdit()
        self.round_hole_measurement_browse_button = QPushButton("Browse")
        self.round_hole_measurement_browse_button.clicked.connect(self.browse_round_hole_measurement)
        round_hole_measurement_layout = QHBoxLayout()
        round_hole_measurement_layout.addWidget(self.round_hole_measurement_input)
        round_hole_measurement_layout.addWidget(self.round_hole_measurement_browse_button)
        layout.addWidget(self.round_hole_measurement_label)
        layout.addLayout(round_hole_measurement_layout)

        # Create a horizontal layout for the buttons
        button_layout = QHBoxLayout()
        
        # Add Save and Cancel buttons
        self.import_button = QPushButton("Import")
        self.cancel_button = QPushButton("Cancel")
        button_layout.addWidget(self.import_button)
        button_layout.addWidget(self.cancel_button)

        # Connect buttons to their respective functions
        self.import_button.clicked.connect(self.import_files)
        self.cancel_button.clicked.connect(self.cancel)

        # Add the button layout to the main layout
        layout.addLayout(button_layout)

        # Set the central widget for the window
        container = QWidget()
        container.setLayout(layout)
        self.setLayout(layout)

    def browse_point_measurement(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Point Measurement File", "", "CSV Files (*.csv)")
        if file_path:
            self.point_measurement_input.setText(file_path)

    def browse_round_hole_measurement(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Round Hole Measurement File", "", "CSV Files (*.csv)")
        if file_path:
            self.round_hole_measurement_input.setText(file_path)

    def import_files(self):
        self.point_measurement_path = self.point_measurement_input.text()
        self.round_hole_measurement_path = self.round_hole_measurement_input.text()
        # Implement the logic to save the project with the given name and paths
        print(f"GUI : Point Measurement Path: {self.point_measurement_path}")
        print(f"GUI : Round Hole Measurement Path: {self.round_hole_measurement_path}")
        self.accept()

    def cancel(self):
        self.reject()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ImportPolyWindow()
    window.show()
    sys.exit(app.exec_())
# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'saveprojectWbCsen.ui'
##
## Created by: Qt User Interface Compiler version 6.5.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
    QPlainTextEdit, QPushButton, QSizePolicy, QSpacerItem,
    QVBoxLayout, QWidget)

class Ui_SaveProjectWindow(object):
    def setupUi(self, SaveProjectWindow):
        if not SaveProjectWindow.objectName():
            SaveProjectWindow.setObjectName(u"SaveProjectWindow")
        SaveProjectWindow.resize(480, 150)
        SaveProjectWindow.setMinimumSize(QSize(350, 150))
        SaveProjectWindow.setStyleSheet(u"background-color: rgb(61, 61, 61);")
        self.verticalLayout_3 = QVBoxLayout(SaveProjectWindow)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(5, 5, 5, 5)
        self.save_window = QLabel(SaveProjectWindow)
        self.save_window.setObjectName(u"save_window")
        self.save_window.setMinimumSize(QSize(0, 28))
        self.save_window.setMaximumSize(QSize(16777215, 28))
        self.save_window.setStyleSheet(u"font: 700 italic 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.save_window.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.verticalLayout_3.addWidget(self.save_window)

        self.message_label_2 = QLabel(SaveProjectWindow)
        self.message_label_2.setObjectName(u"message_label_2")
        self.message_label_2.setMinimumSize(QSize(0, 21))
        self.message_label_2.setMaximumSize(QSize(16777215, 21))
        self.message_label_2.setStyleSheet(u"font: 700 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.message_label_2.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.verticalLayout_3.addWidget(self.message_label_2)

        self.projectname_plainTextEdit = QPlainTextEdit(SaveProjectWindow)
        self.projectname_plainTextEdit.setObjectName(u"projectname_plainTextEdit")
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.projectname_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.projectname_plainTextEdit.setSizePolicy(sizePolicy)
        self.projectname_plainTextEdit.setMinimumSize(QSize(200, 29))
        self.projectname_plainTextEdit.setMaximumSize(QSize(16777215, 29))
        self.projectname_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #1d1d1d; /* Modern dark background */\n"
"    color: white; /* Soft, modern text color */\n"
"    border: 1px solid grey; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"}\n"
"")

        self.verticalLayout_3.addWidget(self.projectname_plainTextEdit)

        self.horizontalWidget = QWidget(SaveProjectWindow)
        self.horizontalWidget.setObjectName(u"horizontalWidget")
        self.horizontalWidget.setMinimumSize(QSize(0, 40))
        self.horizontalWidget.setMaximumSize(QSize(16777215, 40))
        self.horizontalLayout_2 = QHBoxLayout(self.horizontalWidget)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(1, 1, 1, 6)
        self.saveasproject_pushButton = QPushButton(self.horizontalWidget)
        self.saveasproject_pushButton.setObjectName(u"saveasproject_pushButton")
        self.saveasproject_pushButton.setMinimumSize(QSize(120, 30))
        self.saveasproject_pushButton.setMaximumSize(QSize(120, 30))
        self.saveasproject_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_2.addWidget(self.saveasproject_pushButton)

        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_2)

        self.close_pushButton = QPushButton(self.horizontalWidget)
        self.close_pushButton.setObjectName(u"close_pushButton")
        self.close_pushButton.setMinimumSize(QSize(100, 30))
        self.close_pushButton.setMaximumSize(QSize(100, 30))
        self.close_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_2.addWidget(self.close_pushButton)


        self.verticalLayout_3.addWidget(self.horizontalWidget)


        self.retranslateUi(SaveProjectWindow)
        self.close_pushButton.clicked.connect(SaveProjectWindow.close)

        QMetaObject.connectSlotsByName(SaveProjectWindow)
    # setupUi

    def retranslateUi(self, SaveProjectWindow):
        SaveProjectWindow.setWindowTitle(QCoreApplication.translate("SaveProjectWindow", u"Save project window", None))
        self.save_window.setText(QCoreApplication.translate("SaveProjectWindow", u"Save project as(new project name)", None))
        self.message_label_2.setText(QCoreApplication.translate("SaveProjectWindow", u"New project name (for save as)", None))
        self.projectname_plainTextEdit.setPlainText("")
        self.saveasproject_pushButton.setText(QCoreApplication.translate("SaveProjectWindow", u"Save as", None))
        self.close_pushButton.setText(QCoreApplication.translate("SaveProjectWindow", u"Close", None))
    # retranslateUi


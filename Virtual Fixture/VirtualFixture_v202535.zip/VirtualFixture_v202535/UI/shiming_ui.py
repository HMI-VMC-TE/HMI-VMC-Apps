# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'shimingGjmoYs.ui'
##
## Created by: Qt User Interface Compiler version 6.5.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QHeaderView,
    QLabel, QListWidget, QListWidgetItem, QPushButton,
    QSizePolicy, QSpacerItem, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget)

class Ui_BatchShimmingWindow(object):
    def setupUi(self, BatchShimmingWindow):
        if not BatchShimmingWindow.objectName():
            BatchShimmingWindow.setObjectName(u"BatchShimmingWindow")
        BatchShimmingWindow.resize(1136, 700)
        BatchShimmingWindow.setMinimumSize(QSize(750, 200))
        BatchShimmingWindow.setStyleSheet(u"background-color: rgb(61, 61, 61);")
        self.verticalLayout_3 = QVBoxLayout(BatchShimmingWindow)
        self.verticalLayout_3.setSpacing(5)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(5, 5, 5, 5)
        self.horizontalWidget = QWidget(BatchShimmingWindow)
        self.horizontalWidget.setObjectName(u"horizontalWidget")
        self.horizontalWidget.setMinimumSize(QSize(0, 40))
        self.horizontalWidget.setMaximumSize(QSize(16777215, 40))
        self.horizontalLayout_4 = QHBoxLayout(self.horizontalWidget)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(2, 2, 2, 2)
        self.message_label = QLabel(self.horizontalWidget)
        self.message_label.setObjectName(u"message_label")
        self.message_label.setMinimumSize(QSize(0, 35))
        self.message_label.setMaximumSize(QSize(16777215, 35))
        self.message_label.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 16pt \"Segoe UI\";")
        self.message_label.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.horizontalLayout_4.addWidget(self.message_label)

        self.horizontalSpacer_3 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_3)

        self.opensw_pushButton = QPushButton(self.horizontalWidget)
        self.opensw_pushButton.setObjectName(u"opensw_pushButton")
        self.opensw_pushButton.setMinimumSize(QSize(150, 30))
        self.opensw_pushButton.setMaximumSize(QSize(150, 100))
        self.opensw_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 15px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_4.addWidget(self.opensw_pushButton)


        self.verticalLayout_3.addWidget(self.horizontalWidget)

        self.AllLayout = QHBoxLayout()
        self.AllLayout.setSpacing(3)
        self.AllLayout.setObjectName(u"AllLayout")
        self.AllLayout.setContentsMargins(1, 1, 1, 1)
        self.iterationcontrolWidget = QWidget(BatchShimmingWindow)
        self.iterationcontrolWidget.setObjectName(u"iterationcontrolWidget")
        self.iterationcontrolWidget.setMinimumSize(QSize(200, 0))
        self.iterationcontrolWidget.setMaximumSize(QSize(200, 16777215))
        self.verticalLayout = QVBoxLayout(self.iterationcontrolWidget)
        self.verticalLayout.setSpacing(5)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(1, 1, 1, 1)
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer_2)

        self.additeration_pushButton = QPushButton(self.iterationcontrolWidget)
        self.additeration_pushButton.setObjectName(u"additeration_pushButton")
        self.additeration_pushButton.setMinimumSize(QSize(70, 30))
        self.additeration_pushButton.setMaximumSize(QSize(70, 30))
        self.additeration_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout.addWidget(self.additeration_pushButton)

        self.deleteiteration_pushButton = QPushButton(self.iterationcontrolWidget)
        self.deleteiteration_pushButton.setObjectName(u"deleteiteration_pushButton")
        self.deleteiteration_pushButton.setMinimumSize(QSize(80, 30))
        self.deleteiteration_pushButton.setMaximumSize(QSize(80, 30))
        self.deleteiteration_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout.addWidget(self.deleteiteration_pushButton)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.iteration_listWidget = QListWidget(self.iterationcontrolWidget)
        self.iteration_listWidget.setObjectName(u"iteration_listWidget")
        self.iteration_listWidget.setStyleSheet(u"background-color: rgb(77, 77, 77);\n"
"font: 700 12pt \"Segoe UI\";\n"
"text-color: white;")

        self.verticalLayout.addWidget(self.iteration_listWidget)


        self.AllLayout.addWidget(self.iterationcontrolWidget)

        self.input_verticalWidget = QWidget(BatchShimmingWindow)
        self.input_verticalWidget.setObjectName(u"input_verticalWidget")
        self.input_verticalWidget.setMinimumSize(QSize(270, 0))
        self.input_verticalWidget.setMaximumSize(QSize(270, 16777215))
        self.verticalLayout_2 = QVBoxLayout(self.input_verticalWidget)
        self.verticalLayout_2.setSpacing(4)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.message_label_2 = QLabel(self.input_verticalWidget)
        self.message_label_2.setObjectName(u"message_label_2")
        self.message_label_2.setMinimumSize(QSize(0, 22))
        self.message_label_2.setMaximumSize(QSize(16777215, 22))
        self.message_label_2.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 11pt \"Segoe UI\";")
        self.message_label_2.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.verticalLayout_2.addWidget(self.message_label_2)

        self.input_tableWidget = QTableWidget(self.input_verticalWidget)
        if (self.input_tableWidget.columnCount() < 4):
            self.input_tableWidget.setColumnCount(4)
        __qtablewidgetitem = QTableWidgetItem()
        self.input_tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.input_tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.input_tableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.input_tableWidget.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        self.input_tableWidget.setObjectName(u"input_tableWidget")
        self.input_tableWidget.setStyleSheet(u"QTableWidget{\n"
"background-color: rgb(70, 70, 70);\n"
"}")
        self.input_tableWidget.horizontalHeader().setCascadingSectionResizes(True)
        self.input_tableWidget.horizontalHeader().setMinimumSectionSize(20)
        self.input_tableWidget.horizontalHeader().setDefaultSectionSize(65)
        self.input_tableWidget.verticalHeader().setMinimumSectionSize(30)

        self.verticalLayout_2.addWidget(self.input_tableWidget)

        self.message_label_3 = QLabel(self.input_verticalWidget)
        self.message_label_3.setObjectName(u"message_label_3")
        self.message_label_3.setMinimumSize(QSize(0, 22))
        self.message_label_3.setMaximumSize(QSize(16777215, 22))
        self.message_label_3.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 11pt \"Segoe UI\";")
        self.message_label_3.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.verticalLayout_2.addWidget(self.message_label_3)

        self.htypeinput_tableWidget = QTableWidget(self.input_verticalWidget)
        if (self.htypeinput_tableWidget.columnCount() < 6):
            self.htypeinput_tableWidget.setColumnCount(6)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.htypeinput_tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem4)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.htypeinput_tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.htypeinput_tableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem6)
        __qtablewidgetitem7 = QTableWidgetItem()
        self.htypeinput_tableWidget.setHorizontalHeaderItem(3, __qtablewidgetitem7)
        __qtablewidgetitem8 = QTableWidgetItem()
        self.htypeinput_tableWidget.setHorizontalHeaderItem(4, __qtablewidgetitem8)
        __qtablewidgetitem9 = QTableWidgetItem()
        self.htypeinput_tableWidget.setHorizontalHeaderItem(5, __qtablewidgetitem9)
        self.htypeinput_tableWidget.setObjectName(u"htypeinput_tableWidget")
        self.htypeinput_tableWidget.setStyleSheet(u"QTableWidget{\n"
"background-color: rgb(70, 70, 70);\n"
"}")
        self.htypeinput_tableWidget.horizontalHeader().setCascadingSectionResizes(True)
        self.htypeinput_tableWidget.horizontalHeader().setMinimumSectionSize(20)
        self.htypeinput_tableWidget.horizontalHeader().setDefaultSectionSize(65)
        self.htypeinput_tableWidget.verticalHeader().setMinimumSectionSize(30)

        self.verticalLayout_2.addWidget(self.htypeinput_tableWidget)

        self.verticalWidget = QWidget(self.input_verticalWidget)
        self.verticalWidget.setObjectName(u"verticalWidget")
        self.verticalWidget.setMinimumSize(QSize(0, 100))
        self.verticalWidget.setMaximumSize(QSize(16777215, 100))
        self.verticalWidget.setAutoFillBackground(False)
        self.verticalWidget.setInputMethodHints(Qt.ImhDate)
        self.verticalLayout_4 = QVBoxLayout(self.verticalWidget)
        self.verticalLayout_4.setSpacing(1)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.savedata_pushButton = QPushButton(self.verticalWidget)
        self.savedata_pushButton.setObjectName(u"savedata_pushButton")
        self.savedata_pushButton.setMinimumSize(QSize(50, 0))
        self.savedata_pushButton.setMaximumSize(QSize(1000, 100))
        self.savedata_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 15px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.verticalLayout_4.addWidget(self.savedata_pushButton)

        self.loadap_pushButton = QPushButton(self.verticalWidget)
        self.loadap_pushButton.setObjectName(u"loadap_pushButton")
        self.loadap_pushButton.setMinimumSize(QSize(50, 0))
        self.loadap_pushButton.setMaximumSize(QSize(1000, 100))
        self.loadap_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 15px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.verticalLayout_4.addWidget(self.loadap_pushButton)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.runiteration_pushButton = QPushButton(self.verticalWidget)
        self.runiteration_pushButton.setObjectName(u"runiteration_pushButton")
        self.runiteration_pushButton.setMinimumSize(QSize(70, 30))
        self.runiteration_pushButton.setMaximumSize(QSize(1000, 100))
        self.runiteration_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 15px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_2.addWidget(self.runiteration_pushButton)

        self.runalliteration_pushButton = QPushButton(self.verticalWidget)
        self.runalliteration_pushButton.setObjectName(u"runalliteration_pushButton")
        self.runalliteration_pushButton.setMinimumSize(QSize(70, 30))
        self.runalliteration_pushButton.setMaximumSize(QSize(1000, 100))
        self.runalliteration_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 15px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_2.addWidget(self.runalliteration_pushButton)


        self.verticalLayout_4.addLayout(self.horizontalLayout_2)


        self.verticalLayout_2.addWidget(self.verticalWidget)


        self.AllLayout.addWidget(self.input_verticalWidget)

        self.visualization_verticalWidget = QWidget(BatchShimmingWindow)
        self.visualization_verticalWidget.setObjectName(u"visualization_verticalWidget")
        self.visualization_verticalWidget.setMinimumSize(QSize(648, 0))
        self.visualization_verticalWidget.setStyleSheet(u"background-color: rgb(30, 30, 30);\n"
"border-radius: 8px;")
        self.result_verticalLayout = QVBoxLayout(self.visualization_verticalWidget)
        self.result_verticalLayout.setSpacing(1)
        self.result_verticalLayout.setObjectName(u"result_verticalLayout")
        self.result_verticalLayout.setContentsMargins(3, 3, 3, 3)
        self.horizontalWidget1 = QWidget(self.visualization_verticalWidget)
        self.horizontalWidget1.setObjectName(u"horizontalWidget1")
        self.horizontalWidget1.setMinimumSize(QSize(0, 40))
        self.horizontalWidget1.setMaximumSize(QSize(16777215, 40))
        self.horizontalLayout_3 = QHBoxLayout(self.horizontalWidget1)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(3, 3, 3, 3)
        self.showmodel_pushButton = QPushButton(self.horizontalWidget1)
        self.showmodel_pushButton.setObjectName(u"showmodel_pushButton")
        self.showmodel_pushButton.setMinimumSize(QSize(120, 30))
        self.showmodel_pushButton.setMaximumSize(QSize(120, 30))
        self.showmodel_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_3.addWidget(self.showmodel_pushButton)

        self.showresult_pushButton = QPushButton(self.horizontalWidget1)
        self.showresult_pushButton.setObjectName(u"showresult_pushButton")
        self.showresult_pushButton.setMinimumSize(QSize(120, 30))
        self.showresult_pushButton.setMaximumSize(QSize(70, 30))
        self.showresult_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_3.addWidget(self.showresult_pushButton)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer)

        self.creatap_pushButton = QPushButton(self.horizontalWidget1)
        self.creatap_pushButton.setObjectName(u"creatap_pushButton")
        self.creatap_pushButton.setMinimumSize(QSize(160, 30))
        self.creatap_pushButton.setMaximumSize(QSize(160, 30))
        self.creatap_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_3.addWidget(self.creatap_pushButton)


        self.result_verticalLayout.addWidget(self.horizontalWidget1)

        self.widget = QWidget(self.visualization_verticalWidget)
        self.widget.setObjectName(u"widget")
        self.shimming_visualization_layout = QHBoxLayout(self.widget)
        self.shimming_visualization_layout.setObjectName(u"shimming_visualization_layout")

        self.result_verticalLayout.addWidget(self.widget)


        self.AllLayout.addWidget(self.visualization_verticalWidget)


        self.verticalLayout_3.addLayout(self.AllLayout)


        self.retranslateUi(BatchShimmingWindow)

        QMetaObject.connectSlotsByName(BatchShimmingWindow)
    # setupUi

    def retranslateUi(self, BatchShimmingWindow):
        BatchShimmingWindow.setWindowTitle(QCoreApplication.translate("BatchShimmingWindow", u"Batch calculation for Shimming", None))
        self.message_label.setText(QCoreApplication.translate("BatchShimmingWindow", u"# Shimming optimization", None))
        self.opensw_pushButton.setText(QCoreApplication.translate("BatchShimmingWindow", u"Open Simufact", None))
        self.additeration_pushButton.setText(QCoreApplication.translate("BatchShimmingWindow", u"Add", None))
        self.deleteiteration_pushButton.setText(QCoreApplication.translate("BatchShimmingWindow", u"Delete", None))
        self.message_label_2.setText(QCoreApplication.translate("BatchShimmingWindow", u"F-type RPS", None))
        ___qtablewidgetitem = self.input_tableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("BatchShimmingWindow", u"Activate", None));
        ___qtablewidgetitem1 = self.input_tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("BatchShimmingWindow", u"Name", None));
        ___qtablewidgetitem2 = self.input_tableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("BatchShimmingWindow", u"Offset(mm)", None));
        ___qtablewidgetitem3 = self.input_tableWidget.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("BatchShimmingWindow", u"Fixed", None));
        self.message_label_3.setText(QCoreApplication.translate("BatchShimmingWindow", u"H-type RPS", None))
        ___qtablewidgetitem4 = self.htypeinput_tableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("BatchShimmingWindow", u"Activate", None));
        ___qtablewidgetitem5 = self.htypeinput_tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("BatchShimmingWindow", u"Name", None));
        ___qtablewidgetitem6 = self.htypeinput_tableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem6.setText(QCoreApplication.translate("BatchShimmingWindow", u"Off-X(mm)", None));
        ___qtablewidgetitem7 = self.htypeinput_tableWidget.horizontalHeaderItem(3)
        ___qtablewidgetitem7.setText(QCoreApplication.translate("BatchShimmingWindow", u"Off-Y(mm)", None));
        ___qtablewidgetitem8 = self.htypeinput_tableWidget.horizontalHeaderItem(4)
        ___qtablewidgetitem8.setText(QCoreApplication.translate("BatchShimmingWindow", u"Off-Z(mm)", None));
        ___qtablewidgetitem9 = self.htypeinput_tableWidget.horizontalHeaderItem(5)
        ___qtablewidgetitem9.setText(QCoreApplication.translate("BatchShimmingWindow", u"Fixed", None));
        self.savedata_pushButton.setText(QCoreApplication.translate("BatchShimmingWindow", u"Save", None))
        self.loadap_pushButton.setText(QCoreApplication.translate("BatchShimmingWindow", u"Load Analysis points", None))
        self.runiteration_pushButton.setText(QCoreApplication.translate("BatchShimmingWindow", u"Run", None))
        self.runalliteration_pushButton.setText(QCoreApplication.translate("BatchShimmingWindow", u"Run all", None))
        self.showmodel_pushButton.setText(QCoreApplication.translate("BatchShimmingWindow", u"Show model", None))
        self.showresult_pushButton.setText(QCoreApplication.translate("BatchShimmingWindow", u"Show result", None))
        self.creatap_pushButton.setText(QCoreApplication.translate("BatchShimmingWindow", u"Create Analysis points", None))
    # retranslateUi


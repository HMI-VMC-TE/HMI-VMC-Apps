# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'message_confirmGKuovB.ui'
##
## Created by: Qt User Interface Compiler version 6.5.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
    QPushButton, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)

class Ui_MessageConfirmWindow(object):
    def setupUi(self, MessageConfirmWindow):
        if not MessageConfirmWindow.objectName():
            MessageConfirmWindow.setObjectName(u"MessageConfirmWindow")
        MessageConfirmWindow.resize(479, 288)
        MessageConfirmWindow.setStyleSheet(u"    background-color: #3d3d3d")
        self.verticalLayout = QVBoxLayout(MessageConfirmWindow)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(5, 5, 5, 5)
        self.message_label = QLabel(MessageConfirmWindow)
        self.message_label.setObjectName(u"message_label")
        self.message_label.setStyleSheet(u"font: 700 italic 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.message_label.setAlignment(Qt.AlignCenter)

        self.verticalLayout.addWidget(self.message_label)

        self.horizontalWidget = QWidget(MessageConfirmWindow)
        self.horizontalWidget.setObjectName(u"horizontalWidget")
        self.horizontalWidget.setMinimumSize(QSize(0, 40))
        self.horizontalWidget.setMaximumSize(QSize(16777215, 40))
        self.horizontalLayout = QHBoxLayout(self.horizontalWidget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.ok_pushButton = QPushButton(self.horizontalWidget)
        self.ok_pushButton.setObjectName(u"ok_pushButton")
        self.ok_pushButton.setMinimumSize(QSize(100, 30))
        self.ok_pushButton.setMaximumSize(QSize(100, 30))
        self.ok_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout.addWidget(self.ok_pushButton)

        self.cancel_pushButton = QPushButton(self.horizontalWidget)
        self.cancel_pushButton.setObjectName(u"cancel_pushButton")
        self.cancel_pushButton.setMinimumSize(QSize(100, 30))
        self.cancel_pushButton.setMaximumSize(QSize(100, 30))
        self.cancel_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout.addWidget(self.cancel_pushButton)


        self.verticalLayout.addWidget(self.horizontalWidget)

#if QT_CONFIG(shortcut)
        self.message_label.setBuddy(self.ok_pushButton)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(MessageConfirmWindow)

        QMetaObject.connectSlotsByName(MessageConfirmWindow)
    # setupUi

    def retranslateUi(self, MessageConfirmWindow):
        MessageConfirmWindow.setWindowTitle(QCoreApplication.translate("MessageConfirmWindow", u"MessageConfirmWindow", None))
        self.message_label.setText(QCoreApplication.translate("MessageConfirmWindow", u"TextLabel", None))
        self.ok_pushButton.setText(QCoreApplication.translate("MessageConfirmWindow", u"OK", None))
        self.cancel_pushButton.setText(QCoreApplication.translate("MessageConfirmWindow", u"Cancel", None))
    # retranslateUi


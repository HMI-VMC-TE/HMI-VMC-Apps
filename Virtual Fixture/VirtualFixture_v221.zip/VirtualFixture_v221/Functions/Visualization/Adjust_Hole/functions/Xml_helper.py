import xml.etree.ElementTree as ET
from xml.dom import minidom
import os, sys

import simufact

class XmlHelper:
    def __init__(self, swproject_folder):
        self.swproject_folder = swproject_folder
        self.swproject_file = None
        for file in os.listdir(swproject_folder):
            if file.endswith(".swproj"):
                self.swproject_file = os.path.join(swproject_folder, file)
                break
        self.sw_project = simufact.welding.open_project(self.swproject_file)
        #print(f"RPS locations: {self.rps_locations}")

    def find_extract_xml_file(self):
        default_search_folder = os.path.normpath(os.path.join(self.swproject_folder, "_entities/geometries"))
        #print(f"Searching for xml file in {default_search_folder}")
        xml_file = None
        for root, dirs, files in os.walk(default_search_folder):
            #print(f"Root: {files}")
            for file in files:
                if file.endswith(".xml") and "morphed" in file.lower():
                    xml_file = os.path.join(root, file)
                    break
        
        new_xml_file = None
        for root, dirs, files in os.walk(self.swproject_folder):
            for file in files:
                if file.endswith(".xml") and "adjusted" in file.lower():
                    new_xml_file = os.path.join(root, file)
                    break

        if xml_file is None or new_xml_file is None:
            print("Could not find the xml file")
            return
        
        # Extract the information from the old xml file
        tree_old = ET.parse(xml_file)
        root_old = tree_old.getroot()

        # Extrat the information from the new xml file and get some information to the dictionary
        tree_new = ET.parse(new_xml_file)
        root_new = tree_new.getroot()
        name_element = root_new.find("name")
        info_dict = {
            "display_name": name_element.get("display_name"),
            "internal_name": name_element.get("internal_name"),
            "sdc_sync_state_type" : root_new.find("sdc_sync_state_type").text,
            "surface_model_file" : root_new.find("surface_model_file").text,
            "volume_model_file" : root_new.find("volume_model_file").text,
            "unit_length" : root_new.find("unit_length").text,
            "sdc_object_properties/uuid": root_new.find("sdc_object_properties/uuid").text,
        }

        # replace the value of root_old with info_dict
        for key, value in info_dict.items():
            if key in ["display_name", "internal_name"]:
                root_old.find("name").set(key, value)
            else:
                root_old.find(key).text = value
        
        # delete H-type RPS from the xml file
        # find the H-type RPS in the xml file and delete it
        rps_list = root_old.findall("Properties/RpsProperty/rps_locations/rps_location")
        for rps in rps_list:
            if "H" in rps.get("node_type"):
                root_old.find("Properties/RpsProperty/rps_locations").remove(rps)
        
        # change the root element name from wlMorphedGeometry to wlGeometry
        root_old.tag = "wlGeometry"
        
        # save root_old to new_xml_file
        tree_old.write(new_xml_file, encoding="utf-8", xml_declaration=True)
        print(f"XML file successfully updated at {new_xml_file}")

    def modify_sw_project(self, adjusted_geometry_path):
        # this step will include 
        # 1. open sw project, 
        # 2. import adjusted geometry to the catalog, convert it to solid-shell
        # 3. modify the xml of adjusted geometry to get RPS information from the old morphed mesh + delete H-type RPS
        # 4. delete the old morphed mesh from the catalog and rename the adjusted geometry to morphed mesh

        # 1. open sw project
        try:
            mod_project = self.sw_project
        except Exception as e:
            print(f"Error opening the project: {e}")
            return

        # 2. import adjusted geometry to the catalog and convert it to solid-shell
        try:
            new_geo = mod_project.import_geometry(adjusted_geometry_path, unit="mm", as_single_body=True)
            new_ss_geo = new_geo.make_solid_shell()
            mod_project.delete_geometry(new_geo)
            new_ss_geo.name = "Adjusted_geometry"
        except Exception as e:
            print(f"Error importing adjusted geometry: {e}")
            return
        mod_project.save()

        # 3. modify the xml of adjusted geometry to get RPS information from the old morphed mesh + delete H-type RPS
        try:
            simufact.welding.close_project()
            self.find_extract_xml_file()
            mod_project = simufact.welding.open_project(self.swproject_file)
        except Exception as e:
            print(f"Error modifying XML file: {e}")
            return
        mod_project.save()

        # 4. delete the old morphed mesh from the catalog and rename the adjusted geometry to morphed mesh
        try:
            old_geo = mod_project.geometry("Morphed_geometry")
            mod_project.delete_geometry(old_geo)
            new_ss_geo = mod_project.geometry("Adjusted_geometry")
            new_ss_geo.name = "Morphed_geometry"
        except Exception as e:
            print(f"Error deleting old morphed mesh: {e}")
            return
        mod_project.save()

        print("SW project successfully modified for adjusted geometry")


import vtk
import numpy as np
from scipy.spatial import KDTree

from PySide6.QtWidgets import QWidget, QVBoxLayout, QDialog, QLabel, QLineEdit, QPushButton, QGridLayout, QMessageBox
from vtkmodules.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor

# Blocking VTK from showing error messages window
vtk.vtkObject.GlobalWarningDisplayOff()


class CenterInputDialog(QDialog):
    def __init__(self, old_center, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Input New Center Coordinates")

        self.old_center = old_center
        self.new_center = None

        layout = QGridLayout()

        layout.addWidget(QLabel(f"Old Center: {self.old_center}"), 0, 0, 1, 2)

        self.x_input = QLineEdit()
        self.y_input = QLineEdit()
        self.z_input = QLineEdit()

        layout.addWidget(QLabel("New X:"), 1, 0)
        layout.addWidget(self.x_input, 1, 1)

        layout.addWidget(QLabel("New Y:"), 2, 0)
        layout.addWidget(self.y_input, 2, 1)

        layout.addWidget(QLabel("New Z:"), 3, 0)
        layout.addWidget(self.z_input, 3, 1)

        self.ok_button = QPushButton("OK")
        self.ok_button.clicked.connect(self.accept)
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.reject)

        layout.addWidget(self.ok_button, 4, 0)
        layout.addWidget(self.cancel_button, 4, 1)

        self.setLayout(layout)
    def accept(self):
        try:
            x = float(self.x_input.text())
            y = float(self.y_input.text())
            z = float(self.z_input.text())
            self.new_center = (x, y, z)
            super().accept()
        except ValueError:
            QMessageBox.warning(self, "Invalid Input", "Please enter valid numeric values.")

    def get_new_center(self):
        return self.new_center


class CustomInteractorStyle(vtk.vtkInteractorStyleTrackballCamera):
    def __init__(self, visualizer, parent=None):
        super().__init__()
        self.visualizer = visualizer
        self.renderer = visualizer.renderer
        self.AddObserver("LeftButtonPressEvent", self.left_button_press_event)
        self.AddObserver("LeftButtonReleaseEvent", self.left_button_release_event)
        self.AddObserver("RightButtonPressEvent", self.right_button_press_event)
        self.AddObserver("RightButtonReleaseEvent", self.right_button_release_event)
        self.AddObserver("MouseWheelForwardEvent", self.mouse_wheel_forward_event)
        self.AddObserver("MouseWheelBackwardEvent", self.mouse_wheel_backward_event)
        self.AddObserver("MouseMoveEvent", self.mouse_move_event)
        self.left_button_down = False
        self.right_button_down = False
        self.selected_actors = []  # To keep references to selected actors

        # New attributes to keep track of selected edges and centers
        self.selected_edge_ids = []
        self.edge_centers = []
        self.selected_edge_info = []  # To keep track of selected edge info (actor and STL index)
        self.max_selected_edges = 2  # We need to select 2 edges

        # New attribute to store displacement information
        self.displacement_info = []

    def left_button_press_event(self, obj, event):
        self.left_button_down = True
        interactor = self.GetInteractor()
        shift_pressed = interactor.GetShiftKey()
        if shift_pressed:
            # Handle selection of connected edge groups
            self.select_edge_group(obj, event)
        else:
            self.OnMiddleButtonDown()  # Treat left button press as middle button press for translation
        return

    def left_button_release_event(self, obj, event):
        self.left_button_down = False
        self.OnMiddleButtonUp()  # Treat left button release as middle button release
        return

    def right_button_press_event(self, obj, event):
        self.right_button_down = True
        self.OnLeftButtonDown()  # Treat right button press as left button press for rotation
        return

    def right_button_release_event(self, obj, event):
        self.right_button_down = False
        self.OnLeftButtonUp()  # Treat right button release as left button release
        return

    def mouse_move_event(self, obj, event):
        if self.left_button_down or self.right_button_down:
            self.OnMouseMove()
        return

    def mouse_wheel_forward_event(self, obj, event):
        self.OnMouseWheelForward()  # Zoom in
        return

    def mouse_wheel_backward_event(self, obj, event):
        self.OnMouseWheelBackward()  # Zoom out
        return

    def select_edge_group(self, obj, event):
        interactor = self.GetInteractor()
        click_pos = interactor.GetEventPosition()

        # Create a cell picker
        picker = vtk.vtkCellPicker()
        picker.SetTolerance(0.001)
        for edge_actor in self.visualizer.edge_actors:
            picker.AddPickList(edge_actor)
        picker.PickFromListOn()

        # Perform pick
        picker.Pick(click_pos[0], click_pos[1], 0, self.renderer)

        # Get picked actor
        actor = picker.GetActor()
        if actor:
            # Get the ID of the picked cell (edge)
            cell_id = picker.GetCellId()
            if cell_id != -1:
                print(f"Picked edge cell id: {cell_id}")

                # Retrieve the region ID of the picked edge
                region_id_array = actor.GetMapper().GetInput().GetCellData().GetArray("RegionId")
                picked_region_id = region_id_array.GetValue(cell_id)
                print(f"Picked edge region id: {picked_region_id}")

                if picked_region_id in self.selected_edge_ids:
                    print(f"Edge group {picked_region_id} is already selected.")
                    return

                # Determine which STL model this edge belongs to
                try:
                    edge_actor_index = self.visualizer.edge_actors.index(actor)
                except ValueError:
                    print("Actor not found in edge_actors list.")
                    return

                # Create a threshold filter to extract all cells with the same region ID
                threshold = vtk.vtkThreshold()
                threshold.SetInputData(actor.GetMapper().GetInput())
                threshold.SetLowerThreshold(picked_region_id)
                threshold.SetUpperThreshold(picked_region_id)
                threshold.SetThresholdFunction(vtk.vtkThreshold.THRESHOLD_BETWEEN)
                threshold.SetInputArrayToProcess(
                    0, 0, 0, vtk.vtkDataObject.FIELD_ASSOCIATION_CELLS, "RegionId"
                )
                threshold.Update()

                # Convert the unstructured grid to polydata
                geometry_filter = vtk.vtkGeometryFilter()
                geometry_filter.SetInputData(threshold.GetOutput())
                geometry_filter.Update()

                # Make sure the OriginalIds array is preserved
                geometry_filter.GetOutput().GetPointData().CopyAllocate(threshold.GetOutput().GetPointData())
                for i in range(geometry_filter.GetOutput().GetNumberOfPoints()):
                    geometry_filter.GetOutput().GetPointData().CopyData(threshold.GetOutput().GetPointData(), i, i)

                selected_edges = geometry_filter.GetOutput()

                # Store the old coordinates of the selected edges
                old_coords = []
                for i in range(selected_edges.GetNumberOfPoints()):
                    old_coords.append(selected_edges.GetPoint(i))

                # Create a new actor for the selected edge group
                mapper = vtk.vtkPolyDataMapper()
                mapper.SetInputData(selected_edges)

                # Disable scalar visibility to use the actor's property color
                mapper.ScalarVisibilityOff()

                selected_actor = vtk.vtkActor()
                selected_actor.SetMapper(mapper)
                selected_actor.GetProperty().SetColor(1, 0, 0)  # Red color
                selected_actor.GetProperty().SetLineWidth(6)

                # Add the selected actor to the renderer
                self.renderer.AddActor(selected_actor)

                # Keep a reference to prevent garbage collection
                self.selected_actors.append(selected_actor)
                self.visualizer.selected_edge_actors.append(selected_actor)

                # Append the picked_region_id to the list of selected edge ids
                self.selected_edge_ids.append(picked_region_id)

                # Store the selected edge info (including which STL it belongs to)
                self.selected_edge_info.append({
                    'edge_actor': actor,
                    'edge_actor_index': edge_actor_index,
                    'selected_polydata': selected_edges,
                    'stl_index': edge_actor_index  # Assuming one edge actor per STL
                })

                # Render the updated scene
                interactor.GetRenderWindow().Render()

                # Calculate the center of the selected edge group
                center = self.calculate_edge_group_center(selected_edges)
                self.edge_centers.append(center)
                print(f"Center of edge group {picked_region_id}: {center}")

                # If two edges are selected, proceed to get new center coordinates
                if len(self.selected_edge_ids) == self.max_selected_edges:
                    print("Two edges selected. Proceeding to get new center coordinates.")
                    self.get_new_center_coordinates()

    def calculate_edge_group_center(self, polydata):
        num_points = polydata.GetNumberOfPoints()
        if (num_points == 0):
            return (0, 0, 0)

        sum_x, sum_y, sum_z = 0.0, 0.0, 0.0
        for i in range(num_points):
            x, y, z = polydata.GetPoint(i)
            sum_x += x
            sum_y += y
            sum_z += z

        center_x = sum_x / num_points
        center_y = sum_y / num_points
        center_z = sum_z / num_points
        return (center_x, center_y, center_z)

    def get_new_center_coordinates(self):
        # Calculate the average of the two edge centers as the old center
        old_center = (
            self.edge_centers[0][0],
            self.edge_centers[0][1],
            self.edge_centers[0][2]
        )
        # Open the dialog window to get new center coordinates
        dialog = CenterInputDialog(old_center)
        if dialog.exec():
            new_center = dialog.get_new_center()
            print(f"New center: {new_center}")
            self.displace_edges(new_center, old_center)
        else:
            print("Dialog was cancelled.")

    def displace_edges(self, new_center, old_center):
        # Calculate the original displacement vector
        displacement = np.array([new_center[j] - old_center[j] for j in range(3)])
        print(f"Displacement: {displacement}")

        # Apply displacement to the selected edges and corresponding STL surfaces
        for i, edge_info in enumerate(self.selected_edge_info):
            stl_index = edge_info['stl_index']
            # Get the STL polydata with original IDs
            stl_polydata = self.visualizer.stl_polydata_list[stl_index]

            # Get the point IDs of the selected edge from the OriginalPointIds array
            selected_polydata = edge_info['selected_polydata']
            original_ids_array = selected_polydata.GetPointData().GetArray("OriginalPointIds")

            if original_ids_array is None:
                print("OriginalPointIds array is missing in selected_polydata.")
                continue

            point_ids = vtk.vtkIdList()
            for cell_id in range(selected_polydata.GetNumberOfCells()):
                cell = selected_polydata.GetCell(cell_id)
                for point_index in range(cell.GetNumberOfPoints()):
                    local_pid = cell.GetPointId(point_index)
                    original_pid = int(original_ids_array.GetValue(local_pid))
                    point_ids.InsertUniqueId(original_pid)

            # Compute the normal vector of the plane formed by adjacent faces
            normal = np.zeros(3)
            num_normals = 0

            points = stl_polydata.GetPoints()
            cell_ids = vtk.vtkIdList()

            # Collect normals from adjacent cells
            for idx in range(point_ids.GetNumberOfIds()):
                pid = point_ids.GetId(idx)
                stl_polydata.GetPointCells(pid, cell_ids)
                for cid in range(cell_ids.GetNumberOfIds()):
                    cell = stl_polydata.GetCell(cell_ids.GetId(cid))
                    pt_ids = cell.GetPointIds()
                    if pt_ids.GetNumberOfIds() == 3:  # Assuming triangular cells
                        pt0 = np.array(points.GetPoint(pt_ids.GetId(0)))
                        pt1 = np.array(points.GetPoint(pt_ids.GetId(1)))
                        pt2 = np.array(points.GetPoint(pt_ids.GetId(2)))
                        # Calculate the normal of the triangle
                        v1 = pt1 - pt0
                        v2 = pt2 - pt0
                        n = np.cross(v1, v2)
                        if np.linalg.norm(n) > 1e-6:
                            n /= np.linalg.norm(n)  # Normalize
                            normal += n
                            num_normals += 1

            if num_normals > 0:
                normal /= num_normals  # Average normal
                normal /= np.linalg.norm(normal)  # Ensure unit vector
            else:
                print("Could not compute normal for the edge.")
                continue

            print(f"Normal vector: {normal}")

            # Project the displacement onto the plane
            displacement_in_plane = displacement - np.dot(displacement, normal) * normal
            print(f"Displacement in-plane: {displacement_in_plane}")

            # Apply in-plane displacement to the points in the STL polydata
            for idx in range(point_ids.GetNumberOfIds()):
                pid = point_ids.GetId(idx)
                x, y, z = points.GetPoint(pid)
                new_point = [
                    x + displacement_in_plane[0],
                    y + displacement_in_plane[1],
                    z + displacement_in_plane[2],
                ]
                # Store old and new coordinates
                self.displacement_info.append({
                    'old_coords': (x, y, z),
                    'new_coords': tuple(new_point)
                })
                points.SetPoint(pid, new_point)
            points.Modified()
            stl_polydata.Modified()

        # Redraw the scene
        self.GetInteractor().GetRenderWindow().Render()

        # Clear selections after displacement
        self.selected_edge_ids = []
        self.edge_centers = []
        self.selected_edge_info = []
        self.visualizer.selected_edge_actors = []
        # Remove the highlighted edge actors from the renderer
        for actor in self.selected_actors:
            self.renderer.RemoveActor(actor)
        self.selected_actors = []

        #print("Displacement completed.")
        #print("len disp : ", len(self.displacement_info))
        
    def modify_bdf_node(self, old_nodes):
        new_nodes = old_nodes.copy()

        # Create a list of (node_id, coords) tuples
        node_items = list(new_nodes.items())
        node_coords = np.array([coords for _, coords in node_items])

        # Build KDTree using node coordinates
        kdtree = KDTree(node_coords)

        #print(f"Displacement info: {self.displacement_info}")

        # Find the closest nodes and update coordinates
        for disp_info in self.displacement_info:
            old_coords = np.array(disp_info['old_coords'])
            new_coords = np.array(disp_info['new_coords'])

            # Find the index of the closest node
            distance, idx = kdtree.query(old_coords)

            # Debugging outputs
            #print(f"\nProcessing displacement info:")
            #print(f"old_coords: {old_coords}")
            #print(f"new_coords: {new_coords}")
            #print(f"Distance to closest node: {distance}")
            #print(f"Index of closest node: {idx}")

            # Get the correct node ID
            closest_node_key = node_items[idx][0]

            # Update the node coordinates
            new_nodes[closest_node_key] = new_coords
            #print(f"Node {closest_node_key} updated from {old_coords} to {new_coords}")

        return new_nodes


class STLVisualizer:
    def __init__(self, stl_files, colors):
        self.stl_files = stl_files
        self.colors = colors
        self.renderer = vtk.vtkRenderer()
        self.edge_actors = []
        self.orientation_renderer = None

        self.stl_polydata_list = []  # To store STL polydata
        self.selected_edge_actors = []  # To keep references to selected edge actors

    def clear_renderer(self):
        self.renderer.RemoveAllViewProps()
        if self.orientation_renderer:
            self.renderer.GetRenderWindow().RemoveRenderer(self.orientation_renderer)
            self.orientation_renderer = None
        self.edge_actors = []
        self.stl_polydata_list = []

    def load_stl(self):
        # Clear the renderer before loading new STL files
        self.clear_renderer()

        for i, stl_file in enumerate(self.stl_files):
            # Load the STL file
            reader = vtk.vtkSTLReader()
            reader.SetFileName(stl_file)
            reader.Update()

            polydata = reader.GetOutput()

            if i == 0:
                # Process the first STL file as before
                # Use vtkIdFilter to store original point and cell IDs
                id_filter = vtk.vtkIdFilter()
                id_filter.SetInputData(polydata)
                id_filter.SetPointIdsArrayName("OriginalPointIds")
                id_filter.SetCellIdsArrayName("OriginalCellIds")
                id_filter.PointIdsOn()
                id_filter.CellIdsOn()
                id_filter.FieldDataOn()
                id_filter.Update()

                polydata_with_ids = id_filter.GetOutput()
                self.stl_polydata_list.append(polydata_with_ids)

                # Solid model actor
                solid_mapper = vtk.vtkPolyDataMapper()
                solid_mapper.SetInputData(polydata)

                solid_actor = vtk.vtkActor()
                solid_actor.SetMapper(solid_mapper)
                color = self.colors[i] if i < len(self.colors) else (0.8, 0.8, 0.8)
                solid_actor.GetProperty().SetColor(color)
                self.renderer.AddActor(solid_actor)

                # Extract feature edges
                edge_extractor = vtk.vtkFeatureEdges()
                edge_extractor.SetInputData(polydata_with_ids)
                edge_extractor.BoundaryEdgesOff()
                edge_extractor.FeatureEdgesOn()
                edge_extractor.NonManifoldEdgesOff()
                edge_extractor.ManifoldEdgesOff()
                edge_extractor.SetFeatureAngle(45.0)
                edge_extractor.Update()

                feature_edges = edge_extractor.GetOutput()

                # Connectivity filter to group connected edges
                connectivity_filter = vtk.vtkConnectivityFilter()
                connectivity_filter.SetInputData(feature_edges)
                connectivity_filter.SetExtractionModeToAllRegions()
                connectivity_filter.ColorRegionsOn()
                connectivity_filter.Update()

                connected_edges = connectivity_filter.GetOutput()

                # Edge actor
                edge_mapper = vtk.vtkPolyDataMapper()
                edge_mapper.SetInputData(connected_edges)
                edge_mapper.SetScalarModeToUseCellData()
                edge_mapper.SetColorModeToMapScalars()
                edge_mapper.ScalarVisibilityOff()

                edge_actor = vtk.vtkActor()
                edge_actor.SetMapper(edge_mapper)
                edge_actor.GetProperty().SetColor(0, 1, 0)
                edge_actor.GetProperty().SetLineWidth(2)
                edge_actor.GetProperty().LightingOff()

                self.renderer.AddActor(edge_actor)
                self.edge_actors.append(edge_actor)

            elif i == 1:
                print("Processing second STL file")
                # Visualize the second STL file with transparent red color
                solid_mapper = vtk.vtkPolyDataMapper()
                solid_mapper.SetInputData(polydata)

                solid_actor = vtk.vtkActor()
                solid_actor.SetMapper(solid_mapper)
                solid_actor.GetProperty().SetColor(1, 0, 0)  # Red color
                solid_actor.GetProperty().SetOpacity(0.6)  # Transparent
                self.renderer.AddActor(solid_actor)

        self.renderer.ResetCamera()
        self.renderer.ResetCameraClippingRange()

    def add_custom_orientation_indicator(self):
        # Calculate the minimum x, y, z values from the points in the STL files
        min_x, min_y, min_z = float('inf'), float('inf'), float('inf')
        for stl_file in self.stl_files:
            reader = vtk.vtkSTLReader()
            reader.SetFileName(stl_file)
            reader.Update()
            polydata = reader.GetOutput()
            bounds = polydata.GetBounds()
            min_x = min(min_x, bounds[0])
            min_y = min(min_y, bounds[2])
            min_z = min(min_z, bounds[4])

        # Shift the origin of the axes
        origin_x = min_x - 10
        origin_y = min_y - 10
        origin_z = min_z - 10

        # Create an axes actor
        axes = vtk.vtkAxesActor()
        axes.SetTotalLength(80.0, 80.0, 80.0)
        axes.SetShaftTypeToCylinder()
        axes.SetXAxisLabelText("X")
        axes.SetYAxisLabelText("Y")
        axes.SetZAxisLabelText("Z")
        axes.GetXAxisShaftProperty().SetColor(1, 0, 0)  # Red
        axes.GetYAxisShaftProperty().SetColor(0, 1, 0)  # Green
        axes.GetZAxisShaftProperty().SetColor(0, 0, 1)  # Blue

        # Make the letter indicators smaller and set the color to black
        axes.GetXAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetYAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetZAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetXAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetYAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetZAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetXAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black
        axes.GetYAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black
        axes.GetZAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black

        # Use a transform to position the axes
        transform = vtk.vtkTransform()
        transform.Translate(origin_x, origin_y, origin_z)
        axes.SetUserTransform(transform)

        # Create a renderer for the orientation indicator
        self.orientation_renderer = vtk.vtkRenderer()
        self.orientation_renderer.SetViewport(0.0, 0.0, 1.0, 1.0)
        self.orientation_renderer.SetLayer(1)
        self.orientation_renderer.InteractiveOff()
        self.orientation_renderer.AddActor(axes)

        # Link the orientation renderer's camera to the main renderer's camera
        self.orientation_renderer.SetActiveCamera(self.renderer.GetActiveCamera())

        # Add the orientation renderer to the render window
        self.renderer.GetRenderWindow().SetNumberOfLayers(2)
        self.renderer.GetRenderWindow().AddRenderer(self.orientation_renderer)


class VTKWidgetSTL(QWidget):
    def __init__(self, stl_files, colors, parent=None):
        super().__init__(parent)

        # Set up the layout
        layout = QVBoxLayout()
        self.setLayout(layout)

        # Create a VTK Visualizer instance
        self.visualizer = STLVisualizer(stl_files, colors)

        # Create the VTK render window interactor widget
        self.vtk_widget = QVTKRenderWindowInteractor(self)
        layout.addWidget(self.vtk_widget)

        # Set up the renderer and the render window
        self.render_window = self.vtk_widget.GetRenderWindow()
        self.render_window.AddRenderer(self.visualizer.renderer)

        # Set the background color to grey
        self.visualizer.renderer.SetBackground(0.3, 0.3, 0.3)

        # Set the custom interactor style
        self.interactor_style = CustomInteractorStyle(self.visualizer)
        interactor = self.render_window.GetInteractor()
        interactor.SetInteractorStyle(self.interactor_style)

        # Load and visualize the STL files
        self.visualizer.load_stl()

        # Add custom orientation indicator
        self.visualizer.add_custom_orientation_indicator()

        # Initialize and start the VTK interactor
        self.vtk_widget.Initialize()
        self.vtk_widget.Start()

    # Add a function to clear the renderer
    def clear_renderer(self):
        self.visualizer.clear_renderer()
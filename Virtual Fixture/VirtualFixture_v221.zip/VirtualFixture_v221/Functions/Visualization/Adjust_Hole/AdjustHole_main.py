import vtk
import sys, os

from PySide6.QtWidgets import QMainWindow, QWidget

from UI.Adjust_hole_ui import Ui_Adjustmorphedhole
from Functions.Visualization.Adjust_Hole.functions.Adjust_calculation_helper import VTKWidgetSTL
from Functions.Visualization.Adjust_Hole.functions.BDF_helper import BDFReader
from Functions.Visualization.Adjust_Hole.functions.Xml_helper import XmlHelper

class Adjust_window(QWidget, Ui_Adjustmorphedhole):
    def __init__(self):
        super(Adjust_window, self).__init__()
        self.setupUi(self)

        # connect the buttons
        self.finishadjust_pushButton.clicked.connect(self.adjust_bdf_export)
        self.adjusted_geometry_bdf = None
        self.modifysw_pushButton.clicked.connect(self.run_mod_sw_project)    # temporary
    
    def initiate_adjustment(self, project_dict):
        # Set the file path to stl and bdf files
        self.stl_geometry = os.path.normpath(os.path.join(project_dict["output_folder"], "0-Morphing", "Morphed_geometry.stl"))
        self.measurement_geometry = os.path.normpath(os.path.join(project_dict["import_measurement_folder"], "Measurement_data.stl"))
        self.bdf_geometry = os.path.normpath(os.path.join(project_dict["output_folder"], "0-Morphing", "Morphed_geometry.bdf"))
        self.adjusted_geometry_bdf = os.path.normpath(os.path.join(project_dict["output_folder"], "0-Morphing", "Adjusted_geometry.bdf"))
        self.adjusted_geometry_stl = os.path.normpath(os.path.join(project_dict["output_folder"], "0-Morphing", "Adjusted_geometry.stl"))

        # Load the BDF file and read nodes and elements
        self.read_bdf_file()

        # Load the stl file and visualize it in the viewer
        self.stl_visualizer = None
        self.import_stl_file()

        # get the xml file get the rps information fron old morphed mesh
        self.swproject_folder = os.path.normpath(os.path.join(project_dict["swproject_folder"], "Simufact_Project_File"))
        self.xml_helper = XmlHelper(self.swproject_folder)

    def run_mod_sw_project(self):
        self.xml_helper.modify_sw_project(self.adjusted_geometry_bdf)

    # read the bdf file
    def read_bdf_file(self):
        # Load the BDF file and read nodes and elements
        self.bdf_reader = BDFReader(self.bdf_geometry)
        self.bdf_reader.read_bdf()
        self.nodes = self.bdf_reader.get_nodes()    # examples of nodes: {1: (0.0, 0.0, 0.0), 2: (0.0, 0.0, 1.0), 3: (0.0, 1.0, 0.0), 4: (0.0, 1.0, 1.0), 5: (1.0, 0.0, 0.0), 6: (1.0, 0.0, 1.0), 7: (1.0, 1.0, 0.0), 8: (1.0, 1.0, 1.0)}
        self.new_nodes = {}
        self.elements = self.bdf_reader.get_elements()  # example of elements: [('CHEXA', 1, [1, 2, 4, 3, 5, 6, 8, 7]), ('CHEXA', 2, [5, 6, 8, 7, 1, 2, 4, 3])]

    def import_stl_file(self):
        print("Importing STL file")
        # Clear the layout
        self.clear_layout(self.stlviewer_widget_layout)

        # Create a stl visualizer object
        self.stl_visualizer = VTKWidgetSTL([self.stl_geometry, self.measurement_geometry], [(0.8, 0.8, 0.8), (1.0, 0.0, 0.0)])
        self.stlviewer_widget_layout.addWidget(self.stl_visualizer)

    def adjust_bdf_export(self):
        print("Adjusting the BDF file")
        # Get the new node coordinates
        self.new_nodes = self.stl_visualizer.interactor_style.modify_bdf_node(self.nodes)
        #print(f"New node coordinates: {self.new_nodes}")

        #for node_id, new_coords in self.new_nodes.items():
        #    old_coord = self.nodes[node_id]
        #    new_coords = self.new_nodes[node_id]
        #    diff_x = abs(new_coords[0] - old_coord[0])
        #    diff_y = abs(new_coords[1] - old_coord[1])
        #    diff_z = abs(new_coords[2] - old_coord[2])
        #    if diff_x > 1e-3 or diff_y > 1e-3 or diff_z > 1e-3:
        #        print(f"Node {node_id}: {old_coord} -> {new_coords}")

        # Update the nodes in the BDF reader
        self.bdf_reader.update_nodes(self.new_nodes)

        # Export the new BDF file
        output_bdf_path = self.adjusted_geometry_bdf
        self.bdf_reader.write_bdf(output_bdf_path)
        print(f"Updated BDF file written to {output_bdf_path}")

        # Write updated STL file
        output_stl_path = self.adjusted_geometry_stl
        self.stl_visualizer.visualizer.stl_polydata_list[0].GetPoints().Modified()
        writer = vtk.vtkSTLWriter()
        writer.SetFileName(output_stl_path)
        writer.SetInputData(self.stl_visualizer.visualizer.stl_polydata_list[0])
        writer.Write()
        print(f"Updated STL file written to {output_stl_path}")

    # Add a function to clear the layout
    def clear_layout(self, layout):
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
            else:
                self.clear_layout(item.layout())


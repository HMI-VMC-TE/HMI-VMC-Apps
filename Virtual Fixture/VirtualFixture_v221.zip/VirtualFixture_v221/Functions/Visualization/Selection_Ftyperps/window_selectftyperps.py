from PySide6.QtWidgets import QDialog
from UI.selectrps_ui import Ui_SelectRPSWindow
from Functions.Visualization.Selection_Ftyperps.selectrps_vtk import VTKWidgetWithGeometryRPS


class SelectRPSWindow_window(QDialog, Ui_SelectRPSWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        # create a vtk widget for 3D visualization of selected holding fixture
        self.vtk_selectrps = None

        # clear all render in the preview widgets
        if hasattr(self, 'vtk_selectrps') and self.vtk_selectrps is not None:
            self.vtk_selectrps.visualizer.clear_renderer()
    
    def load_cad_geometry(self, cad_file_path, output_csv_path):
        # Create a new VTK widget and load the STL file
        self.vtk_selectrps = VTKWidgetWithGeometryRPS(cad_file_path, output_csv_path)
        self.manualselect_widget_layout.addWidget(self.vtk_selectrps)


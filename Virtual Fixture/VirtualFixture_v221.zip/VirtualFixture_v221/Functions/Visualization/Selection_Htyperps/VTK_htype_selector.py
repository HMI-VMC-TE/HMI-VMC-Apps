import sys
from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QPushButton, QLabel, QDialog, QTableWidget, QTableWidgetItem
import vtk
from vtk.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor
import random
from UI.ui_htype_select import Ui_MainWindow2
import collections
import math
import csv
import os

vtk.vtkObject.GlobalWarningDisplayOff()

class CustomInteractorStyle(vtk.vtkInteractorStyleTrackballCamera):
    def __init__(self, parent=None):
        self.AddObserver("LeftButtonPressEvent", self.left_button_press_event)
        self.AddObserver("LeftButtonReleaseEvent", self.left_button_release_event)
        self.AddObserver("RightButtonPressEvent", self.right_button_press_event)
        self.AddObserver("RightButtonReleaseEvent", self.right_button_release_event)
        self.AddObserver("MouseWheelForwardEvent", self.mouse_wheel_forward_event)
        self.AddObserver("MouseWheelBackwardEvent", self.mouse_wheel_backward_event)
        self.AddObserver("MouseMoveEvent", self.mouse_move_event)
        self.left_button_down = False
        self.right_button_down = False

    def left_button_press_event(self, obj, event):
        self.left_button_down = True
        self.OnMiddleButtonDown()  # Treat left button press as middle button press for translation
        return

    def left_button_release_event(self, obj, event):
        self.left_button_down = False
        self.OnMiddleButtonUp()  # Treat left button release as middle button release
        return

    def right_button_press_event(self, obj, event):
        self.right_button_down = True
        self.OnLeftButtonDown()  # Treat right button press as left button press for rotation
        return

    def right_button_release_event(self, obj, event):
        self.right_button_down = False
        self.OnLeftButtonUp()  # Treat right button release as left button release
        return

    def mouse_move_event(self, obj, event):
        if self.left_button_down:
            self.OnMouseMove()  # Translate
        elif self.right_button_down:
            self.OnMouseMove()  # Rotate
        return

    def mouse_wheel_forward_event(self, obj, event):
        self.OnMouseWheelForward()  # Zoom in
        return

    def mouse_wheel_backward_event(self, obj, event):
        self.OnMouseWheelBackward()  # Zoom out
        return

class FeatureSelectionPopup(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Feature Selection Details")
        self.layout = QVBoxLayout(self)
        self.resize(700, 300)

        self.output_folder = ""
        self.left_feature_nodes = []  # Store node coordinates for left selections
        self.right_feature_nodes = []  # Store node coordinates for right selections

        # Create labels
        self.cad_label = QLabel("CAD feature", self)
        self.distorted_label = QLabel("Distorted feature", self)

        # Create two tables
        self.left_table = QTableWidget(self)
        self.right_table = QTableWidget(self)

        # Set column count and headers
        for table in [self.left_table, self.right_table]:
            table.setColumnCount(6)
            table.setHorizontalHeaderLabels(["#Feature No.", "Control Direction(xyz)", "X(mm)", "Y(mm)", "Z(mm)", "Max Distance(mm)"])

        # Add tables to layout
        self.layout.addWidget(self.cad_label)
        self.layout.addWidget(self.left_table)
        self.layout.addWidget(self.distorted_label)
        self.layout.addWidget(self.right_table)

        # Add the export button
        self.export_button = QPushButton('Export to CSV', self)
        self.export_button.clicked.connect(self.export_to_csv)
        self.layout.addWidget(self.export_button)
    
    def export_to_csv(self):
        # Export left table to CSV
        with open(os.path.join(self.output_folder, 'HType_cad_info.csv'), 'w', newline='') as file:
            writer = csv.writer(file)
            # Write headers
            #headers = [self.left_table.horizontalHeaderItem(i).text() for i in range(self.left_table.columnCount())]
            #writer.writerow(headers)
            # Write data
            for row in range(self.left_table.rowCount()):
                row_data = [self.left_table.item(row, col).text() for col in range(self.left_table.columnCount())]
                row_data[0] = str(row_data[0]) + "-H" + str(row_data[1])
                row_data[1] = row_data[2]
                row_data[2] = row_data[3]
                row_data[3] = row_data[4]
                # delete the last column
                del row_data[4]
                writer.writerow(row_data)

        # Export right table to CSV
        with open(os.path.join(self.output_folder, 'HType_distort_info.csv'), 'w', newline='') as file:
            writer = csv.writer(file)
            # Write headers
            #headers = [self.right_table.horizontalHeaderItem(i).text() for i in range(self.right_table.columnCount())]
            #writer.writerow(headers)
            # Write data
            for row in range(self.right_table.rowCount()):
                row_data = [self.right_table.item(row, col).text() for col in range(self.right_table.columnCount())]
                row_data[0] = str(row_data[0]) + "-H" + str(row_data[1])
                row_data[1] = row_data[2]
                row_data[2] = row_data[3]
                row_data[3] = row_data[4]
                # delete the last column
                del row_data[4]
                writer.writerow(row_data)
        
        # Export left feature nodes coordinates to CSV
        #with open(os.path.join(self.output_folder, 'cad_nodes.csv'), 'w', newline='') as file:
        #    writer = csv.writer(file)
        #    writer.writerow(['Feature_ID', 'Node_Index', 'X(mm)', 'Y(mm)', 'Z(mm)'])
        #    for feature_idx, nodes in enumerate(self.left_feature_nodes):
        #        feature_id = f'{feature_idx + 1:03}-H{self.left_table.item(feature_idx, 1).text() if feature_idx < self.left_table.rowCount() else ""}'
        #        for node_idx, (x, y, z) in enumerate(nodes):
        #            writer.writerow([feature_id, node_idx + 1, x, y, z])

        # Export right feature nodes coordinates to CSV
        #with open(os.path.join(self.output_folder, 'HType_distort_nodes.csv'), 'w', newline='') as file:
        #    writer = csv.writer(file)
        #    writer.writerow(['Feature_ID', 'Node_Index', 'X(mm)', 'Y(mm)', 'Z(mm)'])
        #    for feature_idx, nodes in enumerate(self.right_feature_nodes):
        #        feature_id = f'{feature_idx + 1:03}-H{self.right_table.item(feature_idx, 1).text() if feature_idx < self.right_table.rowCount() else ""}'
        #        for node_idx, (x, y, z) in enumerate(nodes):
        #            writer.writerow([feature_id, node_idx + 1, x, y, z])
        
        print("CSV files exported!")
        print("- HType_cad_info.csv: CAD feature information")
        print("- HType_distort_info.csv: Distorted feature information")
        print("- HType_cad_nodes.csv: CAD feature node coordinates")
        print("- HType_distort_nodes.csv: Distorted feature node coordinates")

    def populate_tables(self, left_data, right_data, left_feature_nodes, right_feature_nodes, output_folder):
        self.output_folder = output_folder
        self.left_feature_nodes = left_feature_nodes
        self.right_feature_nodes = right_feature_nodes
        self._populate_table(self.left_table, left_data)
        self._populate_table(self.right_table, right_data)

    def _populate_table(self, table, data):
        table.setRowCount(len(data))
        for row, (selection_num, direction, x, y, z, max_dist) in enumerate(data):
            table.setItem(row, 0, QTableWidgetItem(f'{row + 1:03}'))
            table.setItem(row, 1, QTableWidgetItem(direction))
            table.setItem(row, 2, QTableWidgetItem(str(x)))
            table.setItem(row, 3, QTableWidgetItem(str(y)))
            table.setItem(row, 4, QTableWidgetItem(str(z)))
            table.setItem(row, 5, QTableWidgetItem(str(round(max_dist, 1))))

class MainWindow(QMainWindow):
    def __init__(self, cad_stl_file, distorted_stl_file, output_folder, parent=None):
        super().__init__(parent)
        self.ui = Ui_MainWindow2()  # Create an instance of the UI class
        self.ui.setupUi(self)  # Set up the UI in the main window

        # get the file paths from the main window
        self.cad_stl_file = cad_stl_file
        self.distorted_stl_file = distorted_stl_file
        self.output_folder = output_folder

        # Set up VTK widgets
        self.vtkWidget_left = QVTKRenderWindowInteractor(self.ui.cadvisual_widget)
        self.ui.cadvisual_layout.addWidget(self.vtkWidget_left)
        self.vtkWidget_right = QVTKRenderWindowInteractor(self.ui.gcvisual_widget)
        self.ui.gcvisual_layout.addWidget(self.vtkWidget_right)

        self.iren_left = self.vtkWidget_left.GetRenderWindow().GetInteractor()
        self.iren_right = self.vtkWidget_right.GetRenderWindow().GetInteractor()

        # VTK Renderer for left window
        self.renderer_left = vtk.vtkRenderer()
        self.vtkWidget_left.GetRenderWindow().AddRenderer(self.renderer_left)

        # VTK Renderer for right window
        self.renderer_right = vtk.vtkRenderer()
        self.vtkWidget_right.GetRenderWindow().AddRenderer(self.renderer_right)

        # Set the interaction style to trackball
        self.iren_left.SetInteractorStyle(CustomInteractorStyle())
        self.iren_right.SetInteractorStyle(CustomInteractorStyle())

        # Picker to select cells
        self.picker_left = vtk.vtkCellPicker()
        self.picker_left.SetTolerance(0.005)
        self.picker_right = vtk.vtkCellPicker()
        self.picker_right.SetTolerance(0.005)

        # Add observer for left button press
        self.iren_left.AddObserver("LeftButtonPressEvent", self.on_left_button_press_left)
        self.iren_right.AddObserver("LeftButtonPressEvent", self.on_left_button_press_right)

        # Track feature selection actors
        self.feature_selection_actors_left = []
        self.feature_selection_actors_right = []

        # Track currently selected feature ID
        self.currently_selected_feature_id_left = None
        self.currently_selected_feature_id_right = None

        # Track feature selection data
        self.left_selections = []
        self.right_selections = []
        
        # Track feature nodes coordinates
        self.left_feature_nodes = []
        self.right_feature_nodes = []

        # Connect buttons
        self.ui.h_visual_pushButton.clicked.connect(self.on_visualize_button_click)
        self.ui.pushButton.clicked.connect(self.on_reset_button_click)
        self.ui.pushButton_2.clicked.connect(self.on_export_button_click)

        # Synchronize cameras
        self.renderer_left.GetActiveCamera().AddObserver("ModifiedEvent", self.synchronize_cameras)

    def synchronize_cameras(self, caller, event):
        camera_left = self.renderer_left.GetActiveCamera()
        camera_right = self.renderer_right.GetActiveCamera()
        camera_right.SetPosition(camera_left.GetPosition())
        camera_right.SetFocalPoint(camera_left.GetFocalPoint())
        camera_right.SetViewUp(camera_left.GetViewUp())
        camera_right.SetClippingRange(camera_left.GetClippingRange())
        self.vtkWidget_right.GetRenderWindow().Render()

    def load_stl(self, file_path, renderer):
        reader = vtk.vtkSTLReader()
        reader.SetFileName(file_path)
        reader.Update()

        # Extract the feature edges
        feature_edges = vtk.vtkFeatureEdges()
        feature_edges.SetInputConnection(reader.GetOutputPort())
        feature_edges.BoundaryEdgesOff()
        feature_edges.FeatureEdgesOn()
        feature_edges.NonManifoldEdgesOn()
        feature_edges.ManifoldEdgesOff()
        feature_edges.SetFeatureAngle(45.0)
        feature_edges.Update()

        # Use vtkConnectivityFilter to find connected regions
        connectivity_filter = vtk.vtkConnectivityFilter()
        connectivity_filter.SetInputConnection(feature_edges.GetOutputPort())
        connectivity_filter.SetExtractionModeToAllRegions()
        connectivity_filter.ColorRegionsOn()
        connectivity_filter.Update()

        # Get the number of connected regions (features)
        number_of_features = connectivity_filter.GetNumberOfExtractedRegions()
        print(f"Number of features: {number_of_features}")

        # Create a lookup table to map region ids to colors
        lut = vtk.vtkLookupTable()
        lut.SetNumberOfTableValues(number_of_features)
        lut.Build()

        # Assign random colors to each region
        for i in range(number_of_features):
            lut.SetTableValue(i, random.random(), random.random(), random.random())

        # Map the region ids to colors
        region_mapper = vtk.vtkPolyDataMapper()
        region_mapper.SetInputConnection(connectivity_filter.GetOutputPort())
        region_mapper.SetScalarModeToUseCellData()
        region_mapper.SetScalarRange(0, number_of_features - 1)
        region_mapper.SetLookupTable(lut)

        # Create an actor for the regions
        region_actor = vtk.vtkActor()
        region_actor.SetMapper(region_mapper)

        # Create a mapper and actor for the original STL geometry
        stl_mapper = vtk.vtkPolyDataMapper()
        stl_mapper.SetInputConnection(reader.GetOutputPort())

        stl_actor = vtk.vtkActor()
        stl_actor.SetMapper(stl_mapper)
        stl_actor.GetProperty().SetColor(0.5, 0.5, 0.5)  # Grey color

        # Add the actors to the scene
        renderer.AddActor(stl_actor)
        renderer.AddActor(region_actor)
        renderer.SetBackground(0.1, 0.1, 0.1)  # Dark background

        return connectivity_filter

    def on_left_button_press_left(self, obj, event):
        self.on_left_button_press(obj, event, self.picker_left, self.renderer_left, self.feature_selection_actors_left, 'left', self.connectivity_filter_left)

    def on_left_button_press_right(self, obj, event):
        self.on_left_button_press(obj, event, self.picker_right, self.renderer_right, self.feature_selection_actors_right, 'right', self.connectivity_filter_right)

    def on_left_button_press(self, obj, event, picker, renderer, feature_selection_actors, side, connectivity_filter):
        if obj.GetShiftKey():
            click_pos = obj.GetEventPosition()
            picker.Pick(click_pos[0], click_pos[1], 0, renderer)
            cell_id = picker.GetCellId()

            if cell_id != -1:
                feature_id = connectivity_filter.GetOutput().GetCellData().GetArray("RegionId").GetValue(cell_id)
                print(f"Selected feature id: {feature_id}")

                # Check if the feature is already selected
                if (side == 'left' and self.currently_selected_feature_id_left == feature_id) or \
                (side == 'right' and self.currently_selected_feature_id_right == feature_id):
                    print("Feature already selected.")
                    return

                # Update the currently selected feature ID
                if side == 'left':
                    self.currently_selected_feature_id_left = feature_id
                else:
                    self.currently_selected_feature_id_right = feature_id

                # Get the points of the selected feature
                points = connectivity_filter.GetOutput().GetPoints()
                point_data = connectivity_filter.GetOutput().GetPointData().GetArray("RegionId")

                # Collect the coordinates of all nodes in the selected feature
                feature_points = [
                    points.GetPoint(i) for i in range(points.GetNumberOfPoints())
                    if point_data.GetValue(i) == feature_id
                ]

                if feature_points:
                    # Calculate the center of the feature
                    avg_x = sum(p[0] for p in feature_points) / len(feature_points)
                    avg_y = sum(p[1] for p in feature_points) / len(feature_points)
                    avg_z = sum(p[2] for p in feature_points) / len(feature_points)
                    center = (avg_x, avg_y, avg_z)

                    # Add center sphere actor
                    center_sphere_actor = self.create_sphere_actor(center, radius=2.0, color=(0.0, 1.0, 0.0))  # Green
                    renderer.AddActor(center_sphere_actor)
                    feature_selection_actors.append(center_sphere_actor)

                    # Add smaller spheres for all feature nodes
                    for point in feature_points:
                        sphere_actor = self.create_sphere_actor(point, radius=1.0, color=(1.0, 0.0, 0.0))  # Red
                        renderer.AddActor(sphere_actor)
                        feature_selection_actors.append(sphere_actor)

                    # Visualize selection order
                    order_number = len(feature_selection_actors) // 3
                    text_actor = vtk.vtkTextActor()
                    text_actor.SetInput(f'{order_number:03}')
                    text_actor.GetTextProperty().SetColor(1.0, 1.0, 1.0)  # White
                    text_actor.SetPosition(center[0], center[1] + 5)
                    renderer.AddActor(text_actor)
                    feature_selection_actors.append(text_actor)

                    # Update renderer
                    renderer.Render()

                    # Store selection data
                    max_distance = max(
                        math.sqrt((p[0] - avg_x) ** 2 + (p[1] - avg_y) ** 2 + (p[2] - avg_z) ** 2)
                        for p in feature_points
                    )
                    selection_data = (f'{order_number:03}', "", avg_x, avg_y, avg_z, max_distance)

                    if side == 'left':
                        self.left_selections.append(selection_data)
                        self.left_feature_nodes.append(feature_points)
                        max_selections = int(self.ui.hnum_comboBox.currentText())
                        if len(self.left_selections) > max_selections:
                            self.left_selections.pop(0)
                            self.left_feature_nodes.pop(0)
                    else:
                        self.right_selections.append(selection_data)
                        self.right_feature_nodes.append(feature_points)
                        max_selections = int(self.ui.hnum_comboBox.currentText())
                        if len(self.right_selections) > max_selections:
                            self.right_selections.pop(0)
                            self.right_feature_nodes.pop(0)

                else:
                    print("No points found in the selected feature.")
            else:
                print("No cell picked.")
        else:
            print("Shift key not pressed.")

    def create_sphere_actor(self, center, radius, color):
        sphere_source = vtk.vtkSphereSource()
        sphere_source.SetCenter(center)
        sphere_source.SetRadius(radius)

        sphere_mapper = vtk.vtkPolyDataMapper()
        sphere_mapper.SetInputConnection(sphere_source.GetOutputPort())

        sphere_actor = vtk.vtkActor()
        sphere_actor.SetMapper(sphere_mapper)
        sphere_actor.GetProperty().SetColor(*color)
        return sphere_actor

    def show_feature_selection_popup(self):
        popup = FeatureSelectionPopup(self)
        print("Left selections:", self.left_selections)
        print("Right selections:", self.right_selections)
        popup.populate_tables(self.left_selections, self.right_selections, 
                             self.left_feature_nodes, self.right_feature_nodes, 
                             self.output_folder)
        popup.exec_()
    
    def add_orientation_marker(self, renderer):
        # Calculate the minimum x, y, z values from the points in the STL files
        min_x, min_y, min_z = float('inf'), float('inf'), float('inf')
        for stl_file in [self.cad_stl_file]:
            reader = vtk.vtkSTLReader()
            reader.SetFileName(stl_file)
            reader.Update()
            polydata = reader.GetOutput()
            bounds = polydata.GetBounds()
            min_x = min(min_x, bounds[0])
            min_y = min(min_y, bounds[2])
            min_z = min(min_z, bounds[4])

        # Shift the origin of the axes
        origin_x = min_x - 10
        origin_y = min_y - 10
        origin_z = min_z - 10

        axes = vtk.vtkAxesActor()
        axes.SetTotalLength(80, 80, 80)
        # Use a transform to position the axes
        transform = vtk.vtkTransform()
        transform.Translate(origin_x, origin_y, origin_z)
        axes.SetUserTransform(transform)

        # Add the axes actor to the renderer
        renderer.AddActor(axes)

    def on_visualize_button_click(self):
        # Clear existing actors
        self.renderer_left.RemoveAllViewProps()
        self.renderer_right.RemoveAllViewProps()

        # Load STL files based on the selected value from the combo box
        self.connectivity_filter_left = self.load_stl(self.cad_stl_file, self.renderer_left)
        self.connectivity_filter_right = self.load_stl(self.distorted_stl_file, self.renderer_right)

        # Add orientation markers with origin at (0, 0, 0)
        self.add_orientation_marker(self.renderer_left)
        self.add_orientation_marker(self.renderer_right)

        # Adjust camera to fit the geometries
        self.renderer_left.ResetCamera()
        self.renderer_right.ResetCamera()

        # Render the changes
        self.vtkWidget_left.GetRenderWindow().Render()
        self.vtkWidget_right.GetRenderWindow().Render()

        # Disable the combo box and the button
        self.ui.hnum_comboBox.setEnabled(False)
        self.ui.h_visual_pushButton.setEnabled(False)

        print("Visualized geometries")

    def on_export_button_click(self):
        print("CSV export button clicked!")
        self.show_feature_selection_popup()

    def on_reset_button_click(self):
        # Remove all feature selection actors from the left renderer
        for actor in self.feature_selection_actors_left:
            self.renderer_left.RemoveActor(actor)
        self.feature_selection_actors_left.clear()

        # Remove all feature selection actors from the right renderer
        for actor in self.feature_selection_actors_right:
            self.renderer_right.RemoveActor(actor)
        self.feature_selection_actors_right.clear()

        # Clear currently selected feature IDs
        self.currently_selected_feature_id_left = None
        self.currently_selected_feature_id_right = None

        # Clear the VTK windows
        self.renderer_left.RemoveAllViewProps()
        self.renderer_right.RemoveAllViewProps()
        self.vtkWidget_left.GetRenderWindow().Render()
        self.vtkWidget_right.GetRenderWindow().Render()

        # Enable the combo box and the button
        self.ui.hnum_comboBox.setEnabled(True)
        self.ui.h_visual_pushButton.setEnabled(True)

        # Reset the selections
        self.left_selections = []
        self.right_selections = []
        self.left_feature_nodes = []
        self.right_feature_nodes = []

        print("Reset selection button clicked!")



if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
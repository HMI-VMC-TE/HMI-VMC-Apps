import os, shutil, csv
import subprocess

class PolyworkHelper:
    def __init__(self, envPath, project_folder, module_folder, measurement_plan):
        self.envPath = envPath
        self.project_folder = project_folder
        self.measurement_plan = measurement_plan
        self.poly_module_folder = os.path.join(module_folder,"polywork_folder")
        self.poly_folder = os.path.normpath(os.path.join(project_folder, "2-Outputs/polywork_folder"))

        self.copyPolyworkProject()
        self.createPolyworkMacro()
    
    def copyPolyworkProject(self):
        # if polywork project folder already exists, delete it and create a new one
        if os.path.exists(self.poly_folder):
            shutil.rmtree(self.poly_folder)

        # copy the polywork project folder from the module folder to the project folder
        shutil.copytree(self.poly_module_folder, self.poly_folder)

    def createPolyworkMacro(self):
        # search for the CAD file in the project folder
        cad_file_path = None
        for file in os.listdir(os.path.join(self.project_folder, r"0-Inputs\0-CAD")):
            if file.endswith(".stl") and "CAD" in file:
                cad_file_path = os.path.join(self.project_folder, r"0-Inputs\0-CAD", file)
                cad_file_path = cad_file_path.replace("/", "\\")
                print("GUI : CAD file found: ", cad_file_path)
                break
        if not cad_file_path:
            print("GUI : CAD file not found in the project folder. Please upload the CAD file and try again.")
            return
        
        # search for the RPS result file in the project folder
        rps_result_file_path = None
        for file in os.listdir(os.path.join(self.project_folder, r"2-Outputs\2-RPS")):
            if file.endswith(".stl"):
                rps_result_file_path = os.path.join(self.project_folder, r"2-Outputs\2-RPS", file)
                rps_result_file_path = rps_result_file_path.replace("/", "\\")
                print("GUI : RPS result file found: ", rps_result_file_path)
                break
        if not rps_result_file_path:
            print("GUI : RPS result file not found in the project folder. Please run the RPS process and try again.")
            return

        script_name = "polywork_macro.pwmacro"

        # ----------------- create Polywork macro script for virtual fixture app -----------------
        self.polywork_macro_file = os.path.join(self.poly_folder, script_name)
        self.polywork_project_file = os.path.join(self.poly_folder, "Polywork_VirtualFixture.pwk")
        with open(self.polywork_macro_file, "w") as f:
            f.write('version "6.0"\n')
            f.write('#===============================================\n')
            f.write('# ---- InnovMetric Software Inc.\n')
            f.write('# ---- Module  :    PolyWorks|Inspector\n')
            f.write('# ---- Version :    2024 IR5.1 (build 3594)\n')
            f.write('# ---- Date    :    December 11, 2024 - 13:43:34\n')
            f.write('#-----------------------------------------------\n')
            f.write('FILE NEW_PROJECT ( , )\n')
            f.write('FILE SAVE_PROJECT_AS ( "{}", "VF_result" )\n'.format(self.polywork_project_file))
            f.write('FILE IMPORT_DATA POLYGONAL_MODEL ("{}", "stl", )\n'.format(cad_file_path))
            f.write('DATA CONVERT_TO_REFERENCE ( )\n')
            f.write('TREEVIEW OBJECT PROPERTIES DISPLAY COLOR ( 192, 192, 192, )\n')
            f.write('FILE IMPORT_DATA POLYGONAL_MODEL ( "{}", "stl", )\n'.format(rps_result_file_path))
            if self.measurement_plan["Round_hole_measurement"] is not None:
                f.write('FEATURE PRIMITIVE CIRCLE CREATE FROM_TEXT_FILE ( "{}", "Name+Point+Vector+Radius", "Feature" )\n'.format(self.measurement_plan["Round_hole_measurement"]))
            f.write('MEASURE EXTRACT MEASURED ( )\n')
            if self.measurement_plan["Point_measurement"] is not None:
                f.write('MEASURE COMPARISON_POINT SURFACE CREATE FROM_TEXT_FILE ( "{}", "names_points" )\n'.format(self.measurement_plan["Point_measurement"]))
            f.write('MEASURE EXTRACT MEASURED ( )\n')
            f.write('MEASURE DATA_COLOR_MAP REFERENCE_SURFACE CREATE ( "CAD to RPS result" )\n')
            f.write('TREEVIEW OBJECT SELECT NONE\n')
            f.write('TREEVIEW REFERENCE SELECT ( 1, "On" )\n')
            f.write('TREEVIEW OBJECT VIEW HIDE ( )\n')
            f.write('VIEW POSE Y_POS ( )\n')
            f.write('COMPARE VIEWING_OPTIONS COLOR_SCALE RANGE_LIMITS ( "Custom", -1.0, 1.0 )\n')
            f.write('COMPARE VIEWING_OPTIONS COLOR_SCALE SCALE_TYPE ( "3steps" )\n')
            f.write('FILE SAVE_PROJECT ( "", )\n')
            f.write('WINDOW VIEW ( "Macro Script Editor", "Off" )')
        print("GUI : Polywork macro file created: ")

    def executePolyworkMacro(self):
        # execute the meshing script by simufact.welding.exe
        try:
            polywork_exe_path = os.path.normpath(self.envPath["Polywork_Path"])
            print("GUI : executing polywork macro")
            subprocess.run([polywork_exe_path, "-pwk", self.polywork_project_file, "-macro", self.polywork_macro_file])
        except Exception as e:
            print("GUI : Polywork macro execution failed")
            print(e)


            


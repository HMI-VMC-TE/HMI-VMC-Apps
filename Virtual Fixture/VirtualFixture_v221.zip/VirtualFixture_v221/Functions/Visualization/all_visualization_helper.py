import math
import csv
import vtk
import numpy as np
import multiprocessing
from functools import partial

from PySide6.QtWidgets import QWidget, QVBoxLayout
from vtkmodules.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor

# Disable VTK warnings globally
vtk.vtkObject.GlobalWarningDisplayOff()

# additional class for Mouse controls that is similar to the Simufact Welding GUI
class CustomInteractorStyle(vtk.vtkInteractorStyleTrackballCamera):
    def __init__(self, parent=None):
        self.AddObserver("LeftButtonPressEvent", self.left_button_press_event)
        self.AddObserver("LeftButtonReleaseEvent", self.left_button_release_event)
        self.AddObserver("RightButtonPressEvent", self.right_button_press_event)
        self.AddObserver("RightButtonReleaseEvent", self.right_button_release_event)
        self.AddObserver("MouseWheelForwardEvent", self.mouse_wheel_forward_event)
        self.AddObserver("MouseWheelBackwardEvent", self.mouse_wheel_backward_event)
        self.AddObserver("MouseMoveEvent", self.mouse_move_event)
        self.left_button_down = False
        self.right_button_down = False

    def left_button_press_event(self, obj, event):
        self.left_button_down = True
        self.OnMiddleButtonDown()  # Treat left button press as middle button press for translation
        return

    def left_button_release_event(self, obj, event):
        self.left_button_down = False
        self.OnMiddleButtonUp()  # Treat left button release as middle button release
        return

    def right_button_press_event(self, obj, event):
        self.right_button_down = True
        self.OnLeftButtonDown()  # Treat right button press as left button press for rotation
        return

    def right_button_release_event(self, obj, event):
        self.right_button_down = False
        self.OnLeftButtonUp()  # Treat right button release as left button release
        return

    def mouse_move_event(self, obj, event):
        if self.left_button_down:
            self.OnMouseMove()  # Translate
        elif self.right_button_down:
            self.OnMouseMove()  # Rotate
        return

    def mouse_wheel_forward_event(self, obj, event):
        self.OnMouseWheelForward()  # Zoom in
        return

    def mouse_wheel_backward_event(self, obj, event):
        self.OnMouseWheelBackward()  # Zoom out
        return


# ---------------------------------------------------------------------------------------
# This part is for showing the CAD model with the gravity direction indicator and points
# ---------------------------------------------------------------------------------------

class STLVisualizer:
    def __init__(self, stl_files, colors, points_csv=None):
        self.stl_files = stl_files
        self.colors = colors
        self.points_csv = points_csv
        self.renderer = vtk.vtkRenderer()
        self.orientation_renderer = None  # Add this line
        self.gravity_actor = None
        # Actors for points and labels to manage them separately
        self.point_actor = None
        self.label_actor = None

    def clear_renderer(self):
        self.renderer.RemoveAllViewProps()
        if self.orientation_renderer:  # Add this block
            self.renderer.GetRenderWindow().RemoveRenderer(self.orientation_renderer)
            self.orientation_renderer = None

    def clear_gravity_indicator(self):
        if self.gravity_actor:
            self.renderer.RemoveActor(self.gravity_actor)
            self.gravity_actor = None

    def load_stl(self):
        # Clear the renderer before loading new STL files
        self.clear_renderer()

        for i, stl_file in enumerate(self.stl_files):
            # Load the STL file
            reader = vtk.vtkSTLReader()
            reader.SetFileName(stl_file)
            reader.Update()

            # Create a mapper
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInputConnection(reader.GetOutputPort())

            # Create an actor
            actor = vtk.vtkActor()
            actor.SetMapper(mapper)

            # Set the front face color
            front_color = self.colors[i] if i < len(self.colors) else (1, 1, 1)  # Default to white
            actor.GetProperty().SetColor(front_color)

            # Set the back face color
            back_color = (0.565, 0.933, 0.565)  # light green as default back face color
            backface_property = vtk.vtkProperty()
            backface_property.SetColor(back_color)
            actor.SetBackfaceProperty(backface_property)

            # Add actor to the renderer
            self.renderer.AddActor(actor)

        self.renderer.ResetCamera()

    def add_custom_orientation_indicator(self):
        # Calculate the minimum x, y, z values from the points in the STL files
        min_x, min_y, min_z = float('inf'), float('inf'), float('inf')
        for stl_file in self.stl_files:
            reader = vtk.vtkSTLReader()
            reader.SetFileName(stl_file)
            reader.Update()
            polydata = reader.GetOutput()
            bounds = polydata.GetBounds()
            min_x = min(min_x, bounds[0])
            min_y = min(min_y, bounds[2])
            min_z = min(min_z, bounds[4])

        # Shift the origin of the axes
        origin_x = min_x - 10
        origin_y = min_y - 10
        origin_z = min_z - 10

        # Create an axes actor
        axes = vtk.vtkAxesActor()
        axes.SetTotalLength(80.0, 80.0, 80.0)
        axes.SetShaftTypeToCylinder()
        axes.SetXAxisLabelText("X")
        axes.SetYAxisLabelText("Y")
        axes.SetZAxisLabelText("Z")
        axes.GetXAxisShaftProperty().SetColor(1, 0, 0)  # Red
        axes.GetYAxisShaftProperty().SetColor(0, 1, 0)  # Green
        axes.GetZAxisShaftProperty().SetColor(0, 0, 1)  # Blue

        # Make the letter indicators smaller and set the color to black
        axes.GetXAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetYAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetZAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetXAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetYAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetZAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetXAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black
        axes.GetYAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black
        axes.GetZAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black

        # Use a transform to position the axes
        transform = vtk.vtkTransform()
        transform.Translate(origin_x, origin_y, origin_z)
        axes.SetUserTransform(transform)

        # Create a renderer for the orientation indicator
        self.orientation_renderer = vtk.vtkRenderer()
        self.orientation_renderer.SetViewport(0.0, 0.0, 1.0, 1.0)  # Bottom right corner
        self.orientation_renderer.SetLayer(1)
        self.orientation_renderer.InteractiveOff()
        self.orientation_renderer.AddActor(axes)

        # Link the orientation renderer's camera to the main renderer's camera
        self.orientation_renderer.SetActiveCamera(self.renderer.GetActiveCamera())

        # Add the orientation renderer to the render window
        self.renderer.GetRenderWindow().SetNumberOfLayers(2)
        self.renderer.GetRenderWindow().AddRenderer(self.orientation_renderer)

    def add_gravity_indicator(self, gravity_direction, customed_direction=None):
        # Clear the previous gravity indicator
        self.clear_gravity_indicator()

        # Calculate the minimum x, y, z values from the points in the STL files
        min_x, min_y, min_z = float('inf'), float('inf'), float('inf')
        max_x, max_y, max_z = float('-inf'), float('-inf'), float('-inf')
        for stl_file in self.stl_files:
            reader = vtk.vtkSTLReader()
            reader.SetFileName(stl_file)
            reader.Update()
            polydata = reader.GetOutput()
            bounds = polydata.GetBounds()
            min_x = min(min_x, bounds[0])
            min_y = min(min_y, bounds[2])
            min_z = min(min_z, bounds[4])
            max_x = max(max_x, bounds[1])
            max_y = max(max_y, bounds[3])
            max_z = max(max_z, bounds[5])

        # Shift the origin of the axes
        origin_x = min_x - 10
        origin_y = max_y + 10
        origin_z = max_z + 10

        # Create an axes actor
        axes = vtk.vtkAxesActor()
        axes.SetTotalLength(80.0, 2.0, 2.0)
        axes.SetShaftTypeToCylinder()
        axes.SetXAxisLabelText("G")
        axes.SetYAxisLabelText("")
        axes.SetZAxisLabelText("")
        axes.GetXAxisShaftProperty().SetColor(0, 0, 0)  # Black for gravity indicator
        axes.GetYAxisShaftProperty().SetColor(0, 1, 0)  # Green
        axes.GetZAxisShaftProperty().SetColor(0, 0, 1)  # Blue

        # Make the letter indicators smaller and set the color to black
        axes.GetXAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetYAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetZAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetXAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetYAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetZAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetXAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black
        axes.GetYAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black
        axes.GetZAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black

        # Use a transform to position the axes
        transform = vtk.vtkTransform()
        transform.Translate(origin_x, origin_y, origin_z)

        # Rotate the gravity indicator to align with the gravity vector
        if customed_direction is None:
            # Handle predefined gravity directions
            if gravity_direction == '+X':
                transform.RotateZ(0)
            elif gravity_direction == '-X':
                transform.RotateZ(180)
            elif gravity_direction == '+Y':
                transform.RotateZ(90)
            elif gravity_direction == '-Y':
                transform.RotateZ(-90)
            elif gravity_direction == '+Z':
                transform.RotateY(-90)
            elif gravity_direction == '-Z':
                transform.RotateY(90)
        else:
            # Ensure customed_direction is a mutable list
            direction = list(customed_direction)
            # Normalize the custom direction vector
            vtk.vtkMath.Normalize(direction)

            # Define the original x-axis
            x_axis = [1.0, 0.0, 0.0]

            # Calculate the rotation axis (cross product of x-axis and direction vector)
            rotation_axis = [0.0, 0.0, 0.0]
            vtk.vtkMath.Cross(x_axis, direction, rotation_axis)
            axis_norm = vtk.vtkMath.Norm(rotation_axis)

            if axis_norm != 0:
                # Normalize the rotation axis
                vtk.vtkMath.Normalize(rotation_axis)

                # Calculate the angle between x-axis and direction vector (in degrees)
                dot_product = vtk.vtkMath.Dot(x_axis, direction)
                # Ensure the dot product is within valid range to avoid numerical errors
                dot_product = max(min(dot_product, 1.0), -1.0)
                angle = math.degrees(math.acos(dot_product))

                # Apply the rotation to the transform
                transform.RotateWXYZ(angle, rotation_axis[0], rotation_axis[1], rotation_axis[2])
            else:
                # The direction is along the x-axis or opposite to it
                dot_product = vtk.vtkMath.Dot(x_axis, direction)
                if dot_product > 0:
                    # The direction is along the positive x-axis; no rotation needed
                    pass
                else:
                    # The direction is along the negative x-axis; rotate 180 degrees around y-axis
                    transform.RotateWXYZ(180, 0, 1, 0)  # Rotate 180 degrees around y-axis

        axes.SetUserTransform(transform)

        # Add the gravity indicator actor to the renderer
        self.renderer.AddActor(axes)
        self.gravity_actor = axes  # Track the gravity indicator actor
    '''
    def load_points_from_csv(self):
        points = vtk.vtkPoints()
        with open(self.points_csv, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
                try:
                    x, y, z = map(float, row[1:4])  # Assuming the first column is an indexm, and the next three are x, y, z
                    points.InsertNextPoint(x, y, z)
                except ValueError:
                    continue
        return points
    '''
    def load_points_from_csv(self):
        """
        Reads points and labels from a CSV file.
        Assumes the first column is the label and the next three are x, y, z coordinates.
        Returns a vtkPoints object and a list of labels.
        """
        points = vtk.vtkPoints()
        labels = []
        with open(self.points_csv, 'r') as file:
            reader = csv.reader(file)
                
            for row in reader:
                if not row: continue # Skip empty rows
                try:
                    # The first column is the label
                    label = row[0]
                    # The next three columns are coordinates
                    x, y, z = map(float, row[1:4])
                    points.InsertNextPoint(x, y, z)
                    labels.append(label)
                except (ValueError, IndexError):
                    # Skip rows that don't have the correct format
                    continue
        return points, labels
    
    def visualize_points(self):
        if not self.points_csv:
            return

        points, labels = self.load_points_from_csv()
        if not points or points.GetNumberOfPoints() == 0:
            return

        polydata = vtk.vtkPolyData()
        polydata.SetPoints(points)

        # --- Create an array for the labels ---
        label_array = vtk.vtkStringArray()
        label_array.SetName("labels")
        for label in labels:
            label_array.InsertNextValue(label)
        polydata.GetPointData().AddArray(label_array)

        # --- Visualize points as spheres (Glyphs) ---
        sphere_source = vtk.vtkSphereSource()
        sphere_source.SetRadius(2.5)
        sphere_source.Update()

        glyph3d = vtk.vtkGlyph3D()
        glyph3d.SetSourceConnection(sphere_source.GetOutputPort())
        glyph3d.SetInputData(polydata)
        glyph3d.Update()

        glyph_mapper = vtk.vtkPolyDataMapper()
        glyph_mapper.SetInputConnection(glyph3d.GetOutputPort())

        self.point_actor = vtk.vtkActor()
        self.point_actor.SetMapper(glyph_mapper)
        self.point_actor.GetProperty().SetColor(1, 0, 0)
        self.renderer.AddActor(self.point_actor)

        # --- Use vtkPointSetToLabelHierarchy and vtkLabelPlacementMapper for string labels ---
        label_hierarchy = vtk.vtkPointSetToLabelHierarchy()
        label_hierarchy.SetInputData(polydata)
        label_hierarchy.SetLabelArrayName("labels")
        label_hierarchy.GetTextProperty().SetColor(1, 1, 1)
        label_hierarchy.GetTextProperty().SetFontSize(16)
        label_hierarchy.GetTextProperty().BoldOn()
        label_hierarchy.GetTextProperty().ShadowOff()

        label_mapper = vtk.vtkLabelPlacementMapper()
        label_mapper.SetInputConnection(label_hierarchy.GetOutputPort())

        self.label_actor = vtk.vtkActor2D()
        self.label_actor.SetMapper(label_mapper)
        self.renderer.AddActor(self.label_actor)

    '''
    def visualize_points(self):
        if not self.points_csv:
            return
        points = self.load_points_from_csv()
        polydata = vtk.vtkPolyData()
        polydata.SetPoints(points)

        # Create a sphere source
        sphere_source = vtk.vtkSphereSource()
        sphere_source.SetRadius(2.5)  # Set the radius of the spheres (adjust as needed)
        sphere_source.Update()

        # Use vtkGlyph3D to create a glyph for each point
        glyph3d = vtk.vtkGlyph3D()
        glyph3d.SetSourceConnection(sphere_source.GetOutputPort())
        glyph3d.SetInputData(polydata)
        glyph3d.Update()

        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(glyph3d.GetOutputPort())
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(1, 0, 0)  # Red color for spheres
        self.renderer.AddActor(actor)
    '''


class VTKWidgetWithPoints(QWidget):
    def __init__(self, stl_files, colors, points_csv=None, gravity_direction=None, parent=None):
        super().__init__(parent)

        # Set up the layout
        layout = QVBoxLayout()
        self.setLayout(layout)

        # Create a VTK Visualizer instance
        self.visualizer = STLVisualizer(stl_files, colors, points_csv)

        # Create the VTK render window interactor widget
        self.vtk_widget = QVTKRenderWindowInteractor(self)
        layout.addWidget(self.vtk_widget)

        # Set up the renderer and the render window
        self.render_window = self.vtk_widget.GetRenderWindow()
        self.render_window.AddRenderer(self.visualizer.renderer)

        # Set the background color to white
        self.visualizer.renderer.SetBackground(0.239, 0.239, 0.239)  # RGB values for white

        # Set the custom interactor style
        interactor = self.render_window.GetInteractor()
        interactor.SetInteractorStyle(CustomInteractorStyle())

        # Load and visualize the STL files
        self.visualizer.load_stl()

        # Load and visualize the points if provided
        self.visualizer.visualize_points()

        # Add custom orientation indicator
        self.visualizer.add_custom_orientation_indicator()

        # Initialize and start the VTK interactor
        self.vtk_widget.Initialize()
        self.vtk_widget.Start()

    # Add a function to clear the renderer
    def clear_renderer(self):
        self.visualizer.clear_renderer()


# ---------------------------------------------------------------------------------------
# This part is for comparing 2 stl surface to calculate surface deviation
# ---------------------------------------------------------------------------------------
class STLCompareVisualizer:
    def __init__(self, stl1, stl2, interactor):
        self.stl1 = stl1
        self.stl2 = stl2
        self.renderer = vtk.vtkRenderer()
        self.interactor = interactor

    def clear_renderer(self):
        self.renderer.RemoveAllViewProps()

    def load_stl(self, stl_file):
        reader = vtk.vtkSTLReader()
        reader.SetFileName(stl_file)
        reader.Update()
        return reader.GetOutput()
    
    def visualize_normals_in_new_window(self, polydata):
        # Create a renderer
        normals_renderer = vtk.vtkRenderer()
        normals_renderer.SetBackground(0.2, 0.3, 0.4)  # Set a background color

        # Create a render window
        normals_render_window = vtk.vtkRenderWindow()
        normals_render_window.AddRenderer(normals_renderer)
        normals_render_window.SetSize(800, 600)  # Set window size

        # Create a render window interactor
        normals_interactor = vtk.vtkRenderWindowInteractor()
        normals_interactor.SetRenderWindow(normals_render_window)

        # Visualize the normals
        self.add_normals_to_renderer(polydata, normals_renderer)

        # Start the interaction
        normals_render_window.Render()
        normals_interactor.Initialize()
        normals_interactor.Start()

    def calculate_surface_deviation(self):
        import math

        stl1_polydata = self.load_stl(self.stl1)
        stl2_polydata = self.load_stl(self.stl2)

        # Ensure normals are computed and consistently oriented
        def ensure_normals(polydata):
            normal_generator = vtk.vtkPolyDataNormals()
            normal_generator.SetInputData(polydata)
            normal_generator.ComputePointNormalsOn()
            normal_generator.SetConsistency(True)
            normal_generator.AutoOrientNormalsOn()
            normal_generator.SplittingOff()  # Prevents sharp edge splitting
            normal_generator.FlipNormalsOff()
            normal_generator.Update()
            return normal_generator.GetOutput()

        stl1_polydata_with_normals = ensure_normals(stl1_polydata)
        stl2_polydata_with_normals = ensure_normals(stl2_polydata)

        # Build the OBBTree for stl1
        obb_tree = vtk.vtkOBBTree()
        obb_tree.SetDataSet(stl1_polydata_with_normals)
        obb_tree.BuildLocator()

        points = stl2_polydata_with_normals.GetPoints()
        normals2 = stl2_polydata_with_normals.GetPointData().GetNormals()

        colors = vtk.vtkUnsignedCharArray()
        colors.SetNumberOfComponents(3)
        colors.SetName("Colors")

        deviation_values = []

        # Prepare the deviation array
        deviation_array = vtk.vtkDoubleArray()
        deviation_array.SetName("Deviation")

        # Loop over points in stl2
        for i in range(points.GetNumberOfPoints()):
            point = points.GetPoint(i)
            normal = normals2.GetTuple(i)

            # Define the ray (line) along the normal
            p0 = point
            p1 = [point[j] + normal[j] * 5.0 for j in range(3)]  # Extend the line sufficiently

            # Perform intersection test
            intersection_points = vtk.vtkPoints()
            obb_tree.IntersectWithLine(p0, p1, intersection_points, None)

            # If no intersection, try the opposite direction
            if intersection_points.GetNumberOfPoints() == 0:
                p1 = [point[j] - normal[j] * 5.0 for j in range(3)]
                obb_tree.IntersectWithLine(p0, p1, intersection_points, None)

            if intersection_points.GetNumberOfPoints() > 0:
                # Take the closest intersection point
                closest_point = None
                min_distance = float('inf')
                for idx in range(intersection_points.GetNumberOfPoints()):
                    intersect_pt = intersection_points.GetPoint(idx)
                    distance = vtk.vtkMath.Distance2BetweenPoints(point, intersect_pt)
                    if distance < min_distance:
                        min_distance = distance
                        closest_point = intersect_pt

                # Compute the deviation (signed distance)
                distance = math.sqrt(min_distance)
                # Determine the sign based on the direction
                vector_to_intersect = [closest_point[j] - point[j] for j in range(3)]
                dot_product = vtk.vtkMath.Dot(normal, vector_to_intersect)
                deviation = distance if dot_product >= 0 else -distance

                deviation_values.append(-1*deviation)
                deviation_array.InsertNextValue(-1*deviation)
            else:
                # No intersection found, mark as invalid
                deviation_values.append(None)
                deviation_array.InsertNextValue(0.0)  # add grey color

        # Calculate max deviation from valid deviations
        valid_deviations = [abs(d) for d in deviation_values if d is not None]
        if not valid_deviations:
            print("No valid deviations found.")
            return
        max_deviation = max(valid_deviations)
        average_deviation = sum(valid_deviations) / len(valid_deviations)

        # Create the lookup table once, using the correct max_deviation
        lookup_table = self.create_lookup_table(max_deviation, average_deviation)

        # Assign colors based on deviations
        for deviation in deviation_values:
            if deviation is None:
                # Assign a distinct color for invalid or skipped points
                colors.InsertNextTuple([200, 200, 200])  # Neutral gray
            else:
                # Clamp deviation to the LUT range
                clamped_distance = max(min(deviation, max_deviation), -max_deviation)

                # Map distance to color
                color = [0, 0, 0]
                lookup_table.GetColor(clamped_distance, color)
                color = [int(c * 255) for c in color]
                colors.InsertNextTuple(color)

        stl2_polydata_with_normals.GetPointData().SetScalars(colors)
        stl2_polydata_with_normals.GetPointData().AddArray(deviation_array)

        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputData(stl2_polydata_with_normals)
        mapper.SetScalarModeToUsePointData()
        mapper.SetColorModeToDirectScalars()

        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        self.renderer.AddActor(actor)

        # Add a color bar
        color_bar = vtk.vtkScalarBarActor()
        color_bar.SetLookupTable(lookup_table)
        color_bar.SetTitle("Deviation (mm)")
        color_bar.SetNumberOfLabels(9)

        self.renderer.AddActor2D(color_bar)
        self.renderer.SetBackground(0.239, 0.239, 0.239)

    def create_lookup_table(self, max_deviation, average_deviation):
        """
        Creates a lookup table for mapping deviation values to colors.
        Args:
            max_deviation (float): The maximum absolute deviation value for the color mapping.
        Returns:
            vtk.vtkLookupTable: A configured lookup table for color mapping.
        """
        # Define the limits for display deviation
        max_display_deviation = average_deviation * 4.0  # Use the actual max_deviation
        max_display_deviation = max(max_display_deviation, 0.1)  # Ensure at least 0.1 mm
        max_display_deviation = min(max_display_deviation, 1.0)  # Ensure at most 1 mm

        # Create and configure the lookup table
        lookup_table = vtk.vtkLookupTable()
        lookup_table.SetNumberOfTableValues(256)  # Number of colors
        lookup_table.SetHueRange(0.666, 0.0)  # Blue to red
        lookup_table.SetTableRange(-max_display_deviation, max_display_deviation)  # Negative to positive deviation
        lookup_table.Build()

        return lookup_table
    
    def add_custom_orientation_indicator(self):
        # Calculate the minimum x, y, z values from the points in the STL files
        min_x, min_y, min_z = float('inf'), float('inf'), float('inf')
        for stl_file in [self.stl1]:
            reader = vtk.vtkSTLReader()
            reader.SetFileName(stl_file)
            reader.Update()
            polydata = reader.GetOutput()
            bounds = polydata.GetBounds()
            min_x = min(min_x, bounds[0])
            min_y = min(min_y, bounds[2])
            min_z = min(min_z, bounds[4])

        # Shift the origin of the axes
        origin_x = min_x - 10
        origin_y = min_y - 10
        origin_z = min_z - 10

        # Create an axes actor
        axes = vtk.vtkAxesActor()
        axes.SetTotalLength(80.0, 80.0, 80.0)
        axes.SetShaftTypeToCylinder()
        axes.SetXAxisLabelText("X")
        axes.SetYAxisLabelText("Y")
        axes.SetZAxisLabelText("Z")
        axes.GetXAxisShaftProperty().SetColor(1, 0, 0)  # Red
        axes.GetYAxisShaftProperty().SetColor(0, 1, 0)  # Green
        axes.GetZAxisShaftProperty().SetColor(0, 0, 1)  # Blue

        # Make the letter indicators smaller and set the color to black
        axes.GetXAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetYAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetZAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetXAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetYAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetZAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetXAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black
        axes.GetYAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black
        axes.GetZAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black

        # Use a transform to position the axes
        transform = vtk.vtkTransform()
        transform.Translate(origin_x, origin_y, origin_z)
        axes.SetUserTransform(transform)

        # Create a renderer for the orientation indicator
        orientation_renderer = vtk.vtkRenderer()
        orientation_renderer.SetViewport(0.0, 0.0, 1.0, 1.0)  # Bottom right corner
        orientation_renderer.SetLayer(1)
        orientation_renderer.InteractiveOff()
        orientation_renderer.AddActor(axes)

        # Link the orientation renderer's camera to the main renderer's camera
        orientation_renderer.SetActiveCamera(self.renderer.GetActiveCamera())

        # Add the orientation renderer to the render window
        self.renderer.GetRenderWindow().SetNumberOfLayers(2)
        self.renderer.GetRenderWindow().AddRenderer(orientation_renderer)


class VTKWidgetWithDeviation(QWidget):
    def __init__(self, stl1, stl2, parent=None):
        super().__init__(parent)

        layout = QVBoxLayout()
        self.setLayout(layout)

        self.vtk_widget = QVTKRenderWindowInteractor(self)
        layout.addWidget(self.vtk_widget)

        self.render_window = self.vtk_widget.GetRenderWindow()
        interactor = self.render_window.GetInteractor()
        interactor.SetInteractorStyle(CustomInteractorStyle())

        self.visualizer = STLCompareVisualizer(stl1, stl2, interactor)
        self.render_window.AddRenderer(self.visualizer.renderer)

        self.visualizer.calculate_surface_deviation()

        self.vtk_widget.Initialize()
        self.vtk_widget.Start()

        self.visualizer.add_custom_orientation_indicator()

    def clear_renderer(self):
        self.visualizer.clear_renderer()


# ---------------------------------------------------------------------------------------
# This part is for comparing 2 stl surface to calculate surface deviation for Morphing
# ---------------------------------------------------------------------------------------
class STLCompareVisualizer_Morphing:

    def __init__(self, stl1, stl2, interactor):
        self.stl1 = stl1
        self.stl2 = stl2
        self.renderer = vtk.vtkRenderer()
        self.interactor = interactor

    def clear_renderer(self):
        self.renderer.RemoveAllViewProps()

    def load_stl(self, stl_file):
        reader = vtk.vtkSTLReader()
        reader.SetFileName(stl_file)
        reader.Update()
        return reader.GetOutput()
    
    def decimate_mesh(self, polydata, reduction=0.5):
        decimate = vtk.vtkDecimatePro()
        decimate.SetInputData(polydata)
        decimate.SetTargetReduction(reduction)  # 0.5 = 50% reduction
        decimate.PreserveTopologyOn()           # Keep topology consistent
        decimate.Update()
        return decimate.GetOutput()

    def calculate_surface_deviation(self):
        stl1_polydata_raw = self.load_stl(self.stl1)
        stl2_polydata_raw = self.load_stl(self.stl2)

        stl1_polydata = self.decimate_mesh(stl1_polydata_raw, reduction=0.5)
        stl2_polydata = self.decimate_mesh(stl2_polydata_raw, reduction=0.5)

        distance_filter = vtk.vtkImplicitPolyDataDistance()
        distance_filter.SetInput(stl1_polydata)

        points = stl2_polydata.GetPoints()
        colors = vtk.vtkUnsignedCharArray()
        colors.SetNumberOfComponents(3)
        colors.SetName("Colors")

        max_deviation = 0
        for i in range(points.GetNumberOfPoints()):
            point = points.GetPoint(i)
            distance = distance_filter.EvaluateFunction(point)
            max_deviation = max(max_deviation, abs(distance))
        max_deviation = min(max_deviation, 0.5)  # Limit the maximum deviation to 1.0 mm
        max_deviation = max(max_deviation, 0.1)  # Limit the minimum deviation to 0.1 mm

        # Create lookup table for color mapping
        lookup_table = vtk.vtkLookupTable()
        lookup_table.SetNumberOfTableValues(256)
        lookup_table.SetHueRange(0.666, 0.0) # Blue to red color map
        lookup_table.SetTableRange(-max_deviation, max_deviation)
        lookup_table.Build()

        for i in range(points.GetNumberOfPoints()):
            point = points.GetPoint(i)
            distance = distance_filter.EvaluateFunction(point)

            # Map distance to color
            color = [0, 0, 0]
            lookup_table.GetColor(distance, color)
            color = [int(c * 255) for c in color]
            colors.InsertNextTuple(color)

        stl2_polydata.GetPointData().SetScalars(colors)

        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputData(stl2_polydata)
        mapper.SetScalarModeToUsePointData()
        mapper.SetColorModeToDirectScalars()

        actor = vtk.vtkLODActor()  # Level of Detail actor
        actor.SetMapper(mapper)
        self.renderer.AddActor(actor)

        # Add a color bar
        color_bar = vtk.vtkScalarBarActor()
        color_bar.SetLookupTable(lookup_table)
        color_bar.SetTitle("Deviation (mm)")
        color_bar.SetNumberOfLabels(9)

        # Set properties for the label text (digits)
        label_text_property = color_bar.GetLabelTextProperty()
        label_text_property.SetColor(1, 1, 1)  # Black color for labels
        label_text_property.SetFontSize(7)  # Smaller font size for digits
        label_text_property.SetBold(0)
        label_text_property.SetItalic(0)
        label_text_property.SetShadow(0)
        label_text_property.SetJustificationToCentered()
        color_bar.SetLabelTextProperty(label_text_property)

        # Set properties for the title text
        title_text_property = color_bar.GetTitleTextProperty()
        title_text_property.SetColor(1, 1, 1)  # Black color for title
        title_text_property.SetFontSize(14)  # Bigger font size for title
        title_text_property.SetBold(1)
        title_text_property.SetItalic(0)
        title_text_property.SetShadow(0)
        title_text_property.SetJustificationToCentered()
        color_bar.SetTitleTextProperty(title_text_property)

        color_bar.SetLabelFormat("%.2f")  # Two decimal places
        self.renderer.AddActor2D(color_bar)

        self.renderer.SetBackground(0.239, 0.239, 0.239) 
    
    def add_custom_orientation_indicator(self):
        # Calculate the minimum x, y, z values from the points in the STL files
        min_x, min_y, min_z = float('inf'), float('inf'), float('inf')
        for stl_file in [self.stl1]:
            reader = vtk.vtkSTLReader()
            reader.SetFileName(stl_file)
            reader.Update()
            polydata = reader.GetOutput()
            bounds = polydata.GetBounds()
            min_x = min(min_x, bounds[0])
            min_y = min(min_y, bounds[2])
            min_z = min(min_z, bounds[4])

        # Shift the origin of the axes
        origin_x = min_x - 10
        origin_y = min_y - 10
        origin_z = min_z - 10

        # Create an axes actor
        axes = vtk.vtkAxesActor()
        axes.SetTotalLength(80.0, 80.0, 80.0)
        axes.SetShaftTypeToCylinder()
        axes.SetXAxisLabelText("X")
        axes.SetYAxisLabelText("Y")
        axes.SetZAxisLabelText("Z")
        axes.GetXAxisShaftProperty().SetColor(1, 0, 0)  # Red
        axes.GetYAxisShaftProperty().SetColor(0, 1, 0)  # Green
        axes.GetZAxisShaftProperty().SetColor(0, 0, 1)  # Blue

        # Make the letter indicators smaller and set the color to black
        axes.GetXAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetYAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetZAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetXAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetYAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetZAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetXAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black
        axes.GetYAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black
        axes.GetZAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black

        # Use a transform to position the axes
        transform = vtk.vtkTransform()
        transform.Translate(origin_x, origin_y, origin_z)
        axes.SetUserTransform(transform)

        # Create a renderer for the orientation indicator
        orientation_renderer = vtk.vtkRenderer()
        orientation_renderer.SetViewport(0.0, 0.0, 1.0, 1.0)  # Bottom right corner
        orientation_renderer.SetLayer(1)
        orientation_renderer.InteractiveOff()
        orientation_renderer.AddActor(axes)

        # Link the orientation renderer's camera to the main renderer's camera
        orientation_renderer.SetActiveCamera(self.renderer.GetActiveCamera())

        # Add the orientation renderer to the render window
        self.renderer.GetRenderWindow().SetNumberOfLayers(2)
        self.renderer.GetRenderWindow().AddRenderer(orientation_renderer)


class VTKWidgetWithDeviation_Morphing(QWidget):
    def __init__(self, stl1, stl2, parent=None):
        super().__init__(parent)

        layout = QVBoxLayout()
        self.setLayout(layout)

        self.vtk_widget = QVTKRenderWindowInteractor(self)
        layout.addWidget(self.vtk_widget)

        self.render_window = self.vtk_widget.GetRenderWindow()
        interactor = self.render_window.GetInteractor()
        interactor.SetInteractorStyle(CustomInteractorStyle())

        self.visualizer = STLCompareVisualizer_Morphing(stl1, stl2, interactor)
        self.render_window.AddRenderer(self.visualizer.renderer)

        self.visualizer.calculate_surface_deviation()

        self.vtk_widget.Initialize()
        self.vtk_widget.Start()

        self.visualizer.add_custom_orientation_indicator()

    def clear_renderer(self):
        self.visualizer.clear_renderer()

import csv
import vtk
from PySide6.QtWidgets import QWidget, QVBoxLayout
from vtkmodules.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor

# Disable VTK warnings globally
vtk.vtkObject.GlobalWarningDisplayOff()

class CustomInteractorStyle(vtk.vtkInteractorStyleTrackballCamera):
    def __init__(self, parent=None):
        self.AddObserver("LeftButtonPressEvent", self.left_button_press_event)
        self.AddObserver("LeftButtonReleaseEvent", self.left_button_release_event)
        self.AddObserver("RightButtonPressEvent", self.right_button_press_event)
        self.AddObserver("RightButtonReleaseEvent", self.right_button_release_event)
        self.AddObserver("MouseWheelForwardEvent", self.mouse_wheel_forward_event)
        self.AddObserver("MouseWheelBackwardEvent", self.mouse_wheel_backward_event)
        self.AddObserver("MouseMoveEvent", self.mouse_move_event)
        self.left_button_down = False
        self.right_button_down = False

    def left_button_press_event(self, obj, event):
        self.left_button_down = True
        self.OnMiddleButtonDown()  # Treat left button press as middle button press for translation
        return

    def left_button_release_event(self, obj, event):
        self.left_button_down = False
        self.OnMiddleButtonUp()  # Treat left button release as middle button release
        return

    def right_button_press_event(self, obj, event):
        self.right_button_down = True
        self.OnLeftButtonDown()  # Treat right button press as left button press for rotation
        return

    def right_button_release_event(self, obj, event):
        self.right_button_down = False
        self.OnLeftButtonUp()  # Treat right button release as left button release
        return

    def mouse_move_event(self, obj, event):
        if self.left_button_down:
            self.OnMouseMove()  # Translate
        elif self.right_button_down:
            self.OnMouseMove()  # Rotate
        return

    def mouse_wheel_forward_event(self, obj, event):
        self.OnMouseWheelForward()  # Zoom in
        return

    def mouse_wheel_backward_event(self, obj, event):
        self.OnMouseWheelBackward()  # Zoom out
        return


class STLVisualizer:
    def __init__(self, geometry_stl, fixture_stl_files, interactor, point_limit_lower=3, point_limit_upper=4):
        self.geometry_stl = geometry_stl
        self.fixture_stl_files = fixture_stl_files
        self.renderer = vtk.vtkRenderer()
        self.selected_points = []
        self.sphere_actors = []
        self.interactor = interactor
        self.point_limit_lower = point_limit_lower
        self.point_limit_upper = point_limit_upper
        self.geometry_actor = None  # Store the geometry actor

    def clear_renderer(self):
        self.renderer.RemoveAllViewProps()

    def load_stl(self, stl_file, color, opacity=1.0, is_geometry=False):
        reader = vtk.vtkSTLReader()
        reader.SetFileName(stl_file)
        reader.Update()
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(reader.GetOutputPort())
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(color)
        actor.GetProperty().SetOpacity(opacity)
        self.renderer.AddActor(actor)
        if is_geometry:
            self.geometry_actor = actor  # Save the geometry actor

    def visualize_geometry(self):
        self.load_stl(self.geometry_stl, (0.6, 0.6, 0.6), 0.6, is_geometry=True)  # Transparent light grey color

    def visualize_fixtures(self):
        for fixture_stl in self.fixture_stl_files:
            self.load_stl(fixture_stl, (0.0, 1.0, 0.0), 0.5)  # Transparent green color

    def add_custom_orientation_indicator(self):
        # Calculate the minimum x, y, z values from the points in the STL files
        min_x, min_y, min_z = float('inf'), float('inf'), float('inf')
        for stl_file in [self.geometry_stl]:
            reader = vtk.vtkSTLReader()
            reader.SetFileName(stl_file)
            reader.Update()
            polydata = reader.GetOutput()
            bounds = polydata.GetBounds()
            min_x = min(min_x, bounds[0])
            min_y = min(min_y, bounds[2])
            min_z = min(min_z, bounds[4])

        # Shift the origin of the axes
        origin_x = min_x - 10
        origin_y = min_y - 10
        origin_z = min_z - 10

        # Create an axes actor
        axes = vtk.vtkAxesActor()
        axes.SetTotalLength(80.0, 80.0, 80.0)
        axes.SetShaftTypeToCylinder()
        axes.SetXAxisLabelText("X")
        axes.SetYAxisLabelText("Y")
        axes.SetZAxisLabelText("Z")
        axes.GetXAxisShaftProperty().SetColor(1, 0, 0)  # Red
        axes.GetYAxisShaftProperty().SetColor(0, 1, 0)  # Green
        axes.GetZAxisShaftProperty().SetColor(0, 0, 1)  # Blue

        # Make the letter indicators smaller and set the color to black
        axes.GetXAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetYAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetZAxisCaptionActor2D().GetTextActor().SetTextScaleModeToNone()
        axes.GetXAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetYAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetZAxisCaptionActor2D().GetCaptionTextProperty().SetFontSize(20)
        axes.GetXAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black
        axes.GetYAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black
        axes.GetZAxisCaptionActor2D().GetCaptionTextProperty().SetColor(0, 0, 0)  # Black

        # Use a transform to position the axes
        transform = vtk.vtkTransform()
        transform.Translate(origin_x, origin_y, origin_z)
        axes.SetUserTransform(transform)

        # Create a renderer for the orientation indicator
        orientation_renderer = vtk.vtkRenderer()
        orientation_renderer.SetViewport(0.0, 0.0, 1.0, 1.0)  # Bottom right corner
        orientation_renderer.SetLayer(1)
        orientation_renderer.InteractiveOff()
        orientation_renderer.AddActor(axes)

        # Link the orientation renderer's camera to the main renderer's camera
        orientation_renderer.SetActiveCamera(self.renderer.GetActiveCamera())

        # Add the orientation renderer to the render window
        self.renderer.GetRenderWindow().SetNumberOfLayers(2)
        self.renderer.GetRenderWindow().AddRenderer(orientation_renderer)

    def on_left_button_press(self, obj, event):
        if self.interactor.GetShiftKey():
            click_pos = self.interactor.GetEventPosition()
            picker = vtk.vtkCellPicker()
            picker.SetTolerance(0.0005)
            picker.Pick(click_pos[0], click_pos[1], 0, self.renderer)
            picked_position = picker.GetPickPosition()
            picked_actor = picker.GetActor()  # Get the picked actor
            if picker.GetCellId() != -1 and picked_actor == self.geometry_actor:
                # Only allow selection on geometry_stl
                if len(self.selected_points) < self.point_limit_upper:
                    self.selected_points.append(picked_position)
                    self.add_sphere_at_point(picked_position)
                else:
                    self.selected_points.pop(0)
                    self.selected_points.append(picked_position)
                    self.update_spheres()
                print(f"Selected point: {picked_position}")
                if len(self.selected_points) >= self.point_limit_lower and len(self.selected_points) <= self.point_limit_upper:
                    self.export_selected_points()

    def add_sphere_at_point(self, point):
        sphere_source = vtk.vtkSphereSource()
        sphere_source.SetCenter(point)
        sphere_source.SetRadius(3.0)  # Adjust the radius as needed
        sphere_source.Update()
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(sphere_source.GetOutputPort())
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(1, 0, 0)  # Red color for the sphere
        self.sphere_actors.append(actor)
        self.renderer.AddActor(actor)
        self.renderer.GetRenderWindow().Render()

    def update_spheres(self):
        for actor in self.sphere_actors:
            self.renderer.RemoveActor(actor)
        self.sphere_actors = []
        for point in self.selected_points:
            self.add_sphere_at_point(point)

    def export_selected_points(self):
        with open(self.output_csv_path, 'w', newline='') as file:
            writer = csv.writer(file)
            for no, point in enumerate(self.selected_points, start=1):
                writer.writerow([no] + list(point))
        print(f"Exported selected points to {self.output_csv_path}")

    def add_fixture_geometry(self, fixture_stls):
        self.fixture_stl_files = fixture_stls

class VTKWidgetWithGeometryAndFixtures(QWidget):
    def __init__(self, geometry_stl, fixture_stl_files, output_csv_path, parent=None):
        super().__init__(parent)
        self.output_csv_path = output_csv_path

        # Set up the layout
        layout = QVBoxLayout()
        self.setLayout(layout)

        # Create the VTK render window interactor widget
        self.vtk_widget = QVTKRenderWindowInteractor(self)
        layout.addWidget(self.vtk_widget)

        # Set up the renderer and the render window
        self.render_window = self.vtk_widget.GetRenderWindow()

        # Set the interactor style to trackball camera
        interactor = self.render_window.GetInteractor()
        interactor.SetInteractorStyle(CustomInteractorStyle())

        # Create a VTK Visualizer instance
        self.visualizer = STLVisualizer(geometry_stl, fixture_stl_files, interactor)
        self.visualizer.output_csv_path = output_csv_path

        self.render_window.AddRenderer(self.visualizer.renderer)

        # Set the background color to white
        self.visualizer.renderer.SetBackground(1.0, 1.0, 1.0)  # RGB values for white

        # Load and visualize the geometry and fixtures
        self.visualizer.visualize_geometry()

        # Initialize and start the VTK interactor
        self.vtk_widget.Initialize()
        self.vtk_widget.Start()

        # Add custom orientation indicator
        self.visualizer.add_custom_orientation_indicator()

        # Add event listener for left button press
        interactor.AddObserver("LeftButtonPressEvent", self.visualizer.on_left_button_press)

    # Add a function to clear the renderer
    def clear_renderer(self):
        self.visualizer.clear_renderer()





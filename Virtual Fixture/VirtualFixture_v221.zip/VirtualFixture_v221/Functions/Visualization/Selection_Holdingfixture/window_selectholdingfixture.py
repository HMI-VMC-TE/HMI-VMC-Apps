from PySide6.QtWidgets import QDialog
from PySide6.QtWidgets import QFileDialog
from UI.selectholdingfixture_ui import Ui_SelectFixtureWindow
from Functions.Visualization.Selection_Holdingfixture.selectholdingfixture_vtk import VTKWidgetWithGeometryAndFixtures


class SelectFixtureWindow_window(QDialog, Ui_SelectFixtureWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        # create a vtk widget for 3D visualization of selected holding fixture
        self.vtk_selectfixture = None

        # clear all render in the preview widgets
        if hasattr(self, 'vtk_selectfixture') and self.vtk_selectfixture is not None:
            self.vtk_selectfixture.visualizer.clear_renderer()
        
        # connect the buttons
        self.loadstl_pushButton_2.clicked.connect(self.load_fixture_stl)

    def load_cad_geometry(self, cad_file_path, output_csv_path):
        # Create a new VTK widget and load the STL file
        self.vtk_selectfixture = VTKWidgetWithGeometryAndFixtures(cad_file_path, [], output_csv_path)
        self.manualselect_widget_layout_2.addWidget(self.vtk_selectfixture)
    
    def load_fixture_stl(self):
        # open dialog to select the multiple stl files
        stl_files_paths, _ = QFileDialog.getOpenFileNames(self, "Select STL Files", "", "STL Files (*.stl);;All Files (*)")
        if not stl_files_paths:
            return

        # visualize the selected stl file in the same adding to self.vtk_selectfixture
        self.vtk_selectfixture.visualizer.add_fixture_geometry(stl_files_paths)
        self.vtk_selectfixture.visualizer.visualize_fixtures()
        




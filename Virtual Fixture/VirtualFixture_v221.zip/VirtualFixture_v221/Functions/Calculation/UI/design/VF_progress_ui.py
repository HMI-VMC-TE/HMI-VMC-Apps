# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'VF_progress.ui'
##
## Created by: Qt User Interface Compiler version 6.5.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
    QProgressBar, QPushButton, QSizePolicy, QSpacerItem,
    QTextEdit, QVBoxLayout, QWidget)

class Ui_Progress_window(object):
    def setupUi(self, Progress_window):
        if not Progress_window.objectName():
            Progress_window.setObjectName(u"Progress_window")
        Progress_window.resize(600, 410)
        Progress_window.setStyleSheet(u"background-color: #3d3d3d;")
        self.verticalLayout = QVBoxLayout(Progress_window)
        self.verticalLayout.setSpacing(5)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(5, 5, 5, 5)
        self.process_name_label = QLabel(Progress_window)
        self.process_name_label.setObjectName(u"process_name_label")
        self.process_name_label.setMinimumSize(QSize(0, 25))
        self.process_name_label.setMaximumSize(QSize(16777215, 25))
        self.process_name_label.setStyleSheet(u"font: 700 11pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")

        self.verticalLayout.addWidget(self.process_name_label)

        self.process_progressBar = QProgressBar(Progress_window)
        self.process_progressBar.setObjectName(u"process_progressBar")
        self.process_progressBar.setMinimumSize(QSize(0, 30))
        self.process_progressBar.setMaximumSize(QSize(16777215, 30))
        self.process_progressBar.setStyleSheet(u"QProgressBar {\n"
"    border: 2px solid #444;\n"
"    border-radius: 5px;\n"
"    background-color: #222;\n"
"    text-align: center;\n"
"    font: bold 10pt \"Segoe UI\";\n"
"    color: #ddd;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    background-color: #29a3ef; /* Bright blue progress color */\n"
"    border-radius: 5px;\n"
"}")
        self.process_progressBar.setValue(0)

        self.verticalLayout.addWidget(self.process_progressBar)

        self.label_2 = QLabel(Progress_window)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setMinimumSize(QSize(0, 25))
        self.label_2.setMaximumSize(QSize(16777215, 25))
        self.label_2.setStyleSheet(u"font: italic 10.5pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.label_2.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.verticalLayout.addWidget(self.label_2)

        self.textEdit = QTextEdit(Progress_window)
        self.textEdit.setObjectName(u"textEdit")
        self.textEdit.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"font: 10pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);")

        self.verticalLayout.addWidget(self.textEdit)

        self.horizontalWidget = QWidget(Progress_window)
        self.horizontalWidget.setObjectName(u"horizontalWidget")
        self.horizontalWidget.setMinimumSize(QSize(0, 35))
        self.horizontalWidget.setMaximumSize(QSize(16777215, 35))
        self.horizontalLayout = QHBoxLayout(self.horizontalWidget)
        self.horizontalLayout.setSpacing(4)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.opensw_pushButton = QPushButton(self.horizontalWidget)
        self.opensw_pushButton.setObjectName(u"opensw_pushButton")
        self.opensw_pushButton.setMinimumSize(QSize(180, 25))
        self.opensw_pushButton.setMaximumSize(QSize(180, 25))
        self.opensw_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: #D8DEE9;\n"
"    border: 2px solid#D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")

        self.horizontalLayout.addWidget(self.opensw_pushButton)

        self.close_pushButton = QPushButton(self.horizontalWidget)
        self.close_pushButton.setObjectName(u"close_pushButton")
        self.close_pushButton.setMinimumSize(QSize(100, 25))
        self.close_pushButton.setMaximumSize(QSize(100, 25))
        self.close_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: #D8DEE9;\n"
"    border: 2px solid#D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")

        self.horizontalLayout.addWidget(self.close_pushButton)


        self.verticalLayout.addWidget(self.horizontalWidget)


        self.retranslateUi(Progress_window)

        QMetaObject.connectSlotsByName(Progress_window)
    # setupUi

    def retranslateUi(self, Progress_window):
        Progress_window.setWindowTitle(QCoreApplication.translate("Progress_window", u"VF Controller", None))
        self.process_name_label.setText(QCoreApplication.translate("Progress_window", u"TextLabel", None))
        self.label_2.setText(QCoreApplication.translate("Progress_window", u"VF controller message", None))
        self.opensw_pushButton.setText(QCoreApplication.translate("Progress_window", u"Open Simufact Welding", None))
        self.close_pushButton.setText(QCoreApplication.translate("Progress_window", u"Close", None))
    # retranslateUi


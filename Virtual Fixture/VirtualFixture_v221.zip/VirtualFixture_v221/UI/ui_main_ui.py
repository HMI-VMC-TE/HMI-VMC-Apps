# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_uiArvWSZ.ui'
##
## Created by: Qt User Interface Compiler version 6.5.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QGridLayout,
    QHBoxLayout, QLabel, QLayout, QMainWindow,
    QPlainTextEdit, QProgressBar, QPushButton, QSizePolicy,
    QSpacerItem, QStackedWidget, QVBoxLayout, QWidget)
import UI.resources_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1220, 820)
        MainWindow.setStyleSheet(u"background-color: rgb(24, 24, 24);")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralwidget.setMinimumSize(QSize(1100, 800))
        self.gridLayout = QGridLayout(self.centralwidget)
        self.gridLayout.setSpacing(0)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.settingsinfo_widget = QWidget(self.centralwidget)
        self.settingsinfo_widget.setObjectName(u"settingsinfo_widget")
        self.settingsinfo_widget.setMinimumSize(QSize(200, 0))
        self.settingsinfo_widget.setMaximumSize(QSize(200, 16777215))
        self.settingsinfo_widget.setSizeIncrement(QSize(0, 0))
        self.settingsinfo_widget.setStyleSheet(u"QWidget{\n"
"background-color: rgb(35, 35, 35);\n"
"}")
        self.settingsinfo_widget_layout = QVBoxLayout(self.settingsinfo_widget)
        self.settingsinfo_widget_layout.setObjectName(u"settingsinfo_widget_layout")
        self.settingsinfo_widget_layout.setContentsMargins(5, -1, 0, -1)
        self.settingsinfo_stackwidget = QStackedWidget(self.settingsinfo_widget)
        self.settingsinfo_stackwidget.setObjectName(u"settingsinfo_stackwidget")
        self.settingsinfo_stackwidget.setStyleSheet(u"QPushButton{\n"
"color:white;\n"
"font: 700 11pt \"Segoe UI\";\n"
"text-align:left;\n"
"padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:checked{\n"
"	background-color: rgb(61, 61, 61);\n"
"}")
        self.settings_page = QWidget()
        self.settings_page.setObjectName(u"settings_page")
        self.verticalLayout_9 = QVBoxLayout(self.settings_page)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalLayout_9.setContentsMargins(6, -1, 6, -1)
        self.label_12 = QLabel(self.settings_page)
        self.label_12.setObjectName(u"label_12")
        self.label_12.setMinimumSize(QSize(0, 50))
        self.label_12.setMaximumSize(QSize(16777215, 50))
        font = QFont()
        font.setFamilies([u"Segoe UI"])
        font.setPointSize(14)
        font.setBold(True)
        font.setItalic(True)
        font.setUnderline(True)
        self.label_12.setFont(font)
        self.label_12.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"text-decoration: underline;\n"
"font: italic 700 14pt \"Segoe UI\";\n"
"padding-right:2px;")
        self.label_12.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.verticalLayout_9.addWidget(self.label_12)

        self.widget_3 = QWidget(self.settings_page)
        self.widget_3.setObjectName(u"widget_3")
        self.widget_3.setMinimumSize(QSize(0, 10))
        self.widget_3.setMaximumSize(QSize(16777215, 10))

        self.verticalLayout_9.addWidget(self.widget_3)

        self.newproject_pushButton = QPushButton(self.settings_page)
        self.newproject_pushButton.setObjectName(u"newproject_pushButton")
        self.newproject_pushButton.setMinimumSize(QSize(180, 60))
        self.newproject_pushButton.setMaximumSize(QSize(16777215, 60))
        self.newproject_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#5d5d5d;\n"
"    font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:clicked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        icon = QIcon()
        icon.addFile(u":/root/images/newproject.png", QSize(), QIcon.Normal, QIcon.Off)
        self.newproject_pushButton.setIcon(icon)
        self.newproject_pushButton.setIconSize(QSize(35, 35))
        self.newproject_pushButton.setCheckable(False)
        self.newproject_pushButton.setAutoExclusive(True)

        self.verticalLayout_9.addWidget(self.newproject_pushButton)

        self.saveproject_pushButton = QPushButton(self.settings_page)
        self.saveproject_pushButton.setObjectName(u"saveproject_pushButton")
        self.saveproject_pushButton.setMinimumSize(QSize(180, 60))
        self.saveproject_pushButton.setMaximumSize(QSize(16777215, 60))
        self.saveproject_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#5d5d5d;\n"
"    font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:clicked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        icon1 = QIcon()
        icon1.addFile(u":/root/images/save.png", QSize(), QIcon.Normal, QIcon.Off)
        self.saveproject_pushButton.setIcon(icon1)
        self.saveproject_pushButton.setIconSize(QSize(35, 35))
        self.saveproject_pushButton.setCheckable(False)
        self.saveproject_pushButton.setAutoExclusive(True)

        self.verticalLayout_9.addWidget(self.saveproject_pushButton)

        self.openproject_pushButton = QPushButton(self.settings_page)
        self.openproject_pushButton.setObjectName(u"openproject_pushButton")
        self.openproject_pushButton.setMinimumSize(QSize(180, 60))
        self.openproject_pushButton.setMaximumSize(QSize(16777215, 60))
        self.openproject_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#5d5d5d;\n"
"    font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:clicked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        icon2 = QIcon()
        icon2.addFile(u":/root/images/open.png", QSize(), QIcon.Normal, QIcon.Off)
        self.openproject_pushButton.setIcon(icon2)
        self.openproject_pushButton.setIconSize(QSize(35, 35))
        self.openproject_pushButton.setCheckable(False)
        self.openproject_pushButton.setAutoExclusive(True)

        self.verticalLayout_9.addWidget(self.openproject_pushButton)

        self.manageresults_pushButton = QPushButton(self.settings_page)
        self.manageresults_pushButton.setObjectName(u"manageresults_pushButton")
        self.manageresults_pushButton.setMinimumSize(QSize(180, 60))
        self.manageresults_pushButton.setMaximumSize(QSize(16777215, 60))
        self.manageresults_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#5d5d5d;\n"
"    font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:clicked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        icon3 = QIcon()
        icon3.addFile(u":/root/images/export.png", QSize(), QIcon.Normal, QIcon.Off)
        self.manageresults_pushButton.setIcon(icon3)
        self.manageresults_pushButton.setIconSize(QSize(35, 35))
        self.manageresults_pushButton.setCheckable(True)
        self.manageresults_pushButton.setAutoExclusive(False)

        self.verticalLayout_9.addWidget(self.manageresults_pushButton)

        self.verticalWidget = QWidget(self.settings_page)
        self.verticalWidget.setObjectName(u"verticalWidget")
        self.verticalWidget.setLayoutDirection(Qt.RightToLeft)
        self.verticalLayout_27 = QVBoxLayout(self.verticalWidget)
        self.verticalLayout_27.setSpacing(3)
        self.verticalLayout_27.setObjectName(u"verticalLayout_27")
        self.verticalLayout_27.setContentsMargins(0, 0, 0, 0)
        self.opensw_pushButton = QPushButton(self.verticalWidget)
        self.opensw_pushButton.setObjectName(u"opensw_pushButton")
        self.opensw_pushButton.setMinimumSize(QSize(150, 50))
        self.opensw_pushButton.setMaximumSize(QSize(150, 50))
        self.opensw_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: white;\n"
"    border: 1px solid#5d5d5d;\n"
"    font: 700 11pt \"Segoe UI\";\n"
"	text-align:right;\n"
"	padding-left:8px;\n"
"    border-radius: 4px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:clicked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        self.opensw_pushButton.setIconSize(QSize(35, 35))
        self.opensw_pushButton.setCheckable(False)
        self.opensw_pushButton.setAutoExclusive(True)

        self.verticalLayout_27.addWidget(self.opensw_pushButton)

        self.openfolder_pushButton = QPushButton(self.verticalWidget)
        self.openfolder_pushButton.setObjectName(u"openfolder_pushButton")
        self.openfolder_pushButton.setMinimumSize(QSize(150, 50))
        self.openfolder_pushButton.setMaximumSize(QSize(150, 50))
        self.openfolder_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: white;\n"
"    border: 1px solid#5d5d5d;\n"
"    font: 700 11pt \"Segoe UI\";\n"
"	text-align:right;\n"
"	padding-left:8px;\n"
"    border-radius: 4px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:clicked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        self.openfolder_pushButton.setIconSize(QSize(35, 35))
        self.openfolder_pushButton.setCheckable(False)
        self.openfolder_pushButton.setAutoExclusive(True)

        self.verticalLayout_27.addWidget(self.openfolder_pushButton)

        self.exportpolywork_pushButton = QPushButton(self.verticalWidget)
        self.exportpolywork_pushButton.setObjectName(u"exportpolywork_pushButton")
        self.exportpolywork_pushButton.setMinimumSize(QSize(150, 50))
        self.exportpolywork_pushButton.setMaximumSize(QSize(150, 50))
        self.exportpolywork_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: white;\n"
"    border: 1px solid#5d5d5d;\n"
"    font: 700 11pt \"Segoe UI\";\n"
"	text-align:right;\n"
"	padding-left:8px;\n"
"    border-radius: 4px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:clicked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        self.exportpolywork_pushButton.setIconSize(QSize(35, 35))
        self.exportpolywork_pushButton.setCheckable(False)
        self.exportpolywork_pushButton.setAutoExclusive(True)

        self.verticalLayout_27.addWidget(self.exportpolywork_pushButton)


        self.verticalLayout_9.addWidget(self.verticalWidget)

        self.verticalSpacer_3 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_9.addItem(self.verticalSpacer_3)

        self.updatematerial_pushButton = QPushButton(self.settings_page)
        self.updatematerial_pushButton.setObjectName(u"updatematerial_pushButton")
        self.updatematerial_pushButton.setMinimumSize(QSize(180, 60))
        self.updatematerial_pushButton.setMaximumSize(QSize(16777215, 60))
        self.updatematerial_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#5d5d5d;\n"
"    font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:clicked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")
        icon4 = QIcon()
        icon4.addFile(u":/root/images/update.png", QSize(), QIcon.Normal, QIcon.Off)
        self.updatematerial_pushButton.setIcon(icon4)
        self.updatematerial_pushButton.setIconSize(QSize(35, 35))
        self.updatematerial_pushButton.setCheckable(False)
        self.updatematerial_pushButton.setAutoExclusive(True)

        self.verticalLayout_9.addWidget(self.updatematerial_pushButton)

        self.pathsettings_pushButton = QPushButton(self.settings_page)
        self.pathsettings_pushButton.setObjectName(u"pathsettings_pushButton")
        self.pathsettings_pushButton.setMinimumSize(QSize(180, 60))
        self.pathsettings_pushButton.setMaximumSize(QSize(16777215, 60))
        self.pathsettings_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#5d5d5d;\n"
"    font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:clicked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")
        icon5 = QIcon()
        icon5.addFile(u":/root/images/pathsettings.png", QSize(), QIcon.Normal, QIcon.Off)
        self.pathsettings_pushButton.setIcon(icon5)
        self.pathsettings_pushButton.setIconSize(QSize(35, 35))
        self.pathsettings_pushButton.setCheckable(False)
        self.pathsettings_pushButton.setAutoExclusive(True)

        self.verticalLayout_9.addWidget(self.pathsettings_pushButton)

        self.settingsinfo_stackwidget.addWidget(self.settings_page)
        self.info_page = QWidget()
        self.info_page.setObjectName(u"info_page")
        self.verticalLayout_28 = QVBoxLayout(self.info_page)
        self.verticalLayout_28.setObjectName(u"verticalLayout_28")
        self.verticalLayout_28.setContentsMargins(6, -1, 6, -1)
        self.label_14 = QLabel(self.info_page)
        self.label_14.setObjectName(u"label_14")
        self.label_14.setMinimumSize(QSize(0, 50))
        self.label_14.setMaximumSize(QSize(16777215, 50))
        self.label_14.setFont(font)
        self.label_14.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"text-decoration: underline;\n"
"font: italic 700 14pt \"Segoe UI\";\n"
"padding-right:2px;")
        self.label_14.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.verticalLayout_28.addWidget(self.label_14)

        self.label_8 = QLabel(self.info_page)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setPixmap(QPixmap(u":/root/images/workflow.png"))
        self.label_8.setScaledContents(True)

        self.verticalLayout_28.addWidget(self.label_8)

        self.verticalSpacer_4 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_28.addItem(self.verticalSpacer_4)

        self.help_pushButton = QPushButton(self.info_page)
        self.help_pushButton.setObjectName(u"help_pushButton")
        self.help_pushButton.setMinimumSize(QSize(180, 60))
        self.help_pushButton.setMaximumSize(QSize(16777215, 60))
        self.help_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#5d5d5d;\n"
"    font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:clicked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")
        icon6 = QIcon()
        icon6.addFile(u":/root/images/info.png", QSize(), QIcon.Normal, QIcon.Off)
        self.help_pushButton.setIcon(icon6)
        self.help_pushButton.setIconSize(QSize(35, 35))
        self.help_pushButton.setCheckable(False)
        self.help_pushButton.setAutoExclusive(True)

        self.verticalLayout_28.addWidget(self.help_pushButton)

        self.settingsinfo_stackwidget.addWidget(self.info_page)

        self.settingsinfo_widget_layout.addWidget(self.settingsinfo_stackwidget)


        self.gridLayout.addWidget(self.settingsinfo_widget, 0, 2, 1, 1)

        self.icon_widget = QWidget(self.centralwidget)
        self.icon_widget.setObjectName(u"icon_widget")
        self.icon_widget.setMinimumSize(QSize(0, 0))
        self.icon_widget.setMaximumSize(QSize(16777215, 16777215))
        self.icon_widget.setStyleSheet(u"QWidget{\n"
"	background-color: rgb(33, 33, 33);\n"
"}\n"
"")
        self.verticalLayout_3 = QVBoxLayout(self.icon_widget)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(-1, -1, 0, -1)
        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setSpacing(10)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(-1, 5, -1, 5)
        self.label = QLabel(self.icon_widget)
        self.label.setObjectName(u"label")
        self.label.setMinimumSize(QSize(55, 55))
        self.label.setMaximumSize(QSize(55, 55))
        self.label.setSizeIncrement(QSize(50, 50))
        self.label.setPixmap(QPixmap(u":/root/images/logo.png"))
        self.label.setScaledContents(True)

        self.horizontalLayout_3.addWidget(self.label)


        self.verticalLayout_3.addLayout(self.horizontalLayout_3)

        self.widget = QWidget(self.icon_widget)
        self.widget.setObjectName(u"widget")
        self.widget.setMinimumSize(QSize(0, 10))
        self.widget.setMaximumSize(QSize(16777215, 10))

        self.verticalLayout_3.addWidget(self.widget)

        self.dataicon_layout = QVBoxLayout()
        self.dataicon_layout.setSpacing(1)
        self.dataicon_layout.setObjectName(u"dataicon_layout")
        self.label_5 = QLabel(self.icon_widget)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setStyleSheet(u"QLabel {\n"
"color: rgb(255, 255, 255);\n"
"font: 700 9pt \"Segoe UI\";\n"
"}")

        self.dataicon_layout.addWidget(self.label_5)

        self.importgeometryicon_pushButton = QPushButton(self.icon_widget)
        self.importgeometryicon_pushButton.setObjectName(u"importgeometryicon_pushButton")
        self.importgeometryicon_pushButton.setMinimumSize(QSize(0, 55))
        self.importgeometryicon_pushButton.setMaximumSize(QSize(1677777, 55))
        self.importgeometryicon_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#D8DEE9;\n"
"    border-radius: 4px;\n"
"   font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        icon7 = QIcon()
        icon7.addFile(u":/root/images/geometry.png", QSize(), QIcon.Normal, QIcon.Off)
        self.importgeometryicon_pushButton.setIcon(icon7)
        self.importgeometryicon_pushButton.setIconSize(QSize(35, 35))
        self.importgeometryicon_pushButton.setCheckable(True)
        self.importgeometryicon_pushButton.setAutoExclusive(True)

        self.dataicon_layout.addWidget(self.importgeometryicon_pushButton)

        self.importmeasurementicon_pushButton = QPushButton(self.icon_widget)
        self.importmeasurementicon_pushButton.setObjectName(u"importmeasurementicon_pushButton")
        self.importmeasurementicon_pushButton.setMinimumSize(QSize(0, 55))
        self.importmeasurementicon_pushButton.setMaximumSize(QSize(1677777, 55))
        self.importmeasurementicon_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#D8DEE9;\n"
"    border-radius: 4px;\n"
"   font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        icon8 = QIcon()
        icon8.addFile(u":/root/images/measurement.png", QSize(), QIcon.Normal, QIcon.Off)
        self.importmeasurementicon_pushButton.setIcon(icon8)
        self.importmeasurementicon_pushButton.setIconSize(QSize(35, 35))
        self.importmeasurementicon_pushButton.setCheckable(True)
        self.importmeasurementicon_pushButton.setAutoExclusive(True)

        self.dataicon_layout.addWidget(self.importmeasurementicon_pushButton)

        self.importfixtureicon_pushButton = QPushButton(self.icon_widget)
        self.importfixtureicon_pushButton.setObjectName(u"importfixtureicon_pushButton")
        self.importfixtureicon_pushButton.setMinimumSize(QSize(0, 55))
        self.importfixtureicon_pushButton.setMaximumSize(QSize(1677777, 55))
        self.importfixtureicon_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#D8DEE9;\n"
"    border-radius: 4px;\n"
"   font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        icon9 = QIcon()
        icon9.addFile(u":/root/images/holdingfixture.png", QSize(), QIcon.Normal, QIcon.Off)
        self.importfixtureicon_pushButton.setIcon(icon9)
        self.importfixtureicon_pushButton.setIconSize(QSize(35, 35))
        self.importfixtureicon_pushButton.setCheckable(True)
        self.importfixtureicon_pushButton.setAutoExclusive(True)

        self.dataicon_layout.addWidget(self.importfixtureicon_pushButton)

        self.importrpsicon_pushButton = QPushButton(self.icon_widget)
        self.importrpsicon_pushButton.setObjectName(u"importrpsicon_pushButton")
        self.importrpsicon_pushButton.setMinimumSize(QSize(0, 55))
        self.importrpsicon_pushButton.setMaximumSize(QSize(1677777, 55))
        self.importrpsicon_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#D8DEE9;\n"
"    border-radius: 4px;\n"
"   font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        icon10 = QIcon()
        icon10.addFile(u":/root/images/importRPS.png", QSize(), QIcon.Normal, QIcon.Off)
        self.importrpsicon_pushButton.setIcon(icon10)
        self.importrpsicon_pushButton.setIconSize(QSize(35, 35))
        self.importrpsicon_pushButton.setCheckable(True)
        self.importrpsicon_pushButton.setAutoExclusive(True)

        self.dataicon_layout.addWidget(self.importrpsicon_pushButton)


        self.verticalLayout_3.addLayout(self.dataicon_layout)

        self.widget_10 = QWidget(self.icon_widget)
        self.widget_10.setObjectName(u"widget_10")
        self.widget_10.setMinimumSize(QSize(0, 10))
        self.widget_10.setMaximumSize(QSize(16777215, 10))

        self.verticalLayout_3.addWidget(self.widget_10)

        self.processicon_layout = QVBoxLayout()
        self.processicon_layout.setSpacing(1)
        self.processicon_layout.setObjectName(u"processicon_layout")
        self.label_17 = QLabel(self.icon_widget)
        self.label_17.setObjectName(u"label_17")
        self.label_17.setStyleSheet(u"QLabel {\n"
"color: rgb(255, 255, 255);\n"
"font: 700 9pt \"Segoe UI\";\n"
"}")

        self.processicon_layout.addWidget(self.label_17)

        self.morphicon_pushButton = QPushButton(self.icon_widget)
        self.morphicon_pushButton.setObjectName(u"morphicon_pushButton")
        self.morphicon_pushButton.setMinimumSize(QSize(0, 55))
        self.morphicon_pushButton.setMaximumSize(QSize(1677777, 55))
        self.morphicon_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#D8DEE9;\n"
"    border-radius: 4px;\n"
"   font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        icon11 = QIcon()
        icon11.addFile(u":/root/images/morphing.png", QSize(), QIcon.Normal, QIcon.Off)
        self.morphicon_pushButton.setIcon(icon11)
        self.morphicon_pushButton.setIconSize(QSize(35, 35))
        self.morphicon_pushButton.setCheckable(True)
        self.morphicon_pushButton.setAutoExclusive(True)

        self.processicon_layout.addWidget(self.morphicon_pushButton)

        self.gcicon_pushButton = QPushButton(self.icon_widget)
        self.gcicon_pushButton.setObjectName(u"gcicon_pushButton")
        self.gcicon_pushButton.setMinimumSize(QSize(0, 55))
        self.gcicon_pushButton.setMaximumSize(QSize(1677777, 55))
        self.gcicon_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#D8DEE9;\n"
"    border-radius: 4px;\n"
"   font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        icon12 = QIcon()
        icon12.addFile(u":/root/images/gravitycompensation.png", QSize(), QIcon.Normal, QIcon.Off)
        self.gcicon_pushButton.setIcon(icon12)
        self.gcicon_pushButton.setIconSize(QSize(35, 35))
        self.gcicon_pushButton.setCheckable(True)
        self.gcicon_pushButton.setAutoExclusive(True)

        self.processicon_layout.addWidget(self.gcicon_pushButton)

        self.rpsicon_pushButton = QPushButton(self.icon_widget)
        self.rpsicon_pushButton.setObjectName(u"rpsicon_pushButton")
        self.rpsicon_pushButton.setMinimumSize(QSize(0, 55))
        self.rpsicon_pushButton.setMaximumSize(QSize(1677777, 55))
        self.rpsicon_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#D8DEE9;\n"
"    border-radius: 4px;\n"
"   font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        icon13 = QIcon()
        icon13.addFile(u":/root/images/RPS.png", QSize(), QIcon.Normal, QIcon.Off)
        self.rpsicon_pushButton.setIcon(icon13)
        self.rpsicon_pushButton.setIconSize(QSize(35, 35))
        self.rpsicon_pushButton.setCheckable(True)
        self.rpsicon_pushButton.setAutoExclusive(True)

        self.processicon_layout.addWidget(self.rpsicon_pushButton)


        self.verticalLayout_3.addLayout(self.processicon_layout)

        self.verticalSpacer = QSpacerItem(20, 219, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_3.addItem(self.verticalSpacer)

        self.settingicon_pushButton = QPushButton(self.icon_widget)
        self.settingicon_pushButton.setObjectName(u"settingicon_pushButton")
        self.settingicon_pushButton.setMinimumSize(QSize(0, 50))
        self.settingicon_pushButton.setMaximumSize(QSize(16777215, 50))
        self.settingicon_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#5d5d5d;\n"
"    font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:clicked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        icon14 = QIcon()
        icon14.addFile(u":/root/images/settings.png", QSize(), QIcon.Normal, QIcon.Off)
        self.settingicon_pushButton.setIcon(icon14)
        self.settingicon_pushButton.setIconSize(QSize(35, 35))
        self.settingicon_pushButton.setCheckable(True)
        self.settingicon_pushButton.setAutoExclusive(False)

        self.verticalLayout_3.addWidget(self.settingicon_pushButton)

        self.infoicon_pushButton = QPushButton(self.icon_widget)
        self.infoicon_pushButton.setObjectName(u"infoicon_pushButton")
        self.infoicon_pushButton.setMinimumSize(QSize(0, 50))
        self.infoicon_pushButton.setMaximumSize(QSize(16777215, 50))
        self.infoicon_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#5d5d5d;\n"
"    font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:clicked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        self.infoicon_pushButton.setIcon(icon6)
        self.infoicon_pushButton.setIconSize(QSize(35, 35))
        self.infoicon_pushButton.setCheckable(True)
        self.infoicon_pushButton.setAutoExclusive(False)

        self.verticalLayout_3.addWidget(self.infoicon_pushButton)


        self.gridLayout.addWidget(self.icon_widget, 0, 0, 1, 1)

        self.main_pages = QWidget(self.centralwidget)
        self.main_pages.setObjectName(u"main_pages")
        self.verticalLayout_5 = QVBoxLayout(self.main_pages)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, -1)
        self.header_widget = QWidget(self.main_pages)
        self.header_widget.setObjectName(u"header_widget")
        self.header_widget.setStyleSheet(u"QWidget{\n"
"	background-color: rgb(33, 33, 33);\n"
"}\n"
"\n"
"QPushButton{\n"
"color:white;\n"
"font: 700 10pt \"Segoe UI\";\n"
"text-align:left;\n"
"padding-left:5px;\n"
"}\n"
"\n"
"QPushButton:checked{\n"
"	background-color: rgb(61, 61, 61);\n"
"}")
        self.horizontalLayout_4 = QHBoxLayout(self.header_widget)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(6, 9, 6, 6)
        self.menu_pushButton = QPushButton(self.header_widget)
        self.menu_pushButton.setObjectName(u"menu_pushButton")
        self.menu_pushButton.setMinimumSize(QSize(50, 50))
        self.menu_pushButton.setMaximumSize(QSize(50, 50))
        self.menu_pushButton.setStyleSheet(u"QPushButton{\n"
"border:none;\n"
"}\n"
"\n"
"QPushButton:checked{\n"
"	background-color: rgb(33, 33, 33);\n"
"}")
        icon15 = QIcon()
        icon15.addFile(u":/root/images/dashboard.png", QSize(), QIcon.Normal, QIcon.Off)
        self.menu_pushButton.setIcon(icon15)
        self.menu_pushButton.setIconSize(QSize(38, 38))
        self.menu_pushButton.setCheckable(True)
        self.menu_pushButton.setAutoExclusive(False)

        self.horizontalLayout_4.addWidget(self.menu_pushButton)

        self.label_4 = QLabel(self.header_widget)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setMinimumSize(QSize(0, 35))
        self.label_4.setMaximumSize(QSize(16777215, 35))
        self.label_4.setStyleSheet(u"QWidget{\n"
"	background-color: rgb(170, 170, 170);\n"
"	background: rgba(255, 255, 255, 70);\n"
"	border-color: rgb(0, 0, 0);\n"
"	border-top-left-radius:10px;\n"
"    border-bottom-left-radius:10px;\n"
"	font: italic 11pt \"Segoe UI\";\n"
"	padding-left:10px;\n"
"}")

        self.horizontalLayout_4.addWidget(self.label_4)

        self.label_68 = QLabel(self.header_widget)
        self.label_68.setObjectName(u"label_68")
        self.label_68.setMinimumSize(QSize(90, 34))
        self.label_68.setMaximumSize(QSize(90, 35))
        self.label_68.setLayoutDirection(Qt.RightToLeft)
        self.label_68.setStyleSheet(u"QWidget{\n"
"	background-color: rgb(170, 170, 170);\n"
"	background: rgba(255, 255, 255, 70);\n"
"	border-color: rgb(0, 0, 0);\n"
"	border-top-right-radius:10px;\n"
"    border-bottom-right-radius:10px;\n"
"	font: italic 11pt \"Segoe UI\";\n"
"	padding-left:10px;\n"
"}")
        self.label_68.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.horizontalLayout_4.addWidget(self.label_68)

        self.label_11 = QLabel(self.header_widget)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setMinimumSize(QSize(40, 40))
        self.label_11.setMaximumSize(QSize(40, 40))
        self.label_11.setPixmap(QPixmap(u":/root/images/hexagon.png"))
        self.label_11.setScaledContents(True)

        self.horizontalLayout_4.addWidget(self.label_11)

        self.parameters_pushButton = QPushButton(self.header_widget)
        self.parameters_pushButton.setObjectName(u"parameters_pushButton")
        self.parameters_pushButton.setMinimumSize(QSize(50, 50))
        self.parameters_pushButton.setMaximumSize(QSize(50, 50))
        self.parameters_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border-radius: 4px;\n"
"   font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")
        icon16 = QIcon()
        icon16.addFile(u":/root/images/parameters.png", QSize(), QIcon.Normal, QIcon.Off)
        self.parameters_pushButton.setIcon(icon16)
        self.parameters_pushButton.setIconSize(QSize(35, 35))
        self.parameters_pushButton.setCheckable(True)

        self.horizontalLayout_4.addWidget(self.parameters_pushButton)


        self.verticalLayout_5.addWidget(self.header_widget)

        self.pages_stackedWidget = QStackedWidget(self.main_pages)
        self.pages_stackedWidget.setObjectName(u"pages_stackedWidget")
        self.importgeometry_page = QWidget()
        self.importgeometry_page.setObjectName(u"importgeometry_page")
        self.importgeometry_page.setStyleSheet(u"")
        self.verticalLayout = QVBoxLayout(self.importgeometry_page)
        self.verticalLayout.setSpacing(5)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(5, 5, 5, 5)
        self.label_6 = QLabel(self.importgeometry_page)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setMinimumSize(QSize(0, 30))
        self.label_6.setMaximumSize(QSize(16777215, 30))
        font1 = QFont()
        font1.setFamilies([u"Segoe UI"])
        font1.setPointSize(18)
        font1.setBold(True)
        font1.setItalic(False)
        self.label_6.setFont(font1)
        self.label_6.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Segoe UI\";")

        self.verticalLayout.addWidget(self.label_6)

        self.widget_4 = QWidget(self.importgeometry_page)
        self.widget_4.setObjectName(u"widget_4")
        self.widget_4.setMinimumSize(QSize(0, 120))
        self.widget_4.setMaximumSize(QSize(16777215, 120))
        self.widget_4.setSizeIncrement(QSize(0, 30))
        self.verticalLayout_7 = QVBoxLayout(self.widget_4)
        self.verticalLayout_7.setSpacing(0)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setSpacing(10)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.geometryfile_plainTextEdit = QPlainTextEdit(self.widget_4)
        self.geometryfile_plainTextEdit.setObjectName(u"geometryfile_plainTextEdit")
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.geometryfile_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.geometryfile_plainTextEdit.setSizePolicy(sizePolicy)
        self.geometryfile_plainTextEdit.setMinimumSize(QSize(500, 29))
        self.geometryfile_plainTextEdit.setMaximumSize(QSize(16777215, 29))
        self.geometryfile_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"}\n"
"")

        self.horizontalLayout_2.addWidget(self.geometryfile_plainTextEdit)

        self.geometryfile_pushButton = QPushButton(self.widget_4)
        self.geometryfile_pushButton.setObjectName(u"geometryfile_pushButton")
        self.geometryfile_pushButton.setMinimumSize(QSize(120, 30))
        self.geometryfile_pushButton.setMaximumSize(QSize(120, 30))
        self.geometryfile_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: #D8DEE9;\n"
"    border: 2px solid#D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")
        icon17 = QIcon()
        icon17.addFile(u":/root/images/import.png", QSize(), QIcon.Normal, QIcon.Off)
        self.geometryfile_pushButton.setIcon(icon17)
        self.geometryfile_pushButton.setIconSize(QSize(24, 24))
        self.geometryfile_pushButton.setCheckable(True)
        self.geometryfile_pushButton.setAutoExclusive(True)

        self.horizontalLayout_2.addWidget(self.geometryfile_pushButton)


        self.verticalLayout_7.addLayout(self.horizontalLayout_2)

        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setSpacing(10)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.meshsize_label_3 = QLabel(self.widget_4)
        self.meshsize_label_3.setObjectName(u"meshsize_label_3")
        sizePolicy1 = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.meshsize_label_3.sizePolicy().hasHeightForWidth())
        self.meshsize_label_3.setSizePolicy(sizePolicy1)
        self.meshsize_label_3.setMinimumSize(QSize(0, 30))
        self.meshsize_label_3.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_3.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 10pt \"Segoe UI\";")

        self.horizontalLayout_5.addWidget(self.meshsize_label_3)

        self.materialtype_comboBox = QComboBox(self.widget_4)
        self.materialtype_comboBox.addItem("")
        self.materialtype_comboBox.addItem("")
        self.materialtype_comboBox.addItem("")
        self.materialtype_comboBox.setObjectName(u"materialtype_comboBox")
        self.materialtype_comboBox.setMinimumSize(QSize(150, 28))
        self.materialtype_comboBox.setMaximumSize(QSize(150, 28))
        self.materialtype_comboBox.setStyleSheet(u"/* QComboBox */\n"
"QComboBox {\n"
"    background-color: #3d3d3d; /* Dark background */\n"
"    color: #abb2bf; /* Modern text color */\n"
"    border: 2px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 4px; /* Rounded corners */\n"
"    padding: 4px; /* Padding for dropdown */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Match font style */\n"
"    font-size: 11pt; /* Match font size */\n"
"}\n"
"\n"
"QComboBox:hover {\n"
"    border: 1px solid #61afef; /* Light blue border on hover */\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    border: none; /* No border for drop-down button */\n"
"    background: none; /* Transparent background */\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"    image: url(\"down-arrow.png\"); /* Replace with your down arrow icon path */\n"
"    width: 12px;\n"
"    height: 12px;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView {\n"
"    background-color: #21252b; /* Dropdown menu background */\n"
"    color: #abb2bf; /* Text color in dropdown"
                        " */\n"
"    border: 1px solid #3c4049; /* Dropdown border */\n"
"    border-radius: 4px; /* Rounded dropdown */\n"
"    selection-background-color: #3e4451; /* Highlight background */\n"
"    selection-color: #ffffff; /* Highlighted text */\n"
"}")

        self.horizontalLayout_5.addWidget(self.materialtype_comboBox)

        self.horizontalSpacer_7 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_5.addItem(self.horizontalSpacer_7)


        self.verticalLayout_7.addLayout(self.horizontalLayout_5)

        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setSpacing(10)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.meshsize_label_4 = QLabel(self.widget_4)
        self.meshsize_label_4.setObjectName(u"meshsize_label_4")
        sizePolicy1.setHeightForWidth(self.meshsize_label_4.sizePolicy().hasHeightForWidth())
        self.meshsize_label_4.setSizePolicy(sizePolicy1)
        self.meshsize_label_4.setMinimumSize(QSize(0, 30))
        self.meshsize_label_4.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_4.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 10pt \"Segoe UI\";")

        self.horizontalLayout_6.addWidget(self.meshsize_label_4)

        self.material_comboBox = QComboBox(self.widget_4)
        self.material_comboBox.setObjectName(u"material_comboBox")
        self.material_comboBox.setMinimumSize(QSize(180, 28))
        self.material_comboBox.setMaximumSize(QSize(180, 28))
        self.material_comboBox.setStyleSheet(u"/* QComboBox */\n"
"QComboBox {\n"
"    background-color: #3d3d3d; /* Dark background */\n"
"    color: #abb2bf; /* Modern text color */\n"
"    border: 2px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 4px; /* Rounded corners */\n"
"    padding: 4px; /* Padding for dropdown */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Match font style */\n"
"    font-size: 11pt; /* Match font size */\n"
"}\n"
"\n"
"QComboBox:hover {\n"
"    border: 1px solid #61afef; /* Light blue border on hover */\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    border: none; /* No border for drop-down button */\n"
"    background: none; /* Transparent background */\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"    image: url(\"down-arrow.png\"); /* Replace with your down arrow icon path */\n"
"    width: 12px;\n"
"    height: 12px;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView {\n"
"    background-color: #21252b; /* Dropdown menu background */\n"
"    color: #abb2bf; /* Text color in dropdown"
                        " */\n"
"    border: 1px solid #3c4049; /* Dropdown border */\n"
"    border-radius: 4px; /* Rounded dropdown */\n"
"    selection-background-color: #3e4451; /* Highlight background */\n"
"    selection-color: #ffffff; /* Highlighted text */\n"
"}")

        self.horizontalLayout_6.addWidget(self.material_comboBox)

        self.horizontalSpacer_3 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_6.addItem(self.horizontalSpacer_3)

        self.advancedmaterial_pushButton = QPushButton(self.widget_4)
        self.advancedmaterial_pushButton.setObjectName(u"advancedmaterial_pushButton")
        sizePolicy1.setHeightForWidth(self.advancedmaterial_pushButton.sizePolicy().hasHeightForWidth())
        self.advancedmaterial_pushButton.setSizePolicy(sizePolicy1)
        self.advancedmaterial_pushButton.setMinimumSize(QSize(75, 0))
        self.advancedmaterial_pushButton.setMaximumSize(QSize(75, 16777215))
        self.advancedmaterial_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: #D8DEE9;\n"
"    border: 1px solid #D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: 12px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")

        self.horizontalLayout_6.addWidget(self.advancedmaterial_pushButton)

        self.advancedmeshing_pushButton = QPushButton(self.widget_4)
        self.advancedmeshing_pushButton.setObjectName(u"advancedmeshing_pushButton")
        sizePolicy1.setHeightForWidth(self.advancedmeshing_pushButton.sizePolicy().hasHeightForWidth())
        self.advancedmeshing_pushButton.setSizePolicy(sizePolicy1)
        self.advancedmeshing_pushButton.setMinimumSize(QSize(75, 0))
        self.advancedmeshing_pushButton.setMaximumSize(QSize(75, 16777215))
        self.advancedmeshing_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: #D8DEE9;\n"
"    border: 1px solid #D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: 12px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")

        self.horizontalLayout_6.addWidget(self.advancedmeshing_pushButton)


        self.verticalLayout_7.addLayout(self.horizontalLayout_6)


        self.verticalLayout.addWidget(self.widget_4)

        self.geovisual_widget = QWidget(self.importgeometry_page)
        self.geovisual_widget.setObjectName(u"geovisual_widget")
        self.geovisual_widget.setStyleSheet(u"background-color: #3d3d3d;\n"
"border-radius: 5px;")
        self.verticalLayout_11 = QVBoxLayout(self.geovisual_widget)
        self.verticalLayout_11.setSpacing(0)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalLayout_11.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.verticalLayout_11.setContentsMargins(-1, 1, -1, 1)
        self.horizontalWidget_5 = QWidget(self.geovisual_widget)
        self.horizontalWidget_5.setObjectName(u"horizontalWidget_5")
        sizePolicy2 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.horizontalWidget_5.sizePolicy().hasHeightForWidth())
        self.horizontalWidget_5.setSizePolicy(sizePolicy2)
        self.horizontalWidget_5.setMinimumSize(QSize(0, 40))
        self.horizontalWidget_5.setMaximumSize(QSize(16777215, 40))
        self.horizontalLayout_9 = QHBoxLayout(self.horizontalWidget_5)
        self.horizontalLayout_9.setSpacing(0)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.horizontalLayout_9.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.horizontalLayout_9.setContentsMargins(0, 0, 5, 0)
        self.meshsize_label_5 = QLabel(self.horizontalWidget_5)
        self.meshsize_label_5.setObjectName(u"meshsize_label_5")
        sizePolicy1.setHeightForWidth(self.meshsize_label_5.sizePolicy().hasHeightForWidth())
        self.meshsize_label_5.setSizePolicy(sizePolicy1)
        self.meshsize_label_5.setMinimumSize(QSize(0, 30))
        self.meshsize_label_5.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_5.setStyleSheet(u"    color: #D8DEE9;\n"
"    font: bold 14px \"Segoe UI\";\n"
"    border: 2px solid #D8DEE9;\n"
"    border-radius: 4px;")

        self.horizontalLayout_9.addWidget(self.meshsize_label_5)

        self.horizontalSpacer_4 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_9.addItem(self.horizontalSpacer_4)

        self.meshsize_label_6 = QLabel(self.horizontalWidget_5)
        self.meshsize_label_6.setObjectName(u"meshsize_label_6")
        sizePolicy1.setHeightForWidth(self.meshsize_label_6.sizePolicy().hasHeightForWidth())
        self.meshsize_label_6.setSizePolicy(sizePolicy1)
        self.meshsize_label_6.setMinimumSize(QSize(0, 30))
        self.meshsize_label_6.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_6.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: bold 14px \"Segoe UI\";")

        self.horizontalLayout_9.addWidget(self.meshsize_label_6)


        self.verticalLayout_11.addWidget(self.horizontalWidget_5)

        self.importgeometryvisual_widget = QWidget(self.geovisual_widget)
        self.importgeometryvisual_widget.setObjectName(u"importgeometryvisual_widget")
        self.importgeometryvisual_widget_layout = QVBoxLayout(self.importgeometryvisual_widget)
        self.importgeometryvisual_widget_layout.setSpacing(0)
        self.importgeometryvisual_widget_layout.setObjectName(u"importgeometryvisual_widget_layout")
        self.importgeometryvisual_widget_layout.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout_11.addWidget(self.importgeometryvisual_widget)


        self.verticalLayout.addWidget(self.geovisual_widget)

        self.pages_stackedWidget.addWidget(self.importgeometry_page)
        self.importmeasurement_page = QWidget()
        self.importmeasurement_page.setObjectName(u"importmeasurement_page")
        self.verticalLayout_2 = QVBoxLayout(self.importmeasurement_page)
        self.verticalLayout_2.setSpacing(5)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(5, 5, 5, 5)
        self.label_15 = QLabel(self.importmeasurement_page)
        self.label_15.setObjectName(u"label_15")
        self.label_15.setMinimumSize(QSize(0, 30))
        self.label_15.setMaximumSize(QSize(16777215, 30))
        self.label_15.setFont(font1)
        self.label_15.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Segoe UI\";")

        self.verticalLayout_2.addWidget(self.label_15)

        self.widget_5 = QWidget(self.importmeasurement_page)
        self.widget_5.setObjectName(u"widget_5")
        self.widget_5.setMinimumSize(QSize(0, 80))
        self.widget_5.setMaximumSize(QSize(16777215, 80))
        self.widget_5.setSizeIncrement(QSize(0, 30))
        self.verticalLayout_10 = QVBoxLayout(self.widget_5)
        self.verticalLayout_10.setSpacing(0)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.verticalLayout_10.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_14 = QHBoxLayout()
        self.horizontalLayout_14.setSpacing(10)
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.measurementfile_plainTextEdit = QPlainTextEdit(self.widget_5)
        self.measurementfile_plainTextEdit.setObjectName(u"measurementfile_plainTextEdit")
        sizePolicy.setHeightForWidth(self.measurementfile_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.measurementfile_plainTextEdit.setSizePolicy(sizePolicy)
        self.measurementfile_plainTextEdit.setMinimumSize(QSize(500, 29))
        self.measurementfile_plainTextEdit.setMaximumSize(QSize(16777215, 29))
        self.measurementfile_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"}\n"
"")

        self.horizontalLayout_14.addWidget(self.measurementfile_plainTextEdit)

        self.measurementfile_pushButton = QPushButton(self.widget_5)
        self.measurementfile_pushButton.setObjectName(u"measurementfile_pushButton")
        self.measurementfile_pushButton.setMinimumSize(QSize(120, 30))
        self.measurementfile_pushButton.setMaximumSize(QSize(120, 30))
        self.measurementfile_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: #D8DEE9;\n"
"    border: 2px solid#D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")
        self.measurementfile_pushButton.setIcon(icon17)
        self.measurementfile_pushButton.setIconSize(QSize(24, 24))
        self.measurementfile_pushButton.setCheckable(True)
        self.measurementfile_pushButton.setAutoExclusive(True)

        self.horizontalLayout_14.addWidget(self.measurementfile_pushButton)


        self.verticalLayout_10.addLayout(self.horizontalLayout_14)

        self.horizontalLayout_15 = QHBoxLayout()
        self.horizontalLayout_15.setSpacing(10)
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.horizontalSpacer_13 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_15.addItem(self.horizontalSpacer_13)


        self.verticalLayout_10.addLayout(self.horizontalLayout_15)


        self.verticalLayout_2.addWidget(self.widget_5)

        self.measurementvisual_widget = QWidget(self.importmeasurement_page)
        self.measurementvisual_widget.setObjectName(u"measurementvisual_widget")
        self.measurementvisual_widget.setStyleSheet(u"background-color: #3d3d3d;\n"
"border-radius: 5px;")
        self.verticalLayout_14 = QVBoxLayout(self.measurementvisual_widget)
        self.verticalLayout_14.setSpacing(0)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.verticalLayout_14.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.verticalLayout_14.setContentsMargins(-1, 1, -1, 1)
        self.horizontalWidget_8 = QWidget(self.measurementvisual_widget)
        self.horizontalWidget_8.setObjectName(u"horizontalWidget_8")
        sizePolicy2.setHeightForWidth(self.horizontalWidget_8.sizePolicy().hasHeightForWidth())
        self.horizontalWidget_8.setSizePolicy(sizePolicy2)
        self.horizontalWidget_8.setMinimumSize(QSize(0, 40))
        self.horizontalWidget_8.setMaximumSize(QSize(16777215, 40))
        self.horizontalLayout_17 = QHBoxLayout(self.horizontalWidget_8)
        self.horizontalLayout_17.setSpacing(0)
        self.horizontalLayout_17.setObjectName(u"horizontalLayout_17")
        self.horizontalLayout_17.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.horizontalLayout_17.setContentsMargins(0, 0, 5, 0)
        self.meshsize_label_15 = QLabel(self.horizontalWidget_8)
        self.meshsize_label_15.setObjectName(u"meshsize_label_15")
        sizePolicy1.setHeightForWidth(self.meshsize_label_15.sizePolicy().hasHeightForWidth())
        self.meshsize_label_15.setSizePolicy(sizePolicy1)
        self.meshsize_label_15.setMinimumSize(QSize(0, 30))
        self.meshsize_label_15.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_15.setStyleSheet(u"    color: #D8DEE9;\n"
"    font: bold 14px \"Segoe UI\";\n"
"    border: 2px solid #D8DEE9;\n"
"    border-radius: 4px;")

        self.horizontalLayout_17.addWidget(self.meshsize_label_15)

        self.horizontalSpacer_15 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_17.addItem(self.horizontalSpacer_15)

        self.meshsize_label_17 = QLabel(self.horizontalWidget_8)
        self.meshsize_label_17.setObjectName(u"meshsize_label_17")
        sizePolicy1.setHeightForWidth(self.meshsize_label_17.sizePolicy().hasHeightForWidth())
        self.meshsize_label_17.setSizePolicy(sizePolicy1)
        self.meshsize_label_17.setMinimumSize(QSize(0, 30))
        self.meshsize_label_17.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_17.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: bold 14px \"Segoe UI\";")

        self.horizontalLayout_17.addWidget(self.meshsize_label_17)

        self.meshsize_label_16 = QLabel(self.horizontalWidget_8)
        self.meshsize_label_16.setObjectName(u"meshsize_label_16")
        sizePolicy1.setHeightForWidth(self.meshsize_label_16.sizePolicy().hasHeightForWidth())
        self.meshsize_label_16.setSizePolicy(sizePolicy1)
        self.meshsize_label_16.setMinimumSize(QSize(0, 30))
        self.meshsize_label_16.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_16.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"font: bold 14px \"Segoe UI\";")

        self.horizontalLayout_17.addWidget(self.meshsize_label_16)


        self.verticalLayout_14.addWidget(self.horizontalWidget_8)

        self.importmeasurementvisual_widget = QWidget(self.measurementvisual_widget)
        self.importmeasurementvisual_widget.setObjectName(u"importmeasurementvisual_widget")
        self.importmeasurementvisual_widget_layout = QVBoxLayout(self.importmeasurementvisual_widget)
        self.importmeasurementvisual_widget_layout.setSpacing(0)
        self.importmeasurementvisual_widget_layout.setObjectName(u"importmeasurementvisual_widget_layout")
        self.importmeasurementvisual_widget_layout.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout_14.addWidget(self.importmeasurementvisual_widget)


        self.verticalLayout_2.addWidget(self.measurementvisual_widget)

        self.pages_stackedWidget.addWidget(self.importmeasurement_page)
        self.importfixture_page = QWidget()
        self.importfixture_page.setObjectName(u"importfixture_page")
        self.verticalLayout_17 = QVBoxLayout(self.importfixture_page)
        self.verticalLayout_17.setSpacing(5)
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.verticalLayout_17.setContentsMargins(5, 5, 5, 5)
        self.label_9 = QLabel(self.importfixture_page)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setMinimumSize(QSize(0, 30))
        self.label_9.setMaximumSize(QSize(16777215, 30))
        self.label_9.setFont(font1)
        self.label_9.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Segoe UI\";")

        self.verticalLayout_17.addWidget(self.label_9)

        self.widget_6 = QWidget(self.importfixture_page)
        self.widget_6.setObjectName(u"widget_6")
        self.widget_6.setMinimumSize(QSize(0, 120))
        self.widget_6.setMaximumSize(QSize(16777215, 120))
        self.widget_6.setSizeIncrement(QSize(0, 30))
        self.verticalLayout_15 = QVBoxLayout(self.widget_6)
        self.verticalLayout_15.setSpacing(0)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.verticalLayout_15.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_16 = QHBoxLayout()
        self.horizontalLayout_16.setSpacing(10)
        self.horizontalLayout_16.setObjectName(u"horizontalLayout_16")
        self.holdingfixturefile_plainTextEdit = QPlainTextEdit(self.widget_6)
        self.holdingfixturefile_plainTextEdit.setObjectName(u"holdingfixturefile_plainTextEdit")
        sizePolicy.setHeightForWidth(self.holdingfixturefile_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.holdingfixturefile_plainTextEdit.setSizePolicy(sizePolicy)
        self.holdingfixturefile_plainTextEdit.setMinimumSize(QSize(500, 29))
        self.holdingfixturefile_plainTextEdit.setMaximumSize(QSize(16777215, 29))
        self.holdingfixturefile_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"}\n"
"")

        self.horizontalLayout_16.addWidget(self.holdingfixturefile_plainTextEdit)

        self.holdingfixturefile_pushButton = QPushButton(self.widget_6)
        self.holdingfixturefile_pushButton.setObjectName(u"holdingfixturefile_pushButton")
        self.holdingfixturefile_pushButton.setMinimumSize(QSize(120, 30))
        self.holdingfixturefile_pushButton.setMaximumSize(QSize(120, 30))
        self.holdingfixturefile_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: #D8DEE9;\n"
"    border: 2px solid#D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")
        self.holdingfixturefile_pushButton.setIcon(icon17)
        self.holdingfixturefile_pushButton.setIconSize(QSize(24, 24))
        self.holdingfixturefile_pushButton.setCheckable(True)
        self.holdingfixturefile_pushButton.setAutoExclusive(True)

        self.horizontalLayout_16.addWidget(self.holdingfixturefile_pushButton)


        self.verticalLayout_15.addLayout(self.horizontalLayout_16)

        self.horizontalLayout_18 = QHBoxLayout()
        self.horizontalLayout_18.setSpacing(10)
        self.horizontalLayout_18.setObjectName(u"horizontalLayout_18")
        self.meshsize_label_13 = QLabel(self.widget_6)
        self.meshsize_label_13.setObjectName(u"meshsize_label_13")
        sizePolicy1.setHeightForWidth(self.meshsize_label_13.sizePolicy().hasHeightForWidth())
        self.meshsize_label_13.setSizePolicy(sizePolicy1)
        self.meshsize_label_13.setMinimumSize(QSize(0, 35))
        self.meshsize_label_13.setMaximumSize(QSize(16777215, 35))
        self.meshsize_label_13.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 10pt \"Segoe UI\";")

        self.horizontalLayout_18.addWidget(self.meshsize_label_13)

        self.horizontalSpacer_14 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_18.addItem(self.horizontalSpacer_14)


        self.verticalLayout_15.addLayout(self.horizontalLayout_18)

        self.horizontalLayout_19 = QHBoxLayout()
        self.horizontalLayout_19.setSpacing(10)
        self.horizontalLayout_19.setObjectName(u"horizontalLayout_19")
        self.horizontalSpacer_16 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_19.addItem(self.horizontalSpacer_16)

        self.selectholdingfixture_pushButton = QPushButton(self.widget_6)
        self.selectholdingfixture_pushButton.setObjectName(u"selectholdingfixture_pushButton")
        sizePolicy1.setHeightForWidth(self.selectholdingfixture_pushButton.sizePolicy().hasHeightForWidth())
        self.selectholdingfixture_pushButton.setSizePolicy(sizePolicy1)
        self.selectholdingfixture_pushButton.setMinimumSize(QSize(130, 28))
        self.selectholdingfixture_pushButton.setMaximumSize(QSize(75, 28))
        self.selectholdingfixture_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")

        self.horizontalLayout_19.addWidget(self.selectholdingfixture_pushButton)


        self.verticalLayout_15.addLayout(self.horizontalLayout_19)


        self.verticalLayout_17.addWidget(self.widget_6)

        self.holdingfixturevisual_widget = QWidget(self.importfixture_page)
        self.holdingfixturevisual_widget.setObjectName(u"holdingfixturevisual_widget")
        self.holdingfixturevisual_widget.setStyleSheet(u"background-color: #3d3d3d;\n"
"border-radius: 5px;")
        self.verticalLayout_16 = QVBoxLayout(self.holdingfixturevisual_widget)
        self.verticalLayout_16.setSpacing(0)
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.verticalLayout_16.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.verticalLayout_16.setContentsMargins(-1, 1, -1, 1)
        self.horizontalWidget_9 = QWidget(self.holdingfixturevisual_widget)
        self.horizontalWidget_9.setObjectName(u"horizontalWidget_9")
        sizePolicy2.setHeightForWidth(self.horizontalWidget_9.sizePolicy().hasHeightForWidth())
        self.horizontalWidget_9.setSizePolicy(sizePolicy2)
        self.horizontalWidget_9.setMinimumSize(QSize(0, 40))
        self.horizontalWidget_9.setMaximumSize(QSize(16777215, 40))
        self.horizontalLayout_20 = QHBoxLayout(self.horizontalWidget_9)
        self.horizontalLayout_20.setSpacing(0)
        self.horizontalLayout_20.setObjectName(u"horizontalLayout_20")
        self.horizontalLayout_20.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.horizontalLayout_20.setContentsMargins(0, 0, 5, 0)
        self.meshsize_label_18 = QLabel(self.horizontalWidget_9)
        self.meshsize_label_18.setObjectName(u"meshsize_label_18")
        sizePolicy1.setHeightForWidth(self.meshsize_label_18.sizePolicy().hasHeightForWidth())
        self.meshsize_label_18.setSizePolicy(sizePolicy1)
        self.meshsize_label_18.setMinimumSize(QSize(0, 30))
        self.meshsize_label_18.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_18.setStyleSheet(u"    color: #D8DEE9;\n"
"    font: bold 14px \"Segoe UI\";\n"
"    border: 2px solid #D8DEE9;\n"
"    border-radius: 4px;")

        self.horizontalLayout_20.addWidget(self.meshsize_label_18)

        self.horizontalSpacer_17 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_20.addItem(self.horizontalSpacer_17)

        self.meshsize_label_19 = QLabel(self.horizontalWidget_9)
        self.meshsize_label_19.setObjectName(u"meshsize_label_19")
        sizePolicy1.setHeightForWidth(self.meshsize_label_19.sizePolicy().hasHeightForWidth())
        self.meshsize_label_19.setSizePolicy(sizePolicy1)
        self.meshsize_label_19.setMinimumSize(QSize(0, 30))
        self.meshsize_label_19.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_19.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: bold 14px \"Segoe UI\";")

        self.horizontalLayout_20.addWidget(self.meshsize_label_19)

        self.meshsize_label_20 = QLabel(self.horizontalWidget_9)
        self.meshsize_label_20.setObjectName(u"meshsize_label_20")
        sizePolicy1.setHeightForWidth(self.meshsize_label_20.sizePolicy().hasHeightForWidth())
        self.meshsize_label_20.setSizePolicy(sizePolicy1)
        self.meshsize_label_20.setMinimumSize(QSize(0, 30))
        self.meshsize_label_20.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_20.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"font: bold 14px \"Segoe UI\";")

        self.horizontalLayout_20.addWidget(self.meshsize_label_20)


        self.verticalLayout_16.addWidget(self.horizontalWidget_9)

        self.importholdingfixturevisual_widget = QWidget(self.holdingfixturevisual_widget)
        self.importholdingfixturevisual_widget.setObjectName(u"importholdingfixturevisual_widget")
        self.importholdingfixturevisual_widget_layout = QVBoxLayout(self.importholdingfixturevisual_widget)
        self.importholdingfixturevisual_widget_layout.setSpacing(0)
        self.importholdingfixturevisual_widget_layout.setObjectName(u"importholdingfixturevisual_widget_layout")
        self.importholdingfixturevisual_widget_layout.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout_16.addWidget(self.importholdingfixturevisual_widget)


        self.verticalLayout_17.addWidget(self.holdingfixturevisual_widget)

        self.pages_stackedWidget.addWidget(self.importfixture_page)
        self.importrps_page = QWidget()
        self.importrps_page.setObjectName(u"importrps_page")
        self.verticalLayout_8 = QVBoxLayout(self.importrps_page)
        self.verticalLayout_8.setSpacing(5)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalLayout_8.setContentsMargins(5, 5, 5, 5)
        self.label_16 = QLabel(self.importrps_page)
        self.label_16.setObjectName(u"label_16")
        self.label_16.setMinimumSize(QSize(0, 30))
        self.label_16.setMaximumSize(QSize(16777215, 30))
        self.label_16.setFont(font1)
        self.label_16.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Segoe UI\";")

        self.verticalLayout_8.addWidget(self.label_16)

        self.widget_7 = QWidget(self.importrps_page)
        self.widget_7.setObjectName(u"widget_7")
        self.widget_7.setMinimumSize(QSize(0, 120))
        self.widget_7.setMaximumSize(QSize(16777215, 120))
        self.widget_7.setSizeIncrement(QSize(0, 30))
        self.verticalLayout_19 = QVBoxLayout(self.widget_7)
        self.verticalLayout_19.setSpacing(0)
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.verticalLayout_19.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_22 = QHBoxLayout()
        self.horizontalLayout_22.setSpacing(10)
        self.horizontalLayout_22.setObjectName(u"horizontalLayout_22")
        self.rpsfile_plainTextEdit = QPlainTextEdit(self.widget_7)
        self.rpsfile_plainTextEdit.setObjectName(u"rpsfile_plainTextEdit")
        sizePolicy.setHeightForWidth(self.rpsfile_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.rpsfile_plainTextEdit.setSizePolicy(sizePolicy)
        self.rpsfile_plainTextEdit.setMinimumSize(QSize(500, 29))
        self.rpsfile_plainTextEdit.setMaximumSize(QSize(16777215, 29))
        self.rpsfile_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"}\n"
"")

        self.horizontalLayout_22.addWidget(self.rpsfile_plainTextEdit)

        self.rpsfile_pushButton = QPushButton(self.widget_7)
        self.rpsfile_pushButton.setObjectName(u"rpsfile_pushButton")
        self.rpsfile_pushButton.setMinimumSize(QSize(120, 30))
        self.rpsfile_pushButton.setMaximumSize(QSize(120, 30))
        self.rpsfile_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: #D8DEE9;\n"
"    border: 2px solid#D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")
        self.rpsfile_pushButton.setIcon(icon17)
        self.rpsfile_pushButton.setIconSize(QSize(24, 24))
        self.rpsfile_pushButton.setCheckable(True)
        self.rpsfile_pushButton.setAutoExclusive(True)

        self.horizontalLayout_22.addWidget(self.rpsfile_pushButton)


        self.verticalLayout_19.addLayout(self.horizontalLayout_22)

        self.horizontalLayout_23 = QHBoxLayout()
        self.horizontalLayout_23.setSpacing(10)
        self.horizontalLayout_23.setObjectName(u"horizontalLayout_23")
        self.meshsize_label_14 = QLabel(self.widget_7)
        self.meshsize_label_14.setObjectName(u"meshsize_label_14")
        sizePolicy1.setHeightForWidth(self.meshsize_label_14.sizePolicy().hasHeightForWidth())
        self.meshsize_label_14.setSizePolicy(sizePolicy1)
        self.meshsize_label_14.setMinimumSize(QSize(0, 35))
        self.meshsize_label_14.setMaximumSize(QSize(16777215, 35))
        self.meshsize_label_14.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 10pt \"Segoe UI\";")

        self.horizontalLayout_23.addWidget(self.meshsize_label_14)

        self.horizontalSpacer_19 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_23.addItem(self.horizontalSpacer_19)


        self.verticalLayout_19.addLayout(self.horizontalLayout_23)

        self.horizontalLayout_24 = QHBoxLayout()
        self.horizontalLayout_24.setSpacing(10)
        self.horizontalLayout_24.setObjectName(u"horizontalLayout_24")
        self.horizontalSpacer_20 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_24.addItem(self.horizontalSpacer_20)

        self.selectrps_pushButton = QPushButton(self.widget_7)
        self.selectrps_pushButton.setObjectName(u"selectrps_pushButton")
        sizePolicy1.setHeightForWidth(self.selectrps_pushButton.sizePolicy().hasHeightForWidth())
        self.selectrps_pushButton.setSizePolicy(sizePolicy1)
        self.selectrps_pushButton.setMinimumSize(QSize(130, 28))
        self.selectrps_pushButton.setMaximumSize(QSize(75, 28))
        self.selectrps_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")

        self.horizontalLayout_24.addWidget(self.selectrps_pushButton)


        self.verticalLayout_19.addLayout(self.horizontalLayout_24)


        self.verticalLayout_8.addWidget(self.widget_7)

        self.rpsvisual_widget = QWidget(self.importrps_page)
        self.rpsvisual_widget.setObjectName(u"rpsvisual_widget")
        self.rpsvisual_widget.setStyleSheet(u"background-color: #3d3d3d;\n"
"border-radius: 5px;")
        self.verticalLayout_18 = QVBoxLayout(self.rpsvisual_widget)
        self.verticalLayout_18.setSpacing(0)
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.verticalLayout_18.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.verticalLayout_18.setContentsMargins(-1, 1, -1, 1)
        self.horizontalWidget_10 = QWidget(self.rpsvisual_widget)
        self.horizontalWidget_10.setObjectName(u"horizontalWidget_10")
        sizePolicy2.setHeightForWidth(self.horizontalWidget_10.sizePolicy().hasHeightForWidth())
        self.horizontalWidget_10.setSizePolicy(sizePolicy2)
        self.horizontalWidget_10.setMinimumSize(QSize(0, 40))
        self.horizontalWidget_10.setMaximumSize(QSize(16777215, 40))
        self.horizontalLayout_21 = QHBoxLayout(self.horizontalWidget_10)
        self.horizontalLayout_21.setSpacing(0)
        self.horizontalLayout_21.setObjectName(u"horizontalLayout_21")
        self.horizontalLayout_21.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.horizontalLayout_21.setContentsMargins(0, 0, 5, 0)
        self.meshsize_label_21 = QLabel(self.horizontalWidget_10)
        self.meshsize_label_21.setObjectName(u"meshsize_label_21")
        sizePolicy1.setHeightForWidth(self.meshsize_label_21.sizePolicy().hasHeightForWidth())
        self.meshsize_label_21.setSizePolicy(sizePolicy1)
        self.meshsize_label_21.setMinimumSize(QSize(0, 30))
        self.meshsize_label_21.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_21.setStyleSheet(u"    color: #D8DEE9;\n"
"    font: bold 14px \"Segoe UI\";\n"
"    border: 2px solid #D8DEE9;\n"
"    border-radius: 4px;")

        self.horizontalLayout_21.addWidget(self.meshsize_label_21)

        self.horizontalSpacer_18 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_21.addItem(self.horizontalSpacer_18)

        self.meshsize_label_22 = QLabel(self.horizontalWidget_10)
        self.meshsize_label_22.setObjectName(u"meshsize_label_22")
        sizePolicy1.setHeightForWidth(self.meshsize_label_22.sizePolicy().hasHeightForWidth())
        self.meshsize_label_22.setSizePolicy(sizePolicy1)
        self.meshsize_label_22.setMinimumSize(QSize(0, 30))
        self.meshsize_label_22.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_22.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: bold 14px \"Segoe UI\";")

        self.horizontalLayout_21.addWidget(self.meshsize_label_22)

        self.meshsize_label_23 = QLabel(self.horizontalWidget_10)
        self.meshsize_label_23.setObjectName(u"meshsize_label_23")
        sizePolicy1.setHeightForWidth(self.meshsize_label_23.sizePolicy().hasHeightForWidth())
        self.meshsize_label_23.setSizePolicy(sizePolicy1)
        self.meshsize_label_23.setMinimumSize(QSize(0, 30))
        self.meshsize_label_23.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_23.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"font: bold 14px \"Segoe UI\";")

        self.horizontalLayout_21.addWidget(self.meshsize_label_23)


        self.verticalLayout_18.addWidget(self.horizontalWidget_10)

        self.importrpsvisual_widget = QWidget(self.rpsvisual_widget)
        self.importrpsvisual_widget.setObjectName(u"importrpsvisual_widget")
        self.importrpsvisual_widget_layout = QVBoxLayout(self.importrpsvisual_widget)
        self.importrpsvisual_widget_layout.setSpacing(0)
        self.importrpsvisual_widget_layout.setObjectName(u"importrpsvisual_widget_layout")
        self.importrpsvisual_widget_layout.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout_18.addWidget(self.importrpsvisual_widget)


        self.verticalLayout_8.addWidget(self.rpsvisual_widget)

        self.pages_stackedWidget.addWidget(self.importrps_page)
        self.morphing_page = QWidget()
        self.morphing_page.setObjectName(u"morphing_page")
        self.verticalLayout_20 = QVBoxLayout(self.morphing_page)
        self.verticalLayout_20.setSpacing(5)
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.verticalLayout_20.setContentsMargins(5, 5, 5, 5)
        self.label_7 = QLabel(self.morphing_page)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setMinimumSize(QSize(0, 30))
        self.label_7.setMaximumSize(QSize(16777215, 30))
        self.label_7.setFont(font1)
        self.label_7.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Segoe UI\";")

        self.verticalLayout_20.addWidget(self.label_7)

        self.widget_8 = QWidget(self.morphing_page)
        self.widget_8.setObjectName(u"widget_8")
        self.widget_8.setMinimumSize(QSize(0, 120))
        self.widget_8.setMaximumSize(QSize(16777215, 120))
        self.widget_8.setSizeIncrement(QSize(0, 30))
        self.verticalLayout_12 = QVBoxLayout(self.widget_8)
        self.verticalLayout_12.setSpacing(0)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.verticalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_7 = QHBoxLayout()
        self.horizontalLayout_7.setSpacing(10)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.meshsize_label_8 = QLabel(self.widget_8)
        self.meshsize_label_8.setObjectName(u"meshsize_label_8")
        sizePolicy1.setHeightForWidth(self.meshsize_label_8.sizePolicy().hasHeightForWidth())
        self.meshsize_label_8.setSizePolicy(sizePolicy1)
        self.meshsize_label_8.setMinimumSize(QSize(0, 30))
        self.meshsize_label_8.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_8.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 10pt \"Segoe UI\";")

        self.horizontalLayout_7.addWidget(self.meshsize_label_8)

        self.morphlevel_comboBox = QComboBox(self.widget_8)
        self.morphlevel_comboBox.addItem("")
        self.morphlevel_comboBox.addItem("")
        self.morphlevel_comboBox.addItem("")
        self.morphlevel_comboBox.addItem("")
        self.morphlevel_comboBox.setObjectName(u"morphlevel_comboBox")
        self.morphlevel_comboBox.setMinimumSize(QSize(150, 28))
        self.morphlevel_comboBox.setMaximumSize(QSize(150, 28))
        self.morphlevel_comboBox.setStyleSheet(u"/* QComboBox */\n"
"QComboBox {\n"
"    background-color: #3d3d3d; /* Dark background */\n"
"    color: #abb2bf; /* Modern text color */\n"
"    border: 2px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 4px; /* Rounded corners */\n"
"    padding: 4px; /* Padding for dropdown */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Match font style */\n"
"    font-size: 11pt; /* Match font size */\n"
"}\n"
"\n"
"QComboBox:hover {\n"
"    border: 1px solid #61afef; /* Light blue border on hover */\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    border: none; /* No border for drop-down button */\n"
"    background: none; /* Transparent background */\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"    image: url(\"down-arrow.png\"); /* Replace with your down arrow icon path */\n"
"    width: 12px;\n"
"    height: 12px;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView {\n"
"    background-color: #21252b; /* Dropdown menu background */\n"
"    color: #abb2bf; /* Text color in dropdown"
                        " */\n"
"    border: 1px solid #3c4049; /* Dropdown border */\n"
"    border-radius: 4px; /* Rounded dropdown */\n"
"    selection-background-color: #3e4451; /* Highlight background */\n"
"    selection-color: #ffffff; /* Highlighted text */\n"
"}")

        self.horizontalLayout_7.addWidget(self.morphlevel_comboBox)

        self.horizontalSpacer_10 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_7.addItem(self.horizontalSpacer_10)


        self.verticalLayout_12.addLayout(self.horizontalLayout_7)

        self.horizontalLayout_8 = QHBoxLayout()
        self.horizontalLayout_8.setSpacing(10)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.morphing_progressBar = QProgressBar(self.widget_8)
        self.morphing_progressBar.setObjectName(u"morphing_progressBar")
        self.morphing_progressBar.setStyleSheet(u"QProgressBar {\n"
"    border: 2px solid #444;\n"
"    border-radius: 5px;\n"
"    background-color: #222;\n"
"    text-align: center;\n"
"    font: bold 10pt \"Segoe UI\";\n"
"    color: #ddd;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    background-color: #29a3ef; /* Bright blue progress color */\n"
"    border-radius: 5px;\n"
"}")
        self.morphing_progressBar.setValue(0)

        self.horizontalLayout_8.addWidget(self.morphing_progressBar)

        self.startmorphing_pushButton = QPushButton(self.widget_8)
        self.startmorphing_pushButton.setObjectName(u"startmorphing_pushButton")
        self.startmorphing_pushButton.setMinimumSize(QSize(80, 30))
        self.startmorphing_pushButton.setMaximumSize(QSize(80, 30))
        self.startmorphing_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: #D8DEE9;\n"
"    border: 2px solid#D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")
        icon18 = QIcon()
        icon18.addFile(u":/root/images/start.png", QSize(), QIcon.Normal, QIcon.Off)
        self.startmorphing_pushButton.setIcon(icon18)
        self.startmorphing_pushButton.setIconSize(QSize(23, 23))
        self.startmorphing_pushButton.setCheckable(True)
        self.startmorphing_pushButton.setAutoExclusive(True)

        self.horizontalLayout_8.addWidget(self.startmorphing_pushButton)

        self.stopmorphing_pushButton = QPushButton(self.widget_8)
        self.stopmorphing_pushButton.setObjectName(u"stopmorphing_pushButton")
        self.stopmorphing_pushButton.setMinimumSize(QSize(80, 30))
        self.stopmorphing_pushButton.setMaximumSize(QSize(80, 30))
        self.stopmorphing_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: #D8DEE9;\n"
"    border: 2px solid#D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")
        icon19 = QIcon()
        icon19.addFile(u":/root/images/stop.png", QSize(), QIcon.Normal, QIcon.Off)
        self.stopmorphing_pushButton.setIcon(icon19)
        self.stopmorphing_pushButton.setIconSize(QSize(23, 23))
        self.stopmorphing_pushButton.setCheckable(True)
        self.stopmorphing_pushButton.setAutoExclusive(True)

        self.horizontalLayout_8.addWidget(self.stopmorphing_pushButton)


        self.verticalLayout_12.addLayout(self.horizontalLayout_8)

        self.horizontalLayout_11 = QHBoxLayout()
        self.horizontalLayout_11.setSpacing(10)
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.horizontalSpacer_21 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_11.addItem(self.horizontalSpacer_21)

        self.adjustholes_pushButton = QPushButton(self.widget_8)
        self.adjustholes_pushButton.setObjectName(u"adjustholes_pushButton")
        sizePolicy1.setHeightForWidth(self.adjustholes_pushButton.sizePolicy().hasHeightForWidth())
        self.adjustholes_pushButton.setSizePolicy(sizePolicy1)
        self.adjustholes_pushButton.setMinimumSize(QSize(75, 0))
        self.adjustholes_pushButton.setMaximumSize(QSize(75, 16777215))
        self.adjustholes_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: #D8DEE9;\n"
"    border: 1px solid #D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: 12px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")

        self.horizontalLayout_11.addWidget(self.adjustholes_pushButton)


        self.verticalLayout_12.addLayout(self.horizontalLayout_11)


        self.verticalLayout_20.addWidget(self.widget_8)

        self.morphingvisual_widget = QWidget(self.morphing_page)
        self.morphingvisual_widget.setObjectName(u"morphingvisual_widget")
        self.morphingvisual_widget.setStyleSheet(u"background-color: #3d3d3d;\n"
"border-radius: 5px;")
        self.verticalLayout_13 = QVBoxLayout(self.morphingvisual_widget)
        self.verticalLayout_13.setSpacing(0)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.verticalLayout_13.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.verticalLayout_13.setContentsMargins(-1, 1, -1, 1)
        self.horizontalWidget_6 = QWidget(self.morphingvisual_widget)
        self.horizontalWidget_6.setObjectName(u"horizontalWidget_6")
        sizePolicy2.setHeightForWidth(self.horizontalWidget_6.sizePolicy().hasHeightForWidth())
        self.horizontalWidget_6.setSizePolicy(sizePolicy2)
        self.horizontalWidget_6.setMinimumSize(QSize(0, 40))
        self.horizontalWidget_6.setMaximumSize(QSize(16777215, 40))
        self.horizontalLayout_12 = QHBoxLayout(self.horizontalWidget_6)
        self.horizontalLayout_12.setSpacing(0)
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.horizontalLayout_12.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.horizontalLayout_12.setContentsMargins(0, 0, 5, 0)
        self.meshsize_label_10 = QLabel(self.horizontalWidget_6)
        self.meshsize_label_10.setObjectName(u"meshsize_label_10")
        sizePolicy1.setHeightForWidth(self.meshsize_label_10.sizePolicy().hasHeightForWidth())
        self.meshsize_label_10.setSizePolicy(sizePolicy1)
        self.meshsize_label_10.setMinimumSize(QSize(0, 30))
        self.meshsize_label_10.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_10.setStyleSheet(u"    color: #D8DEE9;\n"
"    font: bold 14px \"Segoe UI\";\n"
"    border: 2px solid #D8DEE9;\n"
"    border-radius: 4px;")

        self.horizontalLayout_12.addWidget(self.meshsize_label_10)

        self.horizontalSpacer_22 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_12.addItem(self.horizontalSpacer_22)

        self.meshsize_label_11 = QLabel(self.horizontalWidget_6)
        self.meshsize_label_11.setObjectName(u"meshsize_label_11")
        sizePolicy1.setHeightForWidth(self.meshsize_label_11.sizePolicy().hasHeightForWidth())
        self.meshsize_label_11.setSizePolicy(sizePolicy1)
        self.meshsize_label_11.setMinimumSize(QSize(0, 30))
        self.meshsize_label_11.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_11.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: bold 14px \"Segoe UI\";")

        self.horizontalLayout_12.addWidget(self.meshsize_label_11)


        self.verticalLayout_13.addWidget(self.horizontalWidget_6)

        self.horizontalWidget_14 = QWidget(self.morphingvisual_widget)
        self.horizontalWidget_14.setObjectName(u"horizontalWidget_14")
        sizePolicy2.setHeightForWidth(self.horizontalWidget_14.sizePolicy().hasHeightForWidth())
        self.horizontalWidget_14.setSizePolicy(sizePolicy2)
        self.horizontalWidget_14.setMinimumSize(QSize(0, 32))
        self.horizontalWidget_14.setMaximumSize(QSize(16777215, 32))
        self.horizontalLayout_36 = QHBoxLayout(self.horizontalWidget_14)
        self.horizontalLayout_36.setSpacing(5)
        self.horizontalLayout_36.setObjectName(u"horizontalLayout_36")
        self.horizontalLayout_36.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.horizontalLayout_36.setContentsMargins(0, 0, 5, 0)
        self.showmorphresult_pushButton = QPushButton(self.horizontalWidget_14)
        self.showmorphresult_pushButton.setObjectName(u"showmorphresult_pushButton")
        sizePolicy1.setHeightForWidth(self.showmorphresult_pushButton.sizePolicy().hasHeightForWidth())
        self.showmorphresult_pushButton.setSizePolicy(sizePolicy1)
        self.showmorphresult_pushButton.setMinimumSize(QSize(120, 25))
        self.showmorphresult_pushButton.setMaximumSize(QSize(120, 25))
        self.showmorphresult_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_36.addWidget(self.showmorphresult_pushButton)

        self.horizontalSpacer_33 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_36.addItem(self.horizontalSpacer_33)


        self.verticalLayout_13.addWidget(self.horizontalWidget_14)

        self.morphingresultvisual_widget = QWidget(self.morphingvisual_widget)
        self.morphingresultvisual_widget.setObjectName(u"morphingresultvisual_widget")
        self.morphingresultvisual_widget_layout = QVBoxLayout(self.morphingresultvisual_widget)
        self.morphingresultvisual_widget_layout.setSpacing(0)
        self.morphingresultvisual_widget_layout.setObjectName(u"morphingresultvisual_widget_layout")
        self.morphingresultvisual_widget_layout.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout_13.addWidget(self.morphingresultvisual_widget)


        self.verticalLayout_20.addWidget(self.morphingvisual_widget)

        self.pages_stackedWidget.addWidget(self.morphing_page)
        self.gc_page = QWidget()
        self.gc_page.setObjectName(u"gc_page")
        self.verticalLayout_23 = QVBoxLayout(self.gc_page)
        self.verticalLayout_23.setSpacing(5)
        self.verticalLayout_23.setObjectName(u"verticalLayout_23")
        self.verticalLayout_23.setContentsMargins(5, 5, 5, 5)
        self.label_18 = QLabel(self.gc_page)
        self.label_18.setObjectName(u"label_18")
        self.label_18.setMinimumSize(QSize(0, 30))
        self.label_18.setMaximumSize(QSize(16777215, 30))
        self.label_18.setFont(font1)
        self.label_18.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Segoe UI\";")

        self.verticalLayout_23.addWidget(self.label_18)

        self.widget_9 = QWidget(self.gc_page)
        self.widget_9.setObjectName(u"widget_9")
        self.widget_9.setMinimumSize(QSize(0, 120))
        self.widget_9.setMaximumSize(QSize(16777215, 120))
        self.widget_9.setSizeIncrement(QSize(0, 30))
        self.verticalLayout_21 = QVBoxLayout(self.widget_9)
        self.verticalLayout_21.setSpacing(0)
        self.verticalLayout_21.setObjectName(u"verticalLayout_21")
        self.verticalLayout_21.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_13 = QHBoxLayout()
        self.horizontalLayout_13.setSpacing(10)
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.meshsize_label_9 = QLabel(self.widget_9)
        self.meshsize_label_9.setObjectName(u"meshsize_label_9")
        sizePolicy1.setHeightForWidth(self.meshsize_label_9.sizePolicy().hasHeightForWidth())
        self.meshsize_label_9.setSizePolicy(sizePolicy1)
        self.meshsize_label_9.setMinimumSize(QSize(0, 30))
        self.meshsize_label_9.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_9.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 10pt \"Segoe UI\";")

        self.horizontalLayout_13.addWidget(self.meshsize_label_9)

        self.gravitydirection_comboBox = QComboBox(self.widget_9)
        self.gravitydirection_comboBox.addItem("")
        self.gravitydirection_comboBox.addItem("")
        self.gravitydirection_comboBox.addItem("")
        self.gravitydirection_comboBox.addItem("")
        self.gravitydirection_comboBox.addItem("")
        self.gravitydirection_comboBox.addItem("")
        self.gravitydirection_comboBox.addItem("")
        self.gravitydirection_comboBox.setObjectName(u"gravitydirection_comboBox")
        self.gravitydirection_comboBox.setMinimumSize(QSize(160, 28))
        self.gravitydirection_comboBox.setMaximumSize(QSize(160, 28))
        self.gravitydirection_comboBox.setStyleSheet(u"/* QComboBox */\n"
"QComboBox {\n"
"    background-color: #3d3d3d; /* Dark background */\n"
"    color: #abb2bf; /* Modern text color */\n"
"    border: 2px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 4px; /* Rounded corners */\n"
"    padding: 4px; /* Padding for dropdown */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Match font style */\n"
"    font-size: 11pt; /* Match font size */\n"
"}\n"
"\n"
"QComboBox:hover {\n"
"    border: 1px solid #61afef; /* Light blue border on hover */\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    border: none; /* No border for drop-down button */\n"
"    background: none; /* Transparent background */\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"    image: url(\"down-arrow.png\"); /* Replace with your down arrow icon path */\n"
"    width: 12px;\n"
"    height: 12px;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView {\n"
"    background-color: #21252b; /* Dropdown menu background */\n"
"    color: #abb2bf; /* Text color in dropdown"
                        " */\n"
"    border: 1px solid #3c4049; /* Dropdown border */\n"
"    border-radius: 4px; /* Rounded dropdown */\n"
"    selection-background-color: #3e4451; /* Highlight background */\n"
"    selection-color: #ffffff; /* Highlighted text */\n"
"}")

        self.horizontalLayout_13.addWidget(self.gravitydirection_comboBox)

        self.horizontalSpacer_23 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_13.addItem(self.horizontalSpacer_23)


        self.verticalLayout_21.addLayout(self.horizontalLayout_13)

        self.horizontalLayout_25 = QHBoxLayout()
        self.horizontalLayout_25.setSpacing(10)
        self.horizontalLayout_25.setObjectName(u"horizontalLayout_25")
        self.gc_progressBar = QProgressBar(self.widget_9)
        self.gc_progressBar.setObjectName(u"gc_progressBar")
        self.gc_progressBar.setStyleSheet(u"QProgressBar {\n"
"    border: 2px solid #444;\n"
"    border-radius: 5px;\n"
"    background-color: #222;\n"
"    text-align: center;\n"
"    font: bold 10pt \"Segoe UI\";\n"
"    color: #ddd;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    background-color: #29a3ef; /* Bright blue progress color */\n"
"    border-radius: 5px;\n"
"}")
        self.gc_progressBar.setValue(0)

        self.horizontalLayout_25.addWidget(self.gc_progressBar)

        self.startgc_pushButton = QPushButton(self.widget_9)
        self.startgc_pushButton.setObjectName(u"startgc_pushButton")
        self.startgc_pushButton.setMinimumSize(QSize(80, 30))
        self.startgc_pushButton.setMaximumSize(QSize(80, 30))
        self.startgc_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: #D8DEE9;\n"
"    border: 2px solid#D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")
        self.startgc_pushButton.setIcon(icon18)
        self.startgc_pushButton.setIconSize(QSize(23, 23))
        self.startgc_pushButton.setCheckable(True)
        self.startgc_pushButton.setAutoExclusive(True)

        self.horizontalLayout_25.addWidget(self.startgc_pushButton)

        self.stopgc_pushButton = QPushButton(self.widget_9)
        self.stopgc_pushButton.setObjectName(u"stopgc_pushButton")
        self.stopgc_pushButton.setMinimumSize(QSize(80, 30))
        self.stopgc_pushButton.setMaximumSize(QSize(80, 30))
        self.stopgc_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: #D8DEE9;\n"
"    border: 2px solid#D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")
        self.stopgc_pushButton.setIcon(icon19)
        self.stopgc_pushButton.setIconSize(QSize(23, 23))
        self.stopgc_pushButton.setCheckable(True)
        self.stopgc_pushButton.setAutoExclusive(True)

        self.horizontalLayout_25.addWidget(self.stopgc_pushButton)


        self.verticalLayout_21.addLayout(self.horizontalLayout_25)

        self.horizontalLayout_26 = QHBoxLayout()
        self.horizontalLayout_26.setSpacing(10)
        self.horizontalLayout_26.setObjectName(u"horizontalLayout_26")
        self.horizontalSpacer_24 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_26.addItem(self.horizontalSpacer_24)


        self.verticalLayout_21.addLayout(self.horizontalLayout_26)


        self.verticalLayout_23.addWidget(self.widget_9)

        self.gcvisual_widget = QWidget(self.gc_page)
        self.gcvisual_widget.setObjectName(u"gcvisual_widget")
        self.gcvisual_widget.setStyleSheet(u"background-color: #3d3d3d;\n"
"border-radius: 5px;")
        self.verticalLayout_22 = QVBoxLayout(self.gcvisual_widget)
        self.verticalLayout_22.setSpacing(0)
        self.verticalLayout_22.setObjectName(u"verticalLayout_22")
        self.verticalLayout_22.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.verticalLayout_22.setContentsMargins(-1, 1, -1, 1)
        self.horizontalWidget_7 = QWidget(self.gcvisual_widget)
        self.horizontalWidget_7.setObjectName(u"horizontalWidget_7")
        sizePolicy2.setHeightForWidth(self.horizontalWidget_7.sizePolicy().hasHeightForWidth())
        self.horizontalWidget_7.setSizePolicy(sizePolicy2)
        self.horizontalWidget_7.setMinimumSize(QSize(0, 40))
        self.horizontalWidget_7.setMaximumSize(QSize(16777215, 40))
        self.horizontalLayout_27 = QHBoxLayout(self.horizontalWidget_7)
        self.horizontalLayout_27.setSpacing(0)
        self.horizontalLayout_27.setObjectName(u"horizontalLayout_27")
        self.horizontalLayout_27.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.horizontalLayout_27.setContentsMargins(0, 0, 5, 0)
        self.meshsize_label_12 = QLabel(self.horizontalWidget_7)
        self.meshsize_label_12.setObjectName(u"meshsize_label_12")
        sizePolicy1.setHeightForWidth(self.meshsize_label_12.sizePolicy().hasHeightForWidth())
        self.meshsize_label_12.setSizePolicy(sizePolicy1)
        self.meshsize_label_12.setMinimumSize(QSize(0, 30))
        self.meshsize_label_12.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_12.setStyleSheet(u"    color: #D8DEE9;\n"
"    font: bold 14px \"Segoe UI\";\n"
"    border: 2px solid #D8DEE9;\n"
"    border-radius: 4px;")

        self.horizontalLayout_27.addWidget(self.meshsize_label_12)

        self.horizontalSpacer_25 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_27.addItem(self.horizontalSpacer_25)

        self.meshsize_label_24 = QLabel(self.horizontalWidget_7)
        self.meshsize_label_24.setObjectName(u"meshsize_label_24")
        sizePolicy1.setHeightForWidth(self.meshsize_label_24.sizePolicy().hasHeightForWidth())
        self.meshsize_label_24.setSizePolicy(sizePolicy1)
        self.meshsize_label_24.setMinimumSize(QSize(0, 30))
        self.meshsize_label_24.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_24.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: bold 14px \"Segoe UI\";")

        self.horizontalLayout_27.addWidget(self.meshsize_label_24)


        self.verticalLayout_22.addWidget(self.horizontalWidget_7)

        self.horizontalWidget_12 = QWidget(self.gcvisual_widget)
        self.horizontalWidget_12.setObjectName(u"horizontalWidget_12")
        sizePolicy2.setHeightForWidth(self.horizontalWidget_12.sizePolicy().hasHeightForWidth())
        self.horizontalWidget_12.setSizePolicy(sizePolicy2)
        self.horizontalWidget_12.setMinimumSize(QSize(0, 32))
        self.horizontalWidget_12.setMaximumSize(QSize(16777215, 32))
        self.horizontalLayout_34 = QHBoxLayout(self.horizontalWidget_12)
        self.horizontalLayout_34.setSpacing(5)
        self.horizontalLayout_34.setObjectName(u"horizontalLayout_34")
        self.horizontalLayout_34.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.horizontalLayout_34.setContentsMargins(0, 0, 5, 0)
        self.showgcmodel_pushButton = QPushButton(self.horizontalWidget_12)
        self.showgcmodel_pushButton.setObjectName(u"showgcmodel_pushButton")
        sizePolicy1.setHeightForWidth(self.showgcmodel_pushButton.sizePolicy().hasHeightForWidth())
        self.showgcmodel_pushButton.setSizePolicy(sizePolicy1)
        self.showgcmodel_pushButton.setMinimumSize(QSize(120, 25))
        self.showgcmodel_pushButton.setMaximumSize(QSize(120, 25))
        self.showgcmodel_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_34.addWidget(self.showgcmodel_pushButton)

        self.showgcresult_pushButton = QPushButton(self.horizontalWidget_12)
        self.showgcresult_pushButton.setObjectName(u"showgcresult_pushButton")
        sizePolicy1.setHeightForWidth(self.showgcresult_pushButton.sizePolicy().hasHeightForWidth())
        self.showgcresult_pushButton.setSizePolicy(sizePolicy1)
        self.showgcresult_pushButton.setMinimumSize(QSize(120, 25))
        self.showgcresult_pushButton.setMaximumSize(QSize(120, 25))
        self.showgcresult_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_34.addWidget(self.showgcresult_pushButton)

        self.horizontalSpacer_31 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_34.addItem(self.horizontalSpacer_31)


        self.verticalLayout_22.addWidget(self.horizontalWidget_12)

        self.gcresultvisual_widget = QWidget(self.gcvisual_widget)
        self.gcresultvisual_widget.setObjectName(u"gcresultvisual_widget")
        self.gcresultvisual_widget_layout = QVBoxLayout(self.gcresultvisual_widget)
        self.gcresultvisual_widget_layout.setSpacing(0)
        self.gcresultvisual_widget_layout.setObjectName(u"gcresultvisual_widget_layout")
        self.gcresultvisual_widget_layout.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout_22.addWidget(self.gcresultvisual_widget)


        self.verticalLayout_23.addWidget(self.gcvisual_widget)

        self.pages_stackedWidget.addWidget(self.gc_page)
        self.rps_page = QWidget()
        self.rps_page.setObjectName(u"rps_page")
        self.verticalLayout_26 = QVBoxLayout(self.rps_page)
        self.verticalLayout_26.setSpacing(5)
        self.verticalLayout_26.setObjectName(u"verticalLayout_26")
        self.verticalLayout_26.setContentsMargins(5, 5, 5, 5)
        self.label_19 = QLabel(self.rps_page)
        self.label_19.setObjectName(u"label_19")
        self.label_19.setMinimumSize(QSize(0, 30))
        self.label_19.setMaximumSize(QSize(16777215, 30))
        self.label_19.setFont(font1)
        self.label_19.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 700 18pt \"Segoe UI\";")

        self.verticalLayout_26.addWidget(self.label_19)

        self.widget_12 = QWidget(self.rps_page)
        self.widget_12.setObjectName(u"widget_12")
        self.widget_12.setMinimumSize(QSize(0, 120))
        self.widget_12.setMaximumSize(QSize(16777215, 120))
        self.widget_12.setSizeIncrement(QSize(0, 30))
        self.verticalLayout_25 = QVBoxLayout(self.widget_12)
        self.verticalLayout_25.setSpacing(0)
        self.verticalLayout_25.setObjectName(u"verticalLayout_25")
        self.verticalLayout_25.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_29 = QHBoxLayout()
        self.horizontalLayout_29.setSpacing(10)
        self.horizontalLayout_29.setObjectName(u"horizontalLayout_29")
        self.meshsize_label_27 = QLabel(self.widget_12)
        self.meshsize_label_27.setObjectName(u"meshsize_label_27")
        sizePolicy1.setHeightForWidth(self.meshsize_label_27.sizePolicy().hasHeightForWidth())
        self.meshsize_label_27.setSizePolicy(sizePolicy1)
        self.meshsize_label_27.setMinimumSize(QSize(0, 30))
        self.meshsize_label_27.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_27.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 10pt \"Segoe UI\";")

        self.horizontalLayout_29.addWidget(self.meshsize_label_27)

        self.selecthtype_pushButton = QPushButton(self.widget_12)
        self.selecthtype_pushButton.setObjectName(u"selecthtype_pushButton")
        self.selecthtype_pushButton.setMinimumSize(QSize(100, 31))
        self.selecthtype_pushButton.setMaximumSize(QSize(100, 31))
        self.selecthtype_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: #D8DEE9;\n"
"    border: 1px solid#D8DEE9;\n"
"    border-radius: 4px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")
        self.selecthtype_pushButton.setIconSize(QSize(23, 23))
        self.selecthtype_pushButton.setCheckable(True)
        self.selecthtype_pushButton.setAutoExclusive(True)

        self.horizontalLayout_29.addWidget(self.selecthtype_pushButton)

        self.fixedhtype_checkBox = QCheckBox(self.widget_12)
        self.fixedhtype_checkBox.setObjectName(u"fixedhtype_checkBox")
        self.fixedhtype_checkBox.setMinimumSize(QSize(0, 23))
        self.fixedhtype_checkBox.setMaximumSize(QSize(16777215, 23))
        self.fixedhtype_checkBox.setStyleSheet(u"color: rgb(255, 255, 255);")
        self.fixedhtype_checkBox.setIconSize(QSize(18, 18))
        self.fixedhtype_checkBox.setChecked(False)

        self.horizontalLayout_29.addWidget(self.fixedhtype_checkBox)

        self.horizontalSpacer_27 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_29.addItem(self.horizontalSpacer_27)


        self.verticalLayout_25.addLayout(self.horizontalLayout_29)

        self.horizontalLayout_30 = QHBoxLayout()
        self.horizontalLayout_30.setSpacing(10)
        self.horizontalLayout_30.setObjectName(u"horizontalLayout_30")
        self.rps_progressBar = QProgressBar(self.widget_12)
        self.rps_progressBar.setObjectName(u"rps_progressBar")
        self.rps_progressBar.setStyleSheet(u"QProgressBar {\n"
"    border: 2px solid #444;\n"
"    border-radius: 5px;\n"
"    background-color: #222;\n"
"    text-align: center;\n"
"    font: bold 10pt \"Segoe UI\";\n"
"    color: #ddd;\n"
"}\n"
"\n"
"QProgressBar::chunk {\n"
"    background-color: #29a3ef; /* Bright blue progress color */\n"
"    border-radius: 5px;\n"
"}")
        self.rps_progressBar.setValue(0)

        self.horizontalLayout_30.addWidget(self.rps_progressBar)

        self.startrps_pushButton = QPushButton(self.widget_12)
        self.startrps_pushButton.setObjectName(u"startrps_pushButton")
        self.startrps_pushButton.setMinimumSize(QSize(80, 30))
        self.startrps_pushButton.setMaximumSize(QSize(80, 30))
        self.startrps_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: #D8DEE9;\n"
"    border: 2px solid#D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")
        self.startrps_pushButton.setIcon(icon18)
        self.startrps_pushButton.setIconSize(QSize(23, 23))
        self.startrps_pushButton.setCheckable(True)
        self.startrps_pushButton.setAutoExclusive(True)

        self.horizontalLayout_30.addWidget(self.startrps_pushButton)

        self.stoprps_pushButton = QPushButton(self.widget_12)
        self.stoprps_pushButton.setObjectName(u"stoprps_pushButton")
        self.stoprps_pushButton.setMinimumSize(QSize(80, 30))
        self.stoprps_pushButton.setMaximumSize(QSize(80, 30))
        self.stoprps_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #3d3d3d;\n"
"    color: #D8DEE9;\n"
"    border: 2px solid#D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")
        self.stoprps_pushButton.setIcon(icon19)
        self.stoprps_pushButton.setIconSize(QSize(23, 23))
        self.stoprps_pushButton.setCheckable(True)
        self.stoprps_pushButton.setAutoExclusive(True)

        self.horizontalLayout_30.addWidget(self.stoprps_pushButton)


        self.verticalLayout_25.addLayout(self.horizontalLayout_30)

        self.horizontalLayout_31 = QHBoxLayout()
        self.horizontalLayout_31.setSpacing(10)
        self.horizontalLayout_31.setObjectName(u"horizontalLayout_31")
        self.meshsize_label_28 = QLabel(self.widget_12)
        self.meshsize_label_28.setObjectName(u"meshsize_label_28")
        sizePolicy1.setHeightForWidth(self.meshsize_label_28.sizePolicy().hasHeightForWidth())
        self.meshsize_label_28.setSizePolicy(sizePolicy1)
        self.meshsize_label_28.setMinimumSize(QSize(0, 30))
        self.meshsize_label_28.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_28.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: 10pt \"Segoe UI\";")

        self.horizontalLayout_31.addWidget(self.meshsize_label_28)

        self.rpsgravitydirection_comboBox = QComboBox(self.widget_12)
        self.rpsgravitydirection_comboBox.addItem("")
        self.rpsgravitydirection_comboBox.addItem("")
        self.rpsgravitydirection_comboBox.addItem("")
        self.rpsgravitydirection_comboBox.addItem("")
        self.rpsgravitydirection_comboBox.addItem("")
        self.rpsgravitydirection_comboBox.addItem("")
        self.rpsgravitydirection_comboBox.addItem("")
        self.rpsgravitydirection_comboBox.setObjectName(u"rpsgravitydirection_comboBox")
        self.rpsgravitydirection_comboBox.setMinimumSize(QSize(160, 28))
        self.rpsgravitydirection_comboBox.setMaximumSize(QSize(160, 28))
        self.rpsgravitydirection_comboBox.setStyleSheet(u"/* QComboBox */\n"
"QComboBox {\n"
"    background-color: #3d3d3d; /* Dark background */\n"
"    color: #abb2bf; /* Modern text color */\n"
"    border: 2px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 4px; /* Rounded corners */\n"
"    padding: 4px; /* Padding for dropdown */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Match font style */\n"
"    font-size: 11pt; /* Match font size */\n"
"}\n"
"\n"
"QComboBox:hover {\n"
"    border: 1px solid #61afef; /* Light blue border on hover */\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    border: none; /* No border for drop-down button */\n"
"    background: none; /* Transparent background */\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"    image: url(\"down-arrow.png\"); /* Replace with your down arrow icon path */\n"
"    width: 12px;\n"
"    height: 12px;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView {\n"
"    background-color: #21252b; /* Dropdown menu background */\n"
"    color: #abb2bf; /* Text color in dropdown"
                        " */\n"
"    border: 1px solid #3c4049; /* Dropdown border */\n"
"    border-radius: 4px; /* Rounded dropdown */\n"
"    selection-background-color: #3e4451; /* Highlight background */\n"
"    selection-color: #ffffff; /* Highlighted text */\n"
"}")

        self.horizontalLayout_31.addWidget(self.rpsgravitydirection_comboBox)

        self.horizontalSpacer_28 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_31.addItem(self.horizontalSpacer_28)

        self.clearhrps_pushButton = QPushButton(self.widget_12)
        self.clearhrps_pushButton.setObjectName(u"clearhrps_pushButton")
        sizePolicy1.setHeightForWidth(self.clearhrps_pushButton.sizePolicy().hasHeightForWidth())
        self.clearhrps_pushButton.setSizePolicy(sizePolicy1)
        self.clearhrps_pushButton.setMinimumSize(QSize(75, 0))
        self.clearhrps_pushButton.setMaximumSize(QSize(75, 16777215))
        self.clearhrps_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: #D8DEE9;\n"
"    border: 1px solid #D8DEE9;\n"
"    border-radius: 6px;\n"
"    font: 12px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2E3440;\n"
"    border: 1px solid #4C566A;\n"
"    color: #4C566A;\n"
"}")

        self.horizontalLayout_31.addWidget(self.clearhrps_pushButton)


        self.verticalLayout_25.addLayout(self.horizontalLayout_31)


        self.verticalLayout_26.addWidget(self.widget_12)

        self.rpsclampingvisual_widget = QWidget(self.rps_page)
        self.rpsclampingvisual_widget.setObjectName(u"rpsclampingvisual_widget")
        self.rpsclampingvisual_widget.setStyleSheet(u"background-color: #3d3d3d;\n"
"border-radius: 5px;")
        self.verticalLayout_24 = QVBoxLayout(self.rpsclampingvisual_widget)
        self.verticalLayout_24.setSpacing(0)
        self.verticalLayout_24.setObjectName(u"verticalLayout_24")
        self.verticalLayout_24.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.verticalLayout_24.setContentsMargins(-1, 1, -1, 1)
        self.horizontalWidget_11 = QWidget(self.rpsclampingvisual_widget)
        self.horizontalWidget_11.setObjectName(u"horizontalWidget_11")
        sizePolicy2.setHeightForWidth(self.horizontalWidget_11.sizePolicy().hasHeightForWidth())
        self.horizontalWidget_11.setSizePolicy(sizePolicy2)
        self.horizontalWidget_11.setMinimumSize(QSize(0, 40))
        self.horizontalWidget_11.setMaximumSize(QSize(16777215, 40))
        self.horizontalLayout_28 = QHBoxLayout(self.horizontalWidget_11)
        self.horizontalLayout_28.setSpacing(0)
        self.horizontalLayout_28.setObjectName(u"horizontalLayout_28")
        self.horizontalLayout_28.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.horizontalLayout_28.setContentsMargins(0, 0, 5, 0)
        self.meshsize_label_25 = QLabel(self.horizontalWidget_11)
        self.meshsize_label_25.setObjectName(u"meshsize_label_25")
        sizePolicy1.setHeightForWidth(self.meshsize_label_25.sizePolicy().hasHeightForWidth())
        self.meshsize_label_25.setSizePolicy(sizePolicy1)
        self.meshsize_label_25.setMinimumSize(QSize(0, 30))
        self.meshsize_label_25.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_25.setStyleSheet(u"    color: #D8DEE9;\n"
"    font: bold 14px \"Segoe UI\";\n"
"    border: 2px solid #D8DEE9;\n"
"    border-radius: 4px;")

        self.horizontalLayout_28.addWidget(self.meshsize_label_25)

        self.horizontalSpacer_26 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_28.addItem(self.horizontalSpacer_26)

        self.meshsize_label_26 = QLabel(self.horizontalWidget_11)
        self.meshsize_label_26.setObjectName(u"meshsize_label_26")
        sizePolicy1.setHeightForWidth(self.meshsize_label_26.sizePolicy().hasHeightForWidth())
        self.meshsize_label_26.setSizePolicy(sizePolicy1)
        self.meshsize_label_26.setMinimumSize(QSize(0, 30))
        self.meshsize_label_26.setMaximumSize(QSize(16777215, 30))
        self.meshsize_label_26.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"font: bold 14px \"Segoe UI\";")

        self.horizontalLayout_28.addWidget(self.meshsize_label_26)


        self.verticalLayout_24.addWidget(self.horizontalWidget_11)

        self.horizontalWidget_13 = QWidget(self.rpsclampingvisual_widget)
        self.horizontalWidget_13.setObjectName(u"horizontalWidget_13")
        sizePolicy2.setHeightForWidth(self.horizontalWidget_13.sizePolicy().hasHeightForWidth())
        self.horizontalWidget_13.setSizePolicy(sizePolicy2)
        self.horizontalWidget_13.setMinimumSize(QSize(0, 32))
        self.horizontalWidget_13.setMaximumSize(QSize(16777215, 32))
        self.horizontalLayout_35 = QHBoxLayout(self.horizontalWidget_13)
        self.horizontalLayout_35.setSpacing(5)
        self.horizontalLayout_35.setObjectName(u"horizontalLayout_35")
        self.horizontalLayout_35.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.horizontalLayout_35.setContentsMargins(0, 0, 5, 0)
        self.showrpsmodel_pushButton = QPushButton(self.horizontalWidget_13)
        self.showrpsmodel_pushButton.setObjectName(u"showrpsmodel_pushButton")
        sizePolicy1.setHeightForWidth(self.showrpsmodel_pushButton.sizePolicy().hasHeightForWidth())
        self.showrpsmodel_pushButton.setSizePolicy(sizePolicy1)
        self.showrpsmodel_pushButton.setMinimumSize(QSize(120, 25))
        self.showrpsmodel_pushButton.setMaximumSize(QSize(120, 25))
        self.showrpsmodel_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_35.addWidget(self.showrpsmodel_pushButton)

        self.showrpsresult_pushButton = QPushButton(self.horizontalWidget_13)
        self.showrpsresult_pushButton.setObjectName(u"showrpsresult_pushButton")
        sizePolicy1.setHeightForWidth(self.showrpsresult_pushButton.sizePolicy().hasHeightForWidth())
        self.showrpsresult_pushButton.setSizePolicy(sizePolicy1)
        self.showrpsresult_pushButton.setMinimumSize(QSize(120, 25))
        self.showrpsresult_pushButton.setMaximumSize(QSize(120, 25))
        self.showrpsresult_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_35.addWidget(self.showrpsresult_pushButton)

        self.horizontalSpacer_32 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_35.addItem(self.horizontalSpacer_32)


        self.verticalLayout_24.addWidget(self.horizontalWidget_13)

        self.rpsresultvisual_widget = QWidget(self.rpsclampingvisual_widget)
        self.rpsresultvisual_widget.setObjectName(u"rpsresultvisual_widget")
        self.rpsresultvisual_widget_layout = QVBoxLayout(self.rpsresultvisual_widget)
        self.rpsresultvisual_widget_layout.setSpacing(0)
        self.rpsresultvisual_widget_layout.setObjectName(u"rpsresultvisual_widget_layout")
        self.rpsresultvisual_widget_layout.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout_24.addWidget(self.rpsresultvisual_widget)


        self.verticalLayout_26.addWidget(self.rpsclampingvisual_widget)

        self.pages_stackedWidget.addWidget(self.rps_page)

        self.verticalLayout_5.addWidget(self.pages_stackedWidget)


        self.gridLayout.addWidget(self.main_pages, 0, 3, 1, 1)

        self.process_name_widget = QWidget(self.centralwidget)
        self.process_name_widget.setObjectName(u"process_name_widget")
        self.process_name_widget.setMinimumSize(QSize(0, 0))
        self.process_name_widget.setMaximumSize(QSize(16777215, 16777215))
        self.process_name_widget.setStyleSheet(u"QWidget{\n"
"background-color: rgb(33, 33, 33);\n"
"}\n"
"")
        self.verticalLayout_4 = QVBoxLayout(self.process_name_widget)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(-1, -1, 0, -1)
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setSpacing(10)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(-1, 5, -1, 5)
        self.label_2 = QLabel(self.process_name_widget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setMinimumSize(QSize(55, 55))
        self.label_2.setMaximumSize(QSize(55, 55))
        self.label_2.setPixmap(QPixmap(u":/root/images/logo.png"))
        self.label_2.setScaledContents(True)

        self.horizontalLayout.addWidget(self.label_2)

        self.widget1 = QWidget(self.process_name_widget)
        self.widget1.setObjectName(u"widget1")
        self.widget1.setMinimumSize(QSize(0, 55))
        self.widget1.setMaximumSize(QSize(16777215, 55))
        self.verticalLayout_6 = QVBoxLayout(self.widget1)
        self.verticalLayout_6.setSpacing(0)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.label_3 = QLabel(self.widget1)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setMinimumSize(QSize(0, 26))
        self.label_3.setMaximumSize(QSize(16777215, 26))
        self.label_3.setStyleSheet(u"QLabel {\n"
"color: rgb(255, 255, 255);\n"
"font: 700 19pt \"Segoe UI\";\n"
"}")

        self.verticalLayout_6.addWidget(self.label_3)

        self.label_10 = QLabel(self.widget1)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setMinimumSize(QSize(0, 26))
        self.label_10.setMaximumSize(QSize(16777215, 26))
        self.label_10.setStyleSheet(u"QLabel {\n"
"color: rgb(255, 255, 255);\n"
"font: 700 19pt \"Segoe UI\";\n"
"}")

        self.verticalLayout_6.addWidget(self.label_10)


        self.horizontalLayout.addWidget(self.widget1)


        self.verticalLayout_4.addLayout(self.horizontalLayout)

        self.widget_2 = QWidget(self.process_name_widget)
        self.widget_2.setObjectName(u"widget_2")
        self.widget_2.setMinimumSize(QSize(0, 10))
        self.widget_2.setMaximumSize(QSize(16777215, 10))

        self.verticalLayout_4.addWidget(self.widget_2)

        self.data_layout = QVBoxLayout()
        self.data_layout.setSpacing(1)
        self.data_layout.setObjectName(u"data_layout")
        self.data_layout.setContentsMargins(0, 0, 0, 0)
        self.label_13 = QLabel(self.process_name_widget)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setStyleSheet(u"QLabel {\n"
"color: rgb(255, 255, 255);\n"
"font: 700 9pt \"Segoe UI\";\n"
"}")

        self.data_layout.addWidget(self.label_13)

        self.importgeometry_pushButton = QPushButton(self.process_name_widget)
        self.importgeometry_pushButton.setObjectName(u"importgeometry_pushButton")
        self.importgeometry_pushButton.setMinimumSize(QSize(180, 55))
        self.importgeometry_pushButton.setMaximumSize(QSize(16777215, 55))
        self.importgeometry_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#D8DEE9;\n"
"    border-radius: 4px;\n"
"   font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        self.importgeometry_pushButton.setIcon(icon7)
        self.importgeometry_pushButton.setIconSize(QSize(35, 35))
        self.importgeometry_pushButton.setCheckable(True)
        self.importgeometry_pushButton.setAutoExclusive(True)

        self.data_layout.addWidget(self.importgeometry_pushButton)

        self.importmeasurement_pushButton = QPushButton(self.process_name_widget)
        self.importmeasurement_pushButton.setObjectName(u"importmeasurement_pushButton")
        self.importmeasurement_pushButton.setMinimumSize(QSize(180, 55))
        self.importmeasurement_pushButton.setMaximumSize(QSize(16777215, 55))
        self.importmeasurement_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#D8DEE9;\n"
"    border-radius: 4px;\n"
"   font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        self.importmeasurement_pushButton.setIcon(icon8)
        self.importmeasurement_pushButton.setIconSize(QSize(35, 35))
        self.importmeasurement_pushButton.setCheckable(True)
        self.importmeasurement_pushButton.setAutoExclusive(True)

        self.data_layout.addWidget(self.importmeasurement_pushButton)

        self.importfixture_pushButton = QPushButton(self.process_name_widget)
        self.importfixture_pushButton.setObjectName(u"importfixture_pushButton")
        self.importfixture_pushButton.setMinimumSize(QSize(180, 55))
        self.importfixture_pushButton.setMaximumSize(QSize(16777215, 55))
        self.importfixture_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#D8DEE9;\n"
"    border-radius: 4px;\n"
"   font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        self.importfixture_pushButton.setIcon(icon9)
        self.importfixture_pushButton.setIconSize(QSize(35, 35))
        self.importfixture_pushButton.setCheckable(True)
        self.importfixture_pushButton.setAutoExclusive(True)

        self.data_layout.addWidget(self.importfixture_pushButton)

        self.importrps_pushButton = QPushButton(self.process_name_widget)
        self.importrps_pushButton.setObjectName(u"importrps_pushButton")
        self.importrps_pushButton.setMinimumSize(QSize(180, 55))
        self.importrps_pushButton.setMaximumSize(QSize(16777215, 55))
        self.importrps_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#D8DEE9;\n"
"    border-radius: 4px;\n"
"   font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        self.importrps_pushButton.setIcon(icon10)
        self.importrps_pushButton.setIconSize(QSize(35, 35))
        self.importrps_pushButton.setCheckable(True)
        self.importrps_pushButton.setAutoExclusive(True)

        self.data_layout.addWidget(self.importrps_pushButton)


        self.verticalLayout_4.addLayout(self.data_layout)

        self.widget_11 = QWidget(self.process_name_widget)
        self.widget_11.setObjectName(u"widget_11")
        self.widget_11.setMinimumSize(QSize(0, 10))
        self.widget_11.setMaximumSize(QSize(16777215, 10))

        self.verticalLayout_4.addWidget(self.widget_11)

        self.process_layout = QVBoxLayout()
        self.process_layout.setSpacing(1)
        self.process_layout.setObjectName(u"process_layout")
        self.process_layout.setContentsMargins(0, 0, 0, 0)
        self.label_29 = QLabel(self.process_name_widget)
        self.label_29.setObjectName(u"label_29")
        self.label_29.setStyleSheet(u"QLabel {\n"
"color: rgb(255, 255, 255);\n"
"font: 700 9pt \"Segoe UI\";\n"
"}")

        self.process_layout.addWidget(self.label_29)

        self.morph_pushButton = QPushButton(self.process_name_widget)
        self.morph_pushButton.setObjectName(u"morph_pushButton")
        self.morph_pushButton.setMinimumSize(QSize(180, 55))
        self.morph_pushButton.setMaximumSize(QSize(16777215, 55))
        self.morph_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#D8DEE9;\n"
"    border-radius: 4px;\n"
"   font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        self.morph_pushButton.setIcon(icon11)
        self.morph_pushButton.setIconSize(QSize(35, 35))
        self.morph_pushButton.setCheckable(True)
        self.morph_pushButton.setAutoExclusive(True)

        self.process_layout.addWidget(self.morph_pushButton)

        self.gc_pushButton = QPushButton(self.process_name_widget)
        self.gc_pushButton.setObjectName(u"gc_pushButton")
        self.gc_pushButton.setMinimumSize(QSize(180, 55))
        self.gc_pushButton.setMaximumSize(QSize(16777215, 55))
        self.gc_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#D8DEE9;\n"
"    border-radius: 4px;\n"
"   font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        self.gc_pushButton.setIcon(icon12)
        self.gc_pushButton.setIconSize(QSize(35, 35))
        self.gc_pushButton.setCheckable(True)
        self.gc_pushButton.setAutoExclusive(True)

        self.process_layout.addWidget(self.gc_pushButton)

        self.rps_pushButton = QPushButton(self.process_name_widget)
        self.rps_pushButton.setObjectName(u"rps_pushButton")
        self.rps_pushButton.setMinimumSize(QSize(180, 55))
        self.rps_pushButton.setMaximumSize(QSize(16777215, 55))
        self.rps_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#D8DEE9;\n"
"    border-radius: 4px;\n"
"   font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        self.rps_pushButton.setIcon(icon13)
        self.rps_pushButton.setIconSize(QSize(35, 35))
        self.rps_pushButton.setCheckable(True)
        self.rps_pushButton.setAutoExclusive(True)

        self.process_layout.addWidget(self.rps_pushButton)


        self.verticalLayout_4.addLayout(self.process_layout)

        self.verticalSpacer_2 = QSpacerItem(20, 219, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_4.addItem(self.verticalSpacer_2)

        self.setting_pushButton = QPushButton(self.process_name_widget)
        self.setting_pushButton.setObjectName(u"setting_pushButton")
        self.setting_pushButton.setMinimumSize(QSize(0, 50))
        self.setting_pushButton.setMaximumSize(QSize(16777215, 50))
        self.setting_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#5d5d5d;\n"
"    font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:clicked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        self.setting_pushButton.setIcon(icon14)
        self.setting_pushButton.setIconSize(QSize(35, 35))
        self.setting_pushButton.setCheckable(True)
        self.setting_pushButton.setAutoExclusive(False)

        self.verticalLayout_4.addWidget(self.setting_pushButton)

        self.info_pushButton = QPushButton(self.process_name_widget)
        self.info_pushButton.setObjectName(u"info_pushButton")
        self.info_pushButton.setMinimumSize(QSize(0, 50))
        self.info_pushButton.setMaximumSize(QSize(16777215, 50))
        self.info_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: white;\n"
"    border: 1px solid#5d5d5d;\n"
"    font: 700 11pt \"Segoe UI\";\n"
"	text-align:left;\n"
"	padding-left:8px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:clicked {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}\n"
"\n"
"QPushButton:disabled {\n"
"    background-color: #2d2d2d;\n"
"    border: 0px solid #4C566A;\n"
"    color: grey;\n"
"}")
        self.info_pushButton.setIcon(icon6)
        self.info_pushButton.setIconSize(QSize(35, 35))
        self.info_pushButton.setCheckable(True)
        self.info_pushButton.setAutoExclusive(False)

        self.verticalLayout_4.addWidget(self.info_pushButton)


        self.gridLayout.addWidget(self.process_name_widget, 0, 1, 1, 1)

        self.parameters_widget = QWidget(self.centralwidget)
        self.parameters_widget.setObjectName(u"parameters_widget")
        self.parameters_widget.setMinimumSize(QSize(250, 0))
        self.parameters_widget.setMaximumSize(QSize(250, 16777215))
        self.parameters_widget.setSizeIncrement(QSize(0, 0))
        self.parameters_widget.setStyleSheet(u"QWidget{\n"
"background-color: rgb(33, 33, 33);\n"
"	font: 10pt \"Segoe UI\";\n"
"	color: rgb(255, 255, 255);\n"
"}")
        self.settingsinfo_widget_layout_6 = QVBoxLayout(self.parameters_widget)
        self.settingsinfo_widget_layout_6.setSpacing(6)
        self.settingsinfo_widget_layout_6.setObjectName(u"settingsinfo_widget_layout_6")
        self.settingsinfo_widget_layout_6.setContentsMargins(2, 5, 2, 5)
        self.label_23 = QLabel(self.parameters_widget)
        self.label_23.setObjectName(u"label_23")
        self.label_23.setMinimumSize(QSize(0, 35))
        self.label_23.setMaximumSize(QSize(16777215, 35))
        self.label_23.setFont(font)
        self.label_23.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"text-decoration: underline;\n"
"font: italic 700 14pt \"Segoe UI\";\n"
"padding-right:2px;")
        self.label_23.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.settingsinfo_widget_layout_6.addWidget(self.label_23)

        self.generalparameters_layout = QVBoxLayout()
        self.generalparameters_layout.setSpacing(0)
        self.generalparameters_layout.setObjectName(u"generalparameters_layout")
        self.generalparameters_layout.setContentsMargins(0, 0, -1, 0)
        self.generalparameters_label = QLabel(self.parameters_widget)
        self.generalparameters_label.setObjectName(u"generalparameters_label")
        self.generalparameters_label.setMinimumSize(QSize(0, 20))
        self.generalparameters_label.setMaximumSize(QSize(16777215, 20))
        self.generalparameters_label.setStyleSheet(u"font: 700 italic 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.generalparameters_label.setAlignment(Qt.AlignBottom|Qt.AlignRight|Qt.AlignTrailing)

        self.generalparameters_layout.addWidget(self.generalparameters_label)

        self.gcactivation_checkBox = QCheckBox(self.parameters_widget)
        self.gcactivation_checkBox.setObjectName(u"gcactivation_checkBox")
        self.gcactivation_checkBox.setMinimumSize(QSize(0, 23))
        self.gcactivation_checkBox.setMaximumSize(QSize(16777215, 23))
        self.gcactivation_checkBox.setStyleSheet(u"")
        self.gcactivation_checkBox.setIconSize(QSize(18, 18))
        self.gcactivation_checkBox.setChecked(True)

        self.generalparameters_layout.addWidget(self.gcactivation_checkBox)

        self.meshsize_layout_2 = QHBoxLayout()
        self.meshsize_layout_2.setSpacing(10)
        self.meshsize_layout_2.setObjectName(u"meshsize_layout_2")
        self.meshsize_layout_2.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.meshsize_layout_2.setContentsMargins(0, 0, -1, -1)
        self.geometrytype_comboBox = QComboBox(self.parameters_widget)
        self.geometrytype_comboBox.addItem("")
        self.geometrytype_comboBox.addItem("")
        self.geometrytype_comboBox.setObjectName(u"geometrytype_comboBox")
        self.geometrytype_comboBox.setMinimumSize(QSize(110, 27))
        self.geometrytype_comboBox.setMaximumSize(QSize(110, 27))
        self.geometrytype_comboBox.setStyleSheet(u"/* QComboBox */\n"
"QComboBox {\n"
"    background-color: #3d3d3d; /* Dark background */\n"
"    color: #abb2bf; /* Modern text color */\n"
"    border: 2px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 4px; /* Rounded corners */\n"
"    padding: 4px; /* Padding for dropdown */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Match font style */\n"
"    font-size: 10pt; /* Match font size */\n"
"}\n"
"\n"
"QComboBox:hover {\n"
"    border: 1px solid #61afef; /* Light blue border on hover */\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    border: none; /* No border for drop-down button */\n"
"    background: none; /* Transparent background */\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"    image: url(\"down-arrow.png\"); /* Replace with your down arrow icon path */\n"
"    width: 12px;\n"
"    height: 12px;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView {\n"
"    background-color: #21252b; /* Dropdown menu background */\n"
"    color: #abb2bf; /* Text color in dropdown"
                        " */\n"
"    border: 1px solid #3c4049; /* Dropdown border */\n"
"    border-radius: 4px; /* Rounded dropdown */\n"
"    selection-background-color: #3e4451; /* Highlight background */\n"
"    selection-color: #ffffff; /* Highlighted text */\n"
"}")

        self.meshsize_layout_2.addWidget(self.geometrytype_comboBox)

        self.meshsize_label_2 = QLabel(self.parameters_widget)
        self.meshsize_label_2.setObjectName(u"meshsize_label_2")
        sizePolicy1.setHeightForWidth(self.meshsize_label_2.sizePolicy().hasHeightForWidth())
        self.meshsize_label_2.setSizePolicy(sizePolicy1)
        self.meshsize_label_2.setMinimumSize(QSize(0, 29))
        self.meshsize_label_2.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_2.addWidget(self.meshsize_label_2)

        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.meshsize_layout_2.addItem(self.horizontalSpacer_2)


        self.generalparameters_layout.addLayout(self.meshsize_layout_2)

        self.meshsize_layout_4 = QHBoxLayout()
        self.meshsize_layout_4.setSpacing(6)
        self.meshsize_layout_4.setObjectName(u"meshsize_layout_4")
        self.meshsize_layout_4.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.meshsize_layout_4.setContentsMargins(0, 0, -1, -1)
        self.smp_plainTextEdit = QPlainTextEdit(self.parameters_widget)
        self.smp_plainTextEdit.setObjectName(u"smp_plainTextEdit")
        sizePolicy1.setHeightForWidth(self.smp_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.smp_plainTextEdit.setSizePolicy(sizePolicy1)
        self.smp_plainTextEdit.setMinimumSize(QSize(65, 26))
        self.smp_plainTextEdit.setMaximumSize(QSize(65, 26))
        font2 = QFont()
        font2.setFamilies([u"Fira Code"])
        font2.setPointSize(10)
        font2.setBold(False)
        font2.setItalic(False)
        self.smp_plainTextEdit.setFont(font2)
        self.smp_plainTextEdit.setLayoutDirection(Qt.LeftToRight)
        self.smp_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"	padding-left: 2px;\n"
"}\n"
"")
        self.smp_plainTextEdit.setLocale(QLocale(QLocale.English, QLocale.Canada))

        self.meshsize_layout_4.addWidget(self.smp_plainTextEdit)

        self.smp_label = QLabel(self.parameters_widget)
        self.smp_label.setObjectName(u"smp_label")
        sizePolicy1.setHeightForWidth(self.smp_label.sizePolicy().hasHeightForWidth())
        self.smp_label.setSizePolicy(sizePolicy1)
        self.smp_label.setMinimumSize(QSize(0, 29))
        self.smp_label.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_4.addWidget(self.smp_label)

        self.horizontalSpacer_8 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.meshsize_layout_4.addItem(self.horizontalSpacer_8)


        self.generalparameters_layout.addLayout(self.meshsize_layout_4)

        self.meshsize_layout_7 = QHBoxLayout()
        self.meshsize_layout_7.setSpacing(6)
        self.meshsize_layout_7.setObjectName(u"meshsize_layout_7")
        self.meshsize_layout_7.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.meshsize_layout_7.setContentsMargins(0, 0, -1, -1)
        self.ddm_plainTextEdit = QPlainTextEdit(self.parameters_widget)
        self.ddm_plainTextEdit.setObjectName(u"ddm_plainTextEdit")
        sizePolicy1.setHeightForWidth(self.ddm_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.ddm_plainTextEdit.setSizePolicy(sizePolicy1)
        self.ddm_plainTextEdit.setMinimumSize(QSize(65, 26))
        self.ddm_plainTextEdit.setMaximumSize(QSize(65, 26))
        self.ddm_plainTextEdit.setFont(font2)
        self.ddm_plainTextEdit.setLayoutDirection(Qt.LeftToRight)
        self.ddm_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"	padding-left: 2px;\n"
"}\n"
"")
        self.ddm_plainTextEdit.setLocale(QLocale(QLocale.English, QLocale.Canada))

        self.meshsize_layout_7.addWidget(self.ddm_plainTextEdit)

        self.ddm_label = QLabel(self.parameters_widget)
        self.ddm_label.setObjectName(u"ddm_label")
        sizePolicy1.setHeightForWidth(self.ddm_label.sizePolicy().hasHeightForWidth())
        self.ddm_label.setSizePolicy(sizePolicy1)
        self.ddm_label.setMinimumSize(QSize(0, 29))
        self.ddm_label.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_7.addWidget(self.ddm_label)

        self.horizontalSpacer_11 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.meshsize_layout_7.addItem(self.horizontalSpacer_11)


        self.generalparameters_layout.addLayout(self.meshsize_layout_7)


        self.settingsinfo_widget_layout_6.addLayout(self.generalparameters_layout)

        self.meshingparameters_layout = QVBoxLayout()
        self.meshingparameters_layout.setSpacing(0)
        self.meshingparameters_layout.setObjectName(u"meshingparameters_layout")
        self.meshingparameters_layout.setContentsMargins(0, 0, -1, 0)
        self.meshingparameters_label = QLabel(self.parameters_widget)
        self.meshingparameters_label.setObjectName(u"meshingparameters_label")
        self.meshingparameters_label.setMinimumSize(QSize(0, 20))
        self.meshingparameters_label.setMaximumSize(QSize(16777215, 20))
        self.meshingparameters_label.setStyleSheet(u"font: 700 italic 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.meshingparameters_label.setAlignment(Qt.AlignBottom|Qt.AlignRight|Qt.AlignTrailing)

        self.meshingparameters_layout.addWidget(self.meshingparameters_label)

        self.cadhealing_checkBox = QCheckBox(self.parameters_widget)
        self.cadhealing_checkBox.setObjectName(u"cadhealing_checkBox")
        self.cadhealing_checkBox.setMinimumSize(QSize(0, 23))
        self.cadhealing_checkBox.setMaximumSize(QSize(16777215, 23))
        self.cadhealing_checkBox.setStyleSheet(u"")
        self.cadhealing_checkBox.setIconSize(QSize(18, 18))
        self.cadhealing_checkBox.setChecked(True)

        self.meshingparameters_layout.addWidget(self.cadhealing_checkBox)

        self.meshsize_layout = QHBoxLayout()
        self.meshsize_layout.setSpacing(6)
        self.meshsize_layout.setObjectName(u"meshsize_layout")
        self.meshsize_layout.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.meshsize_layout.setContentsMargins(0, 0, -1, -1)
        self.meshsize_plainTextEdit = QPlainTextEdit(self.parameters_widget)
        self.meshsize_plainTextEdit.setObjectName(u"meshsize_plainTextEdit")
        sizePolicy1.setHeightForWidth(self.meshsize_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.meshsize_plainTextEdit.setSizePolicy(sizePolicy1)
        self.meshsize_plainTextEdit.setMinimumSize(QSize(65, 26))
        self.meshsize_plainTextEdit.setMaximumSize(QSize(65, 26))
        self.meshsize_plainTextEdit.setFont(font2)
        self.meshsize_plainTextEdit.setLayoutDirection(Qt.LeftToRight)
        self.meshsize_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"	padding-left: 2px;\n"
"}\n"
"")
        self.meshsize_plainTextEdit.setLocale(QLocale(QLocale.English, QLocale.Canada))

        self.meshsize_layout.addWidget(self.meshsize_plainTextEdit)

        self.meshsize_label = QLabel(self.parameters_widget)
        self.meshsize_label.setObjectName(u"meshsize_label")
        sizePolicy1.setHeightForWidth(self.meshsize_label.sizePolicy().hasHeightForWidth())
        self.meshsize_label.setSizePolicy(sizePolicy1)
        self.meshsize_label.setMinimumSize(QSize(0, 29))
        self.meshsize_label.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout.addWidget(self.meshsize_label)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.meshsize_layout.addItem(self.horizontalSpacer)


        self.meshingparameters_layout.addLayout(self.meshsize_layout)

        self.curvaturerefine_checkBox = QCheckBox(self.parameters_widget)
        self.curvaturerefine_checkBox.setObjectName(u"curvaturerefine_checkBox")
        self.curvaturerefine_checkBox.setMinimumSize(QSize(0, 23))
        self.curvaturerefine_checkBox.setMaximumSize(QSize(16777215, 23))
        self.curvaturerefine_checkBox.setStyleSheet(u"")
        self.curvaturerefine_checkBox.setIconSize(QSize(18, 18))
        self.curvaturerefine_checkBox.setChecked(True)

        self.meshingparameters_layout.addWidget(self.curvaturerefine_checkBox)


        self.settingsinfo_widget_layout_6.addLayout(self.meshingparameters_layout)

        self.morphingparameters_layout = QVBoxLayout()
        self.morphingparameters_layout.setSpacing(0)
        self.morphingparameters_layout.setObjectName(u"morphingparameters_layout")
        self.morphingparameters_layout.setContentsMargins(0, 0, -1, 0)
        self.morphingparameters_label = QLabel(self.parameters_widget)
        self.morphingparameters_label.setObjectName(u"morphingparameters_label")
        self.morphingparameters_label.setMinimumSize(QSize(0, 20))
        self.morphingparameters_label.setMaximumSize(QSize(16777215, 20))
        self.morphingparameters_label.setStyleSheet(u"font: 700 italic 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.morphingparameters_label.setAlignment(Qt.AlignBottom|Qt.AlignRight|Qt.AlignTrailing)

        self.morphingparameters_layout.addWidget(self.morphingparameters_label)

        self.meshsize_layout_3 = QHBoxLayout()
        self.meshsize_layout_3.setSpacing(10)
        self.meshsize_layout_3.setObjectName(u"meshsize_layout_3")
        self.meshsize_layout_3.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.meshsize_layout_3.setContentsMargins(0, 0, -1, -1)
        self.matchmode_comboBox = QComboBox(self.parameters_widget)
        self.matchmode_comboBox.addItem("")
        self.matchmode_comboBox.addItem("")
        self.matchmode_comboBox.addItem("")
        self.matchmode_comboBox.setObjectName(u"matchmode_comboBox")
        self.matchmode_comboBox.setMinimumSize(QSize(135, 27))
        self.matchmode_comboBox.setMaximumSize(QSize(135, 27))
        self.matchmode_comboBox.setStyleSheet(u"/* QComboBox */\n"
"QComboBox {\n"
"    background-color: #3d3d3d; /* Dark background */\n"
"    color: #abb2bf; /* Modern text color */\n"
"    border: 2px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 4px; /* Rounded corners */\n"
"    padding: 4px; /* Padding for dropdown */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Match font style */\n"
"    font-size: 10pt; /* Match font size */\n"
"}\n"
"\n"
"QComboBox:hover {\n"
"    border: 1px solid #61afef; /* Light blue border on hover */\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    border: none; /* No border for drop-down button */\n"
"    background: none; /* Transparent background */\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"    image: url(\"down-arrow.png\"); /* Replace with your down arrow icon path */\n"
"    width: 12px;\n"
"    height: 12px;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView {\n"
"    background-color: #21252b; /* Dropdown menu background */\n"
"    color: #abb2bf; /* Text color in dropdown"
                        " */\n"
"    border: 1px solid #3c4049; /* Dropdown border */\n"
"    border-radius: 4px; /* Rounded dropdown */\n"
"    selection-background-color: #3e4451; /* Highlight background */\n"
"    selection-color: #ffffff; /* Highlighted text */\n"
"}")

        self.meshsize_layout_3.addWidget(self.matchmode_comboBox)

        self.meshsize_label_7 = QLabel(self.parameters_widget)
        self.meshsize_label_7.setObjectName(u"meshsize_label_7")
        sizePolicy1.setHeightForWidth(self.meshsize_label_7.sizePolicy().hasHeightForWidth())
        self.meshsize_label_7.setSizePolicy(sizePolicy1)
        self.meshsize_label_7.setMinimumSize(QSize(0, 29))
        self.meshsize_label_7.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_3.addWidget(self.meshsize_label_7)

        self.horizontalSpacer_6 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.meshsize_layout_3.addItem(self.horizontalSpacer_6)


        self.morphingparameters_layout.addLayout(self.meshsize_layout_3)

        self.bestfit_checkBox = QCheckBox(self.parameters_widget)
        self.bestfit_checkBox.setObjectName(u"bestfit_checkBox")
        self.bestfit_checkBox.setMinimumSize(QSize(0, 23))
        self.bestfit_checkBox.setMaximumSize(QSize(16777215, 23))
        self.bestfit_checkBox.setStyleSheet(u"")
        self.bestfit_checkBox.setIconSize(QSize(18, 18))
        self.bestfit_checkBox.setChecked(False)

        self.morphingparameters_layout.addWidget(self.bestfit_checkBox)

        self.transformation_checkBox = QCheckBox(self.parameters_widget)
        self.transformation_checkBox.setObjectName(u"transformation_checkBox")
        self.transformation_checkBox.setMinimumSize(QSize(0, 23))
        self.transformation_checkBox.setMaximumSize(QSize(16777215, 23))
        self.transformation_checkBox.setStyleSheet(u"")
        self.transformation_checkBox.setIconSize(QSize(18, 18))
        self.transformation_checkBox.setChecked(False)

        self.morphingparameters_layout.addWidget(self.transformation_checkBox)

        self.singlegeometry_checkBox = QCheckBox(self.parameters_widget)
        self.singlegeometry_checkBox.setObjectName(u"singlegeometry_checkBox")
        self.singlegeometry_checkBox.setMinimumSize(QSize(0, 23))
        self.singlegeometry_checkBox.setMaximumSize(QSize(16777215, 23))
        self.singlegeometry_checkBox.setStyleSheet(u"")
        self.singlegeometry_checkBox.setIconSize(QSize(18, 18))
        self.singlegeometry_checkBox.setChecked(True)

        self.morphingparameters_layout.addWidget(self.singlegeometry_checkBox)

        self.meshsize_layout_5 = QHBoxLayout()
        self.meshsize_layout_5.setSpacing(6)
        self.meshsize_layout_5.setObjectName(u"meshsize_layout_5")
        self.meshsize_layout_5.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.meshsize_layout_5.setContentsMargins(0, 0, -1, -1)
        self.surfacetolerance_plainTextEdit = QPlainTextEdit(self.parameters_widget)
        self.surfacetolerance_plainTextEdit.setObjectName(u"surfacetolerance_plainTextEdit")
        sizePolicy1.setHeightForWidth(self.surfacetolerance_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.surfacetolerance_plainTextEdit.setSizePolicy(sizePolicy1)
        self.surfacetolerance_plainTextEdit.setMinimumSize(QSize(65, 26))
        self.surfacetolerance_plainTextEdit.setMaximumSize(QSize(65, 26))
        self.surfacetolerance_plainTextEdit.setFont(font2)
        self.surfacetolerance_plainTextEdit.setLayoutDirection(Qt.LeftToRight)
        self.surfacetolerance_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"	padding-left: 2px;\n"
"}\n"
"")
        self.surfacetolerance_plainTextEdit.setLocale(QLocale(QLocale.English, QLocale.Canada))

        self.meshsize_layout_5.addWidget(self.surfacetolerance_plainTextEdit)

        self.smp_label_2 = QLabel(self.parameters_widget)
        self.smp_label_2.setObjectName(u"smp_label_2")
        sizePolicy1.setHeightForWidth(self.smp_label_2.sizePolicy().hasHeightForWidth())
        self.smp_label_2.setSizePolicy(sizePolicy1)
        self.smp_label_2.setMinimumSize(QSize(0, 29))
        self.smp_label_2.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_5.addWidget(self.smp_label_2)

        self.horizontalSpacer_9 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.meshsize_layout_5.addItem(self.horizontalSpacer_9)


        self.morphingparameters_layout.addLayout(self.meshsize_layout_5)

        self.meshsize_layout_8 = QHBoxLayout()
        self.meshsize_layout_8.setSpacing(6)
        self.meshsize_layout_8.setObjectName(u"meshsize_layout_8")
        self.meshsize_layout_8.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.meshsize_layout_8.setContentsMargins(0, 0, -1, -1)
        self.ignoreoutlier_plainTextEdit = QPlainTextEdit(self.parameters_widget)
        self.ignoreoutlier_plainTextEdit.setObjectName(u"ignoreoutlier_plainTextEdit")
        sizePolicy1.setHeightForWidth(self.ignoreoutlier_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.ignoreoutlier_plainTextEdit.setSizePolicy(sizePolicy1)
        self.ignoreoutlier_plainTextEdit.setMinimumSize(QSize(65, 26))
        self.ignoreoutlier_plainTextEdit.setMaximumSize(QSize(65, 26))
        self.ignoreoutlier_plainTextEdit.setFont(font2)
        self.ignoreoutlier_plainTextEdit.setLayoutDirection(Qt.LeftToRight)
        self.ignoreoutlier_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"	padding-left: 2px;\n"
"}\n"
"")
        self.ignoreoutlier_plainTextEdit.setLocale(QLocale(QLocale.English, QLocale.Canada))

        self.meshsize_layout_8.addWidget(self.ignoreoutlier_plainTextEdit)

        self.ddm_label_2 = QLabel(self.parameters_widget)
        self.ddm_label_2.setObjectName(u"ddm_label_2")
        sizePolicy1.setHeightForWidth(self.ddm_label_2.sizePolicy().hasHeightForWidth())
        self.ddm_label_2.setSizePolicy(sizePolicy1)
        self.ddm_label_2.setMinimumSize(QSize(0, 29))
        self.ddm_label_2.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_8.addWidget(self.ddm_label_2)

        self.horizontalSpacer_12 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.meshsize_layout_8.addItem(self.horizontalSpacer_12)


        self.morphingparameters_layout.addLayout(self.meshsize_layout_8)


        self.settingsinfo_widget_layout_6.addLayout(self.morphingparameters_layout)

        self.meshingparameters_layout_4 = QVBoxLayout()
        self.meshingparameters_layout_4.setSpacing(0)
        self.meshingparameters_layout_4.setObjectName(u"meshingparameters_layout_4")
        self.meshingparameters_layout_4.setContentsMargins(0, 0, -1, 0)
        self.meshingparameters_label_4 = QLabel(self.parameters_widget)
        self.meshingparameters_label_4.setObjectName(u"meshingparameters_label_4")
        self.meshingparameters_label_4.setMinimumSize(QSize(0, 20))
        self.meshingparameters_label_4.setMaximumSize(QSize(16777215, 20))
        self.meshingparameters_label_4.setStyleSheet(u"font: 700 italic 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.meshingparameters_label_4.setAlignment(Qt.AlignBottom|Qt.AlignRight|Qt.AlignTrailing)

        self.meshingparameters_layout_4.addWidget(self.meshingparameters_label_4)

        self.simplifiedgc_checkBox = QCheckBox(self.parameters_widget)
        self.simplifiedgc_checkBox.setObjectName(u"simplifiedgc_checkBox")
        self.simplifiedgc_checkBox.setMinimumSize(QSize(0, 23))
        self.simplifiedgc_checkBox.setMaximumSize(QSize(16777215, 23))
        self.simplifiedgc_checkBox.setStyleSheet(u"")
        self.simplifiedgc_checkBox.setIconSize(QSize(18, 18))
        self.simplifiedgc_checkBox.setChecked(False)

        self.meshingparameters_layout_4.addWidget(self.simplifiedgc_checkBox)

        self.meshsize_layout_32 = QHBoxLayout()
        self.meshsize_layout_32.setSpacing(10)
        self.meshsize_layout_32.setObjectName(u"meshsize_layout_32")
        self.meshsize_layout_32.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.meshsize_layout_32.setContentsMargins(0, 0, -1, -1)
        self.pinnumber_comboBox = QComboBox(self.parameters_widget)
        self.pinnumber_comboBox.addItem("")
        self.pinnumber_comboBox.addItem("")
        self.pinnumber_comboBox.setObjectName(u"pinnumber_comboBox")
        self.pinnumber_comboBox.setMinimumSize(QSize(55, 27))
        self.pinnumber_comboBox.setMaximumSize(QSize(55, 27))
        self.pinnumber_comboBox.setStyleSheet(u"/* QComboBox */\n"
"QComboBox {\n"
"    background-color: #3d3d3d; /* Dark background */\n"
"    color: #abb2bf; /* Modern text color */\n"
"    border: 2px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 4px; /* Rounded corners */\n"
"    padding: 4px; /* Padding for dropdown */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Match font style */\n"
"    font-size: 10pt; /* Match font size */\n"
"}\n"
"\n"
"QComboBox:hover {\n"
"    border: 1px solid #61afef; /* Light blue border on hover */\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    border: none; /* No border for drop-down button */\n"
"    background: none; /* Transparent background */\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"    image: url(\"down-arrow.png\"); /* Replace with your down arrow icon path */\n"
"    width: 12px;\n"
"    height: 12px;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView {\n"
"    background-color: #21252b; /* Dropdown menu background */\n"
"    color: #abb2bf; /* Text color in dropdown"
                        " */\n"
"    border: 1px solid #3c4049; /* Dropdown border */\n"
"    border-radius: 4px; /* Rounded dropdown */\n"
"    selection-background-color: #3e4451; /* Highlight background */\n"
"    selection-color: #ffffff; /* Highlighted text */\n"
"}")

        self.meshsize_layout_32.addWidget(self.pinnumber_comboBox)

        self.meshsize_label_36 = QLabel(self.parameters_widget)
        self.meshsize_label_36.setObjectName(u"meshsize_label_36")
        sizePolicy1.setHeightForWidth(self.meshsize_label_36.sizePolicy().hasHeightForWidth())
        self.meshsize_label_36.setSizePolicy(sizePolicy1)
        self.meshsize_label_36.setMinimumSize(QSize(0, 29))
        self.meshsize_label_36.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_32.addWidget(self.meshsize_label_36)

        self.horizontalSpacer_49 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.meshsize_layout_32.addItem(self.horizontalSpacer_49)


        self.meshingparameters_layout_4.addLayout(self.meshsize_layout_32)

        self.meshsize_layout_25 = QHBoxLayout()
        self.meshsize_layout_25.setSpacing(6)
        self.meshsize_layout_25.setObjectName(u"meshsize_layout_25")
        self.meshsize_layout_25.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.meshsize_layout_25.setContentsMargins(0, 0, -1, -1)
        self.searchradius_plainTextEdit = QPlainTextEdit(self.parameters_widget)
        self.searchradius_plainTextEdit.setObjectName(u"searchradius_plainTextEdit")
        sizePolicy1.setHeightForWidth(self.searchradius_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.searchradius_plainTextEdit.setSizePolicy(sizePolicy1)
        self.searchradius_plainTextEdit.setMinimumSize(QSize(65, 26))
        self.searchradius_plainTextEdit.setMaximumSize(QSize(65, 26))
        self.searchradius_plainTextEdit.setFont(font2)
        self.searchradius_plainTextEdit.setLayoutDirection(Qt.LeftToRight)
        self.searchradius_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"	padding-left: 2px;\n"
"}\n"
"")
        self.searchradius_plainTextEdit.setLocale(QLocale(QLocale.English, QLocale.Canada))

        self.meshsize_layout_25.addWidget(self.searchradius_plainTextEdit)

        self.meshsize_label_29 = QLabel(self.parameters_widget)
        self.meshsize_label_29.setObjectName(u"meshsize_label_29")
        sizePolicy1.setHeightForWidth(self.meshsize_label_29.sizePolicy().hasHeightForWidth())
        self.meshsize_label_29.setSizePolicy(sizePolicy1)
        self.meshsize_label_29.setMinimumSize(QSize(0, 29))
        self.meshsize_label_29.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_25.addWidget(self.meshsize_label_29)

        self.horizontalSpacer_42 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.meshsize_layout_25.addItem(self.horizontalSpacer_42)


        self.meshingparameters_layout_4.addLayout(self.meshsize_layout_25)

        self.meshsize_layout_27 = QHBoxLayout()
        self.meshsize_layout_27.setSpacing(6)
        self.meshsize_layout_27.setObjectName(u"meshsize_layout_27")
        self.meshsize_layout_27.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.meshsize_layout_27.setContentsMargins(0, 0, -1, -1)
        self.targetdeviation_plainTextEdit = QPlainTextEdit(self.parameters_widget)
        self.targetdeviation_plainTextEdit.setObjectName(u"targetdeviation_plainTextEdit")
        sizePolicy1.setHeightForWidth(self.targetdeviation_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.targetdeviation_plainTextEdit.setSizePolicy(sizePolicy1)
        self.targetdeviation_plainTextEdit.setMinimumSize(QSize(65, 26))
        self.targetdeviation_plainTextEdit.setMaximumSize(QSize(65, 26))
        self.targetdeviation_plainTextEdit.setFont(font2)
        self.targetdeviation_plainTextEdit.setLayoutDirection(Qt.LeftToRight)
        self.targetdeviation_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"	padding-left: 2px;\n"
"}\n"
"")
        self.targetdeviation_plainTextEdit.setLocale(QLocale(QLocale.English, QLocale.Canada))

        self.meshsize_layout_27.addWidget(self.targetdeviation_plainTextEdit)

        self.meshsize_label_31 = QLabel(self.parameters_widget)
        self.meshsize_label_31.setObjectName(u"meshsize_label_31")
        sizePolicy1.setHeightForWidth(self.meshsize_label_31.sizePolicy().hasHeightForWidth())
        self.meshsize_label_31.setSizePolicy(sizePolicy1)
        self.meshsize_label_31.setMinimumSize(QSize(0, 29))
        self.meshsize_label_31.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_27.addWidget(self.meshsize_label_31)

        self.horizontalSpacer_44 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.meshsize_layout_27.addItem(self.horizontalSpacer_44)


        self.meshingparameters_layout_4.addLayout(self.meshsize_layout_27)

        self.meshsize_layout_30 = QHBoxLayout()
        self.meshsize_layout_30.setSpacing(6)
        self.meshsize_layout_30.setObjectName(u"meshsize_layout_30")
        self.meshsize_layout_30.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.meshsize_layout_30.setContentsMargins(0, 0, -1, -1)
        self.maxiteration_plainTextEdit = QPlainTextEdit(self.parameters_widget)
        self.maxiteration_plainTextEdit.setObjectName(u"maxiteration_plainTextEdit")
        sizePolicy1.setHeightForWidth(self.maxiteration_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.maxiteration_plainTextEdit.setSizePolicy(sizePolicy1)
        self.maxiteration_plainTextEdit.setMinimumSize(QSize(65, 26))
        self.maxiteration_plainTextEdit.setMaximumSize(QSize(65, 26))
        self.maxiteration_plainTextEdit.setFont(font2)
        self.maxiteration_plainTextEdit.setLayoutDirection(Qt.LeftToRight)
        self.maxiteration_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"	padding-left: 2px;\n"
"}\n"
"")
        self.maxiteration_plainTextEdit.setLocale(QLocale(QLocale.English, QLocale.Canada))

        self.meshsize_layout_30.addWidget(self.maxiteration_plainTextEdit)

        self.meshsize_label_34 = QLabel(self.parameters_widget)
        self.meshsize_label_34.setObjectName(u"meshsize_label_34")
        sizePolicy1.setHeightForWidth(self.meshsize_label_34.sizePolicy().hasHeightForWidth())
        self.meshsize_label_34.setSizePolicy(sizePolicy1)
        self.meshsize_label_34.setMinimumSize(QSize(0, 29))
        self.meshsize_label_34.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_30.addWidget(self.meshsize_label_34)

        self.horizontalSpacer_47 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.meshsize_layout_30.addItem(self.horizontalSpacer_47)


        self.meshingparameters_layout_4.addLayout(self.meshsize_layout_30)

        self.meshsize_label_40 = QLabel(self.parameters_widget)
        self.meshsize_label_40.setObjectName(u"meshsize_label_40")
        sizePolicy1.setHeightForWidth(self.meshsize_label_40.sizePolicy().hasHeightForWidth())
        self.meshsize_label_40.setSizePolicy(sizePolicy1)
        self.meshsize_label_40.setMinimumSize(QSize(0, 20))
        self.meshsize_label_40.setMaximumSize(QSize(16777215, 20))

        self.meshingparameters_layout_4.addWidget(self.meshsize_label_40)

        self.meshsize_layout_33 = QHBoxLayout()
        self.meshsize_layout_33.setSpacing(6)
        self.meshsize_layout_33.setObjectName(u"meshsize_layout_33")
        self.meshsize_layout_33.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.meshsize_layout_33.setContentsMargins(0, 0, -1, -1)
        self.meshsize_label_37 = QLabel(self.parameters_widget)
        self.meshsize_label_37.setObjectName(u"meshsize_label_37")
        sizePolicy1.setHeightForWidth(self.meshsize_label_37.sizePolicy().hasHeightForWidth())
        self.meshsize_label_37.setSizePolicy(sizePolicy1)
        self.meshsize_label_37.setMinimumSize(QSize(0, 29))
        self.meshsize_label_37.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_33.addWidget(self.meshsize_label_37)

        self.customedx_plainTextEdit = QPlainTextEdit(self.parameters_widget)
        self.customedx_plainTextEdit.setObjectName(u"customedx_plainTextEdit")
        sizePolicy1.setHeightForWidth(self.customedx_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.customedx_plainTextEdit.setSizePolicy(sizePolicy1)
        self.customedx_plainTextEdit.setMinimumSize(QSize(57, 26))
        self.customedx_plainTextEdit.setMaximumSize(QSize(57, 26))
        self.customedx_plainTextEdit.setFont(font2)
        self.customedx_plainTextEdit.setLayoutDirection(Qt.LeftToRight)
        self.customedx_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"	padding-left: 2px;\n"
"}\n"
"")
        self.customedx_plainTextEdit.setLocale(QLocale(QLocale.English, QLocale.Canada))

        self.meshsize_layout_33.addWidget(self.customedx_plainTextEdit)

        self.meshsize_label_38 = QLabel(self.parameters_widget)
        self.meshsize_label_38.setObjectName(u"meshsize_label_38")
        sizePolicy1.setHeightForWidth(self.meshsize_label_38.sizePolicy().hasHeightForWidth())
        self.meshsize_label_38.setSizePolicy(sizePolicy1)
        self.meshsize_label_38.setMinimumSize(QSize(0, 29))
        self.meshsize_label_38.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_33.addWidget(self.meshsize_label_38)

        self.customedy_plainTextEdit = QPlainTextEdit(self.parameters_widget)
        self.customedy_plainTextEdit.setObjectName(u"customedy_plainTextEdit")
        sizePolicy1.setHeightForWidth(self.customedy_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.customedy_plainTextEdit.setSizePolicy(sizePolicy1)
        self.customedy_plainTextEdit.setMinimumSize(QSize(57, 26))
        self.customedy_plainTextEdit.setMaximumSize(QSize(57, 26))
        self.customedy_plainTextEdit.setFont(font2)
        self.customedy_plainTextEdit.setLayoutDirection(Qt.LeftToRight)
        self.customedy_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"	padding-left: 2px;\n"
"}\n"
"")
        self.customedy_plainTextEdit.setLocale(QLocale(QLocale.English, QLocale.Canada))

        self.meshsize_layout_33.addWidget(self.customedy_plainTextEdit)

        self.meshsize_label_39 = QLabel(self.parameters_widget)
        self.meshsize_label_39.setObjectName(u"meshsize_label_39")
        sizePolicy1.setHeightForWidth(self.meshsize_label_39.sizePolicy().hasHeightForWidth())
        self.meshsize_label_39.setSizePolicy(sizePolicy1)
        self.meshsize_label_39.setMinimumSize(QSize(0, 29))
        self.meshsize_label_39.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_33.addWidget(self.meshsize_label_39)

        self.customedz_plainTextEdit = QPlainTextEdit(self.parameters_widget)
        self.customedz_plainTextEdit.setObjectName(u"customedz_plainTextEdit")
        sizePolicy1.setHeightForWidth(self.customedz_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.customedz_plainTextEdit.setSizePolicy(sizePolicy1)
        self.customedz_plainTextEdit.setMinimumSize(QSize(57, 26))
        self.customedz_plainTextEdit.setMaximumSize(QSize(57, 26))
        self.customedz_plainTextEdit.setFont(font2)
        self.customedz_plainTextEdit.setLayoutDirection(Qt.LeftToRight)
        self.customedz_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"	padding-left: 2px;\n"
"}\n"
"")
        self.customedz_plainTextEdit.setLocale(QLocale(QLocale.English, QLocale.Canada))

        self.meshsize_layout_33.addWidget(self.customedz_plainTextEdit)

        self.horizontalSpacer_50 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.meshsize_layout_33.addItem(self.horizontalSpacer_50)


        self.meshingparameters_layout_4.addLayout(self.meshsize_layout_33)


        self.settingsinfo_widget_layout_6.addLayout(self.meshingparameters_layout_4)

        self.meshingparameters_layout_6 = QVBoxLayout()
        self.meshingparameters_layout_6.setSpacing(0)
        self.meshingparameters_layout_6.setObjectName(u"meshingparameters_layout_6")
        self.meshingparameters_layout_6.setContentsMargins(0, 0, -1, 0)
        self.meshingparameters_label_6 = QLabel(self.parameters_widget)
        self.meshingparameters_label_6.setObjectName(u"meshingparameters_label_6")
        self.meshingparameters_label_6.setMinimumSize(QSize(0, 20))
        self.meshingparameters_label_6.setMaximumSize(QSize(16777215, 20))
        self.meshingparameters_label_6.setStyleSheet(u"font: 700 italic 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.meshingparameters_label_6.setAlignment(Qt.AlignBottom|Qt.AlignRight|Qt.AlignTrailing)

        self.meshingparameters_layout_6.addWidget(self.meshingparameters_label_6)

        self.meshsize_label_52 = QLabel(self.parameters_widget)
        self.meshsize_label_52.setObjectName(u"meshsize_label_52")
        sizePolicy1.setHeightForWidth(self.meshsize_label_52.sizePolicy().hasHeightForWidth())
        self.meshsize_label_52.setSizePolicy(sizePolicy1)
        self.meshsize_label_52.setMinimumSize(QSize(0, 20))
        self.meshsize_label_52.setMaximumSize(QSize(16777215, 20))

        self.meshingparameters_layout_6.addWidget(self.meshsize_label_52)

        self.meshsize_layout_39 = QHBoxLayout()
        self.meshsize_layout_39.setSpacing(6)
        self.meshsize_layout_39.setObjectName(u"meshsize_layout_39")
        self.meshsize_layout_39.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.meshsize_layout_39.setContentsMargins(0, 0, -1, -1)
        self.meshsize_label_53 = QLabel(self.parameters_widget)
        self.meshsize_label_53.setObjectName(u"meshsize_label_53")
        sizePolicy1.setHeightForWidth(self.meshsize_label_53.sizePolicy().hasHeightForWidth())
        self.meshsize_label_53.setSizePolicy(sizePolicy1)
        self.meshsize_label_53.setMinimumSize(QSize(0, 29))
        self.meshsize_label_53.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_39.addWidget(self.meshsize_label_53)

        self.rpscustomedx_plainTextEdit = QPlainTextEdit(self.parameters_widget)
        self.rpscustomedx_plainTextEdit.setObjectName(u"rpscustomedx_plainTextEdit")
        sizePolicy1.setHeightForWidth(self.rpscustomedx_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.rpscustomedx_plainTextEdit.setSizePolicy(sizePolicy1)
        self.rpscustomedx_plainTextEdit.setMinimumSize(QSize(57, 26))
        self.rpscustomedx_plainTextEdit.setMaximumSize(QSize(57, 26))
        self.rpscustomedx_plainTextEdit.setFont(font2)
        self.rpscustomedx_plainTextEdit.setLayoutDirection(Qt.LeftToRight)
        self.rpscustomedx_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"	padding-left: 2px;\n"
"}\n"
"")
        self.rpscustomedx_plainTextEdit.setLocale(QLocale(QLocale.English, QLocale.Canada))

        self.meshsize_layout_39.addWidget(self.rpscustomedx_plainTextEdit)

        self.meshsize_label_54 = QLabel(self.parameters_widget)
        self.meshsize_label_54.setObjectName(u"meshsize_label_54")
        sizePolicy1.setHeightForWidth(self.meshsize_label_54.sizePolicy().hasHeightForWidth())
        self.meshsize_label_54.setSizePolicy(sizePolicy1)
        self.meshsize_label_54.setMinimumSize(QSize(0, 29))
        self.meshsize_label_54.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_39.addWidget(self.meshsize_label_54)

        self.rpscustomedy_plainTextEdit = QPlainTextEdit(self.parameters_widget)
        self.rpscustomedy_plainTextEdit.setObjectName(u"rpscustomedy_plainTextEdit")
        sizePolicy1.setHeightForWidth(self.rpscustomedy_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.rpscustomedy_plainTextEdit.setSizePolicy(sizePolicy1)
        self.rpscustomedy_plainTextEdit.setMinimumSize(QSize(57, 26))
        self.rpscustomedy_plainTextEdit.setMaximumSize(QSize(57, 26))
        self.rpscustomedy_plainTextEdit.setFont(font2)
        self.rpscustomedy_plainTextEdit.setLayoutDirection(Qt.LeftToRight)
        self.rpscustomedy_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"	padding-left: 2px;\n"
"}\n"
"")
        self.rpscustomedy_plainTextEdit.setLocale(QLocale(QLocale.English, QLocale.Canada))

        self.meshsize_layout_39.addWidget(self.rpscustomedy_plainTextEdit)

        self.meshsize_label_55 = QLabel(self.parameters_widget)
        self.meshsize_label_55.setObjectName(u"meshsize_label_55")
        sizePolicy1.setHeightForWidth(self.meshsize_label_55.sizePolicy().hasHeightForWidth())
        self.meshsize_label_55.setSizePolicy(sizePolicy1)
        self.meshsize_label_55.setMinimumSize(QSize(0, 29))
        self.meshsize_label_55.setMaximumSize(QSize(16777215, 29))

        self.meshsize_layout_39.addWidget(self.meshsize_label_55)

        self.rpscustomedz_plainTextEdit = QPlainTextEdit(self.parameters_widget)
        self.rpscustomedz_plainTextEdit.setObjectName(u"rpscustomedz_plainTextEdit")
        sizePolicy1.setHeightForWidth(self.rpscustomedz_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.rpscustomedz_plainTextEdit.setSizePolicy(sizePolicy1)
        self.rpscustomedz_plainTextEdit.setMinimumSize(QSize(57, 26))
        self.rpscustomedz_plainTextEdit.setMaximumSize(QSize(57, 26))
        self.rpscustomedz_plainTextEdit.setFont(font2)
        self.rpscustomedz_plainTextEdit.setLayoutDirection(Qt.LeftToRight)
        self.rpscustomedz_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #3d3d3d; /* Modern dark background */\n"
"    color: #abb2bf; /* Soft, modern text color */\n"
"    border: 1px solid #3c4049; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"	padding-left: 2px;\n"
"}\n"
"")
        self.rpscustomedz_plainTextEdit.setLocale(QLocale(QLocale.English, QLocale.Canada))

        self.meshsize_layout_39.addWidget(self.rpscustomedz_plainTextEdit)

        self.horizontalSpacer_56 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.meshsize_layout_39.addItem(self.horizontalSpacer_56)


        self.meshingparameters_layout_6.addLayout(self.meshsize_layout_39)


        self.settingsinfo_widget_layout_6.addLayout(self.meshingparameters_layout_6)

        self.verticalSpacer_8 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.settingsinfo_widget_layout_6.addItem(self.verticalSpacer_8)

        self.horizontalLayout_10 = QHBoxLayout()
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.horizontalLayout_10.setContentsMargins(-1, 0, -1, -1)
        self.horizontalSpacer_5 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_10.addItem(self.horizontalSpacer_5)

        self.saveparameters_pushButton = QPushButton(self.parameters_widget)
        self.saveparameters_pushButton.setObjectName(u"saveparameters_pushButton")
        sizePolicy1.setHeightForWidth(self.saveparameters_pushButton.sizePolicy().hasHeightForWidth())
        self.saveparameters_pushButton.setSizePolicy(sizePolicy1)
        self.saveparameters_pushButton.setMinimumSize(QSize(70, 25))
        self.saveparameters_pushButton.setMaximumSize(QSize(70, 25))
        self.saveparameters_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_10.addWidget(self.saveparameters_pushButton)

        self.loadparameters_pushButton = QPushButton(self.parameters_widget)
        self.loadparameters_pushButton.setObjectName(u"loadparameters_pushButton")
        sizePolicy1.setHeightForWidth(self.loadparameters_pushButton.sizePolicy().hasHeightForWidth())
        self.loadparameters_pushButton.setSizePolicy(sizePolicy1)
        self.loadparameters_pushButton.setMinimumSize(QSize(70, 25))
        self.loadparameters_pushButton.setMaximumSize(QSize(70, 25))
        self.loadparameters_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_10.addWidget(self.loadparameters_pushButton)


        self.settingsinfo_widget_layout_6.addLayout(self.horizontalLayout_10)


        self.gridLayout.addWidget(self.parameters_widget, 0, 4, 1, 1)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        self.settingicon_pushButton.toggled.connect(self.setting_pushButton.setChecked)
        self.importmeasurementicon_pushButton.toggled.connect(self.importmeasurement_pushButton.setChecked)
        self.setting_pushButton.toggled.connect(self.info_pushButton.setDisabled)
        self.importrpsicon_pushButton.toggled.connect(self.importrps_pushButton.setChecked)
        self.infoicon_pushButton.toggled.connect(self.info_pushButton.setChecked)
        self.importgeometryicon_pushButton.toggled.connect(self.importgeometry_pushButton.setChecked)
        self.setting_pushButton.toggled.connect(self.settingsinfo_widget.setVisible)
        self.info_pushButton.toggled.connect(self.settingsinfo_widget.setVisible)
        self.settingicon_pushButton.toggled.connect(self.infoicon_pushButton.setDisabled)
        self.menu_pushButton.toggled.connect(self.process_name_widget.setVisible)
        self.info_pushButton.toggled.connect(self.setting_pushButton.setDisabled)
        self.importrps_pushButton.toggled.connect(self.importrpsicon_pushButton.setChecked)
        self.menu_pushButton.toggled.connect(self.icon_widget.setHidden)
        self.importfixtureicon_pushButton.toggled.connect(self.importfixture_pushButton.setChecked)
        self.parameters_pushButton.toggled.connect(self.parameters_widget.setVisible)
        self.importgeometry_pushButton.toggled.connect(self.importgeometryicon_pushButton.setChecked)
        self.importmeasurement_pushButton.toggled.connect(self.importmeasurementicon_pushButton.setChecked)
        self.info_pushButton.toggled.connect(self.infoicon_pushButton.setChecked)
        self.setting_pushButton.toggled.connect(self.settingicon_pushButton.setChecked)
        self.infoicon_pushButton.toggled.connect(self.settingicon_pushButton.setDisabled)
        self.importfixture_pushButton.toggled.connect(self.importfixtureicon_pushButton.setChecked)
        self.morphicon_pushButton.toggled.connect(self.morph_pushButton.setChecked)
        self.morph_pushButton.toggled.connect(self.morphicon_pushButton.setChecked)
        self.gcicon_pushButton.toggled.connect(self.gc_pushButton.setChecked)
        self.gc_pushButton.toggled.connect(self.gcicon_pushButton.setChecked)
        self.rpsicon_pushButton.toggled.connect(self.rps_pushButton.setChecked)
        self.rps_pushButton.toggled.connect(self.rpsicon_pushButton.setChecked)
        self.manageresults_pushButton.toggled.connect(self.verticalWidget.setVisible)

        self.settingsinfo_stackwidget.setCurrentIndex(0)
        self.pages_stackedWidget.setCurrentIndex(4)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Hexagon - Virtual Fixture v2.2.1", None))
        self.label_12.setText(QCoreApplication.translate("MainWindow", u"Settings", None))
        self.newproject_pushButton.setText(QCoreApplication.translate("MainWindow", u" New project", None))
        self.saveproject_pushButton.setText(QCoreApplication.translate("MainWindow", u" Save project", None))
        self.openproject_pushButton.setText(QCoreApplication.translate("MainWindow", u"Open project", None))
        self.manageresults_pushButton.setText(QCoreApplication.translate("MainWindow", u"Manage results", None))
        self.opensw_pushButton.setText(QCoreApplication.translate("MainWindow", u" Open\n"
" Simufact Welding", None))
        self.openfolder_pushButton.setText(QCoreApplication.translate("MainWindow", u" Open\n"
" Project folder", None))
        self.exportpolywork_pushButton.setText(QCoreApplication.translate("MainWindow", u" Export\n"
" to Polywork", None))
        self.updatematerial_pushButton.setText(QCoreApplication.translate("MainWindow", u" Update\n"
" material's library", None))
        self.pathsettings_pushButton.setText(QCoreApplication.translate("MainWindow", u" Paths' settings", None))
        self.label_14.setText(QCoreApplication.translate("MainWindow", u"Workflow", None))
        self.label_8.setText("")
        self.help_pushButton.setText(QCoreApplication.translate("MainWindow", u" Help", None))
        self.label.setText("")
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"DATA\n"
"Collection", None))
        self.importgeometryicon_pushButton.setText("")
        self.importmeasurementicon_pushButton.setText("")
        self.importfixtureicon_pushButton.setText("")
        self.importrpsicon_pushButton.setText("")
        self.label_17.setText(QCoreApplication.translate("MainWindow", u"Processes", None))
        self.morphicon_pushButton.setText("")
        self.gcicon_pushButton.setText("")
        self.rpsicon_pushButton.setText("")
        self.settingicon_pushButton.setText("")
        self.infoicon_pushButton.setText("")
        self.menu_pushButton.setText("")
        self.label_4.setText(QCoreApplication.translate("MainWindow", u" - Go virtual, spend minimum in physical devices - ", None))
        self.label_68.setText(QCoreApplication.translate("MainWindow", u"VMC, HMI", None))
        self.label_11.setText("")
        self.parameters_pushButton.setText("")
        self.label_6.setText(QCoreApplication.translate("MainWindow", u"# Import geometry", None))
        self.geometryfile_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"Select geometry or mesh file here -->", None))
        self.geometryfile_pushButton.setText(QCoreApplication.translate("MainWindow", u" Import file", None))
        self.meshsize_label_3.setText(QCoreApplication.translate("MainWindow", u" Material type:  ", None))
        self.materialtype_comboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"Steel", None))
        self.materialtype_comboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"Aluminum", None))
        self.materialtype_comboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"Stainless steel", None))

        self.meshsize_label_4.setText(QCoreApplication.translate("MainWindow", u" Material:  ", None))
        self.advancedmaterial_pushButton.setText(QCoreApplication.translate("MainWindow", u"Advanced\n"
"Material", None))
        self.advancedmeshing_pushButton.setText(QCoreApplication.translate("MainWindow", u"Advanced\n"
"Meshing", None))
        self.meshsize_label_5.setText(QCoreApplication.translate("MainWindow", u" Geometry preview ", None))
        self.meshsize_label_6.setText(QCoreApplication.translate("MainWindow", u" CAD Geometry(Mesh)", None))
        self.label_15.setText(QCoreApplication.translate("MainWindow", u"# Import Measurement data", None))
        self.measurementfile_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"Select measurement data (.stl) here -->", None))
        self.measurementfile_pushButton.setText(QCoreApplication.translate("MainWindow", u" Import file", None))
        self.meshsize_label_15.setText(QCoreApplication.translate("MainWindow", u" Data preview ", None))
        self.meshsize_label_17.setText(QCoreApplication.translate("MainWindow", u"CAD Geometry // ", None))
        self.meshsize_label_16.setText(QCoreApplication.translate("MainWindow", u" Measurement", None))
        self.label_9.setText(QCoreApplication.translate("MainWindow", u"# Set up Holding Fixtures", None))
        self.holdingfixturefile_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"Select fixture's info file (.csv) here -->", None))
        self.holdingfixturefile_pushButton.setText(QCoreApplication.translate("MainWindow", u" Import file", None))
        self.meshsize_label_13.setText("")
        self.selectholdingfixture_pushButton.setText(QCoreApplication.translate("MainWindow", u"Manually select", None))
        self.meshsize_label_18.setText(QCoreApplication.translate("MainWindow", u" Fixtures preview ", None))
        self.meshsize_label_19.setText(QCoreApplication.translate("MainWindow", u" CAD Geometry // ", None))
        self.meshsize_label_20.setText(QCoreApplication.translate("MainWindow", u"Fixed points", None))
        self.label_16.setText(QCoreApplication.translate("MainWindow", u"# Set up RPS registration", None))
        self.rpsfile_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"Select F-type/H-type RPS info file (.csv) here -->", None))
        self.rpsfile_pushButton.setText(QCoreApplication.translate("MainWindow", u" Import file", None))
        self.meshsize_label_14.setText("")
        self.selectrps_pushButton.setText(QCoreApplication.translate("MainWindow", u"Manually select", None))
        self.meshsize_label_21.setText(QCoreApplication.translate("MainWindow", u" RPS preview ", None))
        self.meshsize_label_22.setText(QCoreApplication.translate("MainWindow", u" CAD Geometry // ", None))
        self.meshsize_label_23.setText(QCoreApplication.translate("MainWindow", u"RPS coords ", None))
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"# Morphing", None))
        self.meshsize_label_8.setText(QCoreApplication.translate("MainWindow", u" Level of detail:  ", None))
        self.morphlevel_comboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"very_low", None))
        self.morphlevel_comboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"low", None))
        self.morphlevel_comboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"medium", None))
        self.morphlevel_comboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"high", None))

        self.startmorphing_pushButton.setText(QCoreApplication.translate("MainWindow", u" Start", None))
        self.stopmorphing_pushButton.setText(QCoreApplication.translate("MainWindow", u" Stop", None))
        self.adjustholes_pushButton.setText(QCoreApplication.translate("MainWindow", u"Adjust\n"
"Holes", None))
        self.meshsize_label_10.setText(QCoreApplication.translate("MainWindow", u" Morphing accuracy preview ", None))
        self.meshsize_label_11.setText(QCoreApplication.translate("MainWindow", u" Morphed geometry // Measurement data ", None))
        self.showmorphresult_pushButton.setText(QCoreApplication.translate("MainWindow", u"Show result", None))
        self.label_18.setText(QCoreApplication.translate("MainWindow", u"# Gravity compensation", None))
        self.meshsize_label_9.setText(QCoreApplication.translate("MainWindow", u" Gravity direction:   ", None))
        self.gravitydirection_comboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"+X", None))
        self.gravitydirection_comboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"-X", None))
        self.gravitydirection_comboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"+Y", None))
        self.gravitydirection_comboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"-Y", None))
        self.gravitydirection_comboBox.setItemText(4, QCoreApplication.translate("MainWindow", u"+Z", None))
        self.gravitydirection_comboBox.setItemText(5, QCoreApplication.translate("MainWindow", u"-Z", None))
        self.gravitydirection_comboBox.setItemText(6, QCoreApplication.translate("MainWindow", u"Customed direction", None))

        self.startgc_pushButton.setText(QCoreApplication.translate("MainWindow", u" Start", None))
        self.stopgc_pushButton.setText(QCoreApplication.translate("MainWindow", u" Stop", None))
        self.meshsize_label_12.setText(QCoreApplication.translate("MainWindow", u" Compensation result preview ", None))
        self.meshsize_label_24.setText(QCoreApplication.translate("MainWindow", u"Compensated geometry // Morphed geometry ", None))
        self.showgcmodel_pushButton.setText(QCoreApplication.translate("MainWindow", u"Show model", None))
        self.showgcresult_pushButton.setText(QCoreApplication.translate("MainWindow", u"Show result", None))
        self.label_19.setText(QCoreApplication.translate("MainWindow", u"# Clamping to vehicle's coordinate", None))
        self.meshsize_label_27.setText(QCoreApplication.translate("MainWindow", u" Manual H-type RPS selection: ", None))
        self.selecthtype_pushButton.setText(QCoreApplication.translate("MainWindow", u"Select holes", None))
        self.fixedhtype_checkBox.setText(QCoreApplication.translate("MainWindow", u"fixed holes' displacement", None))
        self.startrps_pushButton.setText(QCoreApplication.translate("MainWindow", u" Start", None))
        self.stoprps_pushButton.setText(QCoreApplication.translate("MainWindow", u" Stop", None))
        self.meshsize_label_28.setText(QCoreApplication.translate("MainWindow", u" Gravity direction: ", None))
        self.rpsgravitydirection_comboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"+X", None))
        self.rpsgravitydirection_comboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"-X", None))
        self.rpsgravitydirection_comboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"+Y", None))
        self.rpsgravitydirection_comboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"-Y", None))
        self.rpsgravitydirection_comboBox.setItemText(4, QCoreApplication.translate("MainWindow", u"+Z", None))
        self.rpsgravitydirection_comboBox.setItemText(5, QCoreApplication.translate("MainWindow", u"-Z", None))
        self.rpsgravitydirection_comboBox.setItemText(6, QCoreApplication.translate("MainWindow", u"Customed direction", None))

        self.clearhrps_pushButton.setText(QCoreApplication.translate("MainWindow", u"Clear\n"
"H-RPS", None))
        self.meshsize_label_25.setText(QCoreApplication.translate("MainWindow", u" RPS clamping result preview ", None))
        self.meshsize_label_26.setText(QCoreApplication.translate("MainWindow", u" Clamped geometry // CAD geometry ", None))
        self.showrpsmodel_pushButton.setText(QCoreApplication.translate("MainWindow", u"Show model", None))
        self.showrpsresult_pushButton.setText(QCoreApplication.translate("MainWindow", u"Show result", None))
        self.label_2.setText("")
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"Virtual", None))
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"Fixture", None))
        self.label_13.setText(QCoreApplication.translate("MainWindow", u"DATA\n"
"Collection", None))
        self.importgeometry_pushButton.setText(QCoreApplication.translate("MainWindow", u" Import\n"
" geometry", None))
        self.importmeasurement_pushButton.setText(QCoreApplication.translate("MainWindow", u" Import\n"
" Measurement", None))
        self.importfixture_pushButton.setText(QCoreApplication.translate("MainWindow", u" Set up Holding\n"
" Fixture info", None))
        self.importrps_pushButton.setText(QCoreApplication.translate("MainWindow", u" Set up\n"
" RPS info", None))
        self.label_29.setText(QCoreApplication.translate("MainWindow", u"Processes", None))
        self.morph_pushButton.setText(QCoreApplication.translate("MainWindow", u" Morphing", None))
        self.gc_pushButton.setText(QCoreApplication.translate("MainWindow", u" Gravity\n"
" Compensation", None))
        self.rps_pushButton.setText(QCoreApplication.translate("MainWindow", u" Clamping to\n"
" Vehicle's coord", None))
        self.setting_pushButton.setText(QCoreApplication.translate("MainWindow", u" Settings", None))
        self.info_pushButton.setText(QCoreApplication.translate("MainWindow", u" Info", None))
        self.label_23.setText(QCoreApplication.translate("MainWindow", u"Parameters", None))
        self.generalparameters_label.setText(QCoreApplication.translate("MainWindow", u" - Workflow parameters -", None))
        self.gcactivation_checkBox.setText(QCoreApplication.translate("MainWindow", u"GC activation", None))
        self.geometrytype_comboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"Single-part", None))
        self.geometrytype_comboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"Multi-parts", None))

        self.meshsize_label_2.setText(QCoreApplication.translate("MainWindow", u"Geometry type", None))
        self.smp_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"6", None))
        self.smp_label.setText(QCoreApplication.translate("MainWindow", u"SMP cores", None))
        self.ddm_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"1", None))
        self.ddm_label.setText(QCoreApplication.translate("MainWindow", u"DDM domains", None))
        self.meshingparameters_label.setText(QCoreApplication.translate("MainWindow", u" - Meshing parameters -", None))
        self.cadhealing_checkBox.setText(QCoreApplication.translate("MainWindow", u"CAD surface healing", None))
        self.meshsize_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"2.0", None))
        self.meshsize_label.setText(QCoreApplication.translate("MainWindow", u"Mesh size (mm)", None))
        self.curvaturerefine_checkBox.setText(QCoreApplication.translate("MainWindow", u"Curvature refinement", None))
        self.morphingparameters_label.setText(QCoreApplication.translate("MainWindow", u" - Morphing parameters -", None))
        self.matchmode_comboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"scan_incomplete", None))
        self.matchmode_comboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"complete", None))
        self.matchmode_comboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"cad_incomplete", None))

        self.meshsize_label_7.setText(QCoreApplication.translate("MainWindow", u" Match mode", None))
        self.bestfit_checkBox.setText(QCoreApplication.translate("MainWindow", u"Best-fit (before morphing)", None))
        self.transformation_checkBox.setText(QCoreApplication.translate("MainWindow", u"Result with transformation", None))
        self.singlegeometry_checkBox.setText(QCoreApplication.translate("MainWindow", u"Result as single geometry", None))
        self.surfacetolerance_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"60.0", None))
        self.smp_label_2.setText(QCoreApplication.translate("MainWindow", u"Surface tolerance (\u00b0)", None))
        self.ignoreoutlier_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"0.5", None))
        self.ddm_label_2.setText(QCoreApplication.translate("MainWindow", u"Ignore outlier (%)", None))
        self.meshingparameters_label_4.setText(QCoreApplication.translate("MainWindow", u" - Compensation parameters -", None))
        self.simplifiedgc_checkBox.setText(QCoreApplication.translate("MainWindow", u"Simplified compensation", None))
        self.pinnumber_comboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"3", None))
        self.pinnumber_comboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"4", None))

        self.meshsize_label_36.setText(QCoreApplication.translate("MainWindow", u"Number of pins", None))
        self.searchradius_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"3.0", None))
        self.meshsize_label_29.setText(QCoreApplication.translate("MainWindow", u"Search radius (mm)", None))
        self.targetdeviation_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"0.05", None))
        self.meshsize_label_31.setText(QCoreApplication.translate("MainWindow", u"Target deviation (mm)", None))
        self.maxiteration_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"6", None))
        self.meshsize_label_34.setText(QCoreApplication.translate("MainWindow", u"Max iteration", None))
        self.meshsize_label_40.setText(QCoreApplication.translate("MainWindow", u"Customed gravity direction", None))
        self.meshsize_label_37.setText(QCoreApplication.translate("MainWindow", u"X", None))
        self.customedx_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"0.0", None))
        self.meshsize_label_38.setText(QCoreApplication.translate("MainWindow", u" Y", None))
        self.customedy_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"0.0", None))
        self.meshsize_label_39.setText(QCoreApplication.translate("MainWindow", u" Z", None))
        self.customedz_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"-1.0", None))
        self.meshingparameters_label_6.setText(QCoreApplication.translate("MainWindow", u" - RPS parameters -", None))
        self.meshsize_label_52.setText(QCoreApplication.translate("MainWindow", u"Customed gravity direction", None))
        self.meshsize_label_53.setText(QCoreApplication.translate("MainWindow", u"X", None))
        self.rpscustomedx_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"0.0", None))
        self.meshsize_label_54.setText(QCoreApplication.translate("MainWindow", u" Y", None))
        self.rpscustomedy_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"0.0", None))
        self.meshsize_label_55.setText(QCoreApplication.translate("MainWindow", u" Z", None))
        self.rpscustomedz_plainTextEdit.setPlainText(QCoreApplication.translate("MainWindow", u"-1.0", None))
        self.saveparameters_pushButton.setText(QCoreApplication.translate("MainWindow", u"Save", None))
        self.loadparameters_pushButton.setText(QCoreApplication.translate("MainWindow", u"Load", None))
    # retranslateUi


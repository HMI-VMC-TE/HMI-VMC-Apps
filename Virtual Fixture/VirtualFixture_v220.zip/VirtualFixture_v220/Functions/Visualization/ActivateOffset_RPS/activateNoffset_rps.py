import os, sys
import csv, json
import vtk
import xml.etree.ElementTree as ET

from PySide6.QtWidgets import QDialog, QCheckBox, QTableWidgetItem, QMainWindow
from PySide6.QtCore import Qt

from UI.RPSActivation_ui import Ui_RPSActivateWindow
from UI.message_ui import Ui_MessageWindow


class RPSActivationOffset_window(QDialog, Ui_RPSActivateWindow):
    def __init__(self, project_folder):
        super().__init__()
        self.setupUi(self)
        self.project_folder = project_folder

        # set up the message window
        self.message_window = MessageWindow_window()

        # connect the buttons
        self.set_pushButton.clicked.connect(self.modxml_export_json)  # accept the changes

        # load the contents to visualize the teble window
        self.table_rps_points = None
        self.cad_change_count = 0
        self.current_xml_tree = None
        self.table_rps_points, self.cad_change_count, self.current_xml_tree, self.geometry_xml_file = self.load_table_contents()
        self.show_rps_points_in_table()
    
    def load_table_contents(self):
        # 1 read the rps csv file to store the cad_coords
        cad_rps_points = {}
        cad_rps_file = os.path.normpath(os.path.join(self.project_folder, 
                                                     r'0-Inputs\1-RPS\FType_RPS.csv'))
        try:
            with open(cad_rps_file, 'r') as csvfile:
                reader = csv.reader(csvfile)
                for row in reader:
                    label = row[0].strip()
                    cad_coords = [float(coord.strip()) for coord in row[1:4]]
                    node_type = row[4].strip()
                    cad_rps_points[label] = {
                        "node_type": node_type,
                        "cad_coords_mm": cad_coords,
                        "normal_direction": None
                    }
        except Exception as e:
            print(f"Error reading CAD RPS points file: {e}")
            self.message_window.show_message("Error reading CAD RPS points file.")
            return
        
        # 2 Calculate the normal direction for each RPS point at the surface of CAD STL
        cad_stl_file = os.path.normpath(os.path.join(self.project_folder, 
                                                     r'0-Inputs\0-CAD\CAD_geometry.stl'))
        try:
            # Read the STL file
            reader = vtk.vtkSTLReader()
            reader.SetFileName(cad_stl_file)
            reader.Update()

            # Compute normals using vtkPolyDataNormals
            normal_generator = vtk.vtkPolyDataNormals()
            normal_generator.SetInputConnection(reader.GetOutputPort())
            normal_generator.ComputePointNormalsOn()
            normal_generator.ComputeCellNormalsOff()
            normal_generator.SplittingOff()  # prevent normals from splitting at sharp edges
            normal_generator.ConsistencyOn()
            normal_generator.AutoOrientNormalsOn()
            normal_generator.Update()
            
            polydata_with_normals = normal_generator.GetOutput()

            # Create a point locator
            locator = vtk.vtkPointLocator()
            locator.SetDataSet(polydata_with_normals)
            locator.BuildLocator()

            for label, data in cad_rps_points.items():
                if 'H' not in data['node_type']:
                    # Find the closest point on the surface to the RPS point
                    point_id = locator.FindClosestPoint(data["cad_coords_mm"])

                    # Get the normal at that point
                    normals = polydata_with_normals.GetPointData().GetNormals()
                    if normals is not None:
                        normal = normals.GetTuple(point_id)
                        data["normal_direction"] = list(normal)
                    else:
                        print(f"Normals not found in polydata for RPS point {label}")
                        data["normal_direction"] = None
        except Exception as e:
            print(f"Error processing CAD STL file for normal direction: {e}")
            self.message_window.show_message("Error processing CAD STL file for normal direction.")
            return

        # 3 open project and find the right xml file to extract the RPS points
        sw_project_folder = os.path.normpath(os.path.join(self.project_folder, 
                                                          r"1-SWProject\Simufact_Project_File"))
        geometries_xml_folder = os.path.join(sw_project_folder, '_entities', 'geometries')
        rps_xml_file = None
        for file in os.listdir(geometries_xml_folder):
            if file.endswith('.xml') and ('RPS' in file or ('GC' in file and 'result' in file) or 'Morphed' in file):
                rps_xml_file = os.path.join(geometries_xml_folder, file)
                print("Found RPS or GC result XML file:", rps_xml_file)
                break
        if rps_xml_file is None:
            self.message_window.show_message("No RPS or GC result XML file found in the geometries folder.")
            return
        try:
            tree = ET.parse(rps_xml_file)
            root = tree.getroot()
        except ET.ParseError as e:
            self.message_window.show_message(f"Error parsing XML file: {e}")
            raise ValueError(f"Error parsing XML file {rps_xml_file}: {e}")
        
        rps_points_data = {}
        rps_locations = root.find('.//rps_locations')
        if rps_locations is None:
            raise ValueError("No RPS locations found in the XML file.")
        for rps_location in rps_locations.findall('rps_location'):
            current_coords = rps_location.find('current_coords')
            target_coords = rps_location.find('target_coords')
            rps_points_data[rps_location.get('node_label')] = {
                "node_type": rps_location.get('node_type'),
                "active": True,
                "offset_mm": 0.0,
                "current_coords_mm": [float(current_coords.get('x'))*1000,
                                    float(current_coords.get('y'))*1000,
                                    float(current_coords.get('z'))*1000],
                "target_coords_mm": [float(target_coords.get('x'))*1000,
                                    float(target_coords.get('y'))*1000,
                                    float(target_coords.get('z'))*1000],
                "normal_direction": None
            }
        
        rps_points_ordered = {}
        for key in cad_rps_points.keys():
            if key in rps_points_data :
                rps_points_ordered[key] = rps_points_data[key]
                rps_points_ordered[key]["normal_direction"] = cad_rps_points[key]["normal_direction"]

        # 4 check whether the target coords of rps_points_ordered is the same as the cad_rps_points
        # if the distance is more than 0.05 mm change the target coords to match the cad_rps_points
        coords_tolerance = 0.05  # mm
        change_tocad_count = 0
        for label, data in rps_points_ordered.items():
            if 'H' not in data['node_type']:
                cad_coords = cad_rps_points[label]["cad_coords_mm"]
                target_coords = data["target_coords_mm"]
                
                distance = ((cad_coords[0] - target_coords[0]) ** 2 +
                            (cad_coords[1] - target_coords[1]) ** 2 +
                            (cad_coords[2] - target_coords[2]) ** 2) ** 0.5
                
                #print(distance)
                if distance > coords_tolerance:
                    print(f"Updating target coord back to CAD RPS for {label}: {target_coords} -> {cad_coords}")
                    data["target_coords_mm"] = cad_coords

                    try:
                        for rps_location in root.findall('.//rps_location'):
                            node_label = rps_location.get('node_label')
                            if node_label == label:
                                target_coords = rps_location.find('target_coords')
                                if target_coords is not None:
                                    new_target_coords = rps_points_ordered[node_label]["target_coords_mm"]
                                    target_coords.set('x', str(cad_coords[0] / 1000))  # convert back to meters
                                    target_coords.set('y', str(cad_coords[1] / 1000))
                                    target_coords.set('z', str(cad_coords[2] / 1000))
                                    print(f"Updated target coords for {label} in XML to match CAD RPS.")
                                    change_tocad_count += 1
                    except Exception as e:
                        print(f"Error updating XML for {label}: {e}")
        #print(rps_points_ordered)
        
        return rps_points_ordered, change_tocad_count, tree, rps_xml_file

    def show_rps_points_in_table(self):
        self.tableWidget.clear()
        columns = ['Activation', 'Name/Label', 'Fixed direction', 'Offset (mm)']
        self.tableWidget.setColumnCount(len(columns))
        self.tableWidget.setHorizontalHeaderLabels(columns)

        len_table = len(self.table_rps_points)
        self.tableWidget.setRowCount(len_table)

        for row, (label, data) in enumerate(self.table_rps_points.items()):
            # Activation checkbox
            activation_checkbox = QCheckBox()
            activation_checkbox.setChecked(data['active'])
            self.tableWidget.setCellWidget(row, 0, activation_checkbox)

            # Name/Label
            label_item = QTableWidgetItem(label)
            self.tableWidget.setItem(row, 1, label_item)

            # Fixed direction
            fixed_direction_item = QTableWidgetItem(data['node_type'])
            self.tableWidget.setItem(row, 2, fixed_direction_item)

            # Offset (mm)
            offset_item = QTableWidgetItem(str(data['offset_mm']))
            self.tableWidget.setItem(row, 3, offset_item)

    def modxml_export_json(self):
        # update the self.table_rps_points with the current state of the table
        for row in range(self.tableWidget.rowCount()):
            activation_checkbox = self.tableWidget.cellWidget(row, 0)
            label_item = self.tableWidget.item(row, 1)
            fixed_direction_item = self.tableWidget.item(row, 2)
            offset_item = self.tableWidget.item(row, 3)

            label = label_item.text() if label_item else ''
            active = activation_checkbox.isChecked()
            fixed_direction = fixed_direction_item.text()
            offset_mm = float(offset_item.text())

            for label_inner, data in self.table_rps_points.items():
                if label == label_inner:
                    data['active'] = active
                    data['node_type'] = fixed_direction
                    data['offset_mm'] = offset_mm

        #print(self.table_rps_points)
        
        # update the xml tree with the new values of the offset_mm
        offset_count = 0
        root = self.current_xml_tree.getroot()
        for label, data in self.table_rps_points.items():
            if ('H' not in data['node_type'] and data["normal_direction"] is not None and
                data["offset_mm"] != 0.0):
                normal = data["normal_direction"]
                offset_mm = data["offset_mm"]
                
                # Calculate the offset in each direction
                offset_coords = [
                    data["target_coords_mm"][0] + normal[0] * offset_mm,
                    data["target_coords_mm"][1] + normal[1] * offset_mm,
                    data["target_coords_mm"][2] + normal[2] * offset_mm
                ]
                
                # Update the target coords
                data["target_coords_mm"] = offset_coords

                # update the rps_location in the XML
                try:
                    for rps_location in root.findall('.//rps_location'):
                        node_label = rps_location.get('node_label')
                        if node_label == label:
                            target_coords = rps_location.find('target_coords')
                            if target_coords is not None:
                                target_coords.set('x', str(offset_coords[0] / 1000))  # convert back to meters
                                target_coords.set('y', str(offset_coords[1] / 1000))
                                target_coords.set('z', str(offset_coords[2] / 1000))
                                print(f"Updated target coords for {label} with offset in XML.")
                                offset_count += 1
                except Exception as e:
                    print(f"Error updating XML for {label} with offset: {e}")
        
        # write new XML file replacing the old one
        if self.cad_change_count > 0 or offset_count > 0:
            try:
                self.current_xml_tree.write(self.geometry_xml_file, encoding='utf-8', xml_declaration=True)
                print(f"Updated XML file written to {self.geometry_xml_file}")
            except Exception as e:
                print(f"Error writing updated XML file: {e}")
                self.message_window.show_message("Error writing updated XML file.")
                return
        
        # write the active RPS points to a JSON file
        rps_json_file = os.path.normpath(os.path.join(self.project_folder, 
                                                      r'0-Inputs\1-RPS\RPS_activate.json'))
        try:
            with open(rps_json_file, 'w') as jsonfile:
                json.dump(self.table_rps_points, jsonfile, indent=4)
            print(f"Active RPS points written to {rps_json_file}")
            self.close()  # close the dialog after writing
        except Exception as e:
            print(f"Error writing RPS points to JSON file: {e}")
            self.message_window.show_message("Error writing RPS points to JSON file.")
            return


# Warning message class
class MessageWindow_window(QMainWindow, Ui_MessageWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setWindowModality(Qt.ApplicationModal)  # Set the window modality to ApplicationModal

    def show_message(self, message):
        self.message_label.setText(message)
        self.show()


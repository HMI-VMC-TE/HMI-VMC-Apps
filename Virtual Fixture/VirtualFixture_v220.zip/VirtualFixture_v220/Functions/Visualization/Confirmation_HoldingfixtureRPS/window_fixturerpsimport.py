import csv, json
import vtk
from PySide6.QtWidgets import QDialog, QCheckBox, QTableWidgetItem, QMainWindow
from PySide6.QtCore import Qt

from UI.fixturetable_ui import Ui_HoldingFixtureWindow
from UI.RPStable_ui import Ui_RPSTableWindow
from UI.message_ui import Ui_MessageWindow

class HoldingFixtureConfirmation_window(QDialog, Ui_HoldingFixtureWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.point_limit = 4
        self.export_csv_path = None
        self.export_json_path = None

        # set up the message window
        self.message_window = MessageWindow_window()

        # set the button functions
        self.set_pushButton.clicked.connect(self.export_holding_fixture)

    def load_csv(self, csv_file_path, export_csv_path, export_json_path):
        self.export_csv_path = export_csv_path
        self.export_json_path = export_json_path
        self.tableWidget.clear()
        column = ["Status", "X-coords(mm)", "Y-coords(mm)", "Z-coords(mm)", "Fixed direction"]
        self.tableWidget.setColumnCount(len(column))
        self.tableWidget.setHorizontalHeaderLabels(column)

        # read the csv file and show the content in the plainTextEdit
        points = []
        with open(csv_file_path, 'r') as f:
            reader = csv.reader(f)
            row_num = 0
            for row in reader:
                row_num += 1
                if len(row) == 3 and row_num <= self.point_limit:
                    points.append(["active", row[0], row[1], row[2]])
                elif len(row) == 3 and row_num > self.point_limit:
                    points.append(["inactive", row[0], row[1], row[2]])
                elif len(row) >= 4 and row_num <= self.point_limit:
                    points.append(["active", row[1], row[2], row[3]])
                elif len(row) >= 4 and row_num > self.point_limit:
                    points.append(["inactive", row[1], row[2], row[3]])
                elif len(row) < 3:
                    print("GUI : CSV file does not have enough columns")
                    self.message_window.show_message("CSV file does not have enough columns")
                    return
        self.tableWidget.setRowCount(len(points))

        # set the fixture direction
        try:
            direction_dict = self.check_holding_fixture_direction(points)
        except:
            direction_dict = {}
            for i in range(len(points)):
                direction_dict[str(i + 1)] = ["x", "y", "z"]

        for i, point in enumerate(points):
            check_box = QCheckBox(self.tableWidget)
            check_box.setChecked(True if point[0] == "active" else False)
            # set the checkbox in the middle of the cell
            check_box.setStyleSheet("margin-left:50%; margin-right:50%;")
            self.tableWidget.insertRow(i)
            self.tableWidget.setCellWidget(i, 0, check_box)
            for j in range(1, 4):
                item = QTableWidgetItem(str(point[j]))
                self.tableWidget.setItem(i, j, item)
            
            direction_str = ''
            for dir in direction_dict[str(i + 1)]:
                direction_str += dir
                
            self.tableWidget.setItem(i, 4, QTableWidgetItem(direction_str))
    
    def export_holding_fixture(self):
        # read the active points from the tableWidget and write to the export csv file
        points = []
        point_count = 0
        export_direction_dict = {}
        for i in range(self.tableWidget.rowCount()):
            check_box = self.tableWidget.cellWidget(i, 0)
            if isinstance(check_box, QCheckBox) and check_box.isChecked():
                point = []
                point_count += 1
                for j in range(1, 4):
                    point.append(self.tableWidget.item(i, j).text())
                # insert "-1" to the first column
                points.append([str(point_count), point[0], point[1], point[2]])

                # get the fixed direction from the tableWidget
                export_direction_dict[str(point_count)] = []
                fixed_drection = self.tableWidget.item(i, 4).text()
                for dir in fixed_drection:
                    export_direction_dict[str(point_count)].append(dir)
        try:
            # write the points to the export csv file
            with open(self.export_csv_path, 'w', newline='') as f:
                writer = csv.writer(f)
                for point in points:
                    writer.writerow(point)
            print("GUI : Holding fixture exported successfully")
        except:
            print("GUI : Error occured while exporting holding fixture")
            self.message_window.show_message("Error occured while exporting holding fixture")
        
        # also export the fixture direction to the json file
        try:
            # write the points to the export json file
            with open(self.export_json_path, 'w', newline='') as f:
                json.dump(export_direction_dict, f, indent=4)
            print("GUI : Holding fixture direction exported successfully")

            # close the window
            self.close()
        except:
            print("GUI : Error occured while exporting holding fixture direction")
            self.message_window.show_message("Error occured while exporting holding fixture direction")
        
    def check_holding_fixture_direction(self, points):
        # calculate the gravity direction from the vector between point1/2 and point1/3
        points = [list(map(float, point[1:])) for point in points]  # example: [[1, 2, 3], [4, 5, 6]]
        vector12 = [points[1][0] - points[0][0], 
                    points[1][1] - points[0][1],
                    points[1][2] - points[0][2]]
        vector13 = [points[2][0] - points[0][0], 
                    points[2][1] - points[0][1],
                    points[2][2] - points[0][2]]
        
        cross_product = [abs(vector12[1] * vector13[2] - vector12[2] * vector13[1]),
                        abs(vector12[2] * vector13[0] - vector12[0] * vector13[2]),
                        abs(vector12[0] * vector13[1] - vector12[1] * vector13[0])]
        
        # find the major direction from the cross product
        available_directions = ["x", "y", "z"]
        gravity_direction = ""
        max_index = cross_product.index(max(cross_product))
        if max_index == 0:
            gravity_direction = "x"
        elif max_index == 1:
            gravity_direction = "y"
        elif max_index == 2:
            gravity_direction = "z"
        available_directions.remove(gravity_direction)
        
        # generate the dictionary to store the direction
        fixture_direction_dict = {}
        for i in range(len(points)):
            if i == 0:
                fixture_direction_dict[str(i + 1)] = ["x", "y", "z"]
            else:
                fixture_direction_dict[str(i + 1)] = [gravity_direction]

        # consider the direction of the second point --> the 3rd and so on points will be the fixed only in the direction of the gravity
        vector12_abs = [abs(vector12[0]), abs(vector12[1]), abs(vector12[2])]
        max_index12 = vector12_abs.index(max(vector12_abs))
        if max_index12 == 0 and 'x' in available_directions:
            available_directions.remove('x')
            fixture_direction_dict[str(2)].append(available_directions[0])
        elif max_index12 == 1 and 'y' in available_directions:
            available_directions.remove('y')
            fixture_direction_dict[str(2)].append(available_directions[0])
        elif max_index12 == 2 and 'z' in available_directions:
            available_directions.remove('z')
            fixture_direction_dict[str(2)].append(available_directions[0])
        else:
            fixture_direction_dict[str(2)].append(available_directions[0])
        
        # rearrange the list to be in the order of x, y, z
        for i in range(len(fixture_direction_dict)):
            if len(fixture_direction_dict[str(i + 1)]) == 2:
                fixture_direction_dict[str(i + 1)].sort()
            elif len(fixture_direction_dict[str(i + 1)]) == 3:
                fixture_direction_dict[str(i + 1)] = ["x", "y", "z"]
        
        return fixture_direction_dict


class RPSConfirmation_window(QDialog, Ui_RPSTableWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.export_csv_path = None

        # set up the message window
        self.message_window = MessageWindow_window()

        # set the button functions
        self.set_pushButton.clicked.connect(self.export_rps)
        self.calculatedirection_pushButton.clicked.connect(self.calculate_direction)

    def load_csv(self, csv_file_path, export_csv_path, cad_file_path):
        self.export_csv_path = export_csv_path
        self.cad_file_path = cad_file_path
        self.tableWidget.clear()
        column = ["Status", "Name", "X-coords(mm)", "Y-coords(mm)", "Z-coords(mm)", "Fixed direction"]
        self.tableWidget.setColumnCount(len(column))
        self.tableWidget.setHorizontalHeaderLabels(column)

        # read the csv file and show the content in the plainTextEdit
        points = []
        with open(csv_file_path, 'r') as f:
            reader = csv.reader(f)
            row_num = 0
            name_list = []
            for row in reader:
                row_num += 1
                if len(row) == 5 and str(row[0]) not in name_list:
                    points.append(["active", str(row[0]), row[1], row[2], row[3], row[4]])
                    name_list.append(str(row[0]))
                else:
                    print("GUI : CSV file does not have correct column structure \n Please check the file and try again")
                    self.message_window.show_message("GUI : CSV file does not have correct column structure \n Please check the file and try again")
                    return
        self.tableWidget.setRowCount(len(points))
        for i, point in enumerate(points):
            check_box = QCheckBox(self.tableWidget)
            check_box.setChecked(True if point[0] == "active" else False)
            # set the checkbox in the middle of the cell
            check_box.setStyleSheet("margin-left:50%; margin-right:50%;")
            self.tableWidget.insertRow(i)
            self.tableWidget.setCellWidget(i, 0, check_box)
            for j in range(1, 6):
                item = QTableWidgetItem(str(point[j]))
                self.tableWidget.setItem(i, j, item)
    
    def export_rps(self):
        # read the active points from the tableWidget and write to the export csv file
        points = []
        for i in range(self.tableWidget.rowCount()):
            check_box = self.tableWidget.cellWidget(i, 0)
            if isinstance(check_box, QCheckBox) and check_box.isChecked():
                point = []
                for j in range(1, 6):
                    point.append(self.tableWidget.item(i, j).text())
                points.append([point[0], point[1], point[2], point[3], point[4]])
        # check if the points has the last column as F or H
        for point in points:
            if 'F' not in point[4] and 'H' not in point[4]:
                print("GUI : Fixed direction must be indicated")
                self.message_window.show_message("Fixed direction must be indicated before proceeding")
                return
        try:
            # write the points to the export csv file
            with open(self.export_csv_path, 'w', newline='') as f:
                writer = csv.writer(f)
                for point in points:
                    writer.writerow(point)
            print("GUI : RPS exported successfully")
    
            # close the window
            self.close()
        except:
            print("GUI : Error occured while exporting RPS")
            self.message_window.show_message("Error occured while exporting RPS")

    def calculate_direction(self):
        # clear the fixed direction column and check if the points are H type
        H_points_dict = {}   # store i and value if the point is H type
        for i in range(self.tableWidget.rowCount()):
            item_H = self.tableWidget.item(i, 5)
            #print("item_H: ", item_H)
            if self.tableWidget.item(i, 5) is not None and 'H' in item_H.text():
                H_points_dict[i] = item_H.text()

            item = QTableWidgetItem("")
            self.tableWidget.setItem(i, 5, item)
        #print("H_points: ", H_points_dict)  # print the index of the points that are H type
        
        # read all points from the tableWidget
        points = []
        for i in range(self.tableWidget.rowCount()):
            point = []
            for j in range(2, 5):
                item = self.tableWidget.item(i, j)
                if item is not None:
                    point.append(float(item.text()))
                else:
                    continue
            #print("point: ", point)
            if len(point) == 3:
                points.append(point)
        
        # read the stl file from the cad_file_path
        reader = vtk.vtkSTLReader()
        reader.SetFileName(self.cad_file_path)
        reader.Update()
        polydata = reader.GetOutput()

        # find the closest point on the stl file for each point and find the normal vector
        normals = []

        # Compute normals for the polydata
        normal_generator = vtk.vtkPolyDataNormals()
        normal_generator.SetInputData(polydata)
        normal_generator.ComputePointNormalsOn()
        normal_generator.Update()
        polydata_with_normals = normal_generator.GetOutput()

        for point in points:
            closest_point = [0, 0, 0]
            closest_distance = 1000000
            for i in range(polydata_with_normals.GetNumberOfPoints()):
                distance = vtk.vtkMath.Distance2BetweenPoints(point, polydata_with_normals.GetPoint(i))
                if distance < closest_distance:
                    closest_distance = distance
                    closest_point = polydata_with_normals.GetPoint(i)
            # find the normal vector of the closest point
            normal = [0, 0, 0]
            point_id = polydata_with_normals.FindPoint(closest_point)
            polydata_with_normals.GetPointData().GetNormals().GetTuple(point_id, normal)
            normals.append(normal)
        #print("normals: ", normals)
        
        # calculate the major direction from the normal vectors of each points and write to the tableWidget
        major_direction = []
        for point_normal in normals:
            # absolute the normal vector
            point_normal = list(point_normal)
            for i in range(3):
                point_normal[i] = abs(point_normal[i])
            max_index = point_normal.index(max(point_normal))
            #print("max_index: ", max_index)
            major_letter = "F"
            if max_index == 0:
                major_letter += "x"
            elif max_index == 1:
                major_letter += "y"
            elif max_index == 2:
                major_letter += "z"
            else:
                major_letter += "x"  # default
            major_direction.append(major_letter)
        for i in range(len(major_direction)):
            if i in H_points_dict.keys():   # H-type points will remain the old value
                item = QTableWidgetItem(H_points_dict[i])
                self.tableWidget.setItem(i, 5, item)
            else:  
                item = QTableWidgetItem(major_direction[i])
                self.tableWidget.setItem(i, 5, item)
        print("GUI : Fixed direction calculated successfully")


# Warning message class
class MessageWindow_window(QMainWindow, Ui_MessageWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setWindowModality(Qt.ApplicationModal)  # Set the window modality to ApplicationModal

    def show_message(self, message):
        self.message_label.setText(message)
        self.show()


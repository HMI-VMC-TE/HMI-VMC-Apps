from PySide6.QtWidgets import QDialog
from UI.newprojectname_ui import Ui_NewProjectWindow
from Functions.Visualization.Selection_Ftyperps.selectrps_vtk import VTKWidgetWithGeometryRPS


class NewProject_window(QDialog, Ui_NewProjectWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

    def show_name(self, name):
        self.projectname_plainTextEdit.setPlainText(name)

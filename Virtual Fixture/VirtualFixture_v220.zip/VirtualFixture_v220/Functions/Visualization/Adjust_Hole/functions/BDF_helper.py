class BDFReader:
    def __init__(self, file_path):
        self.file_path = file_path
        self.nodes = {}
        self.elements = []

    def read_bdf(self):
        with open(self.file_path, 'r') as file:
            lines = file.readlines()

        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if line.startswith('GRID'):
                if line.endswith('*'):
                    line += lines[i + 1].strip()
                    line = line.replace('*', '')
                    i += 1
                self._parse_grid(line)
            elif line.startswith('CHEXA'):
                if line.endswith('+'):
                    line += lines[i + 1]
                    line = line.replace('+', '')
                    i += 1
                self._parse_hexa_element(line)
            elif line.startswith('CPENTA'):
                self._parse_penta_element(line)
            i += 1

    def _parse_grid(self, line):
        parts = line.split()
        node_id = int(parts[1])
        x = float(parts[2])
        y = float(parts[3])
        if parts[4].endswith('0'):
            parts[4] = parts[4][:-1]
        z = float(parts[4])
        self.nodes[node_id] = (x, y, z)

    def _parse_hexa_element(self, line):
        parts = line.split()
        element_id = int(parts[1])
        node_ids = [int(parts[i]) for i in range(3, len(parts))]
        self.elements.append(("CHEXA", element_id, node_ids))

    def _parse_penta_element(self, line):
        parts = line.split()
        element_id = int(parts[1])
        node_ids = [int(parts[i]) for i in range(3, len(parts))]
        self.elements.append(("CPENTA", element_id, node_ids))

    def get_nodes(self):
        return self.nodes

    def get_elements(self):
        return self.elements

    def update_nodes(self, new_node_coordinates):
        for node_id, new_coords in new_node_coordinates.items():
            if node_id in self.nodes:
                self.nodes[node_id] = new_coords

    def write_bdf(self, output_path):
        with open(output_path, 'w') as file:
            for node_id, coords in self.nodes.items():
                x_str = f"{coords[0]:.8e}".rjust(32)
                y_str = f"{coords[1]:.8e}".rjust(16)
                z_str = f"{coords[2]:.8e}".rjust(17)
                file.write(f"GRID*{node_id:>19}{x_str}{y_str}*       \n")
                file.write(f"*      {z_str}0               \n")
            for element in self.elements:
                if element[0] == "CHEXA":
                    element1_str = ''.join(f"{node_id:>8}" for node_id in element[2][:-2])
                    element2_str = ''.join(f"{node_id:>8}" for node_id in element[2][-2:])
                    file.write(f"CHEXA   {element[1]:>8}       1{element1_str}+       \n")
                    file.write(f"        {element2_str}\n")
                elif element[0] == "CPENTA":
                    element_str = ''.join(f"{node_id:>8}" for node_id in element[2])
                    file.write(f"CPENTA  {element[1]:>8}       1{element_str}\n")
# Standard imports
from datetime import datetime
import os, shutil, subprocess
os.environ['PYTHONIOENCODING'] = 'utf-8'            ## for encoding PC in Chinese or other languages
import json, configparser   # for reading json and ini config files
import xml.etree.ElementTree as ET  # for reading xml files of material database

# Import PySide6 modules
from PySide6 import QtWidgets
from PySide6.QtWidgets import QMainWindow, QDialog
from PySide6.QtGui import QIcon
from PySide6.QtCore import Qt

# Import the Simufact helper class for script generation and execution
from Functions.Calculation.SWunified_controller import SWunified_controller

# Import visualization helper class for visualizing 3D models
from UI.message_ui import Ui_MessageWindow
from UI.pathsetup_ui import Ui_SystemPathWindow
from UI.saveproject_ui import Ui_SaveProjectWindow
from UI.polyworkfile_ui import ImportPolyWindow

from Functions.Visualization.all_visualization_helper import (VTKWidgetWithPoints, VTKWidgetWithDeviation, 
                                                              VTKWidgetWithDeviation_Morphing)    # for 3D visualization of imported geometry
from Functions.Visualization.Selection_Holdingfixture.window_selectholdingfixture import SelectFixtureWindow_window   # for selecting holding fixture
from Functions.Visualization.Selection_Ftyperps.window_selectftyperps import SelectRPSWindow_window   # for selecting holding fixture
from Functions.Visualization.Selection_Htyperps.VTK_htype_selector import MainWindow
from Functions.Visualization.Confirmation_HoldingfixtureRPS.window_fixturerpsimport import HoldingFixtureConfirmation_window, RPSConfirmation_window
from Functions.Visualization.Adjust_Hole.AdjustHole_main import Adjust_window
from Functions.Visualization.Polywork_Export.Polywork_helper import PolyworkHelper
from Functions.Visualization.ActivateOffset_RPS.activateNoffset_rps import RPSActivationOffset_window
from Functions.Visualization.Newproject_Name.window_newproject import NewProject_window



# ------------------------------------------------------------ #
# Main Application (Main window) and VFproject_controller class
# ------------------------------------------------------------ #
class VFproject_controller:
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window

        self.message_window = MessageWindow_window()
        self.filefolder_helper = FileFolder_helper(self.main_window)
        self.material_helper = Material_helper(self.main_window)
        self.parameters_helper = Parameters_helper(self.main_window)
        self.visualization_helper = Visualization_helper(self.main_window)

        self.setpath_window = SystemPathWindow_window()
        self.holdingfixtureconfirm_window = HoldingFixtureConfirmation_window()
        self.rpsconfirm_window = RPSConfirmation_window()
        self.adjust_window = Adjust_window()

        # --------------------- #
        # Read paths and parameters file, and read the material library
        # --------------------- #
        self.parameters_helper.read_paths()
        self.parameters_helper.read_parameters()

        self.unified_controller = None
        self.simufact_helper = None
        self.simufact_project = None
        self.filefolder_helper.update_project_status(self.parameters_helper.current_parameters)

        # --------------------- #
        # connect the buttons in settings to the functions
        # --------------------- #
        self.main_window.newproject_pushButton.clicked.connect(self.create_new_project)
        self.main_window.updatematerial_pushButton.clicked.connect(lambda: self.material_helper.update_materials_dictgui())
        self.main_window.pathsettings_pushButton.clicked.connect(self.open_pathsetup_window)
        self.main_window.saveproject_pushButton.clicked.connect(self.open_save_project)
        self.main_window.openproject_pushButton.clicked.connect(self.load_project)
        self.main_window.opensw_pushButton.clicked.connect(self.open_sw_project)
        self.main_window.openfolder_pushButton.clicked.connect(self.filefolder_helper.open_project_folder)
        self.main_window.exportpolywork_pushButton.clicked.connect(self.export_to_polywork)

        # --------------------- #
        # connect the buttons in parameters to the functions
        # --------------------- #
        self.main_window.saveparameters_pushButton.clicked.connect(lambda: self.parameters_helper.save_parameters(self.filefolder_helper.project_dict))
        self.main_window.loadparameters_pushButton.clicked.connect(lambda: self.parameters_helper.load_parameters())
        self.main_window.gcactivation_checkBox.stateChanged.connect(lambda: self.gc_activation_changed())

        # --------------------- #
        # connect the buttons in pages to the functions
        # --------------------- #
        # Import Geometry Page
        self.main_window.geometryfile_pushButton.clicked.connect(self.import_geometry_file)
        self.main_window.advancedmaterial_pushButton.clicked.connect(lambda: self.material_helper.open_simufact_material(self.parameters_helper.all_paths['Simufact_Matarial_Path']))
        self.main_window.advancedmeshing_pushButton.clicked.connect(lambda: self.material_helper.open_simufact_mesh(self.parameters_helper.all_paths['Simufact_Mesh_Path']))

        # import measurement page
        self.main_window.measurementfile_pushButton.clicked.connect(self.import_measurement_file)

        # import holding fixture page
        self.main_window.holdingfixturefile_pushButton.clicked.connect(self.import_holdingfixture_file)
        self.main_window.selectholdingfixture_pushButton.clicked.connect(self.select_holdingfixture)

        # import rps page
        self.main_window.rpsfile_pushButton.clicked.connect(self.import_rps_file)
        self.main_window.selectrps_pushButton.clicked.connect(self.select_rps)

        # morphing page
        self.main_window.startmorphing_pushButton.clicked.connect(self.start_morphing)
        #self.main_window.stopmorphing_pushButton.clicked.connect(self.stop_morphing)
        self.main_window.adjustholes_pushButton.clicked.connect(self.start_adjusthole)

        # gravity compensation page
        self.main_window.startgc_pushButton.clicked.connect(self.start_gc)
        #self.main_window.stopgc_pushButton.clicked.connect(self.stop_gc)
        self.main_window.gravitydirection_comboBox.currentIndexChanged.connect(lambda: self.visualization_helper.show_gravity_direction(self.filefolder_helper.project_dict, 
                                                                                                                                        self.main_window.gravitydirection_comboBox.currentText()))

        # rps clamping page
        self.main_window.startrps_pushButton.clicked.connect(self.start_rps)
        #self.main_window.stoprps_pushButton.clicked.connect(self.stop_rps)
        self.main_window.selecthtype_pushButton.clicked.connect(self.open_selecthtyperps)
        self.main_window.rpsgravitydirection_comboBox.currentIndexChanged.connect(lambda: self.visualization_helper.show_rps_gravity_direction(self.filefolder_helper.project_dict,
                                                                                                                                               self.main_window.rpsgravitydirection_comboBox.currentText()))
        self.main_window.clearhrps_pushButton.clicked.connect(self.clear_htype_rps)

        # --------------------- #
        # disable some buttons by default
        # --------------------- #
        self.main_window.geometrytype_comboBox.setEnabled(False)    # disable the geometry type comboBox
        self.main_window.pinnumber_comboBox.setEnabled(False)       # disable the pin number comboBox
        self.main_window.stopmorphing_pushButton.setEnabled(False)   # disable the stop morphing button
        self.main_window.stopgc_pushButton.setEnabled(False)         # disable the stop gravity compensation button
        self.main_window.stoprps_pushButton.setEnabled(False)        # disable the stop rps clamping button
        self.main_window.adjustholes_pushButton.setEnabled(False)  # disable the hole adjustment button

    # open simufact welding project
    def open_sw_project(self):
        sw_project_name = 'Simufact_Project_File'
        swproject_folder = os.path.normpath(os.path.join(self.filefolder_helper.project_dict['swproject_folder'], sw_project_name))
        swproj_file = os.path.normpath(os.path.join(swproject_folder, sw_project_name + '.swproj'))

        # open the Simufact Welding software
        try:
            simufact_path = os.path.normpath(os.path.join(self.parameters_helper.all_paths["SW_Installation_Path"], "bin/simufact.welding.exe"))
            process = subprocess.Popen([simufact_path, swproj_file])
            process.wait()
        except Exception as e:
            print(f"Error opening Simufact Welding project: {e}")
            return

    # create a new project with a auto-generated name
    def create_new_project(self):        
        # get the project folder structure from folder_structure.json file
        file_path = os.path.normpath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 
                                                 'Settings/folder_structure.json'))
        with open(file_path) as json_file:
            folder_structure = json.load(json_file)
        
        # create the project folder
        result = self.filefolder_helper.create_project_folder(self.parameters_helper.all_paths, folder_structure['ProjectFile_Structure'])
        if not result:
            print("GUI : Failed to create project folder")
            self.message_window.show_message("Failed to create project folder \n Folder may already exists")
            return
        self.message_window.show_message("New project created successfully")

        # set defaults all instance variables
        self.filefolder_helper.set_defaults()
        self.parameters_helper.read_paths()
        self.parameters_helper.read_parameters()
        self.visualization_helper.clear_all_vtk()

        # rearrange the page back to the import geometry page
        self.main_window.pages_stackedWidget.setCurrentIndex(0)

        # reset the self.simufact_project
        self.simufact_project = None

        # update the project status
        self.filefolder_helper.update_project_status(self.parameters_helper.current_parameters)

    # open the system path setup window
    def open_pathsetup_window(self):
        self.setpath_window.exec()

    # save the project
    def open_save_project(self):
        self.parameters_helper.update_parameters_from_gui()
        
        # collect all status dictionary and save it to the project folder
        project_status_dict = {
            "project_dict": self.filefolder_helper.project_dict,
            "project_status": self.filefolder_helper.project_status
        }

        # pop up the saveproject window and save the project status
        saveproject_window = SaveProject_window(project_status_dict)
        saveproject_window.exec()

        # update the project status
        # change the system variables after saving as the project
        save_as, renew_dict = saveproject_window.saveas_sendback()
        if save_as:
            self.filefolder_helper.project_dict = renew_dict['project_dict']
            self.filefolder_helper.project_status = renew_dict['project_status']
            self.filefolder_helper.renew_project_folder_dict(self.filefolder_helper.project_dict['project_folder'])

            # refresh the visualization of the project
            self.visualization_helper.update_visualization(self.filefolder_helper.project_dict,
                                                           self.filefolder_helper.project_status)

    # load the project
    def load_project(self):
        search_default = self.parameters_helper.all_paths['Work_Directory']
        new_project_folder = QtWidgets.QFileDialog.getExistingDirectory(self.main_window,
                                                                        "Load Project Folder",
                                                                        search_default)
        if not new_project_folder or not os.path.exists(new_project_folder):
            print("GUI : No folder selected")
            self.message_window.show_message("No folder selected")
            return
        elif not os.path.exists(os.path.join(new_project_folder, 'save_project.json')):
            print("GUI : Invalid project folder")
            self.message_window.show_message("Invalid project folder")
            return
        else:
            try:
                # set defaults all instance variables
                self.filefolder_helper.set_defaults()

                # read the project status from the save_project.json file
                with open(os.path.join(new_project_folder, 'save_project.json')) as json_file:
                    project_status_dict = json.load(json_file)
                #self.filefolder_helper.project_dict = project_status_dict['project_dict']
                self.filefolder_helper.renew_project_folder_dict(new_project_folder)
                self.filefolder_helper.project_status = project_status_dict['project_status']

                # update the project status
                self.filefolder_helper.update_project_status(self.parameters_helper.current_parameters)

                # refresh the visualization of the project
                self.visualization_helper.update_visualization(self.filefolder_helper.project_dict,
                                                                self.filefolder_helper.project_status)
                self.message_window.show_message("Project loaded successfully")
            except Exception as e:
                print(f"Error loading project: {e}")
                self.message_window.show_message("Error loading project")
        
        # rearrange the page back to the import geometry page
        self.main_window.pages_stackedWidget.setCurrentIndex(0)

    # export RPS clamping result to Polywork
    def export_to_polywork(self):
        # open import polywork window and get the measurement plan csv file path
        import_polywork_window = ImportPolyWindow()
        import_polywork_window.exec()
        measurement_plan = {
            "Point_measurement": None,
            "Round_hole_measurement": None
        }
        if os.path.exists(import_polywork_window.point_measurement_path):
            measurement_plan["Point_measurement"] = import_polywork_window.point_measurement_path.replace("/", "\\")
        if os.path.exists(import_polywork_window.round_hole_measurement_path):
            measurement_plan["Round_hole_measurement"] = import_polywork_window.round_hole_measurement_path.replace("/", "\\")
        
        # use the polywork helper to generate script and open the polywork
        settings_path = os.path.normpath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 
                                                    'Settings'))
        self.polywork_helper = PolyworkHelper(self.parameters_helper.all_paths, 
                                              self.filefolder_helper.project_dict["project_folder"], 
                                              settings_path, 
                                              measurement_plan)
        self.polywork_helper.createPolyworkMacro()
        self.polywork_helper.executePolyworkMacro()

    # change the activation of gravity compensation
    def gc_activation_changed(self):
        self.parameters_helper.update_parameters_from_gui()

        # delete the rps clamping result from the output folder
        self.filefolder_helper.delete_rps_result()
        self.update_rps_progress(0)

        self.filefolder_helper.update_project_status(self.parameters_helper.current_parameters)
        self.main_window.pages_stackedWidget.setCurrentIndex(0)

    # import geometry file from catalog : CATPart, step, x_t, x_b, igs, bdf extensions s
    def import_geometry_file(self):
        self.parameters_helper.update_parameters_from_gui()

        # --------------- #
        # GUI part
        # --------------- #
        # Get the geometry file path from QFileDialog
        search_directory = os.path.join(os.path.dirname(os.path.dirname(__file__)), "Help", "sample_data")
        geometry_file = QtWidgets.QFileDialog.getOpenFileName(self.main_window, 
                                                             "Select Geometry/Mesh File", 
                                                             search_directory, 
                                                             'CAD Files (*.CATPart *.stp *.x_t *.x_b *.igs *.bdf)')[0]
        if not geometry_file:
            print("No file selected")
            return
        
        # set the path of the geometry from and to
        import_geometry_folder = self.filefolder_helper.project_dict['import_geometry_folder']
        geometry_file_name = os.path.basename(geometry_file)
        import_geometry_file = os.path.join(import_geometry_folder, geometry_file_name)

        # Debugging: Print the import_geometry_folder path
        print(f"Import Geometry Folder: {import_geometry_folder}")

        # Ensure the folder path is correct before deleting files
        if os.path.exists(import_geometry_folder) and os.path.isdir(import_geometry_folder) and "0-CAD" in import_geometry_folder:
            for file in os.listdir(import_geometry_folder):
                file_path = os.path.join(import_geometry_folder, file)
                if os.path.isfile(file_path) and file_path.endswith(('.CATPart', '.stp', '.x_t', '.x_b', '.igs', '.bdf', '.stl')):
                    print(f" ---- Deleting file: {file_path}")
                    os.remove(file_path)
        else:
            print(f"Error: {import_geometry_folder} is not a valid directory")

        # copy the geometry file to the project folder
        shutil.copyfile(geometry_file, import_geometry_file)
        self.main_window.geometryfile_plainTextEdit.setPlainText(geometry_file)


        # --------------- #
        # initiate the Simufact Welding project and run the meshing process
        # --------------- #
        self.unified_controller = None
        self.unified_controller = SWunified_controller(self.filefolder_helper.project_dict['project_folder'],
                                                        self.parameters_helper.current_parameters,
                                                        self.parameters_helper.all_paths,
                                                        self.filefolder_helper.project_status)
        try:  
            self.unified_controller.VF_initiation()
        except Exception as e:
            print(f"**Error in SW initiation: {e}")
            self.message_window.show_message("**Error in SW initiation")
            return
        
        try:
            self.unified_controller.VF_meshing()
        except Exception as e:
            print(f"**Error in meshing: {e}")
            self.message_window.show_message("**Error in meshing")
            return
        
        # --------------- #
        # Visualization part
        # --------------- #
        # add 3d visualization of the geometry file to the visualization layout importgeometryvisual_widget_layout
        cad_stl_file_path = os.path.join(self.filefolder_helper.project_dict['import_geometry_folder'], 'CAD_geometry.stl')
        self.visualization_helper.show_importgeometry_visualization(cad_stl_file_path)

        # delete the result of morphing, gravity compensation and rps clamping from the output folder
        self.filefolder_helper.delete_morphing_result()
        self.update_morphing_progress(0)
        self.filefolder_helper.delete_gc_result()
        self.update_gc_progress(0)
        self.filefolder_helper.delete_rps_result()
        self.update_rps_progress(0)
        # update the project status
        self.filefolder_helper.update_project_status(self.parameters_helper.current_parameters)
        self.visualization_helper.clear_false_visualization(self.filefolder_helper.project_dict,
                                                            self.filefolder_helper.project_status)
        
    # import stl measurement file and visualize it
    def import_measurement_file(self):
        # --------------- #
        # GUI part
        # --------------- #
        # Get the measurement file path from QFileDialog
        search_directory = os.path.join(os.path.dirname(os.path.dirname(__file__)), "Help", "sample_data")
        measurement_file = QtWidgets.QFileDialog.getOpenFileName(self.main_window, 
                                                                 "Select Measurement File", 
                                                                 search_directory, 
                                                                 'STL Files (*.stl)')[0]
        if not measurement_file:
            print("No file selected")
            return
        
        # set the path of the measurement from and to
        import_measurement_folder = self.filefolder_helper.project_dict['import_measurement_folder']
        measurement_file_name = "Measurement_data.stl"
        import_measurement_file = os.path.join(import_measurement_folder, measurement_file_name)

        # delete all file within the import measurement folder
        for file in os.listdir(import_measurement_folder):
            file_path = os.path.join(import_measurement_folder, file)
            if os.path.isfile(file_path) and file_path.endswith('.stl'):
                os.remove(file_path)

        # copy the measurement file to the project folder
        shutil.copyfile(measurement_file, import_measurement_file)
        self.main_window.measurementfile_plainTextEdit.setPlainText(measurement_file)

        # --------------- #
        # Visualization part
        # --------------- #
        # add 3d visualization of the measurement file to the visualization layout importmeasurementvisual_widget_layout
        cad_stl_file_path = os.path.join(self.filefolder_helper.project_dict['import_geometry_folder'], 'CAD_geometry.stl')
        self.visualization_helper.show_importmeasurement_visualization(cad_stl_file_path, import_measurement_file)

        # delete the result of morphing, gravity compensation and rps clamping from the output folder
        self.filefolder_helper.delete_morphing_result()
        self.update_morphing_progress(0)
        self.filefolder_helper.delete_gc_result()
        self.update_gc_progress(0)
        self.filefolder_helper.delete_rps_result()
        self.update_rps_progress(0)
        # update the project status
        self.filefolder_helper.update_project_status(self.parameters_helper.current_parameters)
        self.visualization_helper.clear_false_visualization(self.filefolder_helper.project_dict,
                                                            self.filefolder_helper.project_status)

    # import holding fixture csv file and visualize it
    def import_holdingfixture_file(self):
        # --------------- #
        # GUI part
        # --------------- #
        # Get the holding fixture file path from QFileDialog
        search_directory = os.path.join(os.path.dirname(os.path.dirname(__file__)), "Help", "sample_data")
        holding_fixture_file = QtWidgets.QFileDialog.getOpenFileName(self.main_window, 
                                                                     "Select Holding Fixture File", 
                                                                     search_directory, 
                                                                     'CSV Files (*.csv)')[0]
        if not holding_fixture_file:
            print("No file selected")
            return
        
        # set the path of the holding fixture from and to
        import_fixture_folder = self.filefolder_helper.project_dict['import_fixture_folder']
        holding_fixture_file_name = "Holding_fixture.csv"
        import_fixture_file = os.path.join(import_fixture_folder, holding_fixture_file_name)
        fixture_direction_file = os.path.join(import_fixture_folder, "fixture_direction.json")

        # delete all file within the import holding fixture folder
        for file in os.listdir(import_fixture_folder):
            file_path = os.path.join(import_fixture_folder, file)
            if os.path.isfile(file_path) and file_path.endswith('.csv'):
                os.remove(file_path)

        # pop up the holding fixture confirmation window
        self.holdingfixtureconfirm_window.load_csv(holding_fixture_file, 
                                                   import_fixture_file, 
                                                   fixture_direction_file)
        self.holdingfixtureconfirm_window.exec()

        self.main_window.holdingfixturefile_plainTextEdit.setPlainText(holding_fixture_file)

        # --------------- #
        # Visualization part
        # --------------- #
        if os.path.exists(import_fixture_file):
            # visualize the holding fixture file
            cad_stl_file_path = os.path.join(self.filefolder_helper.project_dict['import_geometry_folder'], 'CAD_geometry.stl')
            self.visualization_helper.show_importfixture_visualization(cad_stl_file_path, import_fixture_file)
        else:
            print("**Error in importing holding fixture file")
            self.message_window.show_message("**Error in importing holding fixture file")
        
        # delete the result of gravity compensation from the output folder
        self.filefolder_helper.delete_gc_result()
        self.update_gc_progress(0)
        self.filefolder_helper.delete_rps_result()
        self.update_rps_progress(0)
        # update the project status
        self.filefolder_helper.update_project_status(self.parameters_helper.current_parameters)
        self.visualization_helper.clear_false_visualization(self.filefolder_helper.project_dict,
                                                            self.filefolder_helper.project_status)

    # select holding fixture from the imported holding fixture file
    def select_holdingfixture(self):
        self.selectholdingfixture_window = SelectFixtureWindow_window()

        cad_stl_file_path = os.path.join(self.filefolder_helper.project_dict['import_geometry_folder'], 'CAD_geometry.stl')
        holding_fixture_file_path = os.path.join(self.filefolder_helper.project_dict['import_fixture_folder'], 'Holding_fixture.csv')
        fixture_direction_file = os.path.join(self.filefolder_helper.project_dict['import_fixture_folder'], "fixture_direction.json")
        self.selectholdingfixture_window.load_cad_geometry(cad_stl_file_path, holding_fixture_file_path)
        self.selectholdingfixture_window.exec()

        # pop up the holding fixture confirmation window
        self.holdingfixtureconfirm_window.load_csv(holding_fixture_file_path, 
                                                   holding_fixture_file_path, 
                                                   fixture_direction_file)
        self.holdingfixtureconfirm_window.exec()

        # --------------- #
        # Visualization part
        # --------------- #
        # visualize the holding fixture file
        self.visualization_helper.show_importfixture_visualization(cad_stl_file_path, holding_fixture_file_path)

        # delete the result of gravity compensation from the output folder
        self.filefolder_helper.delete_gc_result()
        # update the project status
        self.filefolder_helper.update_project_status(self.parameters_helper.current_parameters)
        self.visualization_helper.clear_false_visualization(self.filefolder_helper.project_dict,
                                                            self.filefolder_helper.project_status)

    # import rps file and visualize it
    def import_rps_file(self):
        # Get the rps file path from QFileDialog
        search_directory = os.path.join(os.path.dirname(os.path.dirname(__file__)), "Help", "sample_data")
        rps_file = QtWidgets.QFileDialog.getOpenFileName(self.main_window, 
                                                         "Select RPS info File", 
                                                         search_directory, 
                                                         'CSV Files (*.csv)')[0]
        
        if not rps_file:
            print("No file selected")
            return
        else:
            # set the path of the rps from and to
            import_rps_folder = self.filefolder_helper.project_dict['import_rps_folder']
            rps_file_name = "FType_RPS.csv"
            import_rps_file = os.path.join(import_rps_folder, rps_file_name)

            # delete all file within the import rps folder
            for file in os.listdir(import_rps_folder):
                file_path = os.path.join(import_rps_folder, file)
                if os.path.isfile(file_path) and file_path.endswith('.csv'):
                    os.remove(file_path)
                
            # pop up the rps confirmation window
            self.rpsconfirm_window.load_csv(rps_file, import_rps_file, 
                                            os.path.join(self.filefolder_helper.project_dict['import_geometry_folder'], "CAD_geometry.stl"))
            self.rpsconfirm_window.exec()

            self.main_window.rpsfile_plainTextEdit.setPlainText(rps_file)

            if os.path.exists(import_rps_file):
                # visualize the holding fixture file
                cad_stl_file_path = os.path.join(self.filefolder_helper.project_dict['import_geometry_folder'], 'CAD_geometry.stl')
                self.visualization_helper.show_importrps_visualization(cad_stl_file_path, import_rps_file)
            else:
                print("Error in importing RPS file")
                self.message_window.show_message("Error in importing RPS file")
        
        # delete the result of morphing, gravity compensation and rps clamping from the output folder
        self.filefolder_helper.delete_morphing_result()
        self.update_morphing_progress(0)
        self.filefolder_helper.delete_gc_result()
        self.update_gc_progress(0)
        self.filefolder_helper.delete_rps_result()
        self.update_rps_progress(0)

        # update the project status
        self.filefolder_helper.update_project_status(self.parameters_helper.current_parameters)
        self.visualization_helper.clear_false_visualization(self.filefolder_helper.project_dict,
                                                            self.filefolder_helper.project_status)

    # select rps from the cad geometry
    def select_rps(self):
        self.selectrps_window = SelectRPSWindow_window()

        cad_stl_file_path = os.path.join(self.filefolder_helper.project_dict['import_geometry_folder'], 'CAD_geometry.stl')
        rps_file_path = os.path.join(self.filefolder_helper.project_dict['import_rps_folder'], 'FType_RPS.csv')
        self.selectrps_window.load_cad_geometry(cad_stl_file_path, rps_file_path)
        self.selectrps_window.exec()

        # pop up the rps confirmation window
        self.rpsconfirm_window.load_csv(rps_file_path, rps_file_path, 
                                        cad_stl_file_path)
        self.rpsconfirm_window.exec()

        # --------------- #
        # Visualization part
        # --------------- #
        # visualize the holding fixture file
        self.visualization_helper.show_importrps_visualization(cad_stl_file_path, rps_file_path)

        # delete the result of morphing, gravity compensation and rps clamping from the output folder
        self.filefolder_helper.delete_morphing_result()
        self.update_morphing_progress(0)
        self.filefolder_helper.delete_gc_result()
        self.update_gc_progress(0)
        self.filefolder_helper.delete_rps_result()
        self.update_rps_progress(0)
        # update the project status
        self.filefolder_helper.update_project_status(self.parameters_helper.current_parameters)
        self.visualization_helper.clear_false_visualization(self.filefolder_helper.project_dict,
                                                            self.filefolder_helper.project_status)

    # start morphing process
    def start_morphing(self):
        # pre run steps and set progress bar to 0
        self.parameters_helper.update_parameters_from_gui()
        self.main_window.morphing_progressBar.setValue(0)

        # ---------------- #
        # GUI part
        # ---------------- #
        # delete the result of gravity compensation and rps clamping from the output folder
        self.update_morphing_progress(10)
        self.filefolder_helper.delete_gc_result()
        self.update_gc_progress(0)
        self.filefolder_helper.delete_rps_result()
        self.update_rps_progress(0)

        # disable the start and enable the stop button
        self.main_window.startmorphing_pushButton.setEnabled(False)
        #self.main_window.stopmorphing_pushButton.setEnabled(False)  # morphing cannot be stopped during the process
        
        # copy the xmt material file from simufact material database to the project folder
        material_from_path = os.path.join(os.path.join(os.path.dirname(os.path.dirname(__file__)), 'Materials'), 
                                          self.main_window.material_comboBox.currentText())
        material_to_path = os.path.join(self.filefolder_helper.project_dict['material_folder'], self.main_window.material_comboBox.currentText())
        shutil.copyfile(material_from_path, material_to_path)

        # ---------------- #
        # initiate the Simufact Welding project and run the morphing process
        # ---------------- #
        self.unified_controller = None
        self.unified_controller = SWunified_controller(self.filefolder_helper.project_dict['project_folder'],
                                                        self.parameters_helper.current_parameters,
                                                        self.parameters_helper.all_paths,
                                                        self.filefolder_helper.project_status)
        try:
            self.unified_controller.VF_morphing()
        except Exception as e:
            print(f"**Error in morphing: {e}")
            self.message_window.show_message("**Error in morphing")
            self.update_morphing_progress(10000)
            return

        # --------------- #
        # Visualization part
        # --------------- #
        # add 3d visualization of the morphed geometry to the visualization layout morphingresultvisual_widget_layout
        measurement_stl_file_path = os.path.join(self.filefolder_helper.project_dict['import_measurement_folder'], 'Measurement_data.stl')
        morphed_stl_file_path = os.path.join(self.filefolder_helper.project_dict['output_folder'], '0-Morphing/Morphed_geometry.stl')
        if os.path.exists(morphed_stl_file_path) and os.path.exists(measurement_stl_file_path):
            self.visualization_helper.show_morphing_visualization(measurement_stl_file_path, morphed_stl_file_path)
            self.update_morphing_progress(100)

        # update the project status
        self.filefolder_helper.update_project_status(self.parameters_helper.current_parameters)
        self.visualization_helper.clear_false_visualization(self.filefolder_helper.project_dict,
                                                            self.filefolder_helper.project_status)
        
        # Enable the start button again and disable the stop button when morphing is complete
        self.main_window.startmorphing_pushButton.setEnabled(True)
        #self.main_window.stopmorphing_pushButton.setEnabled(False)

    # update the morphing progress
    def update_morphing_progress(self, progress):
        # update the progress bar
        self.main_window.morphing_progressBar.setValue(progress)
        if progress < 100:
            self.main_window.morphing_progressBar.setStyleSheet(u"QProgressBar {\n"
            "    border: 2px solid #444;\n"
            "    border-radius: 5px;\n"
            "    background-color: #222;\n"
            "    text-align: center;\n"
            "    font: bold 10pt \"Segoe UI\";\n"
            "    color: #ddd;\n"
            "}\n"
            "\n"
            "QProgressBar::chunk {\n"
            "    background-color: #29a3ef; /* Bright blue progress color */\n"
            "    border-radius: 5px;\n"
            "}")
        if progress == 100:
            self.main_window.morphing_progressBar.setStyleSheet(u"QProgressBar {\n"
            "    border: 2px solid #444;\n"
            "    border-radius: 5px;\n"
            "    background-color: #222;\n"
            "    text-align: center;\n"
            "    font: bold 10pt \"Segoe UI\";\n"
            "    color: #ddd;\n"
            "}\n"
            "\n"
            "QProgressBar::chunk {\n"
            "    background-color: #00aa00; /* Bright green progress color */\n"
            "    border-radius: 5px;\n"
            "}")
            # disable the stop and enable the start button
            self.main_window.startmorphing_pushButton.setEnabled(True)
            self.main_window.stopmorphing_pushButton.setEnabled(False)
        if progress > 100:
            self.main_window.morphing_progressBar.setStyleSheet(u"QProgressBar {\n"
            "    border: 2px solid #444;\n"
            "    border-radius: 5px;\n"
            "    background-color: #222;\n"
            "    text-align: center;\n"
            "    font: bold 10pt \"Segoe UI\";\n"
            "    color: #ddd;\n"
            "}\n"
            "\n"
            "QProgressBar::chunk {\n"
            "    background-color: #ff5500; /* Bright red progress color */\n"
            "    border-radius: 5px;\n"
            "}")
            # disable the stop and enable the start button
            self.main_window.startmorphing_pushButton.setEnabled(True)
            self.main_window.stopmorphing_pushButton.setEnabled(False)

    # open the ajust hole window
    def start_adjusthole(self):
        print(f"Before start_adjusthole: {self.simufact_project}")
        # initiate the adjust hole window by assigning the project folder
        self.adjust_window.initiate_adjustment(self.filefolder_helper.project_dict)
        self.adjust_window.show()

        # delete the manaual H-type RPS selection, so the user has to select manaual H-type RPS again
        self.filefolder_helper.delete_manual_htype_rps()
        self.message_window.show_message("All H-type RPS will be lost, \nplease select them manually again")

    # start gravity compensation process
    def start_gc(self):
        # pre run steps and set progress bar to 0
        self.parameters_helper.update_parameters_from_gui()
        self.main_window.gc_progressBar.setValue(10)

        # ---------------- #
        # GUI part
        # ---------------- #
        # disable the start and enable the stop button
        self.main_window.startgc_pushButton.setEnabled(False)
        self.main_window.stopgc_pushButton.setEnabled(True)

        # ---------------- #
        # initiate the Simufact Welding project and run the gravity compensation process
        # ---------------- #
        self.unified_controller = None
        self.unified_controller = SWunified_controller(self.filefolder_helper.project_dict['project_folder'],
                                                        self.parameters_helper.current_parameters,
                                                        self.parameters_helper.all_paths,
                                                        self.filefolder_helper.project_status)
        try:
            self.unified_controller.VF_gc()
        except Exception as e:
            print(f"**Error in gravity compensation: {e}")
            self.message_window.show_message("**Error in gravity compensation")
            self.update_gc_progress(10000)
            return

        # --------------- #
        # Visualization part
        # --------------- #
        # add 3d visualization of the gravity compensated geometry to the visualization layout gcresultvisual_widget_layout
        morphed_stl_file_path = os.path.join(self.filefolder_helper.project_dict['output_folder'], '0-Morphing/Morphed_geometry.stl')
        gc_stl_file_path = os.path.join(self.filefolder_helper.project_dict['output_folder'], '1-GC/GC_result_geometry.stl')
        if os.path.exists(gc_stl_file_path) and os.path.exists(morphed_stl_file_path):
            self.visualization_helper.show_gc_visualization(morphed_stl_file_path, gc_stl_file_path)
            self.update_gc_progress(100)
        else:
            self.update_gc_progress(10000)

        # delete the result of gravity compensation and rps clamping from the output folder
        self.update_rps_progress(0)

        # update the project status
        self.filefolder_helper.update_project_status(self.parameters_helper.current_parameters)
        self.visualization_helper.clear_false_visualization(self.filefolder_helper.project_dict,
                                                            self.filefolder_helper.project_status)
        
        # Enable the start button again and disable the stop button when gravity compensation is complete
        self.main_window.startgc_pushButton.setEnabled(True)
        self.main_window.stopgc_pushButton.setEnabled(False)
    
    # update the gravity compensation progress
    def update_gc_progress(self, progress):
        # update the progress bar
        self.main_window.gc_progressBar.setValue(progress)
        if progress < 100:
            self.main_window.gc_progressBar.setStyleSheet(u"QProgressBar {\n"
            "    border: 2px solid #444;\n"
            "    border-radius: 5px;\n"
            "    background-color: #222;\n"
            "    text-align: center;\n"
            "    font: bold 10pt \"Segoe UI\";\n"
            "    color: #ddd;\n"
            "}\n"
            "\n"
            "QProgressBar::chunk {\n"
            "    background-color: #29a3ef; /* Bright blue progress color */\n"
            "    border-radius: 5px;\n"
            "}")
        if progress == 100:
            self.main_window.gc_progressBar.setStyleSheet(u"QProgressBar {\n"
            "    border: 2px solid #444;\n"
            "    border-radius: 5px;\n"
            "    background-color: #222;\n"
            "    text-align: center;\n"
            "    font: bold 10pt \"Segoe UI\";\n"
            "    color: #ddd;\n"
            "}\n"
            "\n"
            "QProgressBar::chunk {\n"
            "    background-color: #00aa00; /* Bright green progress color */\n"
            "    border-radius: 5px;\n"
            "}")
            # disable the stop and enable the start button
            self.main_window.startgc_pushButton.setEnabled(True)
            self.main_window.stopgc_pushButton.setEnabled(False)
        if progress > 100:
            self.main_window.gc_progressBar.setStyleSheet(u"QProgressBar {\n"
            "    border: 2px solid #444;\n"
            "    border-radius: 5px;\n"
            "    background-color: #222;\n"
            "    text-align: center;\n"
            "    font: bold 10pt \"Segoe UI\";\n"
            "    color: #ddd;\n"
            "}\n"
            "\n"
            "QProgressBar::chunk {\n"
            "    background-color: #ff5500; /* Bright red progress color */\n"
            "    border-radius: 5px;\n"
            "}")
            # disable the stop and enable the start button
            self.main_window.startgc_pushButton.setEnabled(True)
            self.main_window.stopgc_pushButton.setEnabled(False)

    # start rps clamping process
    def start_rps(self):
        # pre run steps and set progress bar to 0
        self.parameters_helper.update_parameters_from_gui()
        self.main_window.rps_progressBar.setValue(10)

        # ---------------- #
        # GUI part
        # ---------------- #
        # disable the start and enable the stop button
        self.main_window.startrps_pushButton.setEnabled(False)
        self.main_window.stoprps_pushButton.setEnabled(True)

        # open the activate/offset rps window
        self.activate_rps_window = RPSActivationOffset_window(self.filefolder_helper.project_dict['project_folder'])
        self.activate_rps_window.exec()

        # ---------------- #
        # initiate the Simufact Welding project and run the gravity compensation process
        # ---------------- #
        self.unified_controller = None
        self.unified_controller = SWunified_controller(self.filefolder_helper.project_dict['project_folder'],
                                                        self.parameters_helper.current_parameters,
                                                        self.parameters_helper.all_paths,
                                                        self.filefolder_helper.project_status)
        try:
            self.unified_controller.VF_rps()
        except Exception as e:
            print(f"**Error in RPS clamping: {e}")
            self.message_window.show_message("**Error in RPS clamping")
            self.update_rps_progress(10000)
            return
        
        # --------------- #
        # Visualization part
        # --------------- #
        # add 3d visualization of the rps clamped geometry to the visualization layout rpsresultvisual_widget_layout
        cad_stl_file_path = os.path.join(self.filefolder_helper.project_dict['import_geometry_folder'], 'CAD_geometry.stl')
        rps_stl_file_path = os.path.join(self.filefolder_helper.project_dict['output_folder'], '2-RPS/RPS_geometry.stl')
        if os.path.exists(rps_stl_file_path):
            self.visualization_helper.show_rps_visualization(cad_stl_file_path, rps_stl_file_path)
            self.update_rps_progress(100)

        # update the project status
        self.filefolder_helper.update_project_status(self.parameters_helper.current_parameters)
        self.visualization_helper.clear_false_visualization(self.filefolder_helper.project_dict,
                                                            self.filefolder_helper.project_status)

        # Enable the start button again and disable the stop button when rps clamping is complete
        self.main_window.startrps_pushButton.setEnabled(True)
        self.main_window.stoprps_pushButton.setEnabled(False)
    
    # update the rps clamping progress
    def update_rps_progress(self, progress):
        # update the progress bar
        self.main_window.rps_progressBar.setValue(progress)
        if progress < 100:
            self.main_window.rps_progressBar.setStyleSheet(u"QProgressBar {\n"
            "    border: 2px solid #444;\n"
            "    border-radius: 5px;\n"
            "    background-color: #222;\n"
            "    text-align: center;\n"
            "    font: bold 10pt \"Segoe UI\";\n"
            "    color: #ddd;\n"
            "}\n"
            "\n"
            "QProgressBar::chunk {\n"
            "    background-color: #29a3ef; /* Bright blue progress color */\n"
            "    border-radius: 5px;\n"
            "}")
        if progress == 100:
            self.main_window.rps_progressBar.setStyleSheet(u"QProgressBar {\n"
            "    border: 2px solid #444;\n"
            "    border-radius: 5px;\n"
            "    background-color: #222;\n"
            "    text-align: center;\n"
            "    font: bold 10pt \"Segoe UI\";\n"
            "    color: #ddd;\n"
            "}\n"
            "\n"
            "QProgressBar::chunk {\n"
            "    background-color: #00aa00; /* Bright green progress color */\n"
            "    border-radius: 5px;\n"
            "}")
            # disable the stop and enable the start button
            self.main_window.startrps_pushButton.setEnabled(True)
            self.main_window.stoprps_pushButton.setEnabled(False)
        if progress > 100:
            self.main_window.rps_progressBar.setStyleSheet(u"QProgressBar {\n"
            "    border: 2px solid #444;\n"
            "    border-radius: 5px;\n"
            "    background-color: #222;\n"
            "    text-align: center;\n"
            "    font: bold 10pt \"Segoe UI\";\n"
            "    color: #ddd;\n"
            "}\n"
            "\n"
            "QProgressBar::chunk {\n"
            "    background-color: #ff5500; /* Bright red progress color */\n"
            "    border-radius: 5px;\n"
            "}")
            # disable the stop and enable the start button
            self.main_window.startrps_pushButton.setEnabled(True)
            self.main_window.stoprps_pushButton.setEnabled(False)

    # open select H-type RPS window
    def open_selecthtyperps(self):
        cad_file_path = os.path.join(self.filefolder_helper.project_dict['import_geometry_folder'], 'CAD_geometry.stl')
        if self.main_window.gcactivation_checkBox.isChecked():
            distorted_file_path = os.path.join(self.filefolder_helper.project_dict['output_folder'], '1-GC/GC_result_geometry.stl')
        else:
            adjust_exist = False
            adjust_file_path = None
            for root, dirs, files in os.walk(os.path.join(self.filefolder_helper.project_dict['output_folder'], '0-Morphing')):
                for file in files:
                    if "adjust" in file.lower() and file.endswith('.stl'):
                        adjust_exist = True
                        adjust_file_path = os.path.join(root, file)
                        break
            if adjust_exist:
                distorted_file_path = adjust_file_path
            else:
                distorted_file_path = os.path.join(self.filefolder_helper.project_dict['output_folder'], '0-Morphing/Morphed_geometry.stl')
        rps_input_path = self.filefolder_helper.project_dict['import_rps_folder']

        htype_window = MainWindow(cad_file_path, distorted_file_path, rps_input_path)
        htype_window.show()

        self.main_window.fixedhtype_checkBox.setEnabled(True)

    # clear H-type RPS both manual and xml
    def clear_htype_rps(self):
        # delete the manual H-type RPS selection
        for file in os.listdir(self.filefolder_helper.project_dict['import_rps_folder']):
            file_path = os.path.join(self.filefolder_helper.project_dict['import_rps_folder'], file)
            if file_path.endswith('.csv') and "HType" in file:
                os.remove(file_path)
        print("GUI : Manual H-type RPS selection cleared.")

        ## delete the H-type section in the xml file --> this is replaced by the table selection
        #xml_folder = os.path.join(self.filefolder_helper.project_dict['swproject_folder'],
        #                          r'Simufact_Project_File\_entities\geometries')
        #for file in os.listdir(xml_folder):
        #    file_path = os.path.join(xml_folder, file)
        #    if file_path.endswith('.xml'):
        #        if (self.parameters_helper.current_parameters['General_parameters']['gc_activation'] and (('GC' in file and 'result' in file) or 'RPS' in file)) or \
        #           (not self.parameters_helper.current_parameters['General_parameters']['gc_activation'] and ('Morphed' in file or 'RPS' in file)):
        #            print(f"GUI : Processing file {file_path} for H-type section removal.")
        #            # load the xml file
        #            xml_tree = ET.parse(file_path)
        #            xml_root = xml_tree.getroot()

        #            # Remove H-type rps_location from their parent
        #            removed = False
        #            for parent in xml_root.iter():
        #                for rps_location in list(parent.findall('rps_location')):
        #                    if 'H' in (rps_location.get('node_type') or ''):
        #                        parent.remove(rps_location)
        #                        print(f"GUI : Removed H-type section from {file_path}.")
        #                        removed = True

        #            if removed:
        #                # save the modified xml file
        #                xml_tree.write(file_path, encoding='utf-8', xml_declaration=True)
        #            break
        
        self.main_window.fixedhtype_checkBox.setEnabled(False)
        self.message_window.show_message("All manaual H-type RPS are cleared")


# ------------------------------------------------------------ #
# Other auxiliary classes and functions
# ------------------------------------------------------------ #

# File and Folder helper class
class FileFolder_helper:
    def __init__(self, main_window):
        self.main_window = main_window

        self.project_dict = {
            "project_name": None,
            "project_folder": None,
            "import_geometry_folder": None,
            "import_measurement_folder": None,
            "import_fixture_folder": None,
            "import_rps_folder": None,
            "material_folder": None,
            "swproject_folder": None,
            "output_folder": None
        }

        self.project_status = {
            "import_data": {
                "import_geometry": False,
                "import_measurement": False,
                "import_fixture": False,
                "import_rps": False
            },
            "processing": {
                "morphing": False,
                "gc": False,
                "rps": False
            }
        }

        self.menubutton_status = {
            "import_geometry": False,
            "import_measurement": False,
            "import_fixture": False,
            "import_rps": False,
            "morphing": False,
            "gc": False,
            "rps": False
        }

        self.advancedbutton_status = {
            "adjust_hole": False,
            "fixed_htype_rps": False,
            "clear_htype_rps": True
        }

        self.settingbutton_status = {
            "export_result": False,
            "save_project": False
        }

        self.parametersbutton_status = {
            "save_parameters": False,
            "load_parameters": False
        }
    
    #This function will set default values to all instance variables and also the visualization of the GUI
    def set_defaults(self):
        self.project_status = {
            "import_data": {
                "import_geometry": False,
                "import_measurement": False,
                "import_fixture": False,
                "import_rps": False
            },
            "processing": {
                "morphing": False,
                "gc": False,
                "rps": False
            }
        }

        self.menubutton_status = {
            "import_geometry": False,
            "import_measurement": False,
            "import_fixture": False,
            "import_rps": False,
            "morphing": False,
            "gc": False,
            "rps": False
        }

        self.advancedbutton_status = {
            "adjust_hole": False,
            "fixed_htype_rps": False,
            "clear_htype_rps": True
        }

        self.settingbutton_status = {
            "export_result": False,
            "save_project": False
        }

        self.parametersbutton_status = {
            "save_parameters": False,
            "load_parameters": False
        }

        # update the status of the run/stop buttons
        self.main_window.startmorphing_pushButton.setEnabled(True)
        self.main_window.stopmorphing_pushButton.setEnabled(False)
        self.main_window.startgc_pushButton.setEnabled(True)
        self.main_window.stopgc_pushButton.setEnabled(False)
        self.main_window.startrps_pushButton.setEnabled(True)
        self.main_window.stoprps_pushButton.setEnabled(False)

        # update the status of the progress bar
        self.main_window.morphing_progressBar.setValue(0)
        self.main_window.gc_progressBar.setValue(0)
        self.main_window.rps_progressBar.setValue(0)

        # set the plain text edit to empty
        self.main_window.geometryfile_plainTextEdit.setPlainText("Select geometry or mesh file here -->")
        self.main_window.measurementfile_plainTextEdit.setPlainText("Select measurement data (.stl) here -->")
        self.main_window.holdingfixturefile_plainTextEdit.setPlainText("Select fixture's info file (.csv) here -->")
        self.main_window.rpsfile_plainTextEdit.setPlainText("Select F-type RPS info file (.csv) here -->")

        # set the advanced buttons to disabled
        self.main_window.adjustholes_pushButton.setEnabled(False)
        self.main_window.fixedhtype_checkBox.setEnabled(False)
        self.main_window.clearhrps_pushButton.setEnabled(True)

    def auto_project_name(self):
        project_name = f"VFproject_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        return project_name

    def create_project_folder(self, all_path, file_structure):
        # auto-generate the project name
        project_name = self.auto_project_name()
        # pop up the new project window to get the project name
        self.newproject_window = None
        self.newproject_window = NewProject_window()
        self.newproject_window.show_name(project_name)
        self.newproject_window.exec()

        self.project_dict['project_name'] = self.newproject_window.projectname_plainTextEdit.toPlainText().strip()
        if not self.project_dict['project_name'] or self.project_dict['project_name'] == "":
            project_name = project_name
        project_folder = os.path.join(all_path['Work_Directory'], self.project_dict['project_name'])

        # check if the project folder already exists
        if os.path.exists(project_folder):
            return False

        os.makedirs(project_folder, exist_ok=True)
        self.createSubFolders(project_folder, file_structure)

        # update the project dictionary
        self.project_dict['project_folder'] = os.path.normpath(project_folder)
        self.project_dict['import_geometry_folder'] = os.path.normpath(os.path.join(project_folder, '0-Inputs/0-CAD'))
        self.project_dict['import_measurement_folder'] = os.path.normpath(os.path.join(project_folder, '0-Inputs/3-Measurement'))
        self.project_dict['import_fixture_folder'] = os.path.normpath(os.path.join(project_folder, '0-Inputs/2-HoldingFixture'))
        self.project_dict['import_rps_folder'] = os.path.normpath(os.path.join(project_folder, '0-Inputs/1-RPS'))
        self.project_dict['material_folder'] = os.path.normpath(os.path.join(project_folder, '0-Inputs/4-Material'))
        self.project_dict['swproject_folder'] = os.path.normpath(os.path.join(project_folder, '1-SWProject'))
        self.project_dict['output_folder'] = os.path.normpath(os.path.join(project_folder, '2-Outputs'))

        return True
    
    def renew_project_folder_dict(self, new_project_folder):
        # update the project dictionary with the new project folder
        new_project_folder = os.path.normpath(new_project_folder)
        self.project_dict['project_folder'] = os.path.normpath(new_project_folder)
        self.project_dict['import_geometry_folder'] = os.path.normpath(os.path.join(new_project_folder, '0-Inputs/0-CAD'))
        self.project_dict['import_measurement_folder'] = os.path.normpath(os.path.join(new_project_folder, '0-Inputs/3-Measurement'))
        self.project_dict['import_fixture_folder'] = os.path.normpath(os.path.join(new_project_folder, '0-Inputs/2-HoldingFixture'))
        self.project_dict['import_rps_folder'] = os.path.normpath(os.path.join(new_project_folder, '0-Inputs/1-RPS'))
        self.project_dict['material_folder'] = os.path.normpath(os.path.join(new_project_folder, '0-Inputs/4-Material'))
        self.project_dict['swproject_folder'] = os.path.normpath(os.path.join(new_project_folder, '1-SWProject'))
        self.project_dict['output_folder'] = os.path.normpath(os.path.join(new_project_folder, '2-Outputs'))

    def createSubFolders(self, parent_directory, subfolders_structure):
        for folder, subfolders in subfolders_structure.items():
            folder_path = os.path.join(parent_directory, folder)
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)

            self.createSubFolders(folder_path, subfolders)

    def update_project_status(self, parameters=None):
        if self.project_dict['project_folder'] is not None:
            # -- check the status of the import geometry
            # search for CAD_geometry.bdf and .stl file within the import geometry folder
            check_geometry = ["CAD_geometry.bdf", "CAD_geometry.stl"]
            import_geometry_folder = self.project_dict['import_geometry_folder']
            for file in check_geometry:
                if os.path.exists(os.path.join(import_geometry_folder, file)):
                    self.project_status['import_data']['import_geometry'] = True
                else:
                    self.project_status['import_data']['import_geometry'] = False
                    break

            # -- check the status of the import measurement
            check_measurement = ["Measurement_data.stl"]
            import_measurement_folder = self.project_dict['import_measurement_folder']
            for file in check_measurement:
                if os.path.exists(os.path.join(import_measurement_folder, file)):
                    self.project_status['import_data']['import_measurement'] = True
                else:
                    self.project_status['import_data']['import_measurement'] = False
                    break
            
            # -- check the status of the import holding fixture
            check_fixture = ["Holding_fixture.csv"]
            import_fixture_folder = self.project_dict['import_fixture_folder']
            for file in check_fixture:
                if os.path.exists(os.path.join(import_fixture_folder, file)):
                    self.project_status['import_data']['import_fixture'] = True
                else:
                    self.project_status['import_data']['import_fixture'] = False
                    break
            
            # -- check the status of the import rps
            check_importrps = ["FType_RPS.csv"]
            import_rps_folder = self.project_dict['import_rps_folder']
            for file in check_importrps:
                if os.path.exists(os.path.join(import_rps_folder, file)):
                    self.project_status['import_data']['import_rps'] = True
                else:
                    self.project_status['import_data']['import_rps'] = False
                    break
            
            # -- check the status of the morphing process
            check_morphing = ["Morphed_geometry.stl", "Morphed_geometry.bdf"]
            result_morphing_folder = os.path.join(self.project_dict['output_folder'], '0-Morphing')
            for file in check_morphing:
                if os.path.exists(os.path.join(result_morphing_folder, file)):
                    self.project_status['processing']['morphing'] = True
                else:
                    self.project_status['processing']['morphing'] = False
                    break
            
            # -- check the status of the gravity compensation process
            check_gc = ["GC_result_geometry.stl", "GC_result_geometry.bdf"]
            result_gc_folder = os.path.join(self.project_dict['output_folder'], '1-GC')
            for file in check_gc:
                if os.path.exists(os.path.join(result_gc_folder, file)):
                    self.project_status['processing']['gc'] = True
                else:
                    self.project_status['processing']['gc'] = False
                    break
            
            # -- check the status of the rps clamping process
            check_rps = ["RPS_geometry.stl", "RPS_geometry.bdf"]
            result_rps_folder = os.path.join(self.project_dict['output_folder'], '2-RPS')
            for file in check_rps:
                if os.path.exists(os.path.join(result_rps_folder, file)):
                    self.project_status['processing']['rps'] = True
                else:
                    self.project_status['processing']['rps'] = False
                    break
        
        # update the color of the icon in the buttons
        if self.project_status['import_data']['import_geometry']:
            self.main_window.importgeometryicon_pushButton.setIcon(QIcon(":/root/images/geometry_green.png"))
            self.main_window.importgeometry_pushButton.setIcon(QIcon(":/root/images/geometry_green.png"))
        else:
            self.main_window.importgeometryicon_pushButton.setIcon(QIcon(":/root/images/geometry.png"))
            self.main_window.importgeometry_pushButton.setIcon(QIcon(":/root/images/geometry.png"))
        if self.project_status['import_data']['import_measurement']:
            self.main_window.importmeasurementicon_pushButton.setIcon(QIcon(":/root/images/measurement_green.png"))
            self.main_window.importmeasurement_pushButton.setIcon(QIcon(":/root/images/measurement_green.png"))
        else:
            self.main_window.importmeasurementicon_pushButton.setIcon(QIcon(":/root/images/measurement.png"))
            self.main_window.importmeasurement_pushButton.setIcon(QIcon(":/root/images/measurement.png"))
        if self.project_status['import_data']['import_fixture']:
            self.main_window.importfixtureicon_pushButton.setIcon(QIcon(":/root/images/holdingfixture_green.png"))
            self.main_window.importfixture_pushButton.setIcon(QIcon(":/root/images/holdingfixture_green.png"))
        else:
            self.main_window.importfixtureicon_pushButton.setIcon(QIcon(":/root/images/holdingfixture.png"))
            self.main_window.importfixture_pushButton.setIcon(QIcon(":/root/images/holdingfixture.png"))
        if self.project_status['import_data']['import_rps']:
            self.main_window.importrpsicon_pushButton.setIcon(QIcon(":/root/images/importRPS_green.png"))
            self.main_window.importrps_pushButton.setIcon(QIcon(":/root/images/importRPS_green.png"))
        else:
            self.main_window.importrpsicon_pushButton.setIcon(QIcon(":/root/images/importRPS.png"))
            self.main_window.importrps_pushButton.setIcon(QIcon(":/root/images/importRPS.png"))
        if self.project_status['processing']['morphing']:
            self.main_window.morphicon_pushButton.setIcon(QIcon(":/root/images/morphing_green.png"))
            self.main_window.morph_pushButton.setIcon(QIcon(":/root/images/morphing_green.png"))
        else:
            self.main_window.morphicon_pushButton.setIcon(QIcon(":/root/images/morphing.png"))
            self.main_window.morph_pushButton.setIcon(QIcon(":/root/images/morphing.png"))
        if self.project_status['processing']['gc'] and parameters['General_parameters']['gc_activation']:
            self.main_window.gcicon_pushButton.setIcon(QIcon(":/root/images/gravitycompensation_green.png"))
            self.main_window.gc_pushButton.setIcon(QIcon(":/root/images/gravitycompensation_green.png"))
        else:
            self.main_window.gcicon_pushButton.setIcon(QIcon(":/root/images/gravitycompensation.png"))
            self.main_window.gc_pushButton.setIcon(QIcon(":/root/images/gravitycompensation.png"))
        if self.project_status['processing']['rps']:
            self.main_window.rpsicon_pushButton.setIcon(QIcon(":/root/images/RPS_green.png"))
            self.main_window.rps_pushButton.setIcon(QIcon(":/root/images/RPS_green.png"))
        else:
            self.main_window.rpsicon_pushButton.setIcon(QIcon(":/root/images/RPS.png"))
            self.main_window.rps_pushButton.setIcon(QIcon(":/root/images/RPS.png"))
        
        # --------------------- #
        # update the menu button status
        # --------------------- #
        self.update_button_status(parameters)

        # --------------------- #
        # export the json file to the project folder
        # this is used for auto-save the project status, so that the user can load it later
        # --------------------- #
        create_json = True
        for key, value in self.project_dict.items():
            if value is None:
                create_json = False
                break
        if create_json:
            json_file_path = os.path.join(self.project_dict['project_folder'], 'save_project.json')
            project_status_dict = {
                "project_dict": self.project_dict,
                "project_status": self.project_status
            }
            with open(json_file_path, 'w') as json_file:
                json.dump(project_status_dict, json_file, indent=4)

    def update_button_status(self, parameters=None):
        # check the button status of the import geometry
        if self.project_dict['project_folder'] is not None and os.path.exists(self.project_dict['project_folder']):
            self.menubutton_status['import_geometry'] = True
        else:
            self.menubutton_status['import_geometry'] = False
        
        # check the button status of the import measurement
        if self.project_status['import_data']['import_geometry'] and self.menubutton_status['import_geometry']:
            self.menubutton_status['import_measurement'] = True
        else:
            self.menubutton_status['import_measurement'] = False
        
        # check the button status of the import holding fixture
        if self.project_status['import_data']['import_geometry'] and self.menubutton_status['import_geometry'] and \
            parameters['General_parameters']['gc_activation']:
            self.menubutton_status['import_fixture'] = True
        else:
            self.menubutton_status['import_fixture'] = False
        
        # check the button status of the import rps
        if self.project_status['import_data']['import_geometry'] and self.menubutton_status['import_geometry'] and \
            self.project_status['import_data']['import_measurement'] and self.menubutton_status['import_measurement']:
            self.menubutton_status['import_rps'] = True
        else:
            self.menubutton_status['import_rps'] = False
        
        # check the button status of the morphing process
        if self.project_status['import_data']['import_geometry'] and self.project_status['import_data']['import_measurement'] and \
            self.project_status['import_data']['import_rps']:
            self.menubutton_status['morphing'] = True
        else:
            self.menubutton_status['morphing'] = False
        
        # check the button status of the gravity compensation process
        if self.project_status['processing']['morphing'] and parameters['General_parameters']['gc_activation'] and \
            self.project_status['import_data']['import_fixture'] and parameters['General_parameters']['gc_activation']:
            self.menubutton_status['gc'] = True
        else:
            self.menubutton_status['gc'] = False
        
        # check the button status of the rps clamping process
        if (self.project_status['processing']['gc'] and parameters['General_parameters']['gc_activation']) or \
            (self.project_status['processing']['morphing'] and not parameters['General_parameters']['gc_activation']):
            self.menubutton_status['rps'] = True
        else:
            self.menubutton_status['rps'] = False

        # check the button status of the export result
        if self.project_status['processing']['rps'] or self.project_status['processing']['gc'] or self.project_status['processing']['morphing']:
            self.settingbutton_status['export_result'] = True
        else:
            self.settingbutton_status['export_result'] = False
        
        # check the button status of the save parameters
        if self.project_dict['project_folder'] is not None and os.path.exists(self.project_dict['project_folder']):
            self.parametersbutton_status['save_parameters'] = True
            self.parametersbutton_status['load_parameters'] = True
            self.settingbutton_status['save_project'] = True
        else:
            self.parametersbutton_status['save_parameters'] = False
            self.parametersbutton_status['load_parameters'] = False
            self.settingbutton_status['save_project'] = False

        # check the button status of the adjust hole
        if self.project_status['processing']['morphing']:
            self.advancedbutton_status['adjust_hole'] = True
        else:
            self.advancedbutton_status['adjust_hole'] = False

        # check the checkbox for fixed H-type RPS
        self.advancedbutton_status['fixed_htype_rps'] = False
        for file in os.listdir(self.project_dict['import_rps_folder']):
            if 'HType_cad_info' in file:
                self.advancedbutton_status['fixed_htype_rps'] = True
                break
        
        # check the buttons for exporting the RPS result to Polyworks
        if self.project_status['processing']['rps']:
            self.menubutton_status['export_rps'] = True
        else:
            self.menubutton_status['export_rps'] = False
        
        # --------------------- #
        # update the button status in the main window
        # --------------------- #
        self.main_window.importgeometryicon_pushButton.setEnabled(self.menubutton_status['import_geometry'])
        self.main_window.importgeometry_pushButton.setEnabled(self.menubutton_status['import_geometry'])
        self.main_window.geometryfile_pushButton.setEnabled(self.menubutton_status['import_geometry'])

        self.main_window.importmeasurementicon_pushButton.setEnabled(self.menubutton_status['import_measurement'])
        self.main_window.importmeasurement_pushButton.setEnabled(self.menubutton_status['import_measurement'])

        self.main_window.importfixtureicon_pushButton.setEnabled(self.menubutton_status['import_fixture'])
        self.main_window.importfixture_pushButton.setEnabled(self.menubutton_status['import_fixture'])

        self.main_window.importrpsicon_pushButton.setEnabled(self.menubutton_status['import_rps'])
        self.main_window.importrps_pushButton.setEnabled(self.menubutton_status['import_rps'])

        self.main_window.morphicon_pushButton.setEnabled(self.menubutton_status['morphing'])
        self.main_window.morph_pushButton.setEnabled(self.menubutton_status['morphing'])

        self.main_window.gcicon_pushButton.setEnabled(self.menubutton_status['gc'])
        self.main_window.gc_pushButton.setEnabled(self.menubutton_status['gc'])

        self.main_window.rpsicon_pushButton.setEnabled(self.menubutton_status['rps'])
        self.main_window.rps_pushButton.setEnabled(self.menubutton_status['rps'])

        self.main_window.manageresults_pushButton.setEnabled(self.settingbutton_status['export_result'])
        self.main_window.saveproject_pushButton.setEnabled(self.settingbutton_status['save_project'])
        self.main_window.opensw_pushButton.setEnabled(self.settingbutton_status['export_result'])

        self.main_window.saveparameters_pushButton.setEnabled(self.parametersbutton_status['save_parameters'])
        self.main_window.loadparameters_pushButton.setEnabled(self.parametersbutton_status['load_parameters'])

        self.main_window.adjustholes_pushButton.setEnabled(self.advancedbutton_status['adjust_hole'])
        self.main_window.fixedhtype_checkBox.setEnabled(self.advancedbutton_status['fixed_htype_rps'])
        self.main_window.clearhrps_pushButton.setEnabled(self.advancedbutton_status['clear_htype_rps'])

    def delete_morphing_result(self):
        morphing_result_folder = os.path.join(self.project_dict['output_folder'], '0-Morphing')
        # delete all file inside the morphing result folder
        if os.path.exists(morphing_result_folder):
            for file in os.listdir(morphing_result_folder):
                file_path = os.path.join(morphing_result_folder, file)
                if os.path.isfile(file_path) and file_path.endswith(('.CATPart', '.stp', '.x_t', '.x_b', '.igs', '.bdf', '.stl')):
                    os.remove(file_path)

    def delete_gc_result(self):
        gc_result_folder = os.path.join(self.project_dict['output_folder'], '1-GC')
        # delete all file inside the GC result folder
        if os.path.exists(gc_result_folder):
            for file in os.listdir(gc_result_folder):
                file_path = os.path.join(gc_result_folder, file)
                if os.path.isfile(file_path) and file_path.endswith(('.CATPart', '.stp', '.x_t', '.x_b', '.igs', '.bdf', '.stl')):
                    os.remove(file_path)

    def delete_rps_result(self):
        rps_result_folder = os.path.join(self.project_dict['output_folder'], '2-RPS')
        # delete all file inside the RPS result folder
        if os.path.exists(rps_result_folder):
            for file in os.listdir(rps_result_folder):
                file_path = os.path.join(rps_result_folder, file)
                if os.path.isfile(file_path) and file_path.endswith(('.bdf', '.stl')):
                    os.remove(file_path)

    def delete_manual_htype_rps(self):
        delete_htype = True

        if delete_htype:
            # delete the GUI H-type RPS csv file in the import rps folder
            rps_input_folder = self.project_dict['import_rps_folder']
            for file in os.listdir(rps_input_folder):
                file_path = os.path.join(rps_input_folder, file)
                if os.path.isfile(file_path) and file.endswith('.csv') and 'HType' in file:
                    os.remove(file_path)
                    print(f"Deleted HType file: {file_path}")

    def open_project_folder(self):
        if self.project_dict['project_folder'] is not None:
            os.startfile(self.project_dict['project_folder'])


# Parameters helper class
class Parameters_helper:
    def __init__(self, main_window):
        self.main_window = main_window
        self.all_paths = None
        self.current_parameters = {
            "General_parameters": {
                "gc_activation": True,
                "geometry_type": "Volume",
                "smp_cores": 4,
                "ddm_domain": 1
            },
            "Meshing_parameters": {
                "cad_healing": True,
                "mesh_size_mm": 2.0,
                "curvature_refinement": True
            },
            "Material_parameters": {
                "material_type": "General steel",
                "material_file": "16MnCr5-SPM_sw.xmt"
            },
            "Morphing_parameters": {
                "match_mode": "scan_incomplete",
                "best_fit": False,
                "add_transformation": False,
                "export_singlegeometry": False,
                "surface_tolerance_degree": 60,
                "ignore_outliers_percent": 0.5,
                "level_of_detail": "medium"
            },
            "GC_parameters": {
                "simplified_gc": False,
                "pin_number": 3,
                "search_radius_mm": 3.0,
                "target_deviation_mm": 0.05,
                "max_iteration": 6,
                "gravity_direction": "-Z",
                "customed_gravity": (0, 0, -1)
            },
            "RPS_parameters": {
                "rps_gravity_direction": "-Z",
                "rps_customed_gravity": (0, 0, -1),
                "htype_activation": False,
                "fixed_htype": False
            }
        }

        # initiate the message window
        self.message_window = MessageWindow_window()

    def read_paths(self):
        # Read the paths from the path_configuration.json file
        path_file = os.path.normpath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 
                                                  'Settings/path_configuration.json'))
        with open(path_file) as json_file:
            paths = json.load(json_file)
        self.all_paths = paths
    
    def read_parameters(self):
        # Read the parameters from the parameters.ini file
        parameters_file = os.path.normpath(os.path.join(os.path.dirname(os.path.dirname(__file__)), 
                                                        'Settings/default_parameters.ini'))
        config = configparser.ConfigParser()
        config.read(parameters_file)

        # assign the parameters to a dictionary, if possible
        try:
            parameters = {
                "General_parameters": {
                    "gc_activation": True if config.get('General_parameters', 'gc_activation') == 'True' else False,
                    "geometry_type": config.get('General_parameters', 'geometry_type'),
                    "smp_cores": int(config.get('General_parameters', 'smp_cores')),
                    "ddm_domain": int(config.get('General_parameters', 'ddm_domain'))
                },
                "Meshing_parameters": {
                    "cad_healing": True if config.get('Meshing_parameters', 'cad_healing') == 'True' else False,
                    "mesh_size_mm": float(config.get('Meshing_parameters', 'mesh_size_mm')),
                    "curvature_refinement": True if config.get('Meshing_parameters', 'curvature_refinement') == 'True' else False
                },
                "Material_parameters": {
                    "material_type": config.get('Material_parameters', 'material_type'),
                    "material_file": config.get('Material_parameters', 'material_file')
                },
                "Morphing_parameters": {
                    "match_mode": config.get('Morphing_parameters', 'match_mode'),
                    "best_fit": True if config.get('Morphing_parameters', 'best_fit') == 'True' else False,
                    "add_transformation": True if config.get('Morphing_parameters', 'add_transformation') == 'True' else False,
                    "export_singlegeometry": True if config.get('Morphing_parameters', 'export_singlegeometry') == 'True' else False,
                    "surface_tolerance_degree": int(config.get('Morphing_parameters', 'surface_tolerance_degree')),
                    "ignore_outliers_percent": float(config.get('Morphing_parameters', 'ignore_outliers_percent')),
                    "level_of_detail": config.get('Morphing_parameters', 'level_of_detail')
                },
                "GC_parameters": {
                    "simplified_gc": True if config.get('GC_parameters', 'simplified_gc') == 'True' else False,
                    "pin_number": int(config.get('GC_parameters', 'pin_number')),
                    "search_radius_mm": float(config.get('GC_parameters', 'search_radius_mm')),
                    "target_deviation_mm": float(config.get('GC_parameters', 'target_deviation_mm')),
                    "max_iteration": int(config.get('GC_parameters', 'max_iteration')),
                    "gravity_direction": config.get('GC_parameters', 'gravity_direction'),
                    "customed_gravity": tuple(map(float, config.get('GC_parameters', 'customed_gravity').split(',')))
                },
                "RPS_parameters": {
                    "rps_gravity_direction": config.get('RPS_parameters', 'rps_gravity_direction'),
                    "rps_customed_gravity": tuple(map(float, config.get('RPS_parameters', 'rps_customed_gravity').split(','))),
                    "htype_activation": True if config.get('RPS_parameters', 'htype_activation') == 'True' else False,
                    "fixed_htype": True if config.get('RPS_parameters', 'fixed_htype') == 'True' else False
                }
            }
            self.current_parameters = parameters
        except Exception as e:
            print(f"Error reading parameters: {e}")
        
        # update the parameters in the main window
        self.update_parameters_gui()
    
    def update_parameters_gui(self):
        # update the parameters in the main window
        self.main_window.gcactivation_checkBox.setChecked(self.current_parameters['General_parameters']['gc_activation'])
        self.main_window.geometrytype_comboBox.setCurrentText(self.current_parameters['General_parameters']['geometry_type'])
        self.main_window.smp_plainTextEdit.setPlainText(str(self.current_parameters['General_parameters']['smp_cores']))
        self.main_window.ddm_plainTextEdit.setPlainText(str(self.current_parameters['General_parameters']['ddm_domain']))

        self.main_window.meshsize_plainTextEdit.setPlainText(str(self.current_parameters['Meshing_parameters']['mesh_size_mm']))
        self.main_window.cadhealing_checkBox.setChecked(self.current_parameters['Meshing_parameters']['cad_healing'])
        self.main_window.curvaturerefine_checkBox.setChecked(self.current_parameters['Meshing_parameters']['curvature_refinement'])

        self.main_window.materialtype_comboBox.setCurrentText(self.current_parameters['Material_parameters']['material_type'])
        self.main_window.material_comboBox.setCurrentText(self.current_parameters['Material_parameters']['material_file'])

        self.main_window.matchmode_comboBox.setCurrentText(self.current_parameters['Morphing_parameters']['match_mode'])
        self.main_window.bestfit_checkBox.setChecked(self.current_parameters['Morphing_parameters']['best_fit'])
        self.main_window.transformation_checkBox.setChecked(self.current_parameters['Morphing_parameters']['add_transformation'])
        self.main_window.singlegeometry_checkBox.setChecked(self.current_parameters['Morphing_parameters']['export_singlegeometry'])
        self.main_window.surfacetolerance_plainTextEdit.setPlainText(str(self.current_parameters['Morphing_parameters']['surface_tolerance_degree']))
        self.main_window.ignoreoutlier_plainTextEdit.setPlainText(str(self.current_parameters['Morphing_parameters']['ignore_outliers_percent']))
        self.main_window.morphlevel_comboBox.setCurrentText(self.current_parameters['Morphing_parameters']['level_of_detail'])

        self.main_window.simplifiedgc_checkBox.setChecked(self.current_parameters['GC_parameters']['simplified_gc'])
        self.main_window.pinnumber_comboBox.setCurrentText(str(self.current_parameters['GC_parameters']['pin_number']))
        self.main_window.searchradius_plainTextEdit.setPlainText(str(self.current_parameters['GC_parameters']['search_radius_mm']))
        self.main_window.targetdeviation_plainTextEdit.setPlainText(str(self.current_parameters['GC_parameters']['target_deviation_mm']))
        self.main_window.maxiteration_plainTextEdit.setPlainText(str(self.current_parameters['GC_parameters']['max_iteration']))
        self.main_window.gravitydirection_comboBox.setCurrentText(self.current_parameters['GC_parameters']['gravity_direction'])
        self.main_window.customedx_plainTextEdit.setPlainText(str(self.current_parameters['GC_parameters']['customed_gravity'][0]))
        self.main_window.customedy_plainTextEdit.setPlainText(str(self.current_parameters['GC_parameters']['customed_gravity'][1]))
        self.main_window.customedz_plainTextEdit.setPlainText(str(self.current_parameters['GC_parameters']['customed_gravity'][2]))

        self.main_window.rpsgravitydirection_comboBox.setCurrentText(self.current_parameters['RPS_parameters']['rps_gravity_direction'])
        self.main_window.rpscustomedx_plainTextEdit.setPlainText(str(self.current_parameters['RPS_parameters']['rps_customed_gravity'][0]))
        self.main_window.rpscustomedy_plainTextEdit.setPlainText(str(self.current_parameters['RPS_parameters']['rps_customed_gravity'][1]))
        self.main_window.rpscustomedz_plainTextEdit.setPlainText(str(self.current_parameters['RPS_parameters']['rps_customed_gravity'][2]))
        self.main_window.fixedhtype_checkBox.setChecked(self.current_parameters['RPS_parameters']['fixed_htype'])

    def save_parameters(self, project_dict):
        # save the parameters to the parameters.ini file in the project folder
        parameters_file = os.path.normpath(os.path.join(project_dict['project_folder'], 'parameters.ini'))
        config = configparser.ConfigParser()
        config['General_parameters'] = {
            'gc_activation': self.main_window.gcactivation_checkBox.isChecked(),
            'geometry_type': self.main_window.geometrytype_comboBox.currentText(),
            'smp_cores': self.main_window.smp_plainTextEdit.toPlainText(),
            'ddm_domain': self.main_window.ddm_plainTextEdit.toPlainText()
        }
        config['Meshing_parameters'] = {
            'cad_healing': self.main_window.cadhealing_checkBox.isChecked(),
            'mesh_size_mm': self.main_window.meshsize_plainTextEdit.toPlainText(),
            'curvature_refinement': self.main_window.curvaturerefine_checkBox.isChecked()
        }
        config['Material_parameters'] = {
            'material_type': self.main_window.materialtype_comboBox.currentText(),
            'material_file': self.main_window.material_comboBox.currentText()
        }
        config['Morphing_parameters'] = {
            'match_mode': self.main_window.matchmode_comboBox.currentText(),
            'best_fit': self.main_window.bestfit_checkBox.isChecked(),
            'add_transformation': self.main_window.transformation_checkBox.isChecked(),
            'export_singlegeometry': self.main_window.singlegeometry_checkBox.isChecked(),
            'surface_tolerance_degree': self.main_window.surfacetolerance_plainTextEdit.toPlainText(),
            'ignore_outliers_percent': self.main_window.ignoreoutlier_plainTextEdit.toPlainText(),
            'level_of_detail': self.main_window.morphlevel_comboBox.currentText()
        }
        config['GC_parameters'] = {
            'simplified_gc': self.main_window.simplifiedgc_checkBox.isChecked(),
            'pin_number': self.main_window.pinnumber_comboBox.currentText(),
            'search_radius_mm': self.main_window.searchradius_plainTextEdit.toPlainText(),
            'target_deviation_mm': self.main_window.targetdeviation_plainTextEdit.toPlainText(),
            'max_iteration': self.main_window.maxiteration_plainTextEdit.toPlainText(),
            'gravity_direction': self.main_window.gravitydirection_comboBox.currentText(),
            'customed_gravity': f"{self.main_window.customedx_plainTextEdit.toPlainText()},{self.main_window.customedy_plainTextEdit.toPlainText()},{self.main_window.customedz_plainTextEdit.toPlainText()}"
        }
        config['RPS_parameters'] = {
            'rps_gravity_direction': self.main_window.rpsgravitydirection_comboBox.currentText(),
            'rps_customed_gravity': f"{self.main_window.rpscustomedx_plainTextEdit.toPlainText()},{self.main_window.rpscustomedy_plainTextEdit.toPlainText()},{self.main_window.rpscustomedz_plainTextEdit.toPlainText()}",
            'htype_activation': "False",
            'fixed_htype': self.main_window.fixedhtype_checkBox.isChecked()
        }

        with open(parameters_file, 'w') as configfile:
            config.write(configfile)

        # save parameters to the ini file in the Settings folder
        default_parameters_file = os.path.normpath(os.path.join(os.path.dirname(os.path.dirname(__file__)),
                                                                'Settings/default_parameters.ini'))
        with open(default_parameters_file, 'w') as configfile:
            config.write(configfile)

        print("Parameters saved successfully")
        self.message_window.show_message("Parameters saved successfully")

    def load_parameters(self):
        # select the .ini file
        default_search = self.all_paths['Work_Directory']
        parameters_file = QtWidgets.QFileDialog.getOpenFileName(self.main_window, 
                                                                "Select the parameters file",
                                                                default_search,
                                                                filter="INI files (*.ini)")[0]
        
        if os.path.exists(parameters_file) and parameters_file.endswith(".ini"):
            # Read the parameters from the .ini file
            config = configparser.ConfigParser()
            config.read(parameters_file)

            # assign the parameters to a dictionary, if possible
            try:
                parameters = {
                    "General_parameters": {
                        "gc_activation": True if config.get('General_parameters', 'gc_activation') == 'True' else False,
                        "geometry_type": config.get('General_parameters', 'geometry_type'),
                        "smp_cores": int(config.get('General_parameters', 'smp_cores')),
                        "ddm_domain": int(config.get('General_parameters', 'ddm_domain'))
                    },
                    "Meshing_parameters": {
                        "cad_healing": True if config.get('Meshing_parameters', 'cad_healing') == 'True' else False,
                        "mesh_size_mm": float(config.get('Meshing_parameters', 'mesh_size_mm')),
                        "curvature_refinement": True if config.get('Meshing_parameters', 'curvature_refinement') == 'True' else False
                    },
                    "Material_parameters": {
                        "material_type": config.get('Material_parameters', 'material_type'),
                        "material_file": config.get('Material_parameters', 'material_file')
                    },
                    "Morphing_parameters": {
                        "match_mode": config.get('Morphing_parameters', 'match_mode'),
                        "best_fit": True if config.get('Morphing_parameters', 'best_fit') == 'True' else False,
                        "add_transformation": True if config.get('Morphing_parameters', 'add_transformation') == 'True' else False,
                        "export_singlegeometry": True if config.get('Morphing_parameters', 'export_singlegeometry') == 'True' else False,
                        "surface_tolerance_degree": int(config.get('Morphing_parameters', 'surface_tolerance_degree')),
                        "ignore_outliers_percent": float(config.get('Morphing_parameters', 'ignore_outliers_percent')),
                        "level_of_detail": config.get('Morphing_parameters', 'level_of_detail')
                    },
                    "GC_parameters": {
                        "simplified_gc": True if config.get('GC_parameters', 'simplified_gc') == 'True' else False,
                        "pin_number": int(config.get('GC_parameters', 'pin_number')),
                        "search_radius_mm": float(config.get('GC_parameters', 'search_radius_mm')),
                        "target_deviation_mm": float(config.get('GC_parameters', 'target_deviation_mm')),
                        "max_iteration": int(config.get('GC_parameters', 'max_iteration')),
                        "gravity_direction": config.get('GC_parameters', 'gravity_direction'),
                        "customed_gravity": tuple(map(float, config.get('GC_parameters', 'customed_gravity').split(',')))
                    },
                    "RPS_parameters": {
                        "rps_gravity_direction": config.get('RPS_parameters', 'rps_gravity_direction'),
                        "rps_customed_gravity": tuple(map(float, config.get('RPS_parameters', 'rps_customed_gravity').split(','))),
                        "htype_activation": True if config.get('RPS_parameters', 'htype_activation') == 'True' else False,
                        "fixed_htype": True if config.get('RPS_parameters', 'fixed_htype') == 'True' else False
                    }
                }
                self.current_parameters = parameters
                self.message_window.show_message("Parameters loaded successfully")
            except Exception as e:
                print(f"Error reading parameters: {e}")
                self.message_window.show_message("Error reading parameters")
                return
            
            # update the parameters in the main window
            self.update_parameters_gui()
        else:
            print("File does not exist or is not an .ini file")
            self.message_window.show_message("File does not exist or is not an .ini file")
            return

    def update_parameters_from_gui(self):
        # update the parameters from the main window
        self.current_parameters['General_parameters']['gc_activation'] = self.main_window.gcactivation_checkBox.isChecked()
        self.current_parameters['General_parameters']['geometry_type'] = self.main_window.geometrytype_comboBox.currentText()
        self.current_parameters['General_parameters']['smp_cores'] = int(self.main_window.smp_plainTextEdit.toPlainText())
        self.current_parameters['General_parameters']['ddm_domain'] = int(self.main_window.ddm_plainTextEdit.toPlainText())

        self.current_parameters['Meshing_parameters']['mesh_size_mm'] = float(self.main_window.meshsize_plainTextEdit.toPlainText())
        self.current_parameters['Meshing_parameters']['cad_healing'] = self.main_window.cadhealing_checkBox.isChecked()
        self.current_parameters['Meshing_parameters']['curvature_refinement'] = self.main_window.curvaturerefine_checkBox.isChecked()

        self.current_parameters['Material_parameters']['material_type'] = self.main_window.materialtype_comboBox.currentText()
        self.current_parameters['Material_parameters']['material_file'] = self.main_window.material_comboBox.currentText()

        self.current_parameters['Morphing_parameters']['match_mode'] = self.main_window.matchmode_comboBox.currentText()
        self.current_parameters['Morphing_parameters']['best_fit'] = self.main_window.bestfit_checkBox.isChecked()
        self.current_parameters['Morphing_parameters']['add_transformation'] = self.main_window.transformation_checkBox.isChecked()
        self.current_parameters['Morphing_parameters']['export_singlegeometry'] = self.main_window.singlegeometry_checkBox.isChecked()
        self.current_parameters['Morphing_parameters']['surface_tolerance_degree'] = int(self.main_window.surfacetolerance_plainTextEdit.toPlainText())
        self.current_parameters['Morphing_parameters']['ignore_outliers_percent'] = float(self.main_window.ignoreoutlier_plainTextEdit.toPlainText())
        self.current_parameters['Morphing_parameters']['level_of_detail'] = self.main_window.morphlevel_comboBox.currentText()

        self.current_parameters['GC_parameters']['simplified_gc'] = self.main_window.simplifiedgc_checkBox.isChecked()
        self.current_parameters['GC_parameters']['pin_number'] = int(self.main_window.pinnumber_comboBox.currentText())
        self.current_parameters['GC_parameters']['search_radius_mm'] = float(self.main_window.searchradius_plainTextEdit.toPlainText())
        self.current_parameters['GC_parameters']['target_deviation_mm'] = float(self.main_window.targetdeviation_plainTextEdit.toPlainText())
        self.current_parameters['GC_parameters']['max_iteration'] = int(self.main_window.maxiteration_plainTextEdit.toPlainText())
        self.current_parameters['GC_parameters']['gravity_direction'] = self.main_window.gravitydirection_comboBox.currentText()
        self.current_parameters['GC_parameters']['customed_gravity'] = (float(self.main_window.customedx_plainTextEdit.toPlainText()),
                                                                       float(self.main_window.customedy_plainTextEdit.toPlainText()),
                                                                       float(self.main_window.customedz_plainTextEdit.toPlainText()))
        
        self.current_parameters['RPS_parameters']['rps_gravity_direction'] = self.main_window.rpsgravitydirection_comboBox.currentText()
        self.current_parameters['RPS_parameters']['rps_customed_gravity'] = (float(self.main_window.rpscustomedx_plainTextEdit.toPlainText()),
                                                                            float(self.main_window.rpscustomedy_plainTextEdit.toPlainText()),
                                                                            float(self.main_window.rpscustomedz_plainTextEdit.toPlainText()))
        self.current_parameters['RPS_parameters']['fixed_htype'] = self.main_window.fixedhtype_checkBox.isChecked()
        

# Material helper class
class Material_helper:
    def __init__(self, main_window):
        self.main_window = main_window
        self.message_window = MessageWindow_window()
        self.materials_dict = {}
        self.read_materials_library()

        # if the materialtype combobox is changed, update the material combobox
        self.main_window.materialtype_comboBox.currentTextChanged.connect(lambda: self.update_material_combobox(self.main_window.materialtype_comboBox.currentText()))
    
    def update_materials_dictgui(self):
        material_data_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 
                                          'Materials')
        material_json_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 
                                          'Settings/material_library.json')
        
        # update the materials dictionary and the gui by searching Simufact Material database
        if os.path.exists(material_data_path):
            material_dict = {}
            for file in os.listdir(material_data_path):
                if file.endswith(".xmt"):
                    root = ET.parse(os.path.join(material_data_path, file)).getroot()
                    
                    for child in root:
                        if child.tag == 'group':
                            group = child.text
                            break
                    
                    if group in material_dict:
                        material_dict[group].append(file)
                    else:
                        material_dict[group] = [file]
            
            # screen the material dict
            self.materials_dict = self.screen_MaterialXMT(material_dict, material_data_path)

            # dump the material dict to json file
            with open(material_json_path, 'w') as json_file:
                json.dump(self.materials_dict, json_file, indent=4)
        
            # update the materials type in the main window
            self.main_window.materialtype_comboBox.clear()
            self.main_window.materialtype_comboBox.addItems(self.materials_dict.keys())

            # update the materials list in the main window
            self.main_window.material_comboBox.clear()
            self.main_window.material_comboBox.addItems(self.materials_dict[self.main_window.materialtype_comboBox.currentText()])

            print("GUI : Material dictionary updated successfully")
            self.message_window.show_message("Material dictionary updated successfully")
        else:
            print("GUI : Material data path does not exist")
            self.message_window.show_message("Material data path does not exist.\nPlease check the path in the settings")
    
    def screen_MaterialXMT(self, material_dict, material_data_path):
        # screening parameters
        min_temp = 40.0         # minimum celcius temperature must be below this value
        max_temp = 100.0        # maximum celcius temperature must be above this value
        material_type = ['General steel', 'Stainless steel', 'Aluminum']    # material type must be one of these

        # iterate through the material dictionary and screen the materials
        screen_material_dict = {}
        delete_material = []
        for key, material_list in material_dict.items():
            # iterate through the material list
            for material in material_list:
                file_path = os.path.normpath(os.path.join(material_data_path, material))
                # open xmt file
                tree = ET.parse(file_path)
                root = tree.getroot()

                # screen the material other than the welding material
                if root.find('class') is None:
                    if material not in delete_material:
                        delete_material.append(material)
                else:
                    material_class = str(root.find('class').text)
                    if 'weld' not in material_class.lower() and material not in delete_material:
                        delete_material.append(material)

        # delete the material that does not meet the criteria and screen the material type
        for key, material_list in material_dict.items():
            if key in material_type:
                screen_material_dict[key] = [material for material in material_list if material not in delete_material]

        # make General steel as the first key of the dixtionary
        assorted_material_dict = {}
        for group in material_type:
            assorted_material_dict[group] = screen_material_dict[group]
    
        return assorted_material_dict
    
    def update_material_combobox(self, material_type):
        if material_type == "":
            self.main_window.material_comboBox.clear()
            self.main_window.material_comboBox.addItems(self.materials_dict["General steel"])
        else:
            self.main_window.material_comboBox.clear()
            self.main_window.material_comboBox.addItems(self.materials_dict[material_type])
    
    def read_materials_library(self):
        material_json_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 
                                          'Settings/material_library.json')
        if os.path.exists(material_json_path):
            with open(material_json_path) as json_file:
                self.materials_dict = json.load(json_file)

            # update the materials type in the main window
            self.main_window.materialtype_comboBox.clear()
            self.main_window.materialtype_comboBox.addItems(self.materials_dict.keys())

            # update the materials list in the main window
            self.main_window.material_comboBox.clear()
            self.main_window.material_comboBox.addItems(self.materials_dict[self.main_window.materialtype_comboBox.currentText()])
        else:
            print("Material library json file does not exist")

    def open_simufact_material(self, sm_path):
        print("GUI : Opening Simufact Material")
        try:
            # open the Simufact Material software
            simufact_material_exe = os.path.join(sm_path, "bin/simufact.material.exe")
            os.startfile(simufact_material_exe)
        except Exception as e:
            print(f"Error opening Simufact Material: {e}")
            self.message_window.show_message(f"Error opening Simufact Material: \n Please check the system paths")

    def open_simufact_mesh(self, sm_path):
        print("GUI : Opening Simufact Mesh")
        try:
            # open the Simufact Mesh software
            simufact_mesh_exe = os.path.join(sm_path, "simufact.mesh.exe")
            os.startfile(simufact_mesh_exe)
        except Exception as e:
            print(f"Error opening Simufact Mesh: {e}")
            self.message_window.show_message(f"Error opening Simufact Mesh: \n Please check the system paths")


# 3D Visualization helper class
class Visualization_helper:
    def __init__(self, main_window):
        self.main_window = main_window

        # declare the vtk widget for 3D visualization
        self.vtk_importgeometry = None
        self.vtk_importmeasurement = None
        self.vtk_importfixture = None
        self.vtk_importrps = None
        self.vtk_morphing = None
        self.vtk_gc = None
        self.vtk_rps = None

        # clear all render in the preview widgets
        if hasattr(self.main_window, 'vtk_importgeometry'):
            self.vtk_importgeometry.visualizer.clear_renderer()
        if hasattr(self.main_window, 'vtk_importmeasurement'):
            self.vtk_importmeasurement.visualizer.clear_renderer()
        if hasattr(self.main_window, 'vtk_importfixture'):
            self.vtk_importfixture.visualizer.clear_renderer()
        if hasattr(self.main_window, 'vtk_importrps'):
            self.vtk_importrps.visualizer.clear_renderer()
        if hasattr(self.main_window, 'vtk_morphing'):
            self.vtk_morphing.visualizer.clear_renderer()
        if hasattr(self.main_window, 'vtk_gc'):
            self.vtk_gc.visualizer.clear_renderer()
        if hasattr(self.main_window, 'vtk_rps'):
            self.vtk_rps.visualizer.clear_renderer()
    
    def clear_all_vtk(self):
        # clear all render in the preview widgets
        if self.vtk_importgeometry is not None:
            self.vtk_importgeometry.visualizer.clear_renderer()
        if self.vtk_importmeasurement is not None:
            self.vtk_importmeasurement.visualizer.clear_renderer()
        if self.vtk_importfixture is not None:
            self.vtk_importfixture.visualizer.clear_renderer()
        if self.vtk_importrps is not None:
            self.vtk_importrps.visualizer.clear_renderer()
        if self.vtk_morphing is not None:
            self.vtk_morphing.visualizer.clear_renderer()
        if self.vtk_gc is not None:
            self.vtk_gc.visualizer.clear_renderer()
        if  self.vtk_rps is not None:
            self.vtk_rps.visualizer.clear_renderer()
        
    # create a vtk widget for 3D visualization of import geometry
    def show_importgeometry_visualization(self, stl_file_path):
        # clear the existing widget from the layout before adding the new widget
        self.clear_layout(self.main_window.importgeometryvisual_widget_layout)
        self.vtk_importgeometry = None

        # Create a new VTK widget and load the STL file
        self.vtk_importgeometry = VTKWidgetWithPoints([stl_file_path], [(0.85, 0.85, 0.85)])
        self.main_window.importgeometryvisual_widget_layout.addWidget(self.vtk_importgeometry)

    # create a vtk widget for 3D visualization of import measurement
    def show_importmeasurement_visualization(self, cad_file_path, measurement_file_path):
        # clear the existing widget from the layout before adding the new widget
        self.clear_layout(self.main_window.importmeasurementvisual_widget_layout)
        self.vtk_importmeasurement = None

        # Create a new VTK widget and load the STL file
        self.vtk_importmeasurement = VTKWidgetWithPoints([cad_file_path, measurement_file_path], [(0.8, 0.8, 0.8), (1.0, 0.0, 0.0)])
        self.main_window.importmeasurementvisual_widget_layout.addWidget(self.vtk_importmeasurement)
    
    # create a vtk widget for 3D visualization of import holding fixture
    def show_importfixture_visualization(self, cad_file_path, holding_fixture_file_path):
        # clear the existing widget from the layout before adding the new widget
        self.clear_layout(self.main_window.importholdingfixturevisual_widget_layout)
        self.vtk_importfixture = None

        # Create a new VTK widget and load the STL file and points
        self.vtk_importfixture = VTKWidgetWithPoints([cad_file_path], [(0.8, 0.8, 0.8)], holding_fixture_file_path)
        self.main_window.importholdingfixturevisual_widget_layout.addWidget(self.vtk_importfixture)

    # create a vtk widget for 3D visualization of import rps
    def show_importrps_visualization(self, cad_file_path, rps_file_path):
        # clear the existing widget from the layout before adding the new widget
        self.clear_layout(self.main_window.importrpsvisual_widget_layout)
        self.vtk_importrps = None

        # Create a new VTK widget and load the STL file and points
        self.vtk_importrps = VTKWidgetWithPoints([cad_file_path], [(0.8, 0.8, 0.8)], rps_file_path)
        self.main_window.importrpsvisual_widget_layout.addWidget(self.vtk_importrps)

    # create a vtk widget for 3D visualization of morphing result
    def show_morphing_visualization(self, measurement_file_path, morphed_file_path):
        # clear the existing widget from the layout before adding the new widget
        self.clear_layout(self.main_window.morphingresultvisual_widget_layout)
        self.vtk_morphing = None

        # Create a new VTK widget and load the STL file and points
        self.vtk_morphing = VTKWidgetWithDeviation_Morphing(measurement_file_path, morphed_file_path)
        self.main_window.morphingresultvisual_widget_layout.addWidget(self.vtk_morphing)

    # create a vtk widget for 3D visualization of gravity direction of gravity compensation
    def show_gravity_direction(self, folder_path, gravity_direction):
        holding_fixture_file_path = os.path.join(folder_path["import_fixture_folder"], "Holding_fixture.csv")
        cad_file_path = os.path.join(folder_path["import_geometry_folder"], "CAD_geometry.stl")

        # clear the existing widget from the layout before adding the new widget
        self.clear_layout(self.main_window.gcresultvisual_widget_layout)
        self.vtk_gc = None

        # Create the instance of the VTK widget and add the gravity direction indicator
        self.vtk_gc = VTKWidgetWithPoints([cad_file_path], [(0.8, 0.8, 0.8)], holding_fixture_file_path)
        if gravity_direction == "Customed direction":
            self.vtk_gc.visualizer.add_gravity_indicator(gravity_direction, (float(self.main_window.customedx_plainTextEdit.toPlainText()),
                                                                                float(self.main_window.customedy_plainTextEdit.toPlainText()),
                                                                                float(self.main_window.customedz_plainTextEdit.toPlainText())))
        else:
            self.vtk_gc.visualizer.add_gravity_indicator(gravity_direction)
        self.main_window.gcresultvisual_widget_layout.addWidget(self.vtk_gc)

    # create a vtk widget for 3D visualization of gravity compensation result
    def show_gc_visualization(self, morphed_file_path, gc_file_path):
        # clear the existing widget from the layout before adding the new widget
        self.clear_layout(self.main_window.gcresultvisual_widget_layout)
        self.vtk_gc = None

        # Create the instance of the VTK widget for gravity compensation result
        self.vtk_gc = VTKWidgetWithDeviation(morphed_file_path, gc_file_path)
        self.main_window.gcresultvisual_widget_layout.addWidget(self.vtk_gc)

    # create a vtk widget for 3D visualization of gravity direction of rps clamping
    def show_rps_gravity_direction(self, folder_path, gravity_direction):
        rps_file_path = os.path.join(folder_path["import_rps_folder"], "FType_RPS.csv")
        cad_file_path = os.path.join(folder_path["import_geometry_folder"], "CAD_geometry.stl")

        # clear the existing widget from the layout before adding the new widget
        self.clear_layout(self.main_window.rpsresultvisual_widget_layout)
        self.vtk_rps = None

        # Create the instance of the VTK widget and add the gravity direction indicator
        self.vtk_rps = VTKWidgetWithPoints([cad_file_path], [(0.8, 0.8, 0.8)], rps_file_path)
        if gravity_direction == "Customed direction":
            self.vtk_rps.visualizer.add_gravity_indicator(gravity_direction, (float(self.main_window.rpscustomedx_plainTextEdit.toPlainText()),
                                                                                float(self.main_window.rpscustomedy_plainTextEdit.toPlainText()),
                                                                                float(self.main_window.rpscustomedz_plainTextEdit.toPlainText())))
        else:
            self.vtk_rps.visualizer.add_gravity_indicator(gravity_direction)
        self.main_window.rpsresultvisual_widget_layout.addWidget(self.vtk_rps)

    # create a vtk widget for 3D visualization of rps clamping result
    def show_rps_visualization(self, cad_file_path, rps_file_path):
        # clear the existing widget from the layout before adding the new widget
        self.clear_layout(self.main_window.rpsresultvisual_widget_layout)
        self.vtk_rps = None
        
        self.vtk_rps = VTKWidgetWithDeviation(cad_file_path, rps_file_path)
        self.main_window.rpsresultvisual_widget_layout.addWidget(self.vtk_rps)

    # update the 3D visualization of all the widgets after save as or load project
    def update_visualization(self, project_dict, project_status):
        # clear all render in the preview widgets
        self.clear_all_vtk()

        # update the 3D visualization of all the widgets
        if project_status["import_data"]["import_geometry"]:
            cad_file_path = os.path.join(project_dict['import_geometry_folder'], 'CAD_geometry.stl')
            self.show_importgeometry_visualization(cad_file_path)
        if project_status["import_data"]["import_measurement"]:
            cad_file_path = os.path.join(project_dict['import_geometry_folder'], 'CAD_geometry.stl')
            measurement_file_path = os.path.join(project_dict['import_measurement_folder'], 'Measurement_data.stl')
            self.show_importmeasurement_visualization(cad_file_path, measurement_file_path)
        if project_status["import_data"]["import_fixture"]:
            cad_file_path = os.path.join(project_dict['import_geometry_folder'], 'CAD_geometry.stl')
            holding_fixture_file_path = os.path.join(project_dict['import_fixture_folder'], 'Holding_fixture.csv')
            self.show_importfixture_visualization(cad_file_path, holding_fixture_file_path)
        if project_status["import_data"]["import_rps"]:
            cad_file_path = os.path.join(project_dict['import_geometry_folder'], 'CAD_geometry.stl')
            rps_file_path = os.path.join(project_dict['import_rps_folder'], 'FType_RPS.csv')
            self.show_importrps_visualization(cad_file_path, rps_file_path)
        if project_status["processing"]["morphing"]:
            measurement_file_path = os.path.join(project_dict['import_measurement_folder'], 'Measurement_data.stl')
            morphed_file_path = os.path.join(project_dict['output_folder'], '0-Morphing/Morphed_geometry.stl')
            #self.show_morphing_visualization(measurement_file_path, morphed_file_path)
        if project_status["processing"]["gc"]:
            morphed_file_path = os.path.join(project_dict['output_folder'], '0-Morphing/Morphed_geometry.stl')
            gc_file_path = os.path.join(project_dict['output_folder'], '1-GC/GC_result_geometry.stl')
            self.show_gc_visualization(morphed_file_path, gc_file_path)
        if project_status["processing"]["rps"]:
            cad_file_path = os.path.join(project_dict['import_geometry_folder'], 'CAD_geometry.stl')
            rps_file_path = os.path.join(project_dict['output_folder'], '2-RPS/RPS_geometry.stl')
            self.show_rps_visualization(cad_file_path, rps_file_path)

    # clear layout for the false process
    def clear_false_visualization(self, project_dict, project_status):
        # update the 3D visualization of all the widgets
        if project_status["import_data"]["import_geometry"] is False:
            self.clear_layout(self.main_window.importgeometryvisual_widget_layout)
            self.vtk_importgeometry = None
        if project_status["import_data"]["import_measurement"] is False:
            self.clear_layout(self.main_window.importmeasurementvisual_widget_layout)
            self.vtk_importmeasurement = None
        if project_status["import_data"]["import_fixture"] is False:
            self.clear_layout(self.main_window.importholdingfixturevisual_widget_layout)
            self.vtk_importfixture = None
        if project_status["import_data"]["import_rps"] is False:
            self.clear_layout(self.main_window.importrpsvisual_widget_layout)
            self.vtk_importrps = None
        if project_status["processing"]["morphing"] is False:
            self.clear_layout(self.main_window.morphingresultvisual_widget_layout)
            self.vtk_morphing = None
        if project_status["processing"]["gc"] is False:
            self.clear_layout(self.main_window.gcresultvisual_widget_layout)
            self.vtk_gc = None
        if project_status["processing"]["rps"] is False:
            self.clear_layout(self.main_window.rpsresultvisual_widget_layout)
            self.vtk_rps = None

    def clear_layout(self, layout):
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
            else:
                self.clear_layout(item.layout())


# Warning message class
class MessageWindow_window(QMainWindow, Ui_MessageWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setWindowModality(Qt.ApplicationModal)  # Set the window modality to ApplicationModal

    def show_message(self, message):
        self.message_label.setText(message)
        self.show()


# set the system path
class SystemPathWindow_window(QDialog, Ui_SystemPathWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        # set the instance for the message window
        self.message_window = MessageWindow_window()

        self.json_file_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 
                                           'Settings', 'path_configuration.json')
        # read json file for the path configuration
        with open(self.json_file_path, 'r') as f:
            path_config = json.load(f)
            self.swpath_plainTextEdit.setPlainText(path_config['SW_Installation_Path'])
            self.smaterialpath_plainTextEdit.setPlainText(path_config['Simufact_Matarial_Path'])
            self.smesh_plainTextEdit.setPlainText(path_config['Simufact_Mesh_Path'])
            self.workdirect_plainTextEdit.setPlainText(path_config['Work_Directory'])

        # connect the buttons to the functions
        self.swpath_pushButton.clicked.connect(self.select_sw_path)
        self.smaterialpath_pushButton.clicked.connect(self.select_smaterial_path)
        self.smesh_pushButton.clicked.connect(self.select_smesh_path)
        self.workdirect_pushButton.clicked.connect(self.select_work_folder)
        self.checkpath_pushButton.clicked.connect(self.checkset_paths)
        self.installvtk_pushButton.clicked.connect(self.install_vtk_module)
    
    def checkset_paths(self):
        # read the paths from the plainTextEdit
        sw_path = self.swpath_plainTextEdit.toPlainText()
        material_path = self.smaterialpath_plainTextEdit.toPlainText()
        mesh_path = self.smesh_plainTextEdit.toPlainText()
        work_path = self.workdirect_plainTextEdit.toPlainText()

        # change the paths text color to green if the path is existing, otherwise red
        if os.path.exists(sw_path):
            self.swpath_plainTextEdit.setStyleSheet("color: green;")
        else:
            self.swpath_plainTextEdit.setStyleSheet("color: red;")
        if os.path.exists(material_path):
            self.smaterialpath_plainTextEdit.setStyleSheet("color: green;")
        else:
            self.smaterialpath_plainTextEdit.setStyleSheet("color: red;")
        if os.path.exists(mesh_path):
            self.smesh_plainTextEdit.setStyleSheet("color: green;")
        else:
            self.smesh_plainTextEdit.setStyleSheet("color: red;")
        if os.path.exists(work_path):
            self.workdirect_plainTextEdit.setStyleSheet("color: green;")
        else:
            self.workdirect_plainTextEdit.setStyleSheet("color: red;")

        # check whether the paths are correct or not
        if os.path.exists(sw_path) and os.path.exists(material_path) and os.path.exists(mesh_path) and os.path.exists(work_path):
            print("GUI : All paths are correct.")
            path_config = {
                "SW_Installation_Path": sw_path,
                "Simufact_Matarial_Path": material_path,
                "Simufact_Mesh_Path": mesh_path,
                "Work_Directory": work_path
            }
            with open(self.json_file_path, 'w') as f:
                json.dump(path_config, f, indent=4)
            print("GUI : Paths are set successfully set to the system.")
            self.message_window.show_message("Paths are set successfully set to the system.")
        else:
            print("GUI : Paths are not correct. Please re-select the paths.")
            self.message_window.show_message("Paths are not correct. Please re-select the paths.")

    def select_sw_path(self):
        default_path = os.path.normpath(r'C:\Program Files\simufact')
        folder_path = QtWidgets.QFileDialog.getExistingDirectory(self, 
                                                                 "Select Simufact Welding Installation Path", 
                                                                 default_path)
        if folder_path:
            self.swpath_plainTextEdit.setPlainText(folder_path)
        else:
            print("GUI : No folder selected")
    
    def select_smaterial_path(self):
        default_path = os.path.normpath(r'C:\Program Files\simufact')
        folder_path = QtWidgets.QFileDialog.getExistingDirectory(self, 
                                                                 "Select Simufact Material Path", 
                                                                 default_path)
        if folder_path:
            self.smaterialpath_plainTextEdit.setPlainText(folder_path)
        else:
            print("GUI : No folder selected")
    
    def select_smesh_path(self):
        default_path = os.path.normpath(r'C:\Program Files\simufact')
        folder_path = QtWidgets.QFileDialog.getExistingDirectory(self, 
                                                                 "Select Simufact Mesh Path", 
                                                                 default_path)
        if folder_path:
            self.smesh_plainTextEdit.setPlainText(folder_path)
        else:
            print("GUI : No folder selected")
    
    def select_work_folder(self):
        folder_path = QtWidgets.QFileDialog.getExistingDirectory(self, 
                                                                 "Select Work Directory", 
                                                                 "")
        if folder_path:
            self.workdirect_plainTextEdit.setPlainText(folder_path)
        else:
            print("GUI : No folder selected")
        
    def install_vtk_module(self):
        print("GUI : Start installing VTK module...")

        # check whether sw installation path is set. if not, show a message. if yes, install the vtk module.
        if not os.path.exists(self.swpath_plainTextEdit.toPlainText()):
            print("GUI : Please set the SW Installation path, before installing the VTK module.")
            self.message_window.show_message("Please set the SW Installation path,\nbefore installing the VTK module.")
        else:
            # use pip.bat inside python folder of sw installation path to install vtk module
            pip_path = os.path.join(self.swpath_plainTextEdit.toPlainText(), "python", "pip.bat")
            module_name = "vtk==9.3.1"
            package_name = "vtk"
            try:
                import vtk
                print(f"GUI : {package_name} is already installed.")
                self.message_window.show_message(f"{package_name} is already installed.")
            except ImportError:
                subprocess.call([pip_path, "install", module_name])
                print(f"GUI : {package_name} is installed successfully.")
                self.message_window.show_message(f"{package_name} is installed successfully.\nPlease restart the application.")


# save project class
class SaveProject_window(QDialog, Ui_SaveProjectWindow):
    def __init__(self, project_status_dict):
        super().__init__()
        self.setupUi(self)
        self.project_status_dict = project_status_dict
        self.save_as = False
        self.message_window = MessageWindow_window()

        # set the project name
        self.projectname_plainTextEdit.setPlainText(self.project_status_dict['project_dict']['project_name'])

        # connect the buttons to the functions
        #self.saveproject_pushButton.clicked.connect(self.save_project)
        self.saveasproject_pushButton.clicked.connect(self.saveas_project)
    
    def save_project(self):
        project_name = self.project_status_dict['project_dict']['project_name']
        try:
            # save the project folder to the json file
            json_file_path = os.path.join(self.project_status_dict['project_dict']['project_folder'], 'save_project.json')
            with open(json_file_path, 'w') as f:
                json.dump(self.project_status_dict, f, indent=4)
            print(f"GUI : Project is saved successfully: {project_name}")
            self.message_window.show_message(f"Project is saved successfully: {project_name}")
        except Exception as e:
            print(f"GUI : Error saving project: {e}")
            self.message_window.show_message(f"Error saving project:\n{e}")
        
        self.save_as = False
    
    def saveas_project(self):
        old_project_folder = self.project_status_dict['project_dict']['project_folder']
        new_project_name = self.projectname_plainTextEdit.toPlainText()
        new_project_folder = os.path.join(os.path.dirname(old_project_folder), new_project_name)

        if os.path.exists(new_project_folder):
            self.save_as = False
            print("GUI : Project folder already exists")
            self.message_window.show_message("Project folder already exists")
        else:
            try:
                # copy the old project folder to the new project folder
                shutil.copytree(old_project_folder, new_project_folder)
                # update the project folder in the project dict
                self.project_status_dict['project_dict']['project_name'] = new_project_name
                self.project_status_dict['project_dict']['project_folder'] = os.path.normpath(new_project_folder)
                self.project_status_dict['project_dict']['import_geometry_folder'] = os.path.normpath(os.path.join(new_project_folder, '0-Inputs/0-CAD'))
                self.project_status_dict['project_dict']['import_measurement_folder'] = os.path.normpath(os.path.join(new_project_folder, '0-Inputs/3-Measurement'))
                self.project_status_dict['project_dict']['import_fixture_folder'] = os.path.normpath(os.path.join(new_project_folder, '0-Inputs/2-HoldingFixture'))
                self.project_status_dict['project_dict']['import_rps_folder'] = os.path.normpath(os.path.join(new_project_folder, '0-Inputs/1-RPS'))
                self.project_status_dict['project_dict']['material_folder'] = os.path.normpath(os.path.join(new_project_folder, '0-Inputs/4-Material'))
                self.project_status_dict['project_dict']['swproject_folder'] = os.path.normpath(os.path.join(new_project_folder, '1-SWProject'))
                self.project_status_dict['project_dict']['output_folder'] = os.path.normpath(os.path.join(new_project_folder, '2-Outputs'))
                # save the project folder to the json file
                json_file_path = os.path.join(new_project_folder, 'save_project.json')
                with open(json_file_path, 'w') as f:
                    json.dump(self.project_status_dict, f, indent=4)
                self.save_as = True
                print(f"GUI : Project is saved successfully: {new_project_name}")
                self.message_window.show_message(f"Project is saved successfully: {new_project_name}")
            except Exception as e:
                self.save_as = False
                print(f"GUI : Error saving project: {e}")
                self.message_window.show_message(f"Error saving project:\n{e}")
    
    def saveas_sendback(self):
        return [self.save_as, self.project_status_dict]


# Standard imports
import os, csv, json, configparser, sys
import time

import simufact
from simufact import UnitValuePercent, UnitValueAngle, UnitValueLength, Vector3D

from PySide6.QtCore import Signal, QThread


class Simufact_helper(QThread):
    message_signal = Signal(str)    # signal for sending the message to the main thread
    progress_signal = Signal(int)   # signal for sending the progress to the main thread
    initiation_finished = Signal()    # signal for sending the VF initiation finishing to the main thread

    def __init__(self, vf_project_folder, VF_status):
        super().__init__()
        self.sw_project = None
        self.swproject_folder = os.path.normpath(os.path.join(vf_project_folder, '1-SWProject'))
        self.VF_status = VF_status
    
    def open_sw_project(self):
        sw_project_name = 'Simufact_Project_File'
        swproj_file = os.path.normpath(os.path.join(self.swproject_folder, sw_project_name + '.swproj'))

        # check the existence of the SW project folder
        if not os.path.exists(self.swproject_folder):
            self.message_signal.emit('**Error : The SW Project folder does not exist in the VF project folder.')
            return

        try:
            self.sw_project = simufact.welding.open_project(swproj_file)
            self.message_signal.emit('VF_controller : Simufact Welding project successfully opened.')
        except:
            self.message_signal.emit('**Error : Error opening the SW Project.')
            return

    def close_simufact_project(self):
        try:
            self.sw_project.save()
            simufact.welding.close_project()
        except Exception as e:
            self.message_signal.emit('**Error : Error closing the SW Project.')
            self.message_signal.emit(str(e))

    def get_new_sw_project(self):
        sw_project_name = 'Simufact_Project_File'

        # check the existence of the SW project folder
        if not os.path.exists(self.swproject_folder):
            self.message_signal.emit('**Error : The SW Project folder does not exist in the VF project folder.')
            self.progress_signal.emit(1000)
            sys.exit()
        
        try:
            self.sw_project = simufact.welding.new_project(sw_project_name, self.swproject_folder)
            self.message_signal.emit('VF_initiation : New SW Project successfully created.')
            self.sw_project.save()
            simufact.welding.close_project()
        except:
            self.message_signal.emit('VF_initiation : SW Project already exists. Delete existing project and create a new one.')
            simufact.welding.close_project()
            self.sw_project = simufact.welding.new_project(sw_project_name, self.swproject_folder)
            self.sw_project.save()
            simufact.welding.close_project()

        # check the VF status after the VF initiation
        self.progress_signal.emit(70)
        self.check_sw_project()

    def load_sw_project(self, swproject_folder):
        sw_project_name = 'Simufact_Project_File'
        
        try:
            sw_project = simufact.welding.open_project(os.path.join(swproject_folder, sw_project_name, sw_project_name + '.swproj'))
            return sw_project
        except:
            print(f'GUI : Failed to open Simufact Welding project.')
            return None

    def check_sw_project(self):
        # check the VF status after the VF initiation
        # checking whether there is a swproj file in the 1-SWProject folder
        swproj_file = 'Simufact_Project_File.swproj'
        for _, _, files in os.walk(self.swproject_folder):
            for file in files:
                if file == swproj_file:
                    for key, value in self.VF_status.items():
                        if key == 'VF_initiation':
                            self.VF_status[key] = True
                        else:
                            self.VF_status[key] = False
                    self.message_signal.emit('VF_initiation : VF_initiation status ** Complete **')
                    self.progress_signal.emit(90)
                    self.initiation_finished.emit()
                    break


class Meshing_helper(QThread):
    message_signal = Signal(str)    # signal for sending the message to the main thread
    progress_signal = Signal(int)   # signal for sending the progress to the main thread
    meshing_finished = Signal()    # signal for sending the VF meshing finishing to the main thread

    def __init__(self, vf_project_folder, VF_status, parameters, all_path, ini_path):
        super().__init__()
        self.vf_project_folder = vf_project_folder
        self.VF_status = VF_status
        self.parameters = parameters
        self.all_path = all_path
        self.ini_path = ini_path
    
    def run_sw_meshing(self):
        # generate log file for the meshing process
        log_file = os.path.normpath(os.path.join(self.vf_project_folder, '1-SWProject', 'Meshing.log'))
        if os.path.exists(log_file):
            os.remove(log_file)
        def write_log(message):
            with open(log_file, 'a') as file:
                file.write(message + '\n')

        # ////////////// Recieve paths and parameters from the main script //////////////
        cad_input_path = os.path.normpath(os.path.join(self.vf_project_folder, '0-Inputs/0-CAD'))

        mesh_size = self.parameters['Meshing_parameters']['mesh_size_mm']
        self.message_signal.emit('VF_meshing : Mesh size --> ' + str(mesh_size) + ' mm')
        write_log('VF_meshing : Mesh size --> ' + str(mesh_size) + ' mm')
        curvature_refinement = self.parameters['Meshing_parameters']['curvature_refinement']
        self.message_signal.emit('VF_meshing : Curvature refinement --> ' + str(curvature_refinement))
        write_log('VF_meshing : Curvature refinement --> ' + str(curvature_refinement))
        cad_healing = self.parameters['Meshing_parameters']['cad_healing']
        self.message_signal.emit('VF_meshing : CAD healing --> ' + str(cad_healing))
        write_log('VF_meshing : CAD healing --> ' + str(cad_healing))

        # modify the meshing ini file for cad healing
        try:
            self.modify_meshing_ini(cad_healing, self.ini_path, os.path.basename(self.all_path['SW_Installation_Path']))
        except Exception as e:
            self.message_signal.emit('**Warning : Failed to modify the meshing ini file.')
            self.message_signal.emit('     Please advanced import some CAD geometry in Simufact Welding GUI.')
            self.message_signal.emit(str(e))
            write_log('**Warning : Failed to modify the meshing ini file.')

        # //////////////////////////// Meshing process in Simufact Welding ////////////////////////////
        # open the SW project
        sw_project_name = 'Simufact_Project_File'
        try:
            meshing_project = simufact.welding.open_project(os.path.join(self.vf_project_folder, '1-SWProject',
                                                                         sw_project_name, sw_project_name + '.swproj'))
            self.message_signal.emit('VF_meshing : Simufact Welding project successfully opened.')
            write_log('VF_meshing : Simufact Welding project successfully opened.')
            self.progress_signal.emit(5)
        except Exception as e:
            self.message_signal.emit('**Error : Error opening the SW Project.')
            self.message_signal.emit(str(e))
            if meshing_project:
                simufact.welding.close_project()
            self.progress_signal.emit(1000)
            write_log('**Error : Error opening the SW Project.')
            write_log(str(e))
            return
        meshing_project.save()

        # process and data cleaning in the SW project
        needed_data = []
        needed_process = []
        for process in meshing_project.all_processes:
            if process.name not in needed_process:
                meshing_project.delete_process(process)
        for geometry in meshing_project.all_geometries:
            if geometry.name not in needed_data:
                meshing_project.delete_geometry(geometry)
        meshing_project.save()
        self.message_signal.emit('VF_meshing : Process and data cleaning is done.')
        write_log('VF_meshing : Process and data cleaning is done.')
        self.progress_signal.emit(10)

        # import CAD to the geometry catalog
        file_type = ""
        for file in os.listdir(cad_input_path):
            if file.endswith('.CATPart') or file.endswith('.stp') or file.endswith('.x_t') or file.endswith('.x_b') or file.endswith('.igs'):
                cad_bdf_path = os.path.normpath(os.path.join(cad_input_path, file))
                file_type = "CAD"
                break
            elif file.endswith('.bdf'):
                cad_bdf_path = os.path.normpath(os.path.join(cad_input_path, file))
                file_type = "BDF"
                break
        if not cad_bdf_path:
            self.message_signal.emit('**Error : No CAD file found in the input folder.')
            write_log('**Error : No CAD file found in the input folder.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        try:
            if cad_bdf_path.endswith('.bdf'):
                cad_geo_tuple = meshing_project.import_geometry(cad_bdf_path, unit='mm')
                cad_geo = cad_geo_tuple[0]
            else:
                cad_geo_tuple = meshing_project.import_CAD_geometry(cad_bdf_path, unit='m')
                cad_geo = cad_geo_tuple[0][0]
            cad_geo.name = 'CAD_geometry'
            self.message_signal.emit('VF_meshing : CAD geometry imported successfully.')
            write_log('VF_meshing : CAD geometry imported successfully.')
            self.progress_signal.emit(20)
        except:
            self.message_signal.emit('**Error : Failed to import CAD geometry. Please check the CAD import advanced settings.')
            write_log('**Error : Failed to import CAD geometry. Please check the CAD import advanced settings.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        meshing_project.save()

        # if the file is a BDF file, create a new process just to export the mesh to the CAD folder
        if file_type == "BDF":
            meshing_process = meshing_project.new_process(name='Mesher', process_type='CoolingAndClamping')
            meshing_process.new_component(name='CAD_geometry', geometry=cad_geo)
            self.message_signal.emit('VF_meshing : Reading BDF file completed.')
            write_log('VF_meshing : Reading BDF file completed.')
            self.progress_signal.emit(40)
        elif file_type == "CAD":
            # if the SW version is 2024.4, use the RSW process to mesh the CAD geometry
            # otherwise, use clamping and cooling process
            sw_version = os.path.basename(self.all_path['SW_Installation_Path'])
            #print("SW version: ", sw_version)
            if sw_version == "2024.4":
                meshing_process = meshing_project.new_process(name='Mesher', process_type='ResistanceSpotWelding')
                meshing_process.new_component(name='CAD_geometry', geometry=cad_geo)
            else:
                meshing_process = meshing_project.new_process(name='Mesher', process_type='CoolingAndClamping')
                meshing_process.new_component(name='CAD_geometry', geometry=cad_geo)
            try:
                self.message_signal.emit('VF_meshing : Starting meshing process...\n   Please wait...')
                if curvature_refinement:
                    componentsWithIssues = meshing_process.remesh_sheet_components(components='all',
                                                                                    global_element_length=mesh_size,
                                                                                    curvature_divisions=9,
                                                                                    enable_solid_shell_elements=True)
                else:
                    componentsWithIssues = meshing_process.remesh_sheet_components(components='all',
                                                                                global_element_length=mesh_size,
                                                                                enable_solid_shell_elements=True)
                if len(componentsWithIssues[0]) > 0 or len(componentsWithIssues[1]) > 0:
                    self.message_signal.emit('VF_meshing : Failed to mesh the components.')
                    write_log('VF_meshing : Failed to mesh the components.')
                    meshing_project.save()
                    simufact.welding.close_project()
                    self.progress_signal.emit(1000)
                    return
            except:
                meshing_project.save()
                self.message_signal.emit('VF_meshing : Failed to mesh the components.')
                write_log('VF_meshing : Failed to mesh the components.')
                simufact.welding.close_project()
                self.progress_signal.emit(1000)
                return
            meshing_project.save()
            self.message_signal.emit('VF_meshing : Meshing completed successfully.')
            write_log('VF_meshing : Meshing completed successfully.')
            self.progress_signal.emit(40)
        else:
            self.message_signal.emit('**Error : File type not supported.')
            write_log('VF_meshing : File type not supported.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        meshing_project.save()

        # ////////////// Export the stl and bdf to CAD input folder //////////////
        try:
            meshing_process.export_geometries(cad_input_path, ['CAD_geometry'], format='stl-bin', unit='mm')
            meshing_process.export_geometries(cad_input_path, ['CAD_geometry'], format='bdf-volume', unit='mm')
            self.message_signal.emit('VF_meshing : Geometries exported successfully.')
            write_log('VF_meshing : Geometries exported successfully.')
            self.progress_signal.emit(80)
            simufact.welding.close_project()
            self.check_meshing_result()
        except:
            self.message_signal.emit('VF_meshing : Failed to export the geometries.')
            write_log('VF_meshing : Failed to export the geometries.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return

    def modify_meshing_ini(self, advanced_meshing, ini_data_path, sw_version):
        #print("ini_data_path: ", ini_data_path)
        # read the database ini file and store the data
        config_database = configparser.ConfigParser()
        config_database.read(ini_data_path)
        advanced_data = {"2025.1" : config_database['CADImportOptions_advanced20251'],
                         "2024.4" : config_database['CADImportOptions_advanced20244']}
        simple_data = {"2025.1" : config_database['CADImportOptions_simple20251'],
                       "2024.4" : config_database['CADImportOptions_simple20244']}
        # get the data based on the Simufact Welding version
        advanced_data = advanced_data[sw_version]
        simple_data = simple_data[sw_version]
        #print("advanced_data: ", advanced_data)
        #print("simple_data: ", simple_data)

        # find the simufact.welding.ini file within AppData folder
        appdata_path = os.getenv('APPDATA')
        simufact_ini_path = os.path.normpath(os.path.join(appdata_path, 
                                                        "Simufact/simufact.welding_" + sw_version,
                                                        "simufact.welding.ini"))
        if not os.path.exists(simufact_ini_path):
            self.message_signal.emit('**Warning : simufact.welding.ini file not found in the AppData folder.')
            return
        #print("simufact_ini_path: ", simufact_ini_path)
        # read the ini file and modify the meshing options
        try:
            config = configparser.ConfigParser()
            config.read(simufact_ini_path)
            # if the 'CADImportOptions' section does not exist, create a new one
            if 'CADImportOptions' not in config:
                config['CADImportOptions'] = {}
                if advanced_meshing:
                    for key, value in advanced_data.items():
                        config['CADImportOptions'][key] = value
                else:
                    for key, value in simple_data.items():
                        config['CADImportOptions'][key] = value
            else:
                if advanced_meshing:
                    for key, value in config['CADImportOptions'].items():
                        config['CADImportOptions'][key] = advanced_data[key]
                else:
                    for key, value in config['CADImportOptions'].items():
                        config['CADImportOptions'][key] = simple_data[key]
            
            with open(simufact_ini_path, 'w') as configfile:
                config.write(configfile)
            self.message_signal.emit("VF meshing : simufact.welding.ini file modified successfully.")
        except Exception as e:
            return

    def check_meshing_result(self):
        # check the VF status after the VF meshing
        # checking whether there are both stl and bdf file in the 0-CAD folder
        stl_file = 'CAD_geometry.stl'
        stl_found = False
        bdf_file = 'CAD_geometry.bdf'
        bdf_found = False
        for _, _, files in os.walk(os.path.normpath(os.path.join(self.vf_project_folder, '0-Inputs/0-CAD'))):
            for file in files:
                if file == stl_file:
                    stl_found = True
                elif file == bdf_file:
                    bdf_found = True
        if stl_found and bdf_found:
            self.message_signal.emit('VF_meshing : VF_meshing status ** Complete **')
            self.progress_signal.emit(90)
            self.meshing_finished.emit()
        else:
            self.message_signal.emit('**Error : Meshing results are not found.')
            self.progress_signal.emit(1000)


class Morphing_helper(QThread):
    message_signal = Signal(str)    # signal for sending the message to the main thread
    progress_signal = Signal(int)   # signal for sending the progress to the main thread
    morphing_finished = Signal()    # signal for sending the VF meshing finishing to the main thread

    def __init__(self, vf_project_folder, VF_status, parameters):
        super().__init__()
        self.vf_project_folder = vf_project_folder
        self.VF_status = VF_status
        self.parameters = parameters

    def run_sw_morphing(self):
        # generate log file for the meshing process
        log_file = os.path.normpath(os.path.join(self.vf_project_folder, '1-SWProject', 'Morphing.log'))
        if os.path.exists(log_file):
            os.remove(log_file)
        def write_log(message):
            with open(log_file, 'a') as file:
                file.write(message + '\n')

        # Recieve paths and parameters from the main scrip
        cadmesh_input_path = os.path.normpath(os.path.join(self.vf_project_folder, '0-Inputs/0-CAD'))
        morph_output_path = os.path.normpath(os.path.join(self.vf_project_folder, '2-Outputs/0-Morphing'))
        measurement_input_path = os.path.normpath(os.path.join(self.vf_project_folder, '0-Inputs/3-Measurement'))
        rps_input_path = os.path.normpath(os.path.join(self.vf_project_folder, '0-Inputs/1-RPS'))
        material_input_path = os.path.normpath(os.path.join(self.vf_project_folder, '0-Inputs/4-Material'))

        fit = self.parameters['Morphing_parameters']['best_fit']
        self.message_signal.emit('VF_morphing : Best fit --> ' + str(fit))
        write_log('VF_morphing : Best fit --> ' + str(fit))
        mode = self.parameters["Morphing_parameters"]["match_mode"]
        self.message_signal.emit('VF_morphing : Match mode --> ' + str(mode))
        write_log('VF_morphing : Match mode --> ' + str(mode))
        details = self.parameters["Morphing_parameters"]["level_of_detail"]
        self.message_signal.emit('VF_morphing : Level of detail --> ' + str(details))
        write_log('VF_morphing : Level of detail --> ' + str(details))
        outlier = self.parameters["Morphing_parameters"]["ignore_outliers_percent"]
        self.message_signal.emit('VF_morphing : Ignore outliers percent --> ' + str(outlier))
        write_log('VF_morphing : Ignore outliers percent --> ' + str(outlier))
        tolerance = self.parameters["Morphing_parameters"]["surface_tolerance_degree"]
        self.message_signal.emit('VF_morphing : Surface tolerance degree --> ' + str(tolerance))
        write_log('VF_morphing : Surface tolerance degree --> ' + str(tolerance))
        transform = self.parameters["Morphing_parameters"]["add_transformation"]
        self.message_signal.emit('VF_morphing : Add transformation --> ' + str(transform))
        write_log('VF_morphing : Add transformation --> ' + str(transform))


        # //////////////////////////// Morphing process in Simufact Welding ////////////////////////////
        # open the SW project
        sw_project_name = 'Simufact_Project_File'
        try:
            morphing_project = simufact.welding.open_project(os.path.join(self.vf_project_folder, '1-SWProject', 
                                                                         sw_project_name, sw_project_name + '.swproj'))
            self.message_signal.emit('VF_morphing : Simufact Welding project successfully opened.')
            write_log('VF_morphing : Simufact Welding project successfully opened.')
            self.progress_signal.emit(5)
        except Exception as e:
            self.message_signal.emit('**Error : Error opening the SW Project.')
            self.message_signal.emit(str(e))
            if morphing_project:
                simufact.welding.close_project()
            self.progress_signal.emit(1000)
            write_log('**Error : Error opening the SW Project.')
            write_log(str(e))
            return
        morphing_project.save()

        # process and data cleaning in the SW project
        needed_data = ['CAD_geometry']
        needed_process = ["Mesher"]
        for process in morphing_project.all_processes:
            if process.name not in needed_process:
                morphing_project.delete_process(process)
        for geometry in morphing_project.all_geometries:
            if geometry.name not in needed_data:
                morphing_project.delete_geometry(geometry)
        for geometry in morphing_project.all_ref_geometries:
            if geometry.name not in needed_data:
                morphing_project.delete_geometry(geometry)
        self.message_signal.emit('VF_morphing : Process and data cleaning is done.')
        write_log('VF_morphing : Process and data cleaning is done.')
        self.progress_signal.emit(10)

        # import CAD mesh to the geometry catalog
        for file in os.listdir(cadmesh_input_path):
            if file == 'CAD_geometry.bdf':
                cadmesh_path = os.path.normpath(os.path.join(cadmesh_input_path, file))
                break
        if not cadmesh_path:
            self.message_signal.emit('**Error : No CAD mesh file found in the input folder.')
            write_log('**Error : No CAD mesh file found in the input folder.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        try:
            cadmesh_tuple = morphing_project.import_geometry(cadmesh_path, unit='mm')
        except:
            self.message_signal.emit('**Error : Failed to import CAD mesh.')
            write_log('**Error : Failed to import CAD mesh.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        morphing_project.save()
        self.message_signal.emit('VF_morphing : CAD mesh imported successfully.')
        write_log('VF_morphing : CAD mesh imported successfully.')
        self.progress_signal.emit(15)

        # import material data to the material catalog and create new temperature object
        for file in os.listdir(material_input_path):
            if file.endswith('.xmt'):
                material_path = os.path.normpath(os.path.join(material_input_path, file))
                break
        if not material_path:
            self.message_signal.emit('**Error : No material data found in the input folder.')
            write_log('**Error : No material data found in the input folder.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        for material in morphing_project.all_materials:
            morphing_project.delete_material(material)
        try:
            morphing_project.import_material(material_path)
        except:
            self.message_signal.emit('**Error : Failed to import material data.')
            write_log('**Error : Failed to import material data.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        morphing_project.save()
        self.message_signal.emit('VF_morphing : Material data imported successfully.')
        write_log('VF_morphing : Material data imported successfully.')
        self.progress_signal.emit(20)

        # create new temperature object
        try:
            morphing_project.new_temperature(name='20C', initial_temperature=20.0)
        except:
            self.message_signal.emit('**Warning : Use the existing temperature object.')
            write_log('**Warning : Use the existing temperature object.')
        self.message_signal.emit('VF_morphing : Temperature object created successfully.')
        write_log('VF_morphing : Temperature object created successfully.')
        morphing_project.save()
        self.progress_signal.emit(25)

        # import measurement data to the reference catalog
        for file in os.listdir(measurement_input_path):
            if file.endswith('.stl'):
                measurement_path = os.path.normpath(os.path.join(measurement_input_path, file))
                break
        if not measurement_path:
            self.message_signal.emit('**Error : No measurement data found in the input folder.')
            write_log('**Error : No measurement data found in the input folder.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        try:
            measurement_tuple = morphing_project.import_scan_reference(measurement_path, unit='mm')
        except:
            self.message_signal.emit('**Error : Failed to import measurement data.')
            write_log('**Error : Failed to import measurement data.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        measurement_data = measurement_tuple[0]
        measurement_data.name = 'Measurement_data'
        morphing_project.save()
        self.message_signal.emit('VF_morphing : Measurement data imported successfully.')
        write_log('VF_morphing : Measurement data imported successfully.')
        self.progress_signal.emit(30)

        # convert hex mesh to solid-shell mesh
        cad_mesh_hex = cadmesh_tuple[0]
        cad_mesh_hex.name = 'CAD_geometry_hex'
        try:
            cad_mesh = cad_mesh_hex.make_solid_shell()
            cad_mesh.name = "CAD_before_morph"
            self.progress_signal.emit(30)
        except:
            self.message_signal.emit('**Error : Failed to convert CAD mesh to solid-shell mesh.')
            write_log('**Error : Failed to convert CAD mesh to solid-shell mesh.')
            simufact.welding.close_project()
            self.progress_signal.emit(10000)
            return
        morphing_project.save()
        self.message_signal.emit('VF_morphing : CAD mesh converted to solid-shell mesh successfully.')
        write_log('VF_morphing : CAD mesh converted to solid-shell mesh successfully.')
        self.progress_signal.emit(35)

        # check and modify the csv file of rps points
        for file in os.listdir(rps_input_path):
            if file.endswith('.csv'):
                rps_file_path = os.path.normpath(os.path.join(rps_input_path, file))
                break
        with open(rps_file_path, 'r', newline='') as csvfile:
            rows = list(csv.reader(csvfile))
            if len(rows[0]) <= 1:
                rows = list(csv.reader(csvfile, delimiter=';'))     # try to read with semicolon delimiter
        # check the number of columns in the csv file
        for row in rows:
            if len(row) == 5:
                try:
                    str(row[0])
                    float(row[1])
                    float(row[2])
                    float(row[3])
                    str(row[4])
                    self.message_signal.emit('VF_morphing : The csv file has 5 columns. OK')
                    write_log('VF_morphing : The csv file has 5 columns. OK')
                except ValueError:
                    self.message_signal.emit('**Error : The csv file has 5 columns but the data is not in the correct format. \n    Please check the rps csv file.')
                    write_log('**Error : The csv file has 5 columns but the data is not in the correct format. Please check the rps csv file.')
                    simufact.welding.close_project()
                    self.progress_signal.emit(10000)
                    return
            else:
                self.message_signal.emit('**Error : The csv file must have 5 columns [Name, X, Y, Z, Direction]. \n    Please check the rps csv file.')
                write_log('**Error : The csv file must have 5 columns. Please check the rps csv file.')
                simufact.welding.close_project()
                self.progress_signal.emit(10000)
                return
        rps_file_path_mod = os.path.normpath(os.path.join(rps_input_path, 'rps_points_mod.csv'))
        with open(rps_file_path_mod, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile, delimiter=';')
            writer.writerows(rows)
        
        # import RPS points to the reference catalog
        try:
            cad_mesh.import_rps_locations(rps_file_path_mod, projection=True, unit='mm')
        except:
            self.message_signal.emit('**Error : Failed to import RPS points.')
            write_log('Morphing : Failed to import RPS points.')
            simufact.welding.close_project()
            self.progress_signal.emit(10000)
            return
        morphing_project.save()
        self.message_signal.emit('VF_morphing : RPS points imported successfully.')
        write_log('VF_morphing : RPS points imported successfully.')
        self.progress_signal.emit(40)

        # Start morphing calculation
        try:
            self.message_signal.emit('VF_morphing : Morphing calculation started...\n   Please wait...')
            morph_cal = morphing_project.morph_geometry((cad_mesh,), (measurement_data,),
                                                        best_fit = fit,
                                                        match_mode = mode,
                                                        level_of_detail = details,
                                                        ignore_outliers = UnitValuePercent(outlier, '%'),
                                                        surface_normal_tolerance = UnitValueAngle(tolerance, '°'),
                                                        add_with_transformation = transform,
                                                        add_as_single_geometry = False)
            # change morphed mesh name
            for geometry in morphing_project.all_geometries:
                if 'morphed' in geometry.name:
                    geometry.name = 'Morphed_geometry'
                    break

        except Exception as e:
            self.message_signal.emit('**Error : Failed to morph the CAD mesh.')
            self.message_signal.emit(str(e))
            write_log('Morphing : Failed to morph the CAD mesh.')
            write_log(str(e))
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        morphing_project.save()
        self.message_signal.emit('VF_morphing : Morphing completed successfully.')
        write_log('VF_morphing : Morphing completed successfully.')
        self.progress_signal.emit(70)
        
        # ////////////// Export the stl and bdf to Output folder //////////////
        # create a temporary process to export the morphed geometry
        morphing_process = morphing_project.new_process(name='Export_morphed', process_type='CoolingAndClamping')
        for geometry in morphing_project.all_geometries:
            if geometry.name == 'Morphed_geometry':
                morphing_process.new_component(name=geometry.name, geometry=geometry)
                break
        try:
            morphing_process.export_geometries(morph_output_path, ['Morphed_geometry'], format='stl-bin', unit='mm')
            morphing_process.export_geometries(morph_output_path, ['Morphed_geometry'], format='bdf-volume', unit='mm')
            self.message_signal.emit('VF_morphing : Geometries exported successfully.')
            write_log('VF_morphing : Geometries exported successfully.')
            self.progress_signal.emit(80)
            morphing_project.save()
            simufact.welding.close_project()
            self.check_morphing_result()
        except:
            self.message_signal.emit('VF_morphing : Failed to export the geometries.')
            write_log('VF_morphing : Failed to export the geometries.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return

    def check_morphing_result(self):
        # check the VF status after the VF morphing
        # checking whether there are both stl and bdf file in the 2-Outputs\0-Morphing folder
        stl_file = 'Morphed_geometry.stl'
        stl_found = False
        bdf_file = 'Morphed_geometry.bdf'
        bdf_found = False
        for _, _, files in os.walk(os.path.normpath(os.path.join(self.vf_project_folder, '2-Outputs/0-Morphing'))):
            for file in files:
                if file == stl_file:
                    stl_found = True
                elif file == bdf_file:
                    bdf_found = True
        if stl_found and bdf_found:
            self.message_signal.emit('VF_morphing : VF_morphing status ** Complete **')
            self.progress_signal.emit(90)
            self.morphing_finished.emit()
        else:
            self.message_signal.emit('**Error : Morphing results are not found.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
    
    def stop_sw_morphing(self):
        self.quit()


class GravityCompensation_helper(QThread):
    message_signal = Signal(str)    # signal for sending the message to the main thread
    progress_signal = Signal(int)   # signal for sending the progress to the main thread
    gc_finished = Signal()    # signal for sending the VF meshing finishing to the main thread

    def __init__(self, vf_project_folder, VF_status, parameters):
        super().__init__()
        self.vf_project_folder = vf_project_folder
        self.VF_status = VF_status
        self.parameters = parameters

        self.gc_analysis = None
        self._stop_requested = False

    def check_holding_fixture(self):
        num_pins = self.parameters["GC_parameters"]["pin_number"]

        if num_pins not in [3, 4, 5]:
            print("GUI: Number of pins must be either 3, 4 or 5.")
            self.message_signal.emit("**Error: Number of pins must be either 3, 4, or 5.")
            self.progress_signal.emit(1000)
            return "Failed"

        # Read fixture data from CSV
        check_fixture_input_path = os.path.normpath(os.path.join(self.vf_project_folder, '0-Inputs/2-HoldingFixture'))
        check_fixture_path = None
        for file in os.listdir(check_fixture_input_path):
            if file.endswith('.csv'):
                check_fixture_path = os.path.normpath(os.path.join(check_fixture_input_path, file))
                break

        if not check_fixture_path:
            print('GUI: No check fixture data found in the input folder.')
            return "Failed"
        
        with open(check_fixture_path, 'r', newline='') as f:
            reader = csv.reader(f)
            rows = list(reader)

        # Export CSV for each point
        for point_num in range(len(rows)):
            point_path = os.path.normpath(os.path.join(check_fixture_input_path, f"point_{point_num + 1}.csv"))
            rows[point_num][0] = "GC_geometry"
            with open(point_path, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerows(rows[point_num:point_num + 1])
        
        print("GUI: Individual check fixture data exported to CSV files.")
        self.message_signal.emit("VF_gc : Individual check fixture data exported to CSV files.")
        return "Success"
    
    def run_sw_gc(self):
        # generate log file for the meshing process
        log_file = os.path.normpath(os.path.join(self.vf_project_folder, '1-SWProject', 'GC.log'))
        if os.path.exists(log_file):
            os.remove(log_file)
        def write_log(message):
            with open(log_file, 'a') as file:
                file.write(message + '\n')

        # execute the check fixture function
        check_result = self.check_holding_fixture()
        if check_result == "Failed":
            self.message_signal.emit("**Error : Check fixture function failed.")
            write_log("**Error : Check fixture function failed.")
            self.progress_signal.emit(1000)
            return
        self.message_signal.emit("VF_gc : Check fixture function successfully executed.")
        write_log("VF_gc : Check fixture function successfully")
        self.progress_signal.emit(5)

        # Recieve paths and parameters from the main scrip
        check_fixture_input_path = os.path.normpath(os.path.join(self.vf_project_folder, '0-Inputs/2-HoldingFixture'))
        gc_output_path = os.path.normpath(os.path.join(self.vf_project_folder, '2-Outputs/1-GC'))

        radius = self.parameters['GC_parameters']['search_radius_mm']
        self.message_signal.emit('VF_gc : Search radius --> ' + str(radius))
        write_log('VF_gc : Search radius --> ' + str(radius))
        smp = self.parameters['General_parameters']['smp_cores']
        self.message_signal.emit('VF_gc : SMP cores --> ' + str(smp))
        write_log('VF_gc : SMP cores --> ' + str(smp))
        ddm = self.parameters['General_parameters']['ddm_domain']
        self.message_signal.emit('VF_gc : DDM domain --> ' + str(ddm))
        write_log('VF_gc : DDM domain --> ' + str(ddm))
        target = self.parameters['GC_parameters']['target_deviation_mm']
        self.message_signal.emit('VF_gc : Target deviation --> ' + str(target))
        write_log('VF_gc : Target deviation --> ' + str(target))
        iteration = self.parameters['GC_parameters']['max_iteration']
        self.message_signal.emit('VF_gc : Max iteration --> ' + str(iteration))
        write_log('VF_gc : Max iteration --> ' + str(iteration))

        # gravity direction
        gc_dict = {
            '+X': (9.80665, 0, 0),
            '-X': (-9.80665, 0, 0),
            '+Y': (0, 9.80665, 0),
            '-Y': (0, -9.80665, 0),
            '+Z': (0, 0, 9.80665),
            '-Z': (0, 0, -9.80665)
            }
        
        gra_dir = self.parameters['GC_parameters']['gravity_direction']
        if gra_dir not in gc_dict.keys():
            customed_gra_dir = self.parameters['GC_parameters']['customed_gravity']
        else:
            customed_gra_dir = None


        # //////////////////////////// GC process in Simufact Welding ////////////////////////////
        # open the SW project
        sw_project_name = 'Simufact_Project_File'
        try:
            gc_project = simufact.welding.open_project(os.path.join(self.vf_project_folder, '1-SWProject', 
                                                                         sw_project_name, sw_project_name + '.swproj'))
            self.message_signal.emit('VF_gc : Simufact Welding project successfully opened.')
            write_log('VF_gc : Simufact Welding project successfully opened.')
            self.progress_signal.emit(10)
        except Exception as e:
            self.message_signal.emit('**Error : Error opening the SW Project.')
            self.message_signal.emit(str(e))
            write_log('**Error : Error opening the SW Project.')
            write_log(str(e))
            if gc_project:
                simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        gc_project.save()

        # process and data cleaning in the SW project
        needed_data = ['CAD_geometry', 'CAD_before_morph', 'Morphed_geometry', "GC_geometry"]
        needed_process = ["Mesher"]
        for process in gc_project.all_processes:
            if process.name not in needed_process:
                gc_project.delete_process(process)
        for geometry in gc_project.all_geometries:
            if geometry.name not in needed_data:
                gc_project.delete_geometry(geometry)
            elif "GC_geometry" in geometry.name:
                geometry.name = "Morphed_geometry"
        self.message_signal.emit('VF_gc : Process and data cleaning is done.')
        write_log('VF_gc : Process and data cleaning is done.')
        self.progress_signal.emit(15)

        # chenge the name of the geometry to GC_geometry
        try:
            gc_geometry = gc_project.geometry('Morphed_geometry')
            gc_geometry.name = 'GC_geometry'
            write_log('VF_gc : Geometry name changed successfully.')
        except:
            self.message_signal.emit('**Error : No Morphed geometry found.')
            write_log('VF_gc : No Morphed geometry found.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        gc_project.save()

        # create a new process for gravity compensation and assign the morphed geometry
        if gra_dir in gc_dict.keys():
           gc_process = gc_project.new_process(name='VirtualFixture_GC',
                                               process_type='GravityCompensation',
                                               gravity=gc_dict[gra_dir])
        else:
            customed_gra_dir_size = (customed_gra_dir[0]**2 + customed_gra_dir[1]**2 + customed_gra_dir[2]**2)**0.5
            customed_gra_dir_input = (customed_gra_dir[0]/customed_gra_dir_size*9.80665,
                                      customed_gra_dir[1]/customed_gra_dir_size*9.80665,
                                      customed_gra_dir[2]/customed_gra_dir_size*9.80665)
            gc_process = gc_project.new_process(name='VirtualFixture_GC',
                                                process_type='GravityCompensation',
                                                gravity=customed_gra_dir_input)
            self.message_signal('VF_gc : Gravity with customed direction.')
            write_log('GC : Gravity with customed direction.')
        gc_process.new_component(name=gc_geometry.name,
                                 geometry=gc_geometry,
                                 material=gc_project.all_materials[0],
                                 temperature=gc_project.all_temperatures[0])
        gc_project.save()
        self.message_signal.emit('VF_gc : Process created successfully.')
        write_log('GC : Process created successfully.')
        self.progress_signal.emit(20)    

        # import json file to get the check fixture direction
        for file in os.listdir(check_fixture_input_path):
            if file.endswith('.json'):
                check_fixture_json_path = os.path.normpath(os.path.join(check_fixture_input_path, file))
                with open(check_fixture_json_path, 'r') as f:
                    check_fixture_json = json.load(f)
                break
        if not check_fixture_json:
            self.message_signal.emit('**Error : No check fixture json file found in the input folder.')
            write_log('**Error : No check fixture json file found in the input folder.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        try:
            for file in os.listdir(check_fixture_input_path):
                if 'point' in file.lower() and file.endswith('.csv'):
                    point_path = os.path.normpath(os.path.join(check_fixture_input_path, file))
                    file_name = file.split('.')[0]
                    point_num = file_name.split('_')[-1]
                    gc_fixednode = gc_process.new_fixed_nodes(name='GC_FixedNode_' + point_num,
                                                              fixed_directions=tuple(check_fixture_json[point_num]))
                    gc_fixednode.import_nodes(point_path,
                                              unit='mm',
                                              decimal_separator='.',
                                              field_separator=',',
                                              search_radius=UnitValueLength(radius, 'mm'))
                    if len(gc_fixednode.nodes) == 0:
                        write_log('VF_gc : No nodes found for original point ' + point_num + '.\n    Find next nearest point.')
                        start_from = -20    # mm
                        for i in range(21):
                            gc_process.delete_fixed_nodes(gc_fixednode)
                            #print(' ** get into loop')
                            with open(point_path, 'r') as f:
                                reader = csv.reader(f)
                                rows = list(reader)
                                if i == 0:
                                    original_x = rows[0][1]
                                    original_y = rows[0][2]
                                    original_z = rows[0][3]
                                if gra_dir == '+X' or gra_dir == '-X':
                                    rows[0][1] = str(float(original_x) + start_from + i*2)
                                elif gra_dir == '+Y' or gra_dir == '-Y':
                                    rows[0][2] = str(float(original_y) + start_from + i*2)
                                elif gra_dir == '+Z' or gra_dir == '-Z':
                                    rows[0][3] = str(float(original_z) + start_from + i*2)
                            with open(point_path, 'w', newline='') as f:
                                writer = csv.writer(f)
                                writer.writerows(rows)
                                #print(' ** write new point', point_num)
                            gc_fixednode = gc_process.new_fixed_nodes(name='GC_FixedNode_' + point_num,
                                                                      fixed_directions=tuple(check_fixture_json[point_num]))
                            gc_fixednode.import_nodes(point_path,
                                                      unit='mm',
                                                      decimal_separator='.',
                                                      field_separator=',',
                                                      search_radius=UnitValueLength(radius, 'mm'))
                            if len(gc_fixednode.nodes) != 0:
                                break
                        if len(gc_fixednode.nodes) == 0:
                            self.message_signal.emit('**Error : Failed to import nodes for point ' + point_num + '.')
                            write_log('VF_gc : Failed to import nodes for point ' + point_num + '.')
                            self.progress_signal.emit(1000)
                            return
        except:
            self.message_signal.emit('**Error : Failed to import check fixture data.')
            write_log('**Error : Failed to import check fixture data.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        gc_project.save()
        self.message_signal.emit('VF_gc : Fixed node set up successfully.')
        write_log('VF_gc : Fixed node set up successfully.')
        self.progress_signal.emit(30)

        # set up SMP and DDM
        gc_process.process_parameters.parallelization.on = True
        gc_process.process_parameters.parallelization.num_domains = ddm
        gc_process.process_parameters.parallelization.num_cores_per_domain = smp
        
        # set the gc calculation parameters
        gc_process.process_parameters.definition.target_deviation = UnitValueLength(target, 'mm')
        gc_process.process_parameters.definition.max_iterations = iteration
        gc_project.save()

        # start the gravity compensation analysis
        if self._stop_requested is True:
            self.message_signal.emit('**Error : Stop requested.')
            write_log('GC : Stop requested.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        
        if not self.parameters['GC_parameters']['simplified_gc']:
            # non-simplified gravity compensation
            try:
                self.message_signal.emit('VF_gc : Starting the gravity compensation analysis. \n   Please wait...')
                write_log('VF_gc : Starting the gravity compensation analysis.')
                self.progress_signal.emit(40)
                self.gc_analysis = gc_process.start_analysis()
                self.gc_analysis.wait()
            except:
                self.message_signal.emit('**Error : Failed to start the gravity compensation analysis.')
                write_log('**Error : Failed to start the gravity compensation analysis.')
                simufact.welding.close_project()
                self.progress_signal.emit(1000)
                return

            # import the result to the catalog
            try:
                gc_result = gc_process.add_gravity_compensated_geometries_to_object_catalog(override_existing=True)[0]
                gc_result.name ='GC_result_geometry'
            except:
                self.message_signal.emit('**Error : Failed to import the gravity compensation to catalog result.')
                write_log('**Error : Failed to import the gravity compensation to catalog result.')
                simufact.welding.close_project()
                self.progress_signal.emit(1000)
                return
            gc_project.save()
            self.message_signal.emit('VF_gc : Gravity compensation result imported to catalog successfully.')
            write_log('VF_gc : Gravity compensation result imported to catalog successfully.')
            self.progress_signal.emit(75)

            gc_result_process = gc_project.new_process(name='Export_gc', process_type='CoolingAndClamping')
            for geometry in gc_project.all_geometries:
                if geometry.name == 'GC_result_geometry':
                    gc_result_process.new_component(name=geometry.name, geometry=geometry)
                    break
        else:
            # simplified gravity compensation
            gc_process.set_process_type(new_process_type = "CoolingAndClamping")

            gravity_vector = gc_process.gravity.vector
            x_gravity = gravity_vector.x * -1
            y_gravity = gravity_vector.y * -1
            z_gravity = gravity_vector.z * -1
            gc_process.gravity.vector = (x_gravity, y_gravity, z_gravity)

            gc_process.process_parameters.time_control.analysis_end_time = 0.4
            gc_process.process_parameters.time_control.set_cooling_time_step_method("FixedManually", 0.1)

            try:
                self.message_signal.emit('VF_gc : Starting simplified gravity compensation analysis. \n   Please wait...')
                write_log('VF_gc : Starting simplified gravity compensation analysis.')
                self.progress_signal.emit(40)
                self.gc_analysis = gc_process.start_analysis()
                self.gc_analysis.wait()
            except:
                self.message_signal.emit('**Error : Failed to start simplified gravity compensation analysis.')
                write_log('**Error : Failed to start simplified gravity compensation analysis.')
                simufact.welding.close_project()
                self.progress_signal.emit(1000)
                return
            
            time.sleep(1)  # wait for the analysis to finish
            gc_result_process = gc_process.copy_from_results(result_step=4)
            gc_result_process.name = 'Export_gc'
            for geometry in gc_project.all_geometries:
                if geometry.name == 'GC_geometry-2':
                    geometry.name = 'GC_result_geometry'
                    break
            for component in gc_result_process.all_components:
                if component.name == 'GC_geometry':
                    component.name = 'GC_result_geometry'
                    break
            
            gc_project.save()

        # ////////////// Export the stl and bdf to Output folder //////////////
        try:
            gc_result_process.export_geometries(gc_output_path, ['GC_result_geometry'], format='stl-bin', unit='mm')
            gc_result_process.export_geometries(gc_output_path, ['GC_result_geometry'], format='bdf-volume', unit='mm')
            self.message_signal.emit('VF_gc : Geometries exported successfully.')
            write_log('VF_gc : Geometries exported successfully.')
            self.progress_signal.emit(80)
            self.check_gc_result()
        except:
            self.message_signal.emit('**Error : Failed to export the geometries.')
            write_log('**Error : Failed to export the geometries.')
            self.progress_signal.emit(1000)
            return
        gc_project.save()
        simufact.welding.close_project()

    def check_gc_result(self):
        # check the VF status after the VF gravity compensation
        # checking whether there are both stl and bdf file in the 2-Outputs\1-GC folder
        stl_file = 'GC_result_geometry.stl'
        stl_found = False
        bdf_file = 'GC_result_geometry.bdf'
        bdf_found = False
        for _, _, files in os.walk(os.path.normpath(os.path.join(self.vf_project_folder, '2-Outputs/1-GC'))):
            for file in files:
                if file == stl_file:
                    stl_found = True
                elif file == bdf_file:
                    bdf_found = True
        if stl_found and bdf_found:
            self.message_signal.emit('VF_gc : VF_gc status ** Complete **')
            self.progress_signal.emit(90)
            self.gc_finished.emit()
        else:
            self.message_signal.emit('**Error : Gravity compensation results are not found.')
            self.progress_signal.emit(1000)
    
    def stop(self):
        self._stop_requested = True
        # stop the GC process
        if self.gc_analysis is not None:
            try:
                self.gc_analysis.stop('immediate')
            except:
                pass


class RPS_helper(QThread):
    message_signal = Signal(str)    # signal for sending the message to the main thread
    progress_signal = Signal(int)   # signal for sending the progress to the main thread
    rps_finished = Signal()    # signal for sending the VF meshing finishing to the main thread

    def __init__(self, vf_project_folder, VF_status, parameters):
        super().__init__()
        self.vf_project_folder = vf_project_folder
        self.VF_status = VF_status
        self.parameters = parameters

        self.rps_analysis = None
        self._stop_requested = False
    
    def run_sw_rps(self):
        # generate log file for the meshing process
        log_file = os.path.normpath(os.path.join(self.vf_project_folder, '1-SWProject', 'RPS.log'))
        if os.path.exists(log_file):
            os.remove(log_file)
        def write_log(message):
            with open(log_file, 'a') as file:
                file.write(message + '\n')

        # Recieve paths and parameters from the main scrip
        rps_output_path = os.path.normpath(os.path.join(self.vf_project_folder, '2-Outputs/2-RPS'))
        rps_input_path = os.path.normpath(os.path.join(self.vf_project_folder, '0-Inputs/1-RPS'))
        hcsv_cad_file = os.path.join(rps_input_path, 'HType_cad_info.csv')
        hcsv_gc_file = os.path.join(rps_input_path, 'HType_distort_info.csv')

        smp = self.parameters["General_parameters"]["smp_cores"]
        self.message_signal.emit('VF_rps : SMP cores --> ' + str(smp))
        write_log('VF_rps : SMP cores --> ' + str(smp))
        ddm = self.parameters["General_parameters"]["ddm_domain"]
        self.message_signal.emit('VF_rps : DDM domain --> ' + str(ddm))
        write_log('VF_rps : DDM domain --> ' + str(ddm))
        fixed_htype = self.parameters["RPS_parameters"]["fixed_htype"]
        self.message_signal.emit('VF_rps : Fixed H-type --> ' + str(fixed_htype))
        write_log('VF_rps : Fixed H-type --> ' + str(fixed_htype))

        # gravity direction
        gc_dict = {
            '+X': (9.81, 0, 0),
            '-X': (-9.81, 0, 0),
            '+Y': (0, 9.81, 0),
            '-Y': (0, -9.81, 0),
            '+Z': (0, 0, 9.81),
            '-Z': (0, 0, -9.81)
        }
        gra_dir = self.parameters["RPS_parameters"]["rps_gravity_direction"]
        if gra_dir not in gc_dict.keys():
            customed_gra_dir = self.parameters['RPS_parameters']['rps_customed_gravity']
        else:
            customed_gra_dir = None

        # ////////////// Functions for calculating the H-type //////////////
        def get_htype_data(cad_file, gc_file):
            htype_dict = {}     # dictionary to store the H-type data
            # {point_name: {"cad_center_m": (x, y, z), "fix_dir": ("x", "y"), "radius_mm": 6.0},
            #               "gc_center_m": (x, y, z)}}
            with open(cad_file, 'r') as f:
                reader = csv.reader(f)
                for row in reader:
                    point_name = str(row[0])
                    coords_m = (float(row[1]) / 1000, float(row[2]) / 1000, float(row[3]) / 1000)   # convert to meters
                    str_dir = point_name.split('-H')
                    fix_dir = tuple(str_dir[-1])
                    radius_mm = float(row[4])   # radius in mm
                    htype_dict[point_name] = {"cad_center_m": coords_m, "fix_dir": fix_dir, "radius_mm": radius_mm}
            
            with open(gc_file, 'r') as f:
                reader = csv.reader(f)
                for row in reader:
                    point_name = str(row[0])
                    coords_m = (float(row[1]) / 1000, float(row[2]) / 1000, float(row[3]) / 1000)   # convert to meters
                    htype_dict[point_name]["gc_center_m"] = coords_m
            
            if len(htype_dict) == 0:
                self.message_signal.emit('**Error : No data was read from the csv files.')
                self.write_log("RPS : No data was read from the csv files.")
                self.progress_signal.emit(1000)
                return
            for key, val in htype_dict.items():
                if len(val) != 4:
                    self.message_signal.emit('**Error : The data was not read correctly from the csv files. or CAD and GC data do not match.')
                    self.write_log("RPS : The data was not read correctly from the csv files. or CAD and GC data do not match.")
                    self.progress_signal.emit(1000)
                    return

            return htype_dict
        
        def modifyhtype_dat_file(dat_file, htype_dict):
            # read the dat file
            with open(dat_file, 'r') as f:
                lines = f.readlines()
            
            # modify the dat file
            keyword = '$ Fixed displacement for virtual pin:'
            lower_limit = 0.00000001
            for key, val in htype_dict.items():
                for line_num, line in enumerate(lines):
                    if keyword in line:
                        vp_name = line.split(':')[-1].strip()
                        if vp_name == key:
                            # Replace the next line from '         1         0         0         0         0'  to '         1         0         0         0         1'
                            lines[line_num + 1].replace('         1         0         0         0         0', 
                                                        '         1         0         0         0         1')
                            dis_x = val['cad_center_m'][0] - val['gc_center_m'][0]
                            dis_y =  val['cad_center_m'][1] - val['gc_center_m'][1]
                            dis_z = val['cad_center_m'][2] - val['gc_center_m'][2]
                            print(vp_name, key)
                            #print(dis_x, dis_y, dis_z)
                            print(val['fix_dir'])
                            if abs(dis_x) < lower_limit:
                                dis_x = f"{lower_limit:.6e}"
                            else:
                                dis_x = f"{dis_x:.6e}"
                            if abs(dis_y) < lower_limit:
                                dis_y = f"{lower_limit:.6e}"
                            else:
                                dis_y = f"{dis_y:.6e}"
                            if abs(dis_z) < lower_limit:
                                dis_z = f"{lower_limit:.6e}"
                            else:
                                dis_z = f"{dis_z:.6e}"
                            print(dis_x, dis_y, dis_z)

                            if val['fix_dir'] == ('x',):
                                lines[line_num + 2] = dis_x + ',\n'
                                lines[line_num + 3] = '33000,\n'
                                lines[line_num + 4] = '         1\n'
                            elif val['fix_dir'] == ('y',):
                                lines[line_num + 2] = dis_y + ',\n'
                                lines[line_num + 3] = '33000,\n'
                                lines[line_num + 4] = '         2\n'
                            elif val['fix_dir'] == ('z',):
                                lines[line_num + 2] = dis_z + ',\n'
                                lines[line_num + 3] = '33000,\n'
                                lines[line_num + 4] = '         3\n'
                            elif val['fix_dir'] == ('x', 'y'):
                                lines[line_num + 2] = dis_x + ',' + dis_y + '\n'
                                lines[line_num + 3] = '33000,33000\n'
                                lines[line_num + 4] = '         1         2\n'
                            elif val['fix_dir'] == ('x', 'z'):
                                lines[line_num + 2] = dis_x + ',' + dis_z + '\n'
                                lines[line_num + 3] = '33000,33000\n'
                                lines[line_num + 4] = '         1         3\n'
                            elif val['fix_dir'] == ('y', 'z'):
                                lines[line_num + 2] = dis_y + ',' + dis_z + '\n'
                                lines[line_num + 3] = '33000,33000\n'
                                lines[line_num + 4] = '         2         3\n'
                            elif val['fix_dir'] == ('x', 'y', 'z'):
                                lines[line_num + 2] = dis_x + ',' + dis_y + ',' + dis_z + '\n'
                                lines[line_num + 3] = '33000,33000,33000\n'
                                lines[line_num + 4] = '         1         2         3\n'
                            print(lines[line_num + 2],
                                lines[line_num + 3],
                                lines[line_num + 4])
                            break

                print(f"Virtual pin {key} was modified successfully.")

            # write the modified dat file
            with open(dat_file, 'w') as f:
                f.writelines(lines)


        # //////////////////////////// RPS process in Simufact Welding ////////////////////////////
        # open the SW project
        sw_project_name = 'Simufact_Project_File'
        try:
            rps_project = simufact.welding.open_project(os.path.join(self.vf_project_folder, '1-SWProject', 
                                                                         sw_project_name, sw_project_name + '.swproj'))
            self.message_signal.emit('VF_rps : Simufact Welding project successfully opened.')
            write_log('VF_rps : Simufact Welding project successfully opened.')
            self.progress_signal.emit(10)
        except Exception as e:
            self.message_signal.emit('**Error : Error opening the SW Project.')
            self.message_signal.emit(str(e))
            write_log('**Error : Error opening the SW Project.')
            write_log(str(e))
            if rps_project:
                simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        rps_project.save()

        # get the H-type data fom csv files
        if os.path.exists(hcsv_cad_file) and os.path.exists(hcsv_gc_file):
            htype_data = get_htype_data(hcsv_cad_file, hcsv_gc_file)
            self.message_signal.emit('VF_rps : Manual H-type data read successfully.')
            write_log('VF_rps : Manual H-type data read successfully.')
        else:
            htype_data = None
            self.message_signal.emit('VF_rps : No manual H-type RPS. Proceed with only the original RPS.')
            write_log('VF_rps : No manual H-type RPS. Proceed with only the original RPS.')

        # process and data cleaning in the SW project
        needed_data = ['CAD_geometry', 'CAD_before_morph', 'Morphed_geometry', 'GC_geometry', 'GC_result_geometry', 'RPS_geometry']
        needed_process = ["Mesher", 'VirtualFixture_GC']
        for process in rps_project.all_processes:
            if process.name not in needed_process:
                rps_project.delete_process(process)
        for geometry in rps_project.all_geometries:
            if geometry.name not in needed_data and 'RPS_geometry' not in geometry.name:
                rps_project.delete_geometry(geometry)
            elif 'RPS_geometry' in geometry.name:
                geometry.name = 'GC_result_geometry'
        rps_project.save()
        self.message_signal.emit('VF_rps : Process and data cleaning is done.')
        write_log('VF_rps : Process and data cleaning is done.')
        self.progress_signal.emit(15)

        # if GC process and GC_result_geometry doesnt exist
        if 'VirtualFixture_GC' not in [process.name for process in rps_project.all_processes]:
            write_log('RPS : No GC process found. RPS will execute Morphed geometry instead.')
            if "Morphed_geometry" in [geometry.name for geometry in rps_project.all_geometries]:
                rps_geometry = rps_project.geometry('Morphed_geometry')
                rps_geometry.name = 'RPS_geometry'
            elif "GC_result_geometry" in [geometry.name for geometry in rps_project.all_geometries]:
                rps_geometry = rps_project.geometry('GC_result_geometry')
                rps_geometry.name = 'RPS_geometry'
        else:
            # change the name of the geometry to RPS_geometry
            try:
                rps_geometry = rps_project.geometry('GC_result_geometry')
                rps_geometry.name = 'RPS_geometry'
            except:
                self.message_signal.emit('**Error : No GC geometry found.')
                write_log('VF_rps : No GC geometry found.')
                self.progress_signal.emit(1000)
                return
        rps_project.save()
        self.message_signal.emit('VF_rps : Geometry name changed successfully.')
        write_log('VF_rps : Geometry name changed successfully.')
        self.progress_signal.emit(20)

        # create a new process for RPS and assign the geometry to the component
        if gra_dir in gc_dict.keys():
            rps_process = rps_project.new_process(name='RPS',
                                                process_type='CoolingAndClamping',
                                                gravity=gc_dict[gra_dir])
        else:
            customed_gra_dir_size = (customed_gra_dir[0]**2 + customed_gra_dir[1]**2 + customed_gra_dir[2]**2)**0.5
            customed_gra_dir_input = (customed_gra_dir[0]/customed_gra_dir_size*9.80665,
                                      customed_gra_dir[1]/customed_gra_dir_size*9.80665,
                                      customed_gra_dir[2]/customed_gra_dir_size*9.80665)
            rps_process = rps_project.new_process(name='RPS',
                                                process_type='CoolingAndClamping',
                                                gravity=customed_gra_dir_input)

        rps_process.set_process_type(new_process_type='CoolingAndClamping',
                                    configurationtype='RPSAlignment')
        for component in rps_process.all_components:
            rps_process.delete_component(component)
        rps_component = rps_process.new_component(name=rps_geometry.name, geometry=rps_geometry)
        rps_component.material = rps_project.all_materials[0]
        rps_component.temperature = rps_project.all_temperatures[0]
        rps_project.save()
        self.message_signal.emit('VF_rps : Process created successfully.')
        write_log('VF_rps : RPS process created successfully.')
        self.progress_signal.emit(30)

        # set smp and ddm parameters and run the simulation
        rps_process.process_parameters.parallelization.on = True
        rps_process.process_parameters.parallelization.num_domains = ddm
        rps_process.process_parameters.parallelization.num_cores_per_domain = smp

        # read the json file and activate/deactivate the RPS points
        rps_control_file = os.path.normpath(os.path.join(rps_input_path, 'RPS_activate.json'))
        if os.path.exists(rps_control_file):
            rpsPoints = rps_process.rps_points

            with open(rps_control_file, 'r') as f:
                rps_control_json = json.load(f)

            try:
                #print('** get into the loop ..')
                for label, data in rps_control_json.items():
                    for rpsPoint in rpsPoints.all_rps_points():
                        #print('{} : {}'.format(label, rpsPoint.label))
                        if rpsPoint.label == label:
                            rpsPoint.active = data['active']
                            self.message_signal.emit(f'VF_rps : RPS point {rpsPoint.label} active --> {rpsPoint.active}.')
                            write_log(f'VF_rps : RPS point {rpsPoint.label} active --> {rpsPoint.active}.')
                            break
            except Exception as e:
                self.message_signal.emit('**Warning : Unable to read the RPS control json file.\n all RPS is activated')
                write_log('**Warning : Unable to read the RPS control json file.')
                write_log(str(e))
                pass

        # set up the Virtual Pins for H-type, based on the data from the csv files
        if htype_data:
            for point_name, point_data in htype_data.items():
                # try creating the virtual pin with edge detection, if failed, create the virtual pin without edge detection
                try:
                    sum_distance_top = 0.0
                    sum_distance_bottom = 0.0
                    # check the distance between center node and all nodes in virtual pin to find the right edge
                    new_vp_top = rps_process.new_virtual_pin_on_hole(center_point=Vector3D(point_data['gc_center_m'], 'm'),
                                                                    fixed_directions=point_data['fix_dir'],
                                                                    node_search_radius=UnitValueLength(point_data['radius_mm']+1.0, 'mm'),
                                                                    side='top')
                    for node in new_vp_top.connected_nodes:
                        dis_x = abs(node[2].x - point_data['gc_center_m'][0])
                        dis_y = abs(node[2].y - point_data['gc_center_m'][1])
                        dis_z = abs(node[2].z - point_data['gc_center_m'][2])
                        sum_distance_top += (dis_x**2 + dis_y**2 + dis_z**2)**0.5

                    new_vp_bottom = rps_process.new_virtual_pin_on_hole(center_point=Vector3D(point_data['gc_center_m'], 'm'),
                                                                        fixed_directions=point_data['fix_dir'],
                                                                        node_search_radius=UnitValueLength(point_data['radius_mm']+1.0, 'mm'),
                                                                        side='bottom')
                    for node in new_vp_bottom.connected_nodes:
                        dis_x = abs(node[2].x - point_data['gc_center_m'][0])
                        dis_y = abs(node[2].y - point_data['gc_center_m'][1])
                        dis_z = abs(node[2].z - point_data['gc_center_m'][2])
                        sum_distance_bottom += (dis_x**2 + dis_y**2 + dis_z**2)**0.5

                    if sum_distance_top > sum_distance_bottom:
                        rps_process.delete_virtual_pin(new_vp_top)
                        new_vp = new_vp_bottom
                    else:
                        rps_process.delete_virtual_pin(new_vp_bottom)
                        new_vp = new_vp_top
                    new_vp.name = point_name
                    print(f'   VF_rps : Virtual pin {point_name} edge detection successfully.')
                    self.message_signal.emit(f'VF_rps : Virtual pin {point_name} edge detection successfully.')
                    write_log(f'VF_rps : Virtual pin {point_name} edge detection successfully.')
                except:
                    new_vp = rps_process.new_virtual_pin(center_point=Vector3D(point_data['gc_center_m'], 'm'),
                                                        fixed_directions=point_data['fix_dir'],
                                                        node_search_radius=UnitValueLength(point_data['radius_mm']+0.5, 'mm'))
                    new_vp.name = point_name
                    print(f'   VF_rps : Virtual pin {point_name} created successfully without auto-detection.')
                    self.message_signal.emit(f'VF_rps : Virtual pin {point_name} created successfully without auto-detection.')
                    write_log(f'VF_rps : Virtual pin {point_name} created successfully without auto-detection.')

            # save the project and write the program input file
            rps_project.save()
            try:
                write_result = rps_process.write_program_input()
            except:
                self.message_signal('**Error : Failed to write the program input file.')
                write_log('**Error : Failed to write the program input file.')
                simufact.welding.close_project()
                self.progress_signal.emit(1000)
                return
            if write_result:
                self.message_signal.emit('VF_rps : Program input file was written successfully.')
                write_log('VF_rps : Program input file was written successfully.')

            # access the dat file and modify the data
            run_folder = os.path.join(rps_process.path, '_RUN_')
            dat_file_path = None
            for file in os.listdir(run_folder):
                if file.endswith('.dat'):
                    dat_file_path = os.path.normpath(os.path.join(run_folder, file))
                    break
            if not dat_file_path:
                self.message_signal.emit('**Error : No dat file found in the run folder.')
                write_log('**Error : No dat file found in the run folder.')
                simufact.welding.close_project()
                self.progress_signal.emit(1000)
                return
            if not fixed_htype:
                modifyhtype_dat_file(dat_file_path, htype_data) # function to modify the dat file
                
        # start the simulation
        if self._stop_requested is True:
            self.message_signal.emit('**Error : Stop requested.')
            write_log('**Error : Stop requested.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return
        try:
            write_log('VF_rps : Starting the RPS analysis.')
            self.message_signal.emit('VF_rps : Starting the RPS analysis.\n   Please wait...')
            self.progress_signal.emit(40)
            self.rps_analysis = rps_process.start_analysis()
            self.rps_analysis.wait()
        except:
            self.message_signal.emit('**Error : Failed to start the RPS analysis')
            write_log('VF_rps : Failed to start the RPS analysis.')
            simufact.welding.close_project()
            self.progress_signal.emit(10000)
            return
        rps_project.save()
        self.message_signal.emit('VF_rps : RPS analysis completed successfully.')
        write_log('VF_rps : RPS calculation completed')
        self.progress_signal.emit(75)

        # check the number of result increments. if > 0 ok
        result_increments = len(rps_process.results)
        write_log(f'VF_rps : Number of result increments found in the RPS process: {result_increments}')
        if result_increments is None or result_increments <= 1:
            self.message_signal.emit('**Error : No result increments found in the RPS process.\n   Please rerun the RPS process.')
            write_log('**Error : No result increments found in the RPS process.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return


        # ////////////// Export the stl and bdf to Output folder //////////////////
        try:
            rps_process.export_geometries(rps_output_path, ['RPS_geometry'], format='stl-bin', unit='mm')
            rps_process.export_geometries(rps_output_path, ['RPS_geometry'], format='bdf-volume', unit='mm')
            self.message_signal.emit('VF_rps : Geometries exported successfully.')
            write_log('VF_rps : Geometries exported successfully.')
            simufact.welding.close_project()
            self.progress_signal.emit(80)
            self.check_rps_result()
        except:
            self.message_signal.emit('**Error : Failed to export the geometries.')
            write_log('**Error : Failed to export the geometries.')
            simufact.welding.close_project()
            self.progress_signal.emit(1000)
            return

    def check_rps_result(self):
        # check the VF status after the VF gravity compensation
        # checking whether there are both stl and bdf file in the 2-Outputs\2-RPS folder
        stl_file = 'RPS_geometry.stl'
        stl_found = False
        bdf_file = 'RPS_geometry.bdf'
        bdf_found = False
        for _, _, files in os.walk(os.path.normpath(os.path.join(self.vf_project_folder, '2-Outputs/2-RPS'))):
            for file in files:
                if file == stl_file:
                    stl_found = True
                elif file == bdf_file:
                    bdf_found = True
        if stl_found and bdf_found:
            self.message_signal.emit('VF_rps : VF_rps status ** Complete **')
            self.progress_signal.emit(90)
            self.rps_finished.emit()
        else:
            self.message_signal.emit('**Error : RPS geometry files not found in the output folder.')
            self.progress_signal.emit(1000)
            return

    def stop(self):
        self._stop_requested = True
        # stop the RPS process
        if self.rps_analysis is not None:
            try:
                self.rps_analysis.stop('immediate')
            except:
                pass




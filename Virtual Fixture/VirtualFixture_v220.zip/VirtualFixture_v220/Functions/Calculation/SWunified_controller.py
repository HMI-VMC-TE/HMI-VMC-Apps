# Import standard modules
import os, json, shutil
import sys
import subprocess
import configparser     # for reading the .ini configuration file

# Import PySide6 modules
from PySide6.QtWidgets import QDialog, QWidget
from PySide6.QtCore import Slot, QThread

# Import custom modules of Simufact process and the progress bar ui
from Functions.Calculation.Simufact_helper import (Simufact_helper, Meshing_helper,
                                                   Morphing_helper, GravityCompensation_helper, 
                                                   RPS_helper)
from Functions.Calculation.UI.ui_VF_progress import Ui_Progress_window


class SWunified_controller:
    def __init__(self, VF_project_folder, parameters, all_paths, status):
        self.VF_project_folder = VF_project_folder

        # initiate the file handler
        self.file_handler = File_handler(self.VF_project_folder)
        
        # load the parameters from the configuration file
        self.parameters = None
        self.load_parameters(parameters)
        self.system_path = None
        self.load_system_path(all_paths)

        # initiate the VF status dictionary
        self.VF_status = None
        self.check_vf_status(status)

    def load_parameters(self, parameters):
        self.parameters = parameters
        print("Unified_controller : Parameters are loaded from the GUI")

    def load_system_path(self, all_paths):
        self.system_path = {
            "SW_Installation_Path": all_paths["SW_Installation_Path"]
        }
        print("Unified_controller : System path is loaded from the GUI")

    def check_vf_status(self, status):
        self.VF_status = {
            "VF_initiation": True,
            "VF_meshing": status["import_data"]["import_geometry"],
            "VF_morphing": status["processing"]["morphing"],
            "VF_gc": status["processing"]["gc"],
            "VF_rps": status["processing"]["rps"]
        }
        print("Unified_controller : VF status is loaded from the GUI")

    # VF initiation
    def VF_initiation(self):
        # delete all the files in the VF project folder except the input files
        self.file_handler.VF_initiation_delete_files()

        # open the VF initiation window
        self.initiation_window = Progress_window(self.system_path, 
                                                 "VF Initiation", 
                                                 self.VF_project_folder, 
                                                 self.VF_status,
                                                 self.parameters)
        self.initiation_window.exec()

    # VF meshing
    def VF_meshing(self):
        #print(self.VF_status)
        # check whether the VF initiation is completed
        if not self.VF_status["VF_initiation"]:
            print("**Error :")
            print("     The VF initiation is not completed")
            print("     Please complete the VF initiation first")
            self.meshing_window = Progress_window(self.system_path,
                                                  "Error",
                                                  self.VF_project_folder,
                                                  self.VF_status,
                                                  self.parameters)
            self.meshing_window.update_message("**Error : The VF initiation is not completed")
            self.meshing_window.update_message("     Please complete the VF initiation first")
            self.meshing_window.update_progressbar(1000)
            self.meshing_window.exec()
            sys.exit()

        # delete all the files in the VF project folder except the input files and simufact project file
        self.file_handler.VF_meshing_delete_files()

        # open the VF meshing window
        self.meshing_window = Progress_window(self.system_path,
                                              "VF Meshing",
                                              self.VF_project_folder,
                                              self.VF_status,
                                              self.parameters)
        self.meshing_window.exec()

    # VF morphing
    def VF_morphing(self):
        if not self.VF_status["VF_meshing"]:
            print("**Error :")
            print("     The VF meshing is not completed")
            print("     Please complete the VF meshing first")
            self.morphing_window = Progress_window(self.system_path,
                                                   "Error",
                                                   self.VF_project_folder,
                                                   self.VF_status,
                                                   self.parameters)
            self.morphing_window.update_message("**Error : The VF meshing is not completed")
            self.morphing_window.update_message("     Please complete the VF meshing first")
            self.morphing_window.update_progressbar(1000)
            self.morphing_window.exec()
            sys.exit()

        # delete all the files in the VF project folder except the input files and simufact project file and meshing output files
        self.file_handler.VF_morphing_delete_files()

        # open the VF morphing window
        self.morphing_window = Progress_window(self.system_path,
                                               "VF Morphing",
                                               self.VF_project_folder,
                                               self.VF_status,
                                               self.parameters)
        self.morphing_window.exec()

    # VF gc
    def VF_gc(self):
        if not self.VF_status["VF_morphing"]:
            print("**Error :")
            print("     The VF morphing is not completed")
            print("     Please complete the VF morphing first")
            self.gc_window = Progress_window(self.system_path,
                                             "Error",
                                             self.VF_project_folder,
                                             self.VF_status,
                                             self.parameters)
            self.gc_window.update_message("**Error : The VF morphing is not completed")
            self.gc_window.update_message("     Please complete the VF morphing first")
            self.gc_window.update_progressbar(1000)
            self.gc_window.exec()
            return
        
        # delete outputs files in the VF project folder except the morphing output files
        self.file_handler.VF_gc_delete_files()

        # open the VF gc window
        self.gc_window = Progress_window(self.system_path,
                                         "VF GC",
                                         self.VF_project_folder,
                                         self.VF_status,
                                         self.parameters)
        self.gc_window.exec()

    # VF rps
    def VF_rps(self):
        if ((self.parameters["General_parameters"]["gc_activation"] and not self.VF_status["VF_gc"]) or
            (not self.parameters["General_parameters"]["gc_activation"] and not self.VF_status["VF_morphing"])):
            print("**Error :")
            print("     The VF gc is not completed or the VF morphing is not completed(GC deactivated)")
            print("     Please complete the VF gc or morphing first")
            self.rps_window = Progress_window(self.system_path,
                                              "Error",
                                              self.VF_project_folder,
                                              self.VF_status,
                                              self.parameters)
            self.rps_window.update_message("**Error : The VF gc is not completed or the VF morphing is not completed(GC deactivated)")
            self.rps_window.update_message("     Please complete the VF gc or morphing first")
            self.rps_window.update_progressbar(1000)
            self.rps_window.exec()
            return
        
        # delete outputs files of the RPS process in the VF project folder
        self.file_handler.VF_rps_delete_files()

        # open the VF rps window
        self.rps_window = Progress_window(self.system_path,
                                          "VF RPS",
                                          self.VF_project_folder,
                                          self.VF_status,
                                          self.parameters)
        self.rps_window.exec()


class File_handler:
    def __init__(self, VF_project_folder):
        self.VF_project_folder = VF_project_folder
    
    def VF_initiation_delete_files(self):
        # delete the all file and folder inside the 1-SWProject folder, but retain the 1-SWProject folder
        swproject_folder = os.path.normpath(os.path.join(self.VF_project_folder, "1-SWProject"))

        if os.path.exists(swproject_folder):
            for root, dirs, files in os.walk(swproject_folder):
                for file in files:
                    os.remove(os.path.join(root, file))
                for dir in dirs:
                    shutil.rmtree(os.path.join(root, dir))

        # delete the output of Morphing, GC and RPS
        output_folder = os.path.normpath(os.path.join(self.VF_project_folder, "2-Outputs"))

        if os.path.exists(output_folder):
            for root, dirs, files in os.walk(output_folder):
                for file in files:
                    if file.endswith(".bdf") or file.endswith(".stl"):
                        os.remove(os.path.join(root, file))

        print("VF_initiation : Delete all existing output in the VF project folder")

    def VF_meshing_delete_files(self):
        # delete the output of Morphing, GC and RPS
        output_folder = os.path.normpath(os.path.join(self.VF_project_folder, "2-Outputs"))

        if os.path.exists(output_folder):
            for root, dirs, files in os.walk(output_folder):
                for file in files:
                    if file.endswith(".bdf") or file.endswith(".stl"):
                        os.remove(os.path.join(root, file))

        print("VF_meshing : Delete all existing output in the VF project folder")

    def VF_morphing_delete_files(self):
        # delete the output of Morphing, GC and RPS
        output_folder = os.path.normpath(os.path.join(self.VF_project_folder, "2-Outputs"))

        if os.path.exists(output_folder):
            for root, dirs, files in os.walk(output_folder):
                for file in files:
                    if file.endswith(".bdf") or file.endswith(".stl"):
                        os.remove(os.path.join(root, file))

        print("VF_morphing : Delete all existing output in the VF project folder")

    def VF_gc_delete_files(self):
        # delete the output of GC and RPS
        output_folder = os.path.normpath(os.path.join(self.VF_project_folder, "2-Outputs"))

        if os.path.exists(output_folder):
            for root, dirs, files in os.walk(output_folder):
                for file in files:
                    if (file.endswith(".bdf") or file.endswith(".stl")) and "Morphing" not in root:
                        os.remove(os.path.join(root, file))

        print("VF_gc : Delete existing output of GC and RPS process in the VF project folder")

    def VF_rps_delete_files(self):
        # delete the output of RPS
        output_folder = os.path.normpath(os.path.join(self.VF_project_folder, "2-Outputs"))

        if os.path.exists(output_folder):
            for root, dirs, files in os.walk(output_folder):
                for file in files:
                    if (file.endswith(".bdf") or file.endswith(".stl")) and "GC" not in root and "Morphing" not in root:
                        os.remove(os.path.join(root, file))

        print("VF_rps : Delete existing output of RPS process in the VF project folder")


class Progress_window(QDialog, Ui_Progress_window):
    def __init__(self, system_path, process_name, VF_project_folder, VF_status, parameters):
        super().__init__()
        self.setupUi(self)

        self.system_path = system_path
        self.process_name = process_name
        self.VF_project_folder = VF_project_folder
        self.VF_status = VF_status
        self.parameters = parameters

        # create the instance helper object
        self.simufact_helper = None
        self.meshing_helper = None
        
        # set the process name of the GUI to process_name and set the progress bar to 0
        self.progress_number = 0
        self.process_progressBar.setValue(self.progress_number)
        self.process_name_label.setText(self.process_name)

        # disable the opensimufact button
        self.opensw_pushButton.setEnabled(False)
        self.opensw_pushButton.clicked.connect(self.open_simufact_software)
        self.close_pushButton.clicked.connect(self.close_window)

        # automatically execute the calculation process right after the window is opened
        if self.process_name == "Error":
            pass
        elif self.process_name == "VF Initiation":
            self.initiation_process()
        elif self.process_name == "VF Meshing":
            self.meshing_process()
        elif self.process_name == "VF Morphing":
            self.morphing_process()
        elif self.process_name == "VF GC":
            self.gc_process()
        elif self.process_name == "VF RPS":
            self.rps_process()

        # variable for the error message
        self.error_message = None
    
    # --------------------------------
    # VF initiation
    # --------------------------------
    def initiation_process(self):
        # initiate the simufact helper object
        self.simufact_helper = Simufact_helper(self.VF_project_folder, self.VF_status)
        self.simufact_helper.progress_signal.connect(self.update_progressbar)
        self.simufact_helper.message_signal.connect(self.update_message)
        self.simufact_helper.initiation_finished.connect(self.after_initiation)

        # create a Qthread object and start the VF initiation process
        self.initiation_thread = QThread()
        self.simufact_helper.moveToThread(self.initiation_thread)
        self.initiation_thread.started.connect(lambda: self.simufact_helper.get_new_sw_project())
        self.initiation_thread.start()
    
    def after_initiation(self):
        self.VF_status = self.simufact_helper.VF_status
        try:
            self.initiation_thread.quit()
            self.initiation_thread.wait()
            self.update_message("VF_initiation : Close the initiation window")
            self.update_progressbar(100)

            # automatically close the initiation window
            self.close()
        except:
            self.update_message("VF_initiation : Error saving the VF status dictionary")
            self.update_progressbar(1000)
            sys.exit()

    # --------------------------------
    # VF meshing
    # --------------------------------
    def meshing_process(self):
        meshing_ini_path = os.path.normpath(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 
                                                             'Settings/advanced_meshing.ini'))
        # initiate the simufact helper object
        self.meshing_helper = Meshing_helper(self.VF_project_folder, self.VF_status, self.parameters, self.system_path, meshing_ini_path)
        self.meshing_helper.progress_signal.connect(self.update_progressbar)
        self.meshing_helper.message_signal.connect(self.update_message)
        self.meshing_helper.meshing_finished.connect(self.after_meshing)

        # create a Qthread object and start the VF meshing process
        self.meshing_thread = QThread()
        self.meshing_helper.moveToThread(self.meshing_thread)
        self.meshing_thread.started.connect(lambda: self.meshing_helper.run_sw_meshing())
        self.meshing_thread.start()
    
    def after_meshing(self):
        self.VF_status = self.meshing_helper.VF_status
        try:
            self.meshing_thread.quit()
            self.meshing_thread.wait()
            self.update_message("VF_meshing : Close the meshing window and proceed to the next step")   
            self.update_progressbar(100)

            # automatically close the meshing window
            # self.close()
        except:
            self.update_message("VF_meshing : Error saving the VF status dictionary")
            self.update_progressbar(1000)
            sys.exit()

    # --------------------------------
    # VF morphing
    # --------------------------------
    def morphing_process(self):
        # initiate the simufact helper object
        self.morphing_helper = Morphing_helper(self.VF_project_folder, self.VF_status, self.parameters)
        self.morphing_helper.progress_signal.connect(self.update_progressbar)
        self.morphing_helper.message_signal.connect(self.update_message)
        self.morphing_helper.morphing_finished.connect(self.after_morphing)

        # create a Qthread object and start the VF morphing process
        self.morphing_thread = QThread()
        self.morphing_helper.moveToThread(self.morphing_thread)
        self.morphing_thread.started.connect(lambda: self.morphing_helper.run_sw_morphing())
        self.morphing_thread.start()

    def after_morphing(self):
        self.VF_status = self.morphing_helper.VF_status
        try:
            self.morphing_thread.quit()
            self.morphing_thread.wait()
            self.update_message("VF_morphing : Close the morphing window and proceed to the next step")
            self.update_progressbar(100)

            # automatically close the morphing window
            #self.close()
        except:
            self.update_message("VF_morphing : Error saving the VF status dictionary")
            self.update_progressbar(1000)
            sys.exit()

    # --------------------------------
    # VF gc
    # --------------------------------
    def gc_process(self):
        # initiate the simufact helper object
        self.gc_helper = GravityCompensation_helper(self.VF_project_folder, self.VF_status, self.parameters)
        self.gc_helper.progress_signal.connect(self.update_progressbar)
        self.gc_helper.message_signal.connect(self.update_message)
        self.gc_helper.gc_finished.connect(self.after_gc)

        # create a Qthread object and start the VF gc process
        self.gc_thread = QThread()
        self.gc_helper.moveToThread(self.gc_thread)
        self.gc_thread.started.connect(lambda: self.gc_helper.run_sw_gc())
        self.gc_thread.start()

    def after_gc(self):
        self.VF_status = self.gc_helper.VF_status
        try:
            self.gc_thread.quit()
            self.gc_thread.wait()
            self.update_message("VF_gc : Close the GC window and proceed to the next step")
            self.update_progressbar(100)

            # automatically close the gc window
            #self.close()
        except:
            self.update_message("VF_gc : Error saving the VF status dictionary")
            self.update_progressbar(1000)
            sys.exit()

    # --------------------------------
    # VF rps
    # --------------------------------
    def rps_process(self):
        # initiate the simufact helper object
        self.rps_helper = RPS_helper(self.VF_project_folder, self.VF_status, self.parameters)
        self.rps_helper.progress_signal.connect(self.update_progressbar)
        self.rps_helper.message_signal.connect(self.update_message)
        self.rps_helper.rps_finished.connect(self.after_rps)

        # create a Qthread object and start the VF rps process
        self.rps_thread = QThread()
        self.rps_helper.moveToThread(self.rps_thread)
        self.rps_thread.started.connect(lambda: self.rps_helper.run_sw_rps())
        self.rps_thread.start()
    
    def after_rps(self):
        self.VF_status = self.rps_helper.VF_status
        try:
            self.rps_thread.quit()
            self.rps_thread.wait()
            self.update_message("VF_rps : Close the RPS window")
            self.update_progressbar(100)

            # automatically close the rps window
            #self.close()
        except:
            self.update_message("VF_rps : Error saving the VF status dictionary")
            self.update_progressbar(1000)
            sys.exit()

    # --------------------------------
    # GUI functions
    # --------------------------------
    def close_window(self):
        # kill the thread
        if self.process_name == "VF Initiation":
            self.initiation_thread.quit()
            self.initiation_thread.wait()
        elif self.process_name == "VF Meshing":
            self.meshing_thread.quit()
            self.meshing_thread.wait()
        elif self.process_name == "VF Morphing":
            self.morphing_thread.quit()
            self.morphing_thread.wait()
        elif self.process_name == "VF GC":
            if hasattr(self, 'gc_helper'):
                self.gc_helper.stop()
            self.gc_thread.quit()
            self.gc_thread.wait()
        elif self.process_name == "VF RPS":
            if hasattr(self, 'rps_helper'):
                self.rps_helper.stop()
            self.rps_thread.quit()
            self.rps_thread.wait()
        if self.error_message is not None:
            print(self.error_message)
        self.close()

    @Slot(int)
    def update_progressbar(self, progress_number):
        if progress_number < 100:
            self.process_progressBar.setValue(progress_number)
            self.process_progressBar.setStyleSheet(u"QProgressBar {\n"
            "    border: 2px solid #444;\n"
            "    border-radius: 5px;\n"
            "    background-color: #222;\n"
            "    text-align: center;\n"
            "    font: bold 10pt \"Segoe UI\";\n"
            "    color: #ddd;\n"
            "}\n"
            "\n"
            "QProgressBar::chunk {\n"
            "    background-color: #29a3ef; /* Bright blue progress color */\n"
            "    border-radius: 5px;\n"
            "}")
        if progress_number == 100:
            self.process_progressBar.setValue(progress_number)
            self.process_progressBar.setStyleSheet(u"QProgressBar {\n"
            "    border: 2px solid #444;\n"
            "    border-radius: 5px;\n"
            "    background-color: #222;\n"
            "    text-align: center;\n"
            "    font: bold 10pt \"Segoe UI\";\n"
            "    color: #ddd;\n"
            "}\n"
            "\n"
            "QProgressBar::chunk {\n"
            "    background-color: #00aa00; /* Bright green progress color */\n"
            "    border-radius: 5px;\n"
            "}")
            # enable the opensimufact button
            self.opensw_pushButton.setEnabled(True)
        if progress_number > 100:
            self.process_progressBar.setStyleSheet(u"QProgressBar {\n"
            "    border: 2px solid #444;\n"
            "    border-radius: 5px;\n"
            "    background-color: #222;\n"
            "    text-align: center;\n"
            "    font: bold 10pt \"Segoe UI\";\n"
            "    color: #ddd;\n"
            "}\n"
            "\n"
            "QProgressBar::chunk {\n"
            "    background-color: #ff5500; /* Bright red progress color */\n"
            "    border-radius: 5px;\n"
            "}")
            # enable the opensimufact button
            self.opensw_pushButton.setEnabled(True)
            # kill the thread
            if self.process_name == "VF Initiation":
                self.initiation_thread.quit()
                self.initiation_thread.wait()
            elif self.process_name == "VF Meshing":
                self.meshing_thread.quit()
                self.meshing_thread.wait()
            elif self.process_name == "VF Morphing":
                self.morphing_thread.quit()
                self.morphing_thread.wait()
            elif self.process_name == "VF GC":
                self.gc_thread.quit()
                self.gc_thread.wait()
            elif self.process_name == "VF RPS":
                self.rps_thread.quit()
                self.rps_thread.wait()

            # enable the opensimufact button
            self.opensw_pushButton.setEnabled(True)

    @Slot(str)
    def update_message(self, message):
        self.textEdit.append(message)
        if "**Error :" in message:
            print(message)
            self.error_message = message
        elif "** Complete **" in message:
            print(message)

    def open_simufact_software(self):
        sw_project_file = os.path.normpath(os.path.join(self.VF_project_folder, '1-SWProject',
                                                        "Simufact_Project_File/Simufact_Project_File.swproj"))
        if not os.path.exists(sw_project_file):
            self.update_message("**Error : The SW project file does not exist in the VF project folder.")
            return

        # open the Simufact Welding software
        try:
            simufact_path = os.path.normpath(os.path.join(self.system_path["SW_Installation_Path"], "bin/simufact.welding.exe"))
            process = subprocess.Popen([simufact_path, sw_project_file])
            process.wait()
        except Exception as e:
            self.update_message("**Error : Error opening the Simufact Welding software.")
            self.update_message(f"     {e}")
            return
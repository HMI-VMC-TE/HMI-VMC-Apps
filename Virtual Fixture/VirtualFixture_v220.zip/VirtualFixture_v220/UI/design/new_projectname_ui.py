# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'new_projectname.ui'
##
## Created by: Qt User Interface Compiler version 6.5.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel,
    QPlainTextEdit, QPushButton, QSizePolicy, QSpacerItem,
    QVBoxLayout, QWidget)
import resources_rc

class Ui_NewProjectWindow(object):
    def setupUi(self, NewProjectWindow):
        if not NewProjectWindow.objectName():
            NewProjectWindow.setObjectName(u"NewProjectWindow")
        NewProjectWindow.resize(510, 150)
        NewProjectWindow.setMinimumSize(QSize(350, 150))
        NewProjectWindow.setStyleSheet(u"background-color: rgb(61, 61, 61);")
        self.verticalLayout_3 = QVBoxLayout(NewProjectWindow)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(5, 5, 5, 5)
        self.message_label = QLabel(NewProjectWindow)
        self.message_label.setObjectName(u"message_label")
        self.message_label.setMinimumSize(QSize(0, 28))
        self.message_label.setMaximumSize(QSize(16777215, 28))
        font = QFont()
        font.setFamilies([u"Segoe UI"])
        font.setPointSize(16)
        font.setBold(True)
        font.setItalic(True)
        self.message_label.setFont(font)
        self.message_label.setStyleSheet(u"font: 700 italic 16pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.message_label.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.verticalLayout_3.addWidget(self.message_label)

        self.message_label_2 = QLabel(NewProjectWindow)
        self.message_label_2.setObjectName(u"message_label_2")
        self.message_label_2.setMinimumSize(QSize(0, 21))
        self.message_label_2.setMaximumSize(QSize(16777215, 21))
        self.message_label_2.setStyleSheet(u"font: 700 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.message_label_2.setAlignment(Qt.AlignBottom|Qt.AlignLeading|Qt.AlignLeft)

        self.verticalLayout_3.addWidget(self.message_label_2)

        self.projectname_plainTextEdit = QPlainTextEdit(NewProjectWindow)
        self.projectname_plainTextEdit.setObjectName(u"projectname_plainTextEdit")
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.projectname_plainTextEdit.sizePolicy().hasHeightForWidth())
        self.projectname_plainTextEdit.setSizePolicy(sizePolicy)
        self.projectname_plainTextEdit.setMinimumSize(QSize(500, 29))
        self.projectname_plainTextEdit.setMaximumSize(QSize(16777215, 29))
        self.projectname_plainTextEdit.setStyleSheet(u"QPlainTextEdit {\n"
"    background-color: #1d1d1d; /* Modern dark background */\n"
"    color: white; /* Soft, modern text color */\n"
"    border: 1px solid grey; /* Slightly lighter border */\n"
"    border-radius: 6px; /* Rounded corners */\n"
"    font-family: \"Fira Code\", Consolas, \"Courier New\", monospace; /* Modern programming font */\n"
"    font-size: 10pt; /* Larger, cleaner font size */\n"
"    selection-background-color: #3e4451; /* Subtle highlight background */\n"
"    selection-color: #ffffff; /* Bright highlight text */\n"
"}\n"
"")

        self.verticalLayout_3.addWidget(self.projectname_plainTextEdit)

        self.horizontalWidget = QWidget(NewProjectWindow)
        self.horizontalWidget.setObjectName(u"horizontalWidget")
        self.horizontalWidget.setMinimumSize(QSize(0, 50))
        self.horizontalWidget.setMaximumSize(QSize(16777215, 50))
        self.horizontalLayout_2 = QHBoxLayout(self.horizontalWidget)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(1, 1, 1, 6)
        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_2)

        self.ok_pushButton = QPushButton(self.horizontalWidget)
        self.ok_pushButton.setObjectName(u"ok_pushButton")
        self.ok_pushButton.setMinimumSize(QSize(100, 30))
        self.ok_pushButton.setMaximumSize(QSize(100, 30))
        self.ok_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_2.addWidget(self.ok_pushButton)


        self.verticalLayout_3.addWidget(self.horizontalWidget)


        self.retranslateUi(NewProjectWindow)
        self.ok_pushButton.clicked.connect(NewProjectWindow.close)

        QMetaObject.connectSlotsByName(NewProjectWindow)
    # setupUi

    def retranslateUi(self, NewProjectWindow):
        NewProjectWindow.setWindowTitle(QCoreApplication.translate("NewProjectWindow", u"System path selection window", None))
        self.message_label.setText(QCoreApplication.translate("NewProjectWindow", u"New project  ", None))
        self.message_label_2.setText(QCoreApplication.translate("NewProjectWindow", u"Input your preferred VF project name", None))
        self.projectname_plainTextEdit.setPlainText(QCoreApplication.translate("NewProjectWindow", u"...", None))
        self.ok_pushButton.setText(QCoreApplication.translate("NewProjectWindow", u"OK", None))
    # retranslateUi


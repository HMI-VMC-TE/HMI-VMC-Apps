# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'message.ui'
##
## Created by: Qt User Interface Compiler version 6.5.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QLabel, QMainWindow, QPushButton,
    QSizePolicy, QVBoxLayout, QWidget)

class Ui_MessageWindow(object):
    def setupUi(self, MessageWindow):
        if not MessageWindow.objectName():
            MessageWindow.setObjectName(u"MessageWindow")
        MessageWindow.resize(350, 150)
        MessageWindow.setMinimumSize(QSize(350, 150))
        MessageWindow.setMaximumSize(QSize(350, 150))
        MessageWindow.setLayoutDirection(Qt.RightToLeft)
        self.centralwidget = QWidget(MessageWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralwidget.setMinimumSize(QSize(350, 150))
        self.centralwidget.setMaximumSize(QSize(350, 150))
        self.centralwidget.setStyleSheet(u"background-color: rgb(61, 61, 61);")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.message_label = QLabel(self.centralwidget)
        self.message_label.setObjectName(u"message_label")
        self.message_label.setStyleSheet(u"font: 700 italic 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.message_label.setAlignment(Qt.AlignCenter)

        self.verticalLayout.addWidget(self.message_label)

        self.close_pushButton = QPushButton(self.centralwidget)
        self.close_pushButton.setObjectName(u"close_pushButton")
        self.close_pushButton.setMinimumSize(QSize(100, 30))
        self.close_pushButton.setMaximumSize(QSize(100, 30))
        self.close_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.verticalLayout.addWidget(self.close_pushButton)

        MessageWindow.setCentralWidget(self.centralwidget)
#if QT_CONFIG(shortcut)
        self.message_label.setBuddy(self.close_pushButton)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(MessageWindow)
        self.close_pushButton.clicked.connect(MessageWindow.close)

        QMetaObject.connectSlotsByName(MessageWindow)
    # setupUi

    def retranslateUi(self, MessageWindow):
        MessageWindow.setWindowTitle(QCoreApplication.translate("MessageWindow", u"Message box", None))
        self.message_label.setText(QCoreApplication.translate("MessageWindow", u"TextLabel", None))
        self.close_pushButton.setText(QCoreApplication.translate("MessageWindow", u"Close", None))
    # retranslateUi


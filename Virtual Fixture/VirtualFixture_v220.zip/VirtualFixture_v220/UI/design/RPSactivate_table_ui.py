# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'RPSactivate_table.ui'
##
## Created by: Qt User Interface Compiler version 6.5.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDialog, QHBoxLayout, QHeaderView,
    QLabel, QPushButton, QSizePolicy, QSpacerItem,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)
import resources_rc

class Ui_RPSActivateWindow(object):
    def setupUi(self, RPSActivateWindow):
        if not RPSActivateWindow.objectName():
            RPSActivateWindow.setObjectName(u"RPSActivateWindow")
        RPSActivateWindow.resize(580, 400)
        RPSActivateWindow.setMinimumSize(QSize(580, 320))
        RPSActivateWindow.setLayoutDirection(Qt.LeftToRight)
        RPSActivateWindow.setAutoFillBackground(False)
        RPSActivateWindow.setStyleSheet(u"background-color: rgb(61, 61, 61);")
        RPSActivateWindow.setSizeGripEnabled(False)
        RPSActivateWindow.setModal(False)
        self.verticalLayout_3 = QVBoxLayout(RPSActivateWindow)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(5, 5, 5, 5)
        self.message_label = QLabel(RPSActivateWindow)
        self.message_label.setObjectName(u"message_label")
        self.message_label.setMinimumSize(QSize(0, 28))
        self.message_label.setMaximumSize(QSize(16777215, 28))
        self.message_label.setStyleSheet(u"font: 700 italic 10pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.message_label.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)

        self.verticalLayout_3.addWidget(self.message_label)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setSpacing(0)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.tableWidget = QTableWidget(RPSActivateWindow)
        if (self.tableWidget.columnCount() < 4):
            self.tableWidget.setColumnCount(4)
        __qtablewidgetitem = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        font = QFont()
        font.setPointSize(10)
        __qtablewidgetitem1 = QTableWidgetItem()
        __qtablewidgetitem1.setFont(font);
        self.tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        __qtablewidgetitem3.setFont(font);
        self.tableWidget.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        self.tableWidget.setObjectName(u"tableWidget")
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.tableWidget.sizePolicy().hasHeightForWidth())
        self.tableWidget.setSizePolicy(sizePolicy)
        font1 = QFont()
        font1.setPointSize(12)
        font1.setBold(False)
        self.tableWidget.setFont(font1)
        self.tableWidget.setStyleSheet(u"QTableWidget::item { color: white; }")

        self.horizontalLayout_3.addWidget(self.tableWidget)


        self.verticalLayout_3.addLayout(self.horizontalLayout_3)

        self.horizontalWidget = QWidget(RPSActivateWindow)
        self.horizontalWidget.setObjectName(u"horizontalWidget")
        self.horizontalWidget.setMinimumSize(QSize(0, 50))
        self.horizontalWidget.setMaximumSize(QSize(16777215, 50))
        self.horizontalLayout_2 = QHBoxLayout(self.horizontalWidget)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(1, 1, 1, 6)
        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_2)

        self.set_pushButton = QPushButton(self.horizontalWidget)
        self.set_pushButton.setObjectName(u"set_pushButton")
        self.set_pushButton.setMinimumSize(QSize(100, 30))
        self.set_pushButton.setMaximumSize(QSize(100, 30))
        self.set_pushButton.setStyleSheet(u"QPushButton {\n"
"    background-color: #2d2d2d;\n"
"    color: rgb(255, 255, 255);\n"
"    border: 2px solid #6d6d6d;\n"
"    border-radius: 6px;\n"
"    font: bold 14px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #434C5E;\n"
"    border: 2px solid #81A1C1;\n"
"    color: #ECEFF4;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #3B4252;\n"
"    border: 2px solid #88C0D0;\n"
"    color: #D8DEE9;\n"
"}")

        self.horizontalLayout_2.addWidget(self.set_pushButton)


        self.verticalLayout_3.addWidget(self.horizontalWidget)


        self.retranslateUi(RPSActivateWindow)

        QMetaObject.connectSlotsByName(RPSActivateWindow)
    # setupUi

    def retranslateUi(self, RPSActivateWindow):
        RPSActivateWindow.setWindowTitle(QCoreApplication.translate("RPSActivateWindow", u"RPS Activate/Offset window", None))
        self.message_label.setText(QCoreApplication.translate("RPSActivateWindow", u"RPS point activation", None))
        ___qtablewidgetitem = self.tableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("RPSActivateWindow", u"Activation", None));
        ___qtablewidgetitem1 = self.tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("RPSActivateWindow", u"Name/Label", None));
        ___qtablewidgetitem2 = self.tableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("RPSActivateWindow", u"Fixed direction", None));
        ___qtablewidgetitem3 = self.tableWidget.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("RPSActivateWindow", u"Offset (mm)", None));
        self.set_pushButton.setText(QCoreApplication.translate("RPSActivateWindow", u"Proceed", None))
    # retranslateUi

